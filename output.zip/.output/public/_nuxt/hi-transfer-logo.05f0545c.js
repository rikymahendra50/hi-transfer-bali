import"./entry.26166356.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
