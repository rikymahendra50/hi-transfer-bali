import{l as e}from"./entry.26166356.js";import{N as r,M as t}from"./swiper-vue.f9dac270.js";const c={};function o(n,a){return t(),r("div")}const f=e(c,[["render",o]]);export{f as default};
