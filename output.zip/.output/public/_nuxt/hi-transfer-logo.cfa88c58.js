import"./entry.add2d68d.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
