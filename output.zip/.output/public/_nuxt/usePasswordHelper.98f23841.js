import{a as o}from"./swiper-vue.fb38f7cd.js";function t(){const e=o("password");function s(){e.value=e.value=="password"?"text":"password"}return{inputType:e,toggleInputType:s}}export{t as u};
