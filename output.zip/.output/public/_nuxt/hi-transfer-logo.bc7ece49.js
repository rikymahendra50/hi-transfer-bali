import"./entry.805b3f31.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
