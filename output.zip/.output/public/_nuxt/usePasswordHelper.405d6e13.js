import{a as o}from"./swiper-vue.a2ec9d3a.js";function t(){const e=o("password");function s(){e.value=e.value=="password"?"text":"password"}return{inputType:e,toggleInputType:s}}export{t as u};
