import{l as e}from"./entry.d8fd5a2c.js";import{N as t,M as r}from"./swiper-vue.a2ec9d3a.js";const c={};function o(n,s){return r(),t("p",null,"test")}const l=e(c,[["render",o]]);export{l as default};
