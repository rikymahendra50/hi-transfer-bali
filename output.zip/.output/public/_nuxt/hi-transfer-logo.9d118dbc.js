import"./entry.9bb197db.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
