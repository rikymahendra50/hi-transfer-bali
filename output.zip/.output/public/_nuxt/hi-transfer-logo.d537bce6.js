import"./entry.c1a18b99.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
