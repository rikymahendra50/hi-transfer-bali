import{l as e}from"./entry.d37566ec.js";import{N as t,M as r}from"./swiper-vue.fb38f7cd.js";const c={};function o(n,s){return r(),t("p",null,"test")}const l=e(c,[["render",o]]);export{l as default};
