import"./entry.ab20f7f6.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
