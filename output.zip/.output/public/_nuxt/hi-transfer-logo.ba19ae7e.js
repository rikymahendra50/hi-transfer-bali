import"./entry.50c1c574.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
