import"./entry.9758db16.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
