import{a as o}from"./swiper-vue.1a5beda2.js";function t(){const e=o("password");function s(){e.value=e.value=="password"?"text":"password"}return{inputType:e,toggleInputType:s}}export{t as u};
