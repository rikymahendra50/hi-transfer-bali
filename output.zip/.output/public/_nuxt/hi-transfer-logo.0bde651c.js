import"./entry.3eb9288e.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
