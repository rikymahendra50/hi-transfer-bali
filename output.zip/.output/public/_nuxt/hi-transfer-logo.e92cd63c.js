import"./entry.bcb5f6aa.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
