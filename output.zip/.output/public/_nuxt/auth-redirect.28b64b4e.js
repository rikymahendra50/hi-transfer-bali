import{d as e}from"./entry.6a0989d5.js";import{N as r,M as t}from"./swiper-vue.2b8caf10.js";const c={};function o(n,a){return t(),r("div")}const f=e(c,[["render",o]]);export{f as default};
