import"./entry.4413a6b8.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
