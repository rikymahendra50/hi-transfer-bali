import"./entry.ec8e158a.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
