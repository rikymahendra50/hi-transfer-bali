import"./entry.1b04c808.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
