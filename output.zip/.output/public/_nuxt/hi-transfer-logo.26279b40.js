import"./entry.d8fca11f.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
