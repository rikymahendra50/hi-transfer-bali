import"./entry.4d916ba8.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
