import"./entry.6d5aed04.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
