import"./entry.6be34b0f.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
