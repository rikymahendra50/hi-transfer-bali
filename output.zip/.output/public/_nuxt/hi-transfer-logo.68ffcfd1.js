import"./entry.c0e1074e.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
