import"./entry.70cdaf49.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
