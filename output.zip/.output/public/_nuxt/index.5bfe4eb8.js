import{m as e,N as n,M as t}from"./swiper-vue.2b8caf10.js";const s=e({__name:"index",setup(o){return(a,r)=>(t(),n("div"))}});export{s as default};
