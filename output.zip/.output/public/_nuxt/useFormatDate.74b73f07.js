const e=()=>({formatDate:t=>new Date(t).toLocaleDateString("en-GB",{day:"numeric",month:"long",year:"numeric"})}),n=e;export{n as u};
