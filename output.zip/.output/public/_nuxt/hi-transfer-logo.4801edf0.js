import"./entry.a48f6f3f.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
