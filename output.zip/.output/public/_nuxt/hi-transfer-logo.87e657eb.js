import"./entry.d8fd5a2c.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
