import"./entry.0b1cefd5.js";const o=""+globalThis.__publicAssetsURL("hi-transfer-logo.png");export{o as _};
