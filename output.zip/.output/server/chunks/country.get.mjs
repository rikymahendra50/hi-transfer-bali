import { a as defineEventHandler } from './nitro/node-server.mjs';
import fs from 'fs';
import path from 'path';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'ipx';

const country_get = defineEventHandler(async (event) => {
  return await fs.readFileSync(
    path.join(process.cwd(), "/data", "country.json")
  );
});

export { country_get as default };
//# sourceMappingURL=country.get.mjs.map
