import { _ as __nuxt_component_0 } from './Container-f78810bd.mjs';
import { _ as _sfc_main$2 } from './Btn-577fa59f.mjs';
import __nuxt_component_0$1 from './Icon-0f6314e3.mjs';
import { _ as _sfc_main$3 } from './AddressInformation-3373b627.mjs';
import { _ as _sfc_main$4 } from './MGroup-e711cd83.mjs';
import { _ as _sfc_main$5 } from './MSelect-8e6f95b5.mjs';
import { ref, watch, withCtx, unref, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, createCommentVNode, Fragment, renderList, useSSRContext, mergeProps } from 'vue';
import { h as useRequestHelper, e as useRequestOptions, b as useRouter, d as useRoute, f as useI18n, a as useHead, g as useAsyncData } from '../server.mjs';
import { u as useTourForm } from './useCarStore-b76cd9f9.mjs';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttrs, ssrRenderAttr } from 'vue/server-renderer';
import { _ as __nuxt_component_7 } from './Empty-bbf16402.mjs';
import 'clsx';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './TransitionX-601819e8.mjs';
import 'vee-validate';
import './nofication-1c3cca5e.mjs';

const _sfc_main$1 = {
  __name: "Card",
  __ssrInlineRender: true,
  props: {
    id: {
      type: [String, Number]
    },
    name: {
      type: String
    },
    price: {
      type: [String, Number]
    },
    image: {
      type: String
    },
    facilities: {
      type: [Array, Object]
    },
    maxPerson: {
      type: [String, Number]
    }
  },
  setup(__props) {
    const props = __props;
    const router = useRouter();
    const { locale, t: $t } = useI18n();
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedCarData,
      clearSavedCarData
    } = useTourForm({
      callback: () => {
        console.log("Form has been submitted!");
      }
    });
    function goToVehicleBooking(id, image, price, facilities, name) {
      dataForm.value.car_id = id;
      dataForm.value.name_car = name;
      dataForm.value.image = image;
      dataForm.value.total_price = price;
      dataForm.value.facilities = facilities;
      saveFormData();
      router.push("/vehicles/booking");
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_Icon = __nuxt_component_0$1;
      const _component_UIBtn = _sfc_main$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "border rounded-xl p-4 hover:border-primary hover:shadow shadow-primary" }, _attrs))}><div class="grid grid-cols-[100px_1fr] lg:grid-cols-[150px_1fr] gap-4"><div><div class="border rounded-xl overflow-hidden max-h-max"><img${ssrRenderAttr("src", __props.image)}${ssrRenderAttr("alt", __props.image)} class="w-full h-[100px] xl:h-[150px] object-cover"></div></div><div class="grid grid-cols-1 xl:grid-cols-[1fr_170px] gap-6"><div class="space-y-2 border-0 xl:border-r"><h4 class="text-xl lg:text-2xl font-semibold">${ssrInterpolate(__props.name)}</h4><div class="grid grid-cols-1 md:grid-cols-2 gap-1 lg:p-4"><div class="inline-flex space-x-1 items-center">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "i-heroicons-users",
        class: "w-6 h-6 text-primary"
      }, null, _parent));
      _push(`<div class="text-zinc-400 text-sm whitespace-nowrap">${ssrInterpolate(unref($t)("menampilkan-number-penumpang", {
        number: __props.maxPerson
      }))}</div></div><!--[-->`);
      ssrRenderList(__props.facilities, (item) => {
        _push(`<div class="inline-flex space-x-1 items-center"><img${ssrRenderAttr("src", item.image)}${ssrRenderAttr("alt", item.image)} class="w-6 h-6"><div class="text-zinc-400 text-sm whitespace-nowrap">${ssrInterpolate(item.description)}</div></div>`);
      });
      _push(`<!--]--></div></div><div class="flex flex-col justify-between space-y-4"><h4 class="text-xl font-semibold text-primary xl:text-right">${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(
        (_a = props == null ? void 0 : props.price) == null ? void 0 : _a.toString(),
        unref(locale) == "id" ? "IDR" : "usd"
      ))}</h4><div>`);
      _push(ssrRenderComponent(_component_UIBtn, {
        onClick: ($event) => goToVehicleBooking(__props.id, __props.image, __props.price, __props.facilities, __props.name),
        variant: "primary",
        outlined: "",
        class: "w-full"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(unref($t)("order-sekarang"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(unref($t)("order-sekarang")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vehicle/Card.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main$1;
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    useRoute();
    const { locale, t: $t } = useI18n();
    const selectedDistance = ref("");
    const selectedPassenger = ref("");
    ref("");
    const apiData = ref();
    const totalData = ref();
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedCarData,
      clearSavedCarData
    } = useTourForm({
      callback: () => {
        console.log("Form has been submitted!");
      }
    });
    const filter = ref({
      sort: ""
    });
    watch([() => selectedDistance, selectedPassenger], (newValues, oldValues) => {
      if (newValues !== oldValues) {
        replaceWindow();
      }
    });
    watch(
      () => filter.value.sort,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          replaceWindow();
        }
      }
    );
    const fetchData = async () => {
      var _a;
      const { data, error, refresh } = await useAsyncData(
        "cars",
        () => $fetch(
          `/cars?sort=${filter.value.sort}&filter[passenger_count]=${selectedPassenger.value}&filter[distance]=${selectedDistance.value}&lang=${locale.value}`,
          {
            headers: {
              Accept: "application/json"
            },
            method: "get",
            ...requestOptions
          }
        )
      );
      apiData.value = data.value;
      totalData.value = (_a = data == null ? void 0 : data.value.meta) == null ? void 0 : _a.total;
    };
    function replaceWindow() {
      let filters = [];
      if (filter.value.sort) {
        filters.push(`sort=${filter.value.sort}`);
      }
      const queryString = filters.join("&");
      const url = `/vehicles?${queryString ? `${queryString}` : ""}`;
      fetchData();
      router.replace(url);
    }
    function goToHomePage() {
      clearSavedCarData();
      router.push({ path: "/?cars" });
    }
    useHead({
      title: "Vehicle",
      meta: [
        {
          name: "description",
          content: "Safe and Comfortable Transfer in Bali. A fleet of modern vehicles and experienced drivers are ready to take you wherever you want."
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_UIBtn = _sfc_main$2;
      const _component_Icon = __nuxt_component_0$1;
      const _component_VehicleAddressInformation = _sfc_main$3;
      const _component_UIFormMGroup = _sfc_main$4;
      const _component_UIFormMSelect = _sfc_main$5;
      const _component_VehicleCard = __nuxt_component_6;
      const _component_Empty = __nuxt_component_7;
      _push(`<!--[--><div class="h-44 sm:h-28"></div><div class="w-full border-b">`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              onClick: ($event) => goToHomePage(),
              variant: "primary",
              outlined: "",
              class: "whitespace-nowrap"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref($t)("kembali-ke-beranda"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref($t)("kembali-ke-beranda")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
            if (unref(dataForm).location_pickup_name || unref(dataForm).location_return_name) {
              _push2(`<div class="w-full flex flex-col gap-2"${_scopeId}><div class="flex flex-col lg:flex-row space-y-1 lg:space-y-0 lg:space-x-4 text-lg 2xl:text-xl font-semibold"${_scopeId}><div class="text-start"${_scopeId}>${ssrInterpolate(unref(dataForm).location_pickup_name)}</div><div class="hidden lg:block text-center"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, {
                name: "i-heroicons-arrow-right",
                class: "w-4 h-4"
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="block lg:hidden text-center"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, {
                name: "i-heroicons-arrow-down",
                class: "w-4 h-4"
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="text-start"${_scopeId}>${ssrInterpolate(unref(dataForm).location_return_name)}</div></div><div class="text-zinc-400 text-sm whitespace-nowrap text-center lg:text-left"${_scopeId}>${ssrInterpolate(unref(dataForm).pickup_date)} \xA0 | \xA0 ${ssrInterpolate(unref(dataForm).passengers)} ${ssrInterpolate(unref($t)("penumpang"))}</div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full" }, [
                createVNode("div", null, [
                  createVNode(_component_UIBtn, {
                    onClick: ($event) => goToHomePage(),
                    variant: "primary",
                    outlined: "",
                    class: "whitespace-nowrap"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref($t)("kembali-ke-beranda")), 1)
                    ]),
                    _: 1
                  }, 8, ["onClick"])
                ]),
                unref(dataForm).location_pickup_name || unref(dataForm).location_return_name ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "w-full flex flex-col gap-2"
                }, [
                  createVNode("div", { class: "flex flex-col lg:flex-row space-y-1 lg:space-y-0 lg:space-x-4 text-lg 2xl:text-xl font-semibold" }, [
                    createVNode("div", { class: "text-start" }, toDisplayString(unref(dataForm).location_pickup_name), 1),
                    createVNode("div", { class: "hidden lg:block text-center" }, [
                      createVNode(_component_Icon, {
                        name: "i-heroicons-arrow-right",
                        class: "w-4 h-4"
                      })
                    ]),
                    createVNode("div", { class: "block lg:hidden text-center" }, [
                      createVNode(_component_Icon, {
                        name: "i-heroicons-arrow-down",
                        class: "w-4 h-4"
                      })
                    ]),
                    createVNode("div", { class: "text-start" }, toDisplayString(unref(dataForm).location_return_name), 1)
                  ]),
                  createVNode("div", { class: "text-zinc-400 text-sm whitespace-nowrap text-center lg:text-left" }, toDisplayString(unref(dataForm).pickup_date) + " \xA0 | \xA0 " + toDisplayString(unref(dataForm).passengers) + " " + toDisplayString(unref($t)("penumpang")), 1)
                ])) : createCommentVNode("", true)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d;
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 divide-x-2"${_scopeId}><div class="space-y-6 py-4"${_scopeId}><h3 class="text-2xl font-semibold text-primary-dark"${_scopeId}>${ssrInterpolate(unref($t)("perjalanan-anda"))}</h3>`);
            if (unref(dataForm).location_pickup_name && unref(dataForm).location_return_name) {
              _push2(`<div class="space-y-4"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_VehicleAddressInformation, {
                name: unref($t)("penjemputan"),
                locationName: unref(dataForm).location_pickup_name,
                locationAddress: unref(dataForm).location_pickup_address
              }, null, _parent2, _scopeId));
              _push2(`<div class="divider text-xs text-zinc-400"${_scopeId}>${ssrInterpolate(unref($t)("perjalananmu-sekitar"))} ${ssrInterpolate(unref(dataForm).distance)} Km </div>`);
              _push2(ssrRenderComponent(_component_VehicleAddressInformation, {
                name: unref($t)("tujuan"),
                locationName: unref(dataForm).location_return_name,
                locationAddress: unref(dataForm).location_return_address
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="p-4"${_scopeId}><div class="flex flex-col space-y-6"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><div${_scopeId}>${ssrInterpolate(unref($t)("menampilkan-mobil", { number: unref(totalData) }))}</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "sort",
              label: unref($t)("urut-berdasarkan")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMSelect, {
                    modelValue: unref(filter).sort,
                    "onUpdate:modelValue": ($event) => unref(filter).sort = $event,
                    name: "sort",
                    class: true
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<option value=""${_scopeId3}>${ssrInterpolate(unref($t)("semua"))}</option><option value="price"${_scopeId3}>${ssrInterpolate(unref($t)("murah-ke-mahal"))}</option><option value="-price"${_scopeId3}>${ssrInterpolate(unref($t)("mahal-ke-murah"))}</option><option value="recomended"${_scopeId3}>${ssrInterpolate(unref($t)("rekomendasi"))}</option>`);
                      } else {
                        return [
                          createVNode("option", { value: "" }, toDisplayString(unref($t)("semua")), 1),
                          createVNode("option", { value: "price" }, toDisplayString(unref($t)("murah-ke-mahal")), 1),
                          createVNode("option", { value: "-price" }, toDisplayString(unref($t)("mahal-ke-murah")), 1),
                          createVNode("option", { value: "recomended" }, toDisplayString(unref($t)("rekomendasi")), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMSelect, {
                      modelValue: unref(filter).sort,
                      "onUpdate:modelValue": ($event) => unref(filter).sort = $event,
                      name: "sort",
                      class: true
                    }, {
                      default: withCtx(() => [
                        createVNode("option", { value: "" }, toDisplayString(unref($t)("semua")), 1),
                        createVNode("option", { value: "price" }, toDisplayString(unref($t)("murah-ke-mahal")), 1),
                        createVNode("option", { value: "-price" }, toDisplayString(unref($t)("mahal-ke-murah")), 1),
                        createVNode("option", { value: "recomended" }, toDisplayString(unref($t)("rekomendasi")), 1)
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="space-y-4"${_scopeId}>`);
            if (((_a = unref(apiData)) == null ? void 0 : _a.data.length) > 0) {
              _push2(`<div${_scopeId}><!--[-->`);
              ssrRenderList((_b = unref(apiData)) == null ? void 0 : _b.data, (item) => {
                _push2(ssrRenderComponent(_component_VehicleCard, {
                  key: item.id,
                  id: item.id,
                  name: item.name,
                  image: item.image,
                  price: item.trip_price,
                  facilities: item.facilities,
                  maxPerson: item.max_person,
                  class: "mb-3"
                }, null, _parent2, _scopeId));
              });
              _push2(`<!--]--></div>`);
            } else {
              _push2(ssrRenderComponent(_component_Empty, {
                description: unref($t)("mobil-tidak-ditemukan")
              }, null, _parent2, _scopeId));
            }
            _push2(`</div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 divide-x-2" }, [
                createVNode("div", { class: "space-y-6 py-4" }, [
                  createVNode("h3", { class: "text-2xl font-semibold text-primary-dark" }, toDisplayString(unref($t)("perjalanan-anda")), 1),
                  unref(dataForm).location_pickup_name && unref(dataForm).location_return_name ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "space-y-4"
                  }, [
                    createVNode(_component_VehicleAddressInformation, {
                      name: unref($t)("penjemputan"),
                      locationName: unref(dataForm).location_pickup_name,
                      locationAddress: unref(dataForm).location_pickup_address
                    }, null, 8, ["name", "locationName", "locationAddress"]),
                    createVNode("div", { class: "divider text-xs text-zinc-400" }, toDisplayString(unref($t)("perjalananmu-sekitar")) + " " + toDisplayString(unref(dataForm).distance) + " Km ", 1),
                    createVNode(_component_VehicleAddressInformation, {
                      name: unref($t)("tujuan"),
                      locationName: unref(dataForm).location_return_name,
                      locationAddress: unref(dataForm).location_return_address
                    }, null, 8, ["name", "locationName", "locationAddress"])
                  ])) : createCommentVNode("", true)
                ]),
                createVNode("div", { class: "p-4" }, [
                  createVNode("div", { class: "flex flex-col space-y-6" }, [
                    createVNode("div", { class: "flex justify-between items-center" }, [
                      createVNode("div", null, toDisplayString(unref($t)("menampilkan-mobil", { number: unref(totalData) })), 1),
                      createVNode("div", null, [
                        createVNode(_component_UIFormMGroup, {
                          name: "sort",
                          label: unref($t)("urut-berdasarkan")
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_UIFormMSelect, {
                              modelValue: unref(filter).sort,
                              "onUpdate:modelValue": ($event) => unref(filter).sort = $event,
                              name: "sort",
                              class: true
                            }, {
                              default: withCtx(() => [
                                createVNode("option", { value: "" }, toDisplayString(unref($t)("semua")), 1),
                                createVNode("option", { value: "price" }, toDisplayString(unref($t)("murah-ke-mahal")), 1),
                                createVNode("option", { value: "-price" }, toDisplayString(unref($t)("mahal-ke-murah")), 1),
                                createVNode("option", { value: "recomended" }, toDisplayString(unref($t)("rekomendasi")), 1)
                              ]),
                              _: 1
                            }, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        }, 8, ["label"])
                      ])
                    ]),
                    createVNode("div", { class: "space-y-4" }, [
                      ((_c = unref(apiData)) == null ? void 0 : _c.data.length) > 0 ? (openBlock(), createBlock("div", { key: 0 }, [
                        (openBlock(true), createBlock(Fragment, null, renderList((_d = unref(apiData)) == null ? void 0 : _d.data, (item) => {
                          return openBlock(), createBlock(_component_VehicleCard, {
                            key: item.id,
                            id: item.id,
                            name: item.name,
                            image: item.image,
                            price: item.trip_price,
                            facilities: item.facilities,
                            maxPerson: item.max_person,
                            class: "mb-3"
                          }, null, 8, ["id", "name", "image", "price", "facilities", "maxPerson"]);
                        }), 128))
                      ])) : (openBlock(), createBlock(_component_Empty, {
                        key: 1,
                        description: unref($t)("mobil-tidak-ditemukan")
                      }, null, 8, ["description"]))
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/vehicles/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-8508530b.mjs.map
