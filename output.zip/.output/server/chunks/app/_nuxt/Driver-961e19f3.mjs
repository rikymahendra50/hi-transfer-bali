import { Form } from 'vee-validate';
import { _ as _sfc_main$1 } from './TextFieldWLabel-0de16bf1.mjs';
import { b as useRouter, j as __nuxt_component_0$1 } from '../server.mjs';
import { u as useSchema } from './useSchema-2d00eed1.mjs';
import { useSSRContext, mergeProps, unref, withCtx, createTextVNode, createVNode, toDisplayString } from 'vue';
import { u as useDriver } from './useDriver-a263cd04.mjs';
import { ssrRenderComponent, ssrIncludeBooleanAttr, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "Driver",
  __ssrInlineRender: true,
  props: {
    driver: {
      type: [Array, Object]
    },
    buttonTitle: {
      type: String
    }
  },
  setup(__props) {
    const { driverSchema } = useSchema();
    const router = useRouter();
    function redirect() {
      router.push("/admin/driver");
    }
    const {
      dataForm,
      onSubmit,
      message,
      alertType,
      loading,
      existingImage,
      selectedDriver
    } = useDriver({ callback: redirect });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIFormTextFieldWLabel = _sfc_main$1;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        "validation-schema": unref(driverSchema),
        onSubmit: unref(onSubmit)
      }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="border shadow-sm rounded-[8px] py-4 px-4"${_scopeId}><p class="text-black font-semibold"${_scopeId}>General</p><div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 mt-3 gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormTextFieldWLabel, {
              label: "Nama Pengemudi",
              name: "name",
              placeholder: "Input Pengemudi",
              modelValue: unref(dataForm).name,
              "onUpdate:modelValue": ($event) => unref(dataForm).name = $event,
              class: "input-bordered shadow-sm focus:outline-none",
              useStarIcon: false
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormTextFieldWLabel, {
              label: "Nomor Telepon",
              name: "phone",
              placeholder: "Input Nomor Telepon",
              modelValue: unref(dataForm).phone,
              "onUpdate:modelValue": ($event) => unref(dataForm).phone = $event,
              class: "input-bordered shadow-sm focus:outline-none",
              useStarIcon: false
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormTextFieldWLabel, {
              label: "Email",
              name: "email",
              placeholder: "Input Email",
              modelValue: unref(dataForm).email,
              "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
              class: "input-bordered shadow-sm focus:outline-none",
              useStarIcon: false
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="flex items-center justify-between mt-6"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, {
              to: "/admin/driver",
              class: "btn bg-transparent border border-red-600 text-red-500"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Batalkan `);
                } else {
                  return [
                    createTextVNode(" Batalkan ")
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<button type="submit"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""} class="btn bg-primary text-white normal-case !font-medium text-base hover:bg-primary"${_scopeId}>${ssrInterpolate(__props.buttonTitle)}</button></div>`);
          } else {
            return [
              createVNode("div", { class: "border shadow-sm rounded-[8px] py-4 px-4" }, [
                createVNode("p", { class: "text-black font-semibold" }, "General"),
                createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 mt-3 gap-4" }, [
                  createVNode(_component_UIFormTextFieldWLabel, {
                    label: "Nama Pengemudi",
                    name: "name",
                    placeholder: "Input Pengemudi",
                    modelValue: unref(dataForm).name,
                    "onUpdate:modelValue": ($event) => unref(dataForm).name = $event,
                    class: "input-bordered shadow-sm focus:outline-none",
                    useStarIcon: false
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode(_component_UIFormTextFieldWLabel, {
                    label: "Nomor Telepon",
                    name: "phone",
                    placeholder: "Input Nomor Telepon",
                    modelValue: unref(dataForm).phone,
                    "onUpdate:modelValue": ($event) => unref(dataForm).phone = $event,
                    class: "input-bordered shadow-sm focus:outline-none",
                    useStarIcon: false
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode(_component_UIFormTextFieldWLabel, {
                    label: "Email",
                    name: "email",
                    placeholder: "Input Email",
                    modelValue: unref(dataForm).email,
                    "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                    class: "input-bordered shadow-sm focus:outline-none",
                    useStarIcon: false
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ])
              ]),
              createVNode("div", { class: "flex items-center justify-between mt-6" }, [
                createVNode(_component_NuxtLink, {
                  to: "/admin/driver",
                  class: "btn bg-transparent border border-red-600 text-red-500"
                }, {
                  default: withCtx(() => [
                    createTextVNode(" Batalkan ")
                  ]),
                  _: 1
                }),
                createVNode("button", {
                  type: "submit",
                  disabled: unref(loading),
                  class: "btn bg-primary text-white normal-case !font-medium text-base hover:bg-primary"
                }, toDisplayString(__props.buttonTitle), 9, ["disabled"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/Driver.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main;

export { __nuxt_component_1 as _ };
//# sourceMappingURL=Driver-961e19f3.mjs.map
