import __nuxt_component_0 from './Icon-0f6314e3.mjs';
import { useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "StatusActive",
  __ssrInlineRender: true,
  props: { status: { type: [Number, String, Boolean] } },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["font-medium text-[14px] px-3 py-1 w-fit rounded-xl", {
          "bg-[#ECFDF3] text-[#037847]": __props.status === 1,
          "bg-[#EF4444] bg-opacity-[12%] text-error": __props.status === 0
        }]
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "icon-park-outline:dot",
        class: {
          "text-[#22C55E]": __props.status === 1,
          "text-[#EF4444]": __props.status === 0
        }
      }, null, _parent));
      _push(` ${ssrInterpolate(__props.status === 0 ? "Tidak aktif" : "Aktif")}</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/StatusActive.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main;

export { __nuxt_component_1 as _ };
//# sourceMappingURL=StatusActive-51cb6631.mjs.map
