import { _ as __nuxt_component_0 } from './TitleAdmin-130db81a.mjs';
import { _ as _sfc_main$1 } from './MGroup-560eed6a.mjs';
import { _ as _sfc_main$2 } from './MSelect-8e6f95b5.mjs';
import { defineComponent, ref, withCtx, unref, createVNode, useSSRContext } from 'vue';
import { f as useHead } from '../server.mjs';
import { ssrRenderComponent } from 'vue/server-renderer';
import 'vee-validate';
import 'clsx';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[slug]",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Order detail"
    });
    const status = ref({
      sort: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TitleAdmin = __nuxt_component_0;
      const _component_UIFormMGroup = _sfc_main$1;
      const _component_UIFormMSelect = _sfc_main$2;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_TitleAdmin, {
        title: "Ringkasan Pesanan",
        subTitle: "Informasi lengkap untuk pesanan TP12356780"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "sort",
              label: "Urut berdasarkan"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMSelect, {
                    modelValue: unref(status).sort,
                    "onUpdate:modelValue": ($event) => unref(status).sort = $event,
                    name: "sort"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<option value=""${_scopeId3}>Sudah Bayar</option><option value="recommended"${_scopeId3}>Belum bayar</option>`);
                      } else {
                        return [
                          createVNode("option", { value: "" }, "Sudah Bayar"),
                          createVNode("option", { value: "recommended" }, "Belum bayar")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMSelect, {
                      modelValue: unref(status).sort,
                      "onUpdate:modelValue": ($event) => unref(status).sort = $event,
                      name: "sort"
                    }, {
                      default: withCtx(() => [
                        createVNode("option", { value: "" }, "Sudah Bayar"),
                        createVNode("option", { value: "recommended" }, "Belum bayar")
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode(_component_UIFormMGroup, {
                  name: "sort",
                  label: "Urut berdasarkan"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMSelect, {
                      modelValue: unref(status).sort,
                      "onUpdate:modelValue": ($event) => unref(status).sort = $event,
                      name: "sort"
                    }, {
                      default: withCtx(() => [
                        createVNode("option", { value: "" }, "Sudah Bayar"),
                        createVNode("option", { value: "recommended" }, "Belum bayar")
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="px-5 py-4 flex flex-col gap-3 border-b"><div class="text-gray-500 uppercase text-[12px] font-semibold"> Informasi Pelanggan </div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Nama pelanggan:</p><p>Lorem, ipsum.</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Email:</p><p>coopertorff@mail.com</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold text-sm">Nomor Telepon:</p><p>+6281234567890</p></div></div><div class="px-5 py-4 flex flex-col gap-3 border-b"><div class="text-gray-500 uppercase text-[12px] font-semibold"> Informasi Pemesanan </div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Nama Tur</p><p>West Nusa Penida Tour</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Tanggal Tur</p><p>24 Juni 2024</p></div></div><div class="px-5 py-4 flex flex-col gap-3 border-b"><div class="text-gray-500 uppercase text-[12px] font-semibold"> Informasi Peserta </div><div class="overflow-x-auto"><table class="table"><thead><tr><th><div class="text-[#121212] font-semibold text-sm"> Nama Peserta </div></th><th><div class="text-[#121212] font-semibold text-sm">Kebangsaan</div></th><th><div class="text-[#121212] font-semibold text-sm">Kategori</div></th></tr></thead><tbody><tr><td>Cooper Torff</td><td>Indonesia</td><td>Dewasa</td></tr></tbody></table></div></div><div class="px-5 py-4 flex flex-col gap-3"><div class="text-gray-500 uppercase text-[12px] font-semibold"> Payment Information </div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Payment Method</p><p>Bank Transfer</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Payment Channel</p><p>Bank BCA</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Payment Status</p><p>Paid</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Total Price</p><p>Rp1.700.000</p></div></div><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/orders/order-detail-tourpackage/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-4502870f.mjs.map
