import { Swiper, SwiperSlide } from 'swiper/vue';
import { useSSRContext, defineComponent, computed, mergeProps, unref, ref, withAsyncContext, withCtx, createVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, createCommentVNode, watch } from 'vue';
import { Autoplay } from 'swiper/modules';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseContain } from 'vue/server-renderer';
import { _ as __nuxt_component_0$1 } from './Container-afb1bf23.mjs';
import __nuxt_component_1 from './Icon-9a1ee2a3.mjs';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import { _ as _sfc_main$4 } from './CtaSection-21a3976a.mjs';
import { k as _export_sfc, e as useI18n, u as useRequestHelper, a as useRequestOptions, b as useRouter, d as useRoute, g as useAsyncData, f as useHead } from '../server.mjs';
import { u as useTourForm } from './useTourStore-2a5da3ea.mjs';
import './config-71e93c9c.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main$3 = {
  __name: "Swiper",
  __ssrInlineRender: true,
  props: { data: { type: Array } },
  setup(__props) {
    const props = __props;
    const slidesPerView1024 = computed(() => {
      if (props.data.length <= 1) {
        return 1;
      } else if (props.data.length <= 2) {
        return 2;
      } else if (props.data.length <= 3) {
        return 3;
      } else {
        return 3;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Swiper = Swiper;
      const _component_SwiperSlide = SwiperSlide;
      _push(ssrRenderComponent(_component_Swiper, mergeProps({
        modules: ["SwiperAutoplay" in _ctx ? _ctx.SwiperAutoplay : unref(Autoplay)],
        "slides-per-view": 1,
        loop: true,
        effect: "creative",
        "space-between": "1",
        autoplay: {
          delay: 8e3,
          disableOnInteraction: true
        },
        breakpoints: {
          "640": {
            slidesPerView: 2,
            spaceBetween: 20
          },
          "1024": {
            slidesPerView: unref(slidesPerView1024),
            spaceBetween: 30
          }
        }
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(__props.data, (slide) => {
              _push2(ssrRenderComponent(_component_SwiperSlide, { key: slide }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="h-[350px] border"${_scopeId2}><img${ssrRenderAttr("src", slide.image)} alt="slide" class="w-full h-full object-cover"${_scopeId2}></div>`);
                  } else {
                    return [
                      createVNode("div", { class: "h-[350px] border" }, [
                        createVNode("img", {
                          src: slide.image,
                          alt: "slide",
                          class: "w-full h-full object-cover"
                        }, null, 8, ["src"])
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(__props.data, (slide) => {
                return openBlock(), createBlock(_component_SwiperSlide, { key: slide }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "h-[350px] border" }, [
                      createVNode("img", {
                        src: slide.image,
                        alt: "slide",
                        class: "w-full h-full object-cover"
                      }, null, 8, ["src"])
                    ])
                  ]),
                  _: 2
                }, 1024);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/Swiper.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$3;
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "NumberUpDown",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      type: [Number, String]
    },
    minValue: {
      type: [Number, String]
    },
    maxValue: {
      type: [Number, String]
    },
    showTooltip: {
      type: Boolean,
      default: false
    }
  },
  emits: ["update:modelValue", "increment", "decrement"],
  setup(__props, { emit }) {
    const props = __props;
    const input = computed({
      get() {
        var _a;
        return (_a = props.modelValue) != null ? _a : 0;
      },
      set(value) {
        emit("update:modelValue", value);
      }
    });
    const disabledDecrement = computed(() => {
      if (props.minValue) {
        return input.value < props.minValue;
      }
      return input.value <= 0;
    });
    const disabledIncrement = computed(() => {
      if (props.maxValue) {
        return input.value >= parseInt(props.maxValue);
      }
      return false;
    });
    const dataTip = computed(() => {
      const array = [];
      if (props.minValue) {
        array.push(`Minimal order: ${props.minValue}`);
      }
      if (props.maxValue) {
        array.push(`Maximal order: ${props.maxValue}`);
      }
      if (array.length === 0) {
        return "no min and max order";
      }
      return array.join(" and ");
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["inline-flex space-x-1 items-center", { tooltip: __props.showTooltip }],
        "data-tip": unref(dataTip)
      }, _attrs))}><button${ssrRenderAttrs(mergeProps({
        disabled: unref(disabledDecrement),
        class: "btn btn-sm btn-primary h-8 w-8 !p-0",
        type: "button"
      }, _ctx.$attrs))}>`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "i-heroicons-minus",
        class: "h-4 w-4"
      }, null, _parent));
      _push(`</button><div class="px-3">${ssrInterpolate(unref(input))}</div><button${ssrRenderAttrs(mergeProps({
        type: "button",
        class: "btn btn-sm btn-primary h-8 w-8 !p-0",
        disabled: unref(disabledIncrement)
      }, _ctx.$attrs))}>`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "i-heroicons-plus",
        class: "h-4 w-4"
      }, null, _parent));
      _push(`</button></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/NumberUpDown.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "CheckboxProductVariant",
  __ssrInlineRender: true,
  props: {
    productVariant: {
      type: Object
    },
    modelValue: {
      type: Array
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit }) {
    const props = __props;
    const additionalChecked = ref(false);
    const internalValue = ref({
      id: props.productVariant.id,
      quantity: 1,
      type: "",
      total: 0
    });
    const price = computed(() => {
      return parseFloat(props.productVariant.price) || 0;
    });
    const total = computed(() => {
      return price.value * internalValue.value.quantity;
    });
    function updateModelValue() {
      internalValue.value.total = total.value;
      emit("update:modelValue", [...props.modelValue]);
    }
    watch(
      () => additionalChecked.value,
      (newValue) => {
        handleClick();
      }
    );
    function handleClick() {
      let variant = [...props.modelValue];
      const existingIndex = variant.findIndex(
        (el) => el.id === internalValue.value.id
      );
      if (additionalChecked.value) {
        if (existingIndex !== -1) {
          variant[existingIndex] = { ...internalValue.value, total: total.value };
        } else {
          variant.push({ ...internalValue.value, total: total.value });
        }
      } else {
        if (existingIndex !== -1) {
          variant.splice(existingIndex, 1);
        }
      }
      emit("update:modelValue", variant);
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NumberUpDown = _sfc_main$2;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["flex flex-col border rounded-lg p-4 form-control hover:border-primary transition-all duration-300 mb-2", { "border-primary": additionalChecked.value }]
      }, _attrs))}><div class="flex flex-row space-x-4"><div class="flex p-4 gap-3 w-full"><div class="form-control"><label class="cursor-pointer label"><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(additionalChecked.value) ? ssrLooseContain(additionalChecked.value, null) : additionalChecked.value) ? " checked" : ""} class="checkbox checkbox-primary"${ssrIncludeBooleanAttr(additionalChecked.value) ? " checked" : ""}></label></div><div class="flex flex-col w-full"><div class="flex flex-col gap-y-2 relative"><p class="text-black text-sm lg:text-base font-semibold pt-1">${ssrInterpolate(props.productVariant.description)}</p><div class="flex items-center justify-between gap-4 mt-2"><div class="flex items-center gap-4">`);
      _push(ssrRenderComponent(_component_NumberUpDown, {
        modelValue: internalValue.value.quantity,
        "onUpdate:modelValue": ($event) => internalValue.value.quantity = $event,
        minValue: 1,
        maxValue: 10,
        showTooltip: true,
        onIncrement: updateModelValue,
        onDecrement: updateModelValue
      }, null, _parent));
      _push(`</div><div class="font-semibold">${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(total.value.toString()))}</div></div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/CheckboxProductVariant.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$1;
const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    const { locale, t: $t } = useI18n();
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    const route = useRoute();
    const slug = computed(() => route.params.slug);
    const data = ref(null);
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedTourData,
      clearSavedTourData
    } = useTourForm({
      callback: () => {
        alert("Form has been submitted!");
      }
    });
    const {
      data: apiData,
      error,
      refresh
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "toursDetail",
      () => $fetch(`/tours/${slug.value}?lang=${locale.value}`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    if (apiData.value) {
      data.value = apiData.value;
      data.value.data.variants.forEach((variant) => {
        variant.quantity = 1;
        variant.selected = false;
      });
    }
    const result = computed(() => {
      var _a2, _b, _c;
      return ((_c = (_b = (_a2 = apiData.value) == null ? void 0 : _a2.data) == null ? void 0 : _b.locations) == null ? void 0 : _c.map((item) => item.name).join(" - ")) || "";
    });
    function continueOnsubmit() {
      saveFormData();
      router.push({ path: "/tours/booking" });
    }
    useHead({
      title: (_a = apiData == null ? void 0 : apiData.value.data) == null ? void 0 : _a.name,
      meta: [
        {
          name: "description",
          content: result.value
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b;
      const _component_TourSwiper = __nuxt_component_0;
      const _component_UIContainer = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_1;
      const _component_UIFormCheckboxProductVariant = __nuxt_component_3;
      const _component_ShareCtaSection = _sfc_main$4;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-3dfee0ae><div class="h-28" data-v-3dfee0ae></div>`);
      _push(ssrRenderComponent(_component_TourSwiper, {
        data: (_b = (_a2 = unref(data)) == null ? void 0 : _a2.data) == null ? void 0 : _b.images
      }, null, _parent));
      _push(`<div class="h-5" data-v-3dfee0ae></div>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a3, _b2, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x;
          if (_push2) {
            _push2(`<div class="flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full my-2 lg:my-4" data-v-3dfee0ae${_scopeId}><div class="flex flex-col space-y-2 gap-2" data-v-3dfee0ae${_scopeId}><h1 class="text-xl lg:text-[32px] lg:leading-[40px] font-semibold" data-v-3dfee0ae${_scopeId}>${ssrInterpolate((_b2 = (_a3 = unref(data)) == null ? void 0 : _a3.data) == null ? void 0 : _b2.name)}</h1><div class="inline-flex space-x-2" data-v-3dfee0ae${_scopeId}><div data-v-3dfee0ae${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Icon, {
              name: "ph:map-pin-line-fill",
              class: "w-5 h-5 text-[#00A59A]"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="text-zinc-400" data-v-3dfee0ae${_scopeId}>${ssrInterpolate(unref(result))}</div></div><div data-v-3dfee0ae${_scopeId}><div class="text-zinc-400 text-xs" data-v-3dfee0ae${_scopeId}>${ssrInterpolate(unref($t)("harga-mulai-dari"))}</div><h4 class="text-xl font-semibold text-primary" data-v-3dfee0ae${_scopeId}>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))((_f = (_e = (_d = (_c = unref(data)) == null ? void 0 : _c.data) == null ? void 0 : _d.variants[0]) == null ? void 0 : _e.price) == null ? void 0 : _f.toString()))} /${ssrInterpolate(unref($t)("orang"))}</h4></div><div class="flex justify-start items-center" data-v-3dfee0ae${_scopeId}><div class="text-lg font-semibold" data-v-3dfee0ae${_scopeId}>Total: ${ssrInterpolate(21)}</div></div></div><div class="flex justify-end w-full" data-v-3dfee0ae${_scopeId}><div class="flex items-center justify-end" data-v-3dfee0ae${_scopeId}><button class="btn btn-primary" type="button" data-v-3dfee0ae${_scopeId}>${ssrInterpolate(unref($t)("lanjutkan"))}</button></div></div></div><div class="h-5" data-v-3dfee0ae${_scopeId}></div>`);
            if (((_h = (_g = unref(apiData)) == null ? void 0 : _g.data) == null ? void 0 : _h.is_varied) === 1) {
              _push2(`<div class="grid grid-cols-1 md:grid-cols-[150px_1fr] gap-4 mb-4 sm:mb-6 md:mb-8 lg:mb-10" data-v-3dfee0ae${_scopeId}><div class="text-2xl font-semibold pt-5 md:pt-10" data-v-3dfee0ae${_scopeId}>${ssrInterpolate(unref($t)("variant"))}</div><div class="" data-v-3dfee0ae${_scopeId}><!--[-->`);
              ssrRenderList((_j = (_i = unref(apiData)) == null ? void 0 : _i.data) == null ? void 0 : _j.variants, (item, index) => {
                _push2(ssrRenderComponent(_component_UIFormCheckboxProductVariant, {
                  key: item.id,
                  productVariant: item,
                  modelValue: unref(dataForm).bookingForm.variant,
                  "onUpdate:modelValue": ($event) => unref(dataForm).bookingForm.variant = $event
                }, null, _parent2, _scopeId));
              });
              _push2(`<!--]--></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="grid grid-cols-1 md:grid-cols-[150px_1fr] gap-4 mb-4 sm:mb-6 md:mb-8 lg:mb-10" data-v-3dfee0ae${_scopeId}><div class="text-2xl font-semibold pt-5 md:pt-10" data-v-3dfee0ae${_scopeId}>Ringkasan</div><div class="rounded-[6px] shadow-sm flex flex-col" data-v-3dfee0ae${_scopeId}><div class="adjustdefault" data-v-3dfee0ae${_scopeId}>${(_l = (_k = unref(apiData)) == null ? void 0 : _k.data) == null ? void 0 : _l.description}</div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full my-2 lg:my-4" }, [
                createVNode("div", { class: "flex flex-col space-y-2 gap-2" }, [
                  createVNode("h1", { class: "text-xl lg:text-[32px] lg:leading-[40px] font-semibold" }, toDisplayString((_n = (_m = unref(data)) == null ? void 0 : _m.data) == null ? void 0 : _n.name), 1),
                  createVNode("div", { class: "inline-flex space-x-2" }, [
                    createVNode("div", null, [
                      createVNode(_component_Icon, {
                        name: "ph:map-pin-line-fill",
                        class: "w-5 h-5 text-[#00A59A]"
                      })
                    ]),
                    createVNode("div", { class: "text-zinc-400" }, toDisplayString(unref(result)), 1)
                  ]),
                  createVNode("div", null, [
                    createVNode("div", { class: "text-zinc-400 text-xs" }, toDisplayString(unref($t)("harga-mulai-dari")), 1),
                    createVNode("h4", { class: "text-xl font-semibold text-primary" }, toDisplayString(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))((_r = (_q = (_p = (_o = unref(data)) == null ? void 0 : _o.data) == null ? void 0 : _p.variants[0]) == null ? void 0 : _q.price) == null ? void 0 : _r.toString())) + " /" + toDisplayString(unref($t)("orang")), 1)
                  ]),
                  createVNode("div", { class: "flex justify-start items-center" }, [
                    createVNode("div", { class: "text-lg font-semibold" }, "Total: " + toDisplayString(21))
                  ])
                ]),
                createVNode("div", { class: "flex justify-end w-full" }, [
                  createVNode("div", { class: "flex items-center justify-end" }, [
                    createVNode("button", {
                      class: "btn btn-primary",
                      type: "button",
                      onClick: ($event) => continueOnsubmit()
                    }, toDisplayString(unref($t)("lanjutkan")), 9, ["onClick"])
                  ])
                ])
              ]),
              createVNode("div", { class: "h-5" }),
              ((_t = (_s = unref(apiData)) == null ? void 0 : _s.data) == null ? void 0 : _t.is_varied) === 1 ? (openBlock(), createBlock("div", {
                key: 0,
                class: "grid grid-cols-1 md:grid-cols-[150px_1fr] gap-4 mb-4 sm:mb-6 md:mb-8 lg:mb-10"
              }, [
                createVNode("div", { class: "text-2xl font-semibold pt-5 md:pt-10" }, toDisplayString(unref($t)("variant")), 1),
                createVNode("div", { class: "" }, [
                  (openBlock(true), createBlock(Fragment, null, renderList((_v = (_u = unref(apiData)) == null ? void 0 : _u.data) == null ? void 0 : _v.variants, (item, index) => {
                    return openBlock(), createBlock(_component_UIFormCheckboxProductVariant, {
                      key: item.id,
                      productVariant: item,
                      modelValue: unref(dataForm).bookingForm.variant,
                      "onUpdate:modelValue": ($event) => unref(dataForm).bookingForm.variant = $event
                    }, null, 8, ["productVariant", "modelValue", "onUpdate:modelValue"]);
                  }), 128))
                ])
              ])) : createCommentVNode("", true),
              createVNode("div", { class: "grid grid-cols-1 md:grid-cols-[150px_1fr] gap-4 mb-4 sm:mb-6 md:mb-8 lg:mb-10" }, [
                createVNode("div", { class: "text-2xl font-semibold pt-5 md:pt-10" }, "Ringkasan"),
                createVNode("div", { class: "rounded-[6px] shadow-sm flex flex-col" }, [
                  createVNode("div", {
                    innerHTML: (_x = (_w = unref(apiData)) == null ? void 0 : _w.data) == null ? void 0 : _x.description,
                    class: "adjustdefault"
                  }, null, 8, ["innerHTML"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_ShareCtaSection, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tours/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _slug_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-3dfee0ae"]]);

export { _slug_ as default };
//# sourceMappingURL=_slug_-890343f3.mjs.map
