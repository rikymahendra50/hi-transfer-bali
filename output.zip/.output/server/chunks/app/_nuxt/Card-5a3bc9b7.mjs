import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs } from 'vue/server-renderer';
import { e as _export_sfc } from '../server.mjs';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "overflow-hidden rounded-xl space-y-2 border border-zinc-200 shadow-sm group" }, _attrs))}><div class="h-[300px] overflow-hidden"><img src="https://placehold.co/400x400" alt="tour" class="h-[300px] w-full object-cover group-hover:scale-125 transition-all duration-300"></div><div class="p-3 space-y-4"><div><h4 class="text-xl font-semibold text-primary-dark">West Nusa Penida Tour</h4><div class="text-zinc-400 text-sm line-clamp-2"> Kelingking Cliff - Angel&#39;s Billabong - Broken Beach - Crystal Bay Beach </div></div><div><div class="text-zinc-400 text-xs">Harga Mulai Dari</div><h4 class="text-xl font-semibold text-primary">Rp. 1.000.000/Orang</h4></div></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/Card.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_4 as _ };
//# sourceMappingURL=Card-5a3bc9b7.mjs.map
