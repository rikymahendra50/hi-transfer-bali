import __nuxt_component_1 from './Icon-7218f0f6.mjs';
import { b as useAuth } from '../server.mjs';
import { useSSRContext, ref, defineComponent, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrIncludeBooleanAttr } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "SocialLogin",
  __ssrInlineRender: true,
  setup(__props) {
    const { $loginWithGoogle, loading } = useAuth();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex justify-center space-x-4" }, _attrs))}><button type="button" class="btn btn-outline border-zinc-400 hover:bg-zinc-200 hover:border-zinc-400">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "logos:facebook",
        class: "w-5 h-5"
      }, null, _parent));
      _push(`<div> Facebook </div></button><button type="button"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""} class="btn btn-outline border-zinc-400 hover:bg-zinc-200 hover:border-zinc-400">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "flat-color-icons:google",
        class: "w-5 h-5"
      }, null, _parent));
      _push(`<div> Google </div></button><button type="button" class="btn btn-outline border-zinc-400 hover:bg-zinc-200 hover:border-zinc-400">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "basil:apple-outline",
        class: "w-5 h-5"
      }, null, _parent));
      _push(`<div> Apple </div></button></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Auth/SocialLogin.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
function usePasswordHelper() {
  const inputType = ref("password");
  function togglePasswordType() {
    inputType.value = inputType.value === "password" ? "text" : "password";
  }
  return { inputType, togglePasswordType };
}

export { _sfc_main as _, usePasswordHelper as u };
//# sourceMappingURL=usePasswordHelper-bd5c09b9.mjs.map
