import { _ as _sfc_main$2, a as __nuxt_component_1 } from './ChangePassword-43d498ec.mjs';
import { u as useAuth, a as useHead } from '../server.mjs';
import { defineComponent, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import 'vee-validate';
import './Alert-f7c32dd8.mjs';
import './TransitionTopToBottom-a8e40871.mjs';
import './Icon-ab561e52.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './index-dea25161.mjs';
import './index-596a8548.mjs';
import './MGroup-56a6a0a6.mjs';
import './TransitionX-601819e8.mjs';
import 'clsx';
import './MTextField-bd75102a.mjs';
import './useSchema-27c20d48.mjs';
import 'zod';
import '@vee-validate/zod';
import './nofication-1c3cca5e.mjs';
import './Group-4dcbb69b.mjs';
import './usePasswordHelper-d8a46f8b.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "profile",
  __ssrInlineRender: true,
  setup(__props) {
    const { $fetchAuthProfile } = useAuth();
    useHead({
      title: "Admin"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIFormProfile = _sfc_main$2;
      const _component_UIFormChangePassword = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="max-w-xl space-y-8 p-4">`);
      _push(ssrRenderComponent(_component_UIFormProfile, {
        onReload: ($event) => unref($fetchAuthProfile)(),
        "used-by": "admin"
      }, null, _parent));
      _push(ssrRenderComponent(_component_UIFormChangePassword, { "used-by": "admin" }, null, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/profile.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=profile-529c087a.mjs.map
