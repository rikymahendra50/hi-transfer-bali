import { d as useRoute, b as useRouter, u as useAuth, a as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import { defineComponent, computed, ref, mergeProps, unref, withCtx, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[token]",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    useRouter();
    useAuth({ usedBy: "admin" });
    computed(() => {
      return route.params.token;
    });
    const message = ref("");
    const isSuccess = ref(true);
    const title = ref("Email Verification");
    useHead({
      title: "Email Verification"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "hero min-h-screen" }, _attrs))}><div class="hero-content text-center"><div class="max-w-md"><h1 class="text-5xl font-bold">${ssrInterpolate(unref(title))}</h1><p class="py-6">${ssrInterpolate(unref(message))}</p>`);
      if (unref(isSuccess)) {
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: "/admin/sign-in",
          class: "btn btn-primary"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Get Started`);
            } else {
              return [
                createTextVNode("Get Started")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/email-verification/[token].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_token_-6e3c92e8.mjs.map
