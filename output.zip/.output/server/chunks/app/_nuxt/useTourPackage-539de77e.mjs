import { a as useRequestOptions, u as useRequestHelper, h as useFetch } from '../server.mjs';
import { ref, computed, watch } from 'vue';
import { u as useNotification } from './nofication-176ebe9f.mjs';

function useTourPackage(options = {}) {
  const { requestOptions } = useRequestOptions();
  const { message, loading, alertType, transformErrors, setErrorMessage } = useRequestHelper();
  const { pushNotification } = useNotification();
  const selectedTourPackage = ref();
  const dataForm = ref({
    name: void 0,
    price: void 0,
    "description[en]": void 0,
    "description[id]": void 0,
    "meta[en]": void 0,
    "meta[id]": void 0,
    locations: [],
    max_person: void 0,
    is_varied: 0,
    variants: []
  });
  function resetForm() {
    dataForm.value = {
      name: void 0,
      price: void 0,
      "description[en]": void 0,
      "description[id]": void 0,
      "meta[en]": void 0,
      "meta[id]": void 0,
      locations: [],
      max_person: void 0,
      is_varied: 0,
      variants: []
    };
  }
  const isVaried = computed(() => dataForm.value.is_varied === 1);
  function resetProductVariants() {
    dataForm.value.variants = [];
  }
  watch(isVaried, () => {
    if (isVaried.value) {
      addProductVariants();
    } else {
      resetProductVariants();
    }
  });
  const existingImage = computed(() => {
    var _a;
    return (_a = selectedTourPackage.value) == null ? void 0 : _a.image;
  });
  function onSubmit(values, ctx) {
    if (selectedTourPackage.value) {
      updateTourPackage(ctx);
    } else {
      createTourPackage(ctx);
    }
  }
  async function createTourPackage(ctx) {
    const formData = new FormData();
    loading.value = true;
    const uniqueLocations = [...new Set(dataForm.value.locations)];
    for (const item in dataForm.value) {
      if (item === "locations") {
        uniqueLocations.forEach((location, index) => {
          formData.append(`locations[${index}]`, location);
        });
      } else {
        const objectItem = dataForm.value[item];
        formData.append(item, objectItem);
      }
    }
    if (dataForm.value.variants) {
      dataForm.value.variants.forEach((variant, index) => {
        formData.append(`variants[${index}][name]`, variant.name);
        formData.append(`variants[${index}][price]`, variant.price);
        formData.append(
          `variants[${index}][descriptions][en]`,
          variant.description.en
        );
        formData.append(
          `variants[${index}][descriptions][id]`,
          variant.description.id
        );
      });
    }
    await $fetch("/admins/tours", {
      headers: {
        Accept: "Application/json"
      },
      method: "POST",
      body: formData,
      ...requestOptions
    }).catch((error) => {
      var _a;
      setErrorMessage((_a = error.data) == null ? void 0 : _a.message);
      ctx.setErrors(transformErrors(error.data));
    }).then((data) => {
      var _a;
      if (data) {
        ctx.resetForm();
        pushNotification({
          type: "success",
          text: "Tour Package created successfully"
        });
        (_a = options.callback) == null ? void 0 : _a.call(options);
      }
    });
    loading.value = false;
  }
  const updateTourPackage = async (ctx) => {
    var _a;
    const formData = new FormData();
    loading.value = true;
    for (const item in dataForm.value) {
      if (item === "locations") {
        dataForm.value.locations.forEach((location, index) => {
          formData.append(`locations[${index}]`, location);
        });
      } else {
        const objectItem = dataForm.value[item];
        formData.append(item, objectItem);
      }
    }
    if (dataForm.value.variants) {
      dataForm.value.variants.forEach((variant, index) => {
        formData.append(`variants[${index}][name]`, variant.name);
        formData.append(`variants[${index}][price]`, variant.price);
        formData.append(
          `variants[${index}][descriptions][en]`,
          variant.description.en
        );
        formData.append(
          `variants[${index}][descriptions][id]`,
          variant.description.id
        );
      });
    }
    await $fetch(
      `/admins/tours/${(_a = selectedTourPackage.value) == null ? void 0 : _a.slug}?_method=PUT`,
      {
        headers: {
          Accept: "Application/json"
        },
        method: "POST",
        body: formData,
        ...requestOptions
      }
    ).catch((error) => {
      var _a2, _b, _c;
      setErrorMessage((_a2 = error.data) == null ? void 0 : _a2.message);
      ctx.setErrors(transformErrors(error.data));
      pushNotification({
        type: "error",
        text: (_b = error.value.data) == null ? void 0 : _b.message,
        title: "error"
      });
      pushNotification({
        type: "error",
        text: (_c = error.value.data) == null ? void 0 : _c.message,
        title: "error"
      });
    }).then((data) => {
      var _a2;
      if (data) {
        ctx.resetForm();
        pushNotification({
          type: "success",
          text: "Tour Package updated successfully"
        });
        resetForm();
        (_a2 = options.callback) == null ? void 0 : _a2.call(options);
      }
    });
    loading.value = false;
  };
  async function deleteTourPackage(slug) {
    var _a2;
    var _a, _b, _c;
    loading.value = true;
    const { error } = await useFetch(
      `/admins/tours/${slug}`,
      {
        method: "DELETE",
        ...requestOptions
      },
      "$YaaLfURe2l"
    );
    if (error.value) {
      setErrorMessage((_a2 = (_b = (_a = error.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message) != null ? _a2 : "Something went wrong");
    } else {
      pushNotification({
        type: "success",
        text: "Tour Package deleted successfully"
      });
      (_c = options.callback) == null ? void 0 : _c.call(options);
    }
    loading.value = false;
  }
  function addProductVariants() {
    var _a, _b, _c;
    if (!dataForm.value.variants) {
      dataForm.value.variants = [];
    }
    if (((_a = selectedTourPackage.value) == null ? void 0 : _a.variants) && ((_b = selectedTourPackage.value) == null ? void 0 : _b.variants.length) > 0) {
      dataForm.value.variants = (_c = selectedTourPackage.value) == null ? void 0 : _c.variants.map(
        (variant) => {
          var _a2, _b2;
          return {
            name: variant.name,
            price: variant.price,
            description: {
              en: (_a2 = variant.description.find((item) => item.language === "en")) == null ? void 0 : _a2.translation,
              id: (_b2 = variant.description.find((item) => item.language === "id")) == null ? void 0 : _b2.translation
            }
          };
        }
      );
    } else {
      dataForm.value.variants.push({
        name: "",
        price: "",
        description: {
          en: "",
          id: ""
        }
      });
    }
  }
  return {
    selectedTourPackage,
    dataForm,
    onSubmit,
    existingImage,
    message,
    loading,
    alertType,
    deleteTourPackage
  };
}

export { useTourPackage as u };
//# sourceMappingURL=useTourPackage-539de77e.mjs.map
