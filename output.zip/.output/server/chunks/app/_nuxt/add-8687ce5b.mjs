import { _ as __nuxt_component_0 } from './TitleBack-aa5a1267.mjs';
import { _ as _sfc_main$1 } from './FormAdmin-3cb78173.mjs';
import { a as useHead, b as useRouter } from '../server.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './Icon-0f6314e3.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'vee-validate';
import './Alert-4fa497cc.mjs';
import './TransitionTopToBottom-a8e40871.mjs';
import './Group-4dcbb69b.mjs';
import './TransitionX-601819e8.mjs';
import 'clsx';
import './nofication-1c3cca5e.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "add",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Admin Create"
    });
    const router = useRouter();
    const reload = () => {
      router.push("/admin/admin-list");
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TitleBack = __nuxt_component_0;
      const _component_FormAdmin = _sfc_main$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-6 px-5 py-4" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_TitleBack, {
        link: "/admin/admin-list",
        title: "Tambah Admin"
      }, null, _parent));
      _push(`<div class="grid grid-cols-1 lg:grid-cols-[2fr_1fr]">`);
      _push(ssrRenderComponent(_component_FormAdmin, { onReload: reload }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/admin-list/add.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=add-8687ce5b.mjs.map
