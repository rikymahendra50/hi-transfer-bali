import { Form, Field, ErrorMessage } from 'vee-validate';
import { _ as _sfc_main$3 } from './Alert-129c5078.mjs';
import { _ as _sfc_main$4 } from './MGroup-e711cd83.mjs';
import { _ as _sfc_main$5 } from './MTextField-bd75102a.mjs';
import { _ as _sfc_main$6 } from './Btn-577fa59f.mjs';
import { u as useSchema } from './useSchema-0246d9f0.mjs';
import { u as useAuth, b as useRouter } from '../server.mjs';
import { defineComponent, mergeProps, unref, withCtx, isRef, createVNode, createTextVNode, toDisplayString, useSSRContext, openBlock, createBlock, createCommentVNode } from 'vue';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import { _ as _sfc_main$7 } from './Group-4dcbb69b.mjs';
import { _ as _sfc_main$8 } from './InputOTP-bbb2b053.mjs';
import { _ as __nuxt_component_0 } from './TransitionX-601819e8.mjs';

const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  props: {
    usedBy: {
      type: String,
      default: "user",
      validator(value) {
        return ["user", "admin"].includes(value);
      }
    }
  },
  emits: ["next", "update:email"],
  setup(__props, { emit }) {
    const props = __props;
    const { onlyEmailSchema } = useSchema();
    function updateToParent() {
      emit("update:email", $credentialForgotPassword.value.email);
      emit("next");
    }
    const {
      loading,
      message,
      alertType,
      $credentialForgotPassword,
      $requestForgotPassword
    } = useAuth({
      usedBy: props.usedBy,
      callback: updateToParent
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIAlert = _sfc_main$3;
      const _component_UIFormMGroup = _sfc_main$4;
      const _component_UIFormMTextField = _sfc_main$5;
      const _component_UIBtn = _sfc_main$6;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        onSubmit: unref($requestForgotPassword),
        "validation-schema": unref(onlyEmailSchema)
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 w-[450px] text-left gap-4 p-4 rounded-md shadow"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIAlert, {
              modelValue: unref(message),
              "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
              type: unref(alertType)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Email",
              name: "email"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "email",
                    modelValue: unref($credentialForgotPassword).email,
                    "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).email = $event,
                    placeholder: "ex:myemail@gmail.com",
                    class: "input-bordered"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "email",
                      modelValue: unref($credentialForgotPassword).email,
                      "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).email = $event,
                      placeholder: "ex:myemail@gmail.com",
                      class: "input-bordered"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}><p class="text-gray-400 text-xs"${_scopeId}>${ssrInterpolate(_ctx.$t("kami-akan-mengirimkan"))}</p></div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              variant: "primary",
              type: "submit",
              disabled: unref(loading)
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Submit `);
                } else {
                  return [
                    createTextVNode(" Submit ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 w-[450px] text-left gap-4 p-4 rounded-md shadow" }, [
                createVNode(_component_UIAlert, {
                  modelValue: unref(message),
                  "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
                  type: unref(alertType)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "type"]),
                createVNode(_component_UIFormMGroup, {
                  label: "Email",
                  name: "email"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      name: "email",
                      modelValue: unref($credentialForgotPassword).email,
                      "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).email = $event,
                      placeholder: "ex:myemail@gmail.com",
                      class: "input-bordered"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode("div", null, [
                  createVNode("p", { class: "text-gray-400 text-xs" }, toDisplayString(_ctx.$t("kami-akan-mengirimkan")), 1)
                ]),
                createVNode("div", null, [
                  createVNode(_component_UIBtn, {
                    variant: "primary",
                    type: "submit",
                    disabled: unref(loading)
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Submit ")
                    ]),
                    _: 1
                  }, 8, ["disabled"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ForgotPassword/index.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "VerifiedOTP",
  __ssrInlineRender: true,
  props: {
    email: {},
    usedBy: { default: "user" }
  },
  emits: ["next", "update:pin"],
  setup(__props, { emit }) {
    const props = __props;
    const { otpSchema } = useSchema();
    const {
      loading,
      message,
      alertType,
      $verificationOTPForgotPassword,
      $credentialForgotPassword,
      $countdownTokenExpired,
      $countdownHelper,
      $reRequestForgotPassword
    } = useAuth({
      usedBy: props.usedBy,
      callback: updateToParent
    });
    function updateToParent() {
      emit("update:pin", $credentialForgotPassword.value.pin);
      emit("next");
    }
    async function resentEmail() {
      if (loading.value) {
        return;
      }
      await $reRequestForgotPassword();
      $countdownHelper.value.showExpired = false;
      $countdownHelper.value.expiredTime = 60;
      $countdownTokenExpired();
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIAlert = _sfc_main$3;
      const _component_UIFormGroup = _sfc_main$7;
      const _component_VeeField = Field;
      const _component_UIFormInputOTP = _sfc_main$8;
      const _component_TransitionX = __nuxt_component_0;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_UIBtn = _sfc_main$6;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        onSubmit: unref($verificationOTPForgotPassword),
        "validation-schema": unref(otpSchema)
      }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 w-[450px] text-left gap-2 p-4 rounded-md shadow"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIAlert, {
              modelValue: unref(message),
              "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
              type: unref(alertType)
            }, null, _parent2, _scopeId));
            _push2(`<div class="flex justify-center"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormGroup, {
              label: "OTP",
              name: "opt"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="hidden"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_VeeField, {
                    name: "otp",
                    modelValue: unref($credentialForgotPassword).pin,
                    "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).pin = $event
                  }, null, _parent3, _scopeId2));
                  _push3(`</div>`);
                  _push3(ssrRenderComponent(_component_UIFormInputOTP, {
                    modelValue: unref($credentialForgotPassword).pin,
                    "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).pin = $event,
                    "is-error": !!(errors == null ? void 0 : errors.otp)
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_TransitionX, null, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_VeeErrorMessage, {
                          name: "otp",
                          class: "form-error-message"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_VeeErrorMessage, {
                            name: "otp",
                            class: "form-error-message"
                          })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode("div", { class: "hidden" }, [
                      createVNode(_component_VeeField, {
                        name: "otp",
                        modelValue: unref($credentialForgotPassword).pin,
                        "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).pin = $event
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    createVNode(_component_UIFormInputOTP, {
                      modelValue: unref($credentialForgotPassword).pin,
                      "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).pin = $event,
                      "is-error": !!(errors == null ? void 0 : errors.otp)
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "is-error"]),
                    createVNode(_component_TransitionX, null, {
                      default: withCtx(() => [
                        createVNode(_component_VeeErrorMessage, {
                          name: "otp",
                          class: "form-error-message"
                        })
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-center"${_scopeId}>`);
            if (unref($countdownHelper).showExpired) {
              _push2(`<div${_scopeId}><p class="text-gray-400 text-xs"${_scopeId}> If you did not receive the an email <span class="link" role="button"${_scopeId}>click here</span></p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="flex justify-center"${_scopeId}><div${_scopeId}>`);
            if (unref($countdownHelper).expiredTime > 0) {
              _push2(`<div class="text-gray-400 text-xs"${_scopeId}> We have sent an OTP to your email. Your OTP will expired in <span class="whitespace-nowrap"${_scopeId}>${ssrInterpolate(unref($countdownHelper).expiredTime)} seconds </span></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (unref($countdownHelper).showExpired) {
              _push2(`<div class="text-error text-xs"${_scopeId}> Your OTP has expired. Please request a new one </div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="flex justify-center"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              type: "submit",
              disabled: unref(loading),
              variant: "primary"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Submit `);
                } else {
                  return [
                    createTextVNode(" Submit ")
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 w-[450px] text-left gap-2 p-4 rounded-md shadow" }, [
                createVNode(_component_UIAlert, {
                  modelValue: unref(message),
                  "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
                  type: unref(alertType)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "type"]),
                createVNode("div", { class: "flex justify-center" }, [
                  createVNode(_component_UIFormGroup, {
                    label: "OTP",
                    name: "opt"
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "hidden" }, [
                        createVNode(_component_VeeField, {
                          name: "otp",
                          modelValue: unref($credentialForgotPassword).pin,
                          "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).pin = $event
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode(_component_UIFormInputOTP, {
                        modelValue: unref($credentialForgotPassword).pin,
                        "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).pin = $event,
                        "is-error": !!(errors == null ? void 0 : errors.otp)
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "is-error"]),
                      createVNode(_component_TransitionX, null, {
                        default: withCtx(() => [
                          createVNode(_component_VeeErrorMessage, {
                            name: "otp",
                            class: "form-error-message"
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 2
                  }, 1024)
                ]),
                createVNode("div", { class: "flex justify-center" }, [
                  unref($countdownHelper).showExpired ? (openBlock(), createBlock("div", { key: 0 }, [
                    createVNode("p", { class: "text-gray-400 text-xs" }, [
                      createTextVNode(" If you did not receive the an email "),
                      createVNode("span", {
                        class: "link",
                        onClick: resentEmail,
                        role: "button"
                      }, "click here")
                    ])
                  ])) : createCommentVNode("", true)
                ]),
                createVNode("div", { class: "flex justify-center" }, [
                  createVNode("div", null, [
                    unref($countdownHelper).expiredTime > 0 ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "text-gray-400 text-xs"
                    }, [
                      createTextVNode(" We have sent an OTP to your email. Your OTP will expired in "),
                      createVNode("span", { class: "whitespace-nowrap" }, toDisplayString(unref($countdownHelper).expiredTime) + " seconds ", 1)
                    ])) : createCommentVNode("", true),
                    unref($countdownHelper).showExpired ? (openBlock(), createBlock("div", {
                      key: 1,
                      class: "text-error text-xs"
                    }, " Your OTP has expired. Please request a new one ")) : createCommentVNode("", true)
                  ])
                ]),
                createVNode("div", { class: "flex justify-center" }, [
                  createVNode(_component_UIBtn, {
                    type: "submit",
                    disabled: unref(loading),
                    variant: "primary"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Submit ")
                    ]),
                    _: 1
                  }, 8, ["disabled"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ForgotPassword/VerifiedOTP.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Change",
  __ssrInlineRender: true,
  props: {
    email: {},
    pin: {},
    usedBy: { default: "user" }
  },
  setup(__props) {
    const props = __props;
    const router = useRouter();
    function updateToParent() {
      router.push(props.usedBy === "user" ? "/sign-in" : "/admin/sign-in");
    }
    const {
      loading,
      message,
      alertType,
      $setNewPasswordForgotPassword,
      $credentialForgotPassword
    } = useAuth({
      usedBy: props.usedBy,
      callback: updateToParent
    });
    const { resetPasswordSchema } = useSchema();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIAlert = _sfc_main$3;
      const _component_UIFormMGroup = _sfc_main$4;
      const _component_UIFormMTextField = _sfc_main$5;
      const _component_UIBtn = _sfc_main$6;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        onSubmit: unref($setNewPasswordForgotPassword),
        "validation-schema": unref(resetPasswordSchema)
      }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 w-[450px] text-left gap-4 p-4 rounded-md shadow"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIAlert, {
              modelValue: unref(message),
              "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
              type: unref(alertType)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Password",
              name: "password"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: unref($credentialForgotPassword).password,
                    "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).password = $event,
                    name: "password",
                    placeholder: "*******",
                    type: "password",
                    class: "input input-bordered"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref($credentialForgotPassword).password,
                      "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).password = $event,
                      name: "password",
                      placeholder: "*******",
                      type: "password",
                      class: "input input-bordered"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Confirm Password",
              name: "confirm_password"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: unref($credentialForgotPassword).confirm_password,
                    "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).confirm_password = $event,
                    name: "confirm_password",
                    type: "password",
                    placeholder: "*******",
                    class: "input input-bordered"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref($credentialForgotPassword).confirm_password,
                      "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).confirm_password = $event,
                      name: "confirm_password",
                      type: "password",
                      placeholder: "*******",
                      class: "input input-bordered"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}><p class="text-gray-400"${_scopeId}>${ssrInterpolate(_ctx.$t("kami-akan-mengirimkan"))}</p></div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              disabled: unref(loading),
              variant: "primary",
              type: "submit"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Submit`);
                } else {
                  return [
                    createTextVNode("Submit")
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 w-[450px] text-left gap-4 p-4 rounded-md shadow" }, [
                createVNode(_component_UIAlert, {
                  modelValue: unref(message),
                  "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
                  type: unref(alertType)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "type"]),
                createVNode(_component_UIFormMGroup, {
                  label: "Password",
                  name: "password"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref($credentialForgotPassword).password,
                      "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).password = $event,
                      name: "password",
                      placeholder: "*******",
                      type: "password",
                      class: "input input-bordered"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  label: "Confirm Password",
                  name: "confirm_password"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref($credentialForgotPassword).confirm_password,
                      "onUpdate:modelValue": ($event) => unref($credentialForgotPassword).confirm_password = $event,
                      name: "confirm_password",
                      type: "password",
                      placeholder: "*******",
                      class: "input input-bordered"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode("div", null, [
                  createVNode("p", { class: "text-gray-400" }, toDisplayString(_ctx.$t("kami-akan-mengirimkan")), 1)
                ]),
                createVNode("div", null, [
                  createVNode(_component_UIBtn, {
                    disabled: unref(loading),
                    variant: "primary",
                    type: "submit"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Submit")
                    ]),
                    _: 1
                  }, 8, ["disabled"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ForgotPassword/Change.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main$2 as _, _sfc_main$1 as a, _sfc_main as b };
//# sourceMappingURL=Change-5e0500a5.mjs.map
