import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { ref, mergeProps, useSSRContext } from 'vue';
import { e as _export_sfc } from '../server.mjs';
import { _ as _sfc_main$2 } from './SelectedCard-bf5abcb8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './Icon-7218f0f6.mjs';
import './config-aab100d3.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';

const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><div class="space-y-4 p-4 border rounded-xl"><div class="flex flex-col lg:flex-row lg:justify-between item-center"><div class="text-lg font-semibold"> Silvester Wali </div><div class="flex flex-col lg:flex-row space-y-4 lg:space-y-0 space-x-0 lg:space-x-4"><div class="flex flex-col space-y-1"><div class="text-xs text-zinc-400">Email</div><div> Silvester@example.com </div></div><div class="flex flex-col space-y-1"><div class="text-xs text-zinc-400">Nomor Telepon</div><div> 08123456789 </div></div></div></div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vehicle/OrdererCard.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = {
  __name: "checkout",
  __ssrInlineRender: true,
  setup(__props) {
    ref({
      sort: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VehicleOrdererCard = __nuxt_component_0;
      const _component_VehicleSelectedCard = _sfc_main$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col space-y-6" }, _attrs))}><div class="flex justify-between items-center"><div class="text-2xl font-semibold"> Data Pemesan </div></div><div class="space-y-4">`);
      _push(ssrRenderComponent(_component_VehicleOrdererCard, null, null, _parent));
      _push(`</div><div class="flex justify-between items-center"><div class="text-2xl font-semibold"> Detail Mobil </div></div><div class="space-y-4">`);
      _push(ssrRenderComponent(_component_VehicleSelectedCard, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/vehicles/checkout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=checkout-d1d35258.mjs.map
