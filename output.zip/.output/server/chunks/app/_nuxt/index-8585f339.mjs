import { _ as __nuxt_component_0 } from './Container-f78810bd.mjs';
import { _ as _sfc_main$2 } from './SelectedCard-f7c91828.mjs';
import { u as useAuth, e as useRequestOptions, b as useRouter, i as useFetch, a as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import { Form, Field } from 'vee-validate';
import { _ as _sfc_main$3 } from './MGroup-56a6a0a6.mjs';
import { _ as _sfc_main$4 } from './MTextField-bd75102a.mjs';
import { u as useTourForm } from './useTourStore-4a6f0bac.mjs';
import { useSSRContext, withAsyncContext, ref, withCtx, unref, createVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, createCommentVNode, defineComponent, watch } from 'vue';
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr, ssrRenderAttrs } from 'vue/server-renderer';
import { useRouter as useRouter$1 } from 'vue-router';
import { _ as _sfc_main$5 } from './MSelect-8e6f95b5.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './TransitionX-601819e8.mjs';
import 'clsx';
import './nofication-1c3cca5e.mjs';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "OrdererForm",
  __ssrInlineRender: true,
  props: {
    name: {
      type: String,
      required: false
    },
    email: {
      type: String,
      required: false
    },
    phone: {
      type: String,
      required: false
    }
  },
  emits: ["update:name", "update:email", "update:phone"],
  setup(__props, { emit }) {
    const props = __props;
    useRouter$1();
    useTourForm({
      callback: () => {
        alert("Form has been submitted!");
      }
    });
    const dataFormProfile = ref({
      name: props.name,
      email: props.email,
      phone: props.phone
    });
    watch(
      () => props.name,
      (newName) => {
        dataFormProfile.value.name = newName;
      }
    );
    watch(
      () => props.email,
      (newEmail) => {
        dataFormProfile.value.email = newEmail;
      }
    );
    watch(
      () => props.phone,
      (newPhone) => {
        dataFormProfile.value.phone = newPhone;
      }
    );
    function onSubmit() {
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIFormMGroup = _sfc_main$3;
      const _component_UIFormMTextField = _sfc_main$4;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_VeeForm, { onSubmit }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 lg:grid-cols-3 p-4 gap-4 border rounded-xl"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "name",
              label: "Nama Lengkap"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: dataFormProfile.value.name,
                    "onUpdate:modelValue": ($event) => dataFormProfile.value.name = $event,
                    name: "name",
                    class: "input-bordered",
                    placeholder: "ex:John Doe"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: dataFormProfile.value.name,
                      "onUpdate:modelValue": ($event) => dataFormProfile.value.name = $event,
                      name: "name",
                      class: "input-bordered",
                      placeholder: "ex:John Doe"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "email",
              label: "Email"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: dataFormProfile.value.email,
                    "onUpdate:modelValue": ($event) => dataFormProfile.value.email = $event,
                    name: "email",
                    class: "input-bordered",
                    placeholder: "ex:myemail@gmail.com"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: dataFormProfile.value.email,
                      "onUpdate:modelValue": ($event) => dataFormProfile.value.email = $event,
                      name: "email",
                      class: "input-bordered",
                      placeholder: "ex:myemail@gmail.com"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "phone",
              label: "Phone"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: dataFormProfile.value.phone,
                    "onUpdate:modelValue": ($event) => dataFormProfile.value.phone = $event,
                    name: "phone",
                    class: "input-bordered",
                    placeholder: "ex:081234567890"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: dataFormProfile.value.phone,
                      "onUpdate:modelValue": ($event) => dataFormProfile.value.phone = $event,
                      name: "phone",
                      class: "input-bordered",
                      placeholder: "ex:081234567890"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="hidden"${_scopeId}><button type="submit"${_scopeId}>submit</button></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-3 p-4 gap-4 border rounded-xl" }, [
                createVNode(_component_UIFormMGroup, {
                  name: "name",
                  label: "Nama Lengkap"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: dataFormProfile.value.name,
                      "onUpdate:modelValue": ($event) => dataFormProfile.value.name = $event,
                      name: "name",
                      class: "input-bordered",
                      placeholder: "ex:John Doe"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  name: "email",
                  label: "Email"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: dataFormProfile.value.email,
                      "onUpdate:modelValue": ($event) => dataFormProfile.value.email = $event,
                      name: "email",
                      class: "input-bordered",
                      placeholder: "ex:myemail@gmail.com"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  name: "phone",
                  label: "Phone"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: dataFormProfile.value.phone,
                      "onUpdate:modelValue": ($event) => dataFormProfile.value.phone = $event,
                      name: "phone",
                      class: "input-bordered",
                      placeholder: "ex:081234567890"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode("div", { class: "hidden" }, [
                  createVNode("button", {
                    ref: "btnSubmit",
                    type: "submit"
                  }, "submit", 512)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/OrdererForm.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { $isLoggedIn, $isUser, $logout } = useAuth();
    useRequestOptions();
    const router = useRouter();
    const { data: dataCountry } = ([__temp, __restore] = withAsyncContext(() => useFetch("/api/country", "$nBZG9g13kK")), __temp = await __temp, __restore(), __temp);
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedTourData,
      clearSavedTourData
    } = useTourForm({
      callback: () => {
        console.log("Form has been submitted!");
      }
    });
    ref(null);
    const dataFormT = ref({
      user_uuid: void 0,
      name: void 0,
      email: void 0,
      phone: void 0
    });
    const dataFormParticitpant = ref([]);
    ref({
      sort: ""
    });
    function getParticipantIndex(variantIndex, participantIndex) {
      let index = 0;
      for (let i = 0; i < variantIndex; i++) {
        index += dataForm.value.variants[i].quantity;
      }
      return index + participantIndex;
    }
    function onSubmit() {
      dataForm.value.user_uuid = dataFormT.value.user_uuid;
      dataForm.value.name = dataFormT.value.name;
      dataForm.value.email = dataFormT.value.email;
      dataForm.value.phone = dataFormT.value.phone;
      dataForm.value.forms = dataFormParticitpant.value;
      saveFormData();
      console.log("ini di booking", dataForm.value);
      router.push("/tours/booking/checkout");
    }
    useHead({
      title: "Booking tours"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_TourSelectedCard = _sfc_main$2;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_TourOrdererForm = _sfc_main$1;
      const _component_VeeForm = Form;
      const _component_VeeField = Field;
      const _component_UIFormMGroup = _sfc_main$3;
      const _component_UIFormMTextField = _sfc_main$4;
      const _component_UIFormMSelect = _sfc_main$5;
      _push(`<!--[--><div class="h-28"></div>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 divide-x-2"${_scopeId}><div class="space-y-6 py-4"${_scopeId}><h3 class="text-2xl font-semibold text-primary-dark"${_scopeId}>${ssrInterpolate(_ctx.$t("pesanan-anda"))}</h3><div class="space-y-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_TourSelectedCard, {
              image: unref(dataForm).tour_image,
              name: unref(dataForm).tour_name,
              desk: unref(dataForm).list_location_string
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="p-4 border-2 relative"${_scopeId}>`);
            if (!unref($isUser)) {
              _push2(ssrRenderComponent(_component_NuxtLink, {
                to: "/sign-in",
                class: "absolute w-full h-full z-[200] bg-opacity-0"
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="flex flex-col space-y-6"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><div class="text-2xl font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("data-pemesan"))}</div></div><div class="space-y-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_TourOrdererForm, {
              name: unref(dataFormT).name,
              email: unref(dataFormT).email,
              phone: unref(dataFormT).phone,
              "onUpdate:name": ($event) => unref(dataFormT).name = $event,
              "onUpdate:email": ($event) => unref(dataFormT).email = $event,
              "onUpdate:phone": ($event) => unref(dataFormT).phone = $event
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-between items-center"${_scopeId}><div class="text-2xl font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("data-peserta"))}</div></div><div class="space-y-4"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeForm, { onSubmit }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(unref(dataForm).variants, (item, variantIndex) => {
                    _push3(`<div class="rounded-xl grid grid-cols-1 divide-y"${_scopeId2}><div class="my-3"${_scopeId2}>${ssrInterpolate(item.quantity > 0 ? item.name : "")}</div><!--[-->`);
                    ssrRenderList(item.quantity, (n, participantIndex) => {
                      _push3(`<div class="p-4"${_scopeId2}>`);
                      _push3(ssrRenderComponent(_component_VeeField, {
                        modelValue: unref(dataFormParticitpant)[getParticipantIndex(variantIndex, participantIndex)].variant_id,
                        "onUpdate:modelValue": ($event) => unref(dataFormParticitpant)[getParticipantIndex(variantIndex, participantIndex)].variant_id = $event,
                        type: "text",
                        name: "variant_id",
                        class: "border hidden",
                        id: "variant_id"
                      }, null, _parent3, _scopeId2));
                      _push3(`<div class="grid grid-cols-1 lg:grid-cols-3 gap-4"${_scopeId2}>`);
                      _push3(ssrRenderComponent(_component_UIFormMGroup, {
                        name: `name` + getParticipantIndex(variantIndex, participantIndex),
                        label: "Nama Lengkap"
                      }, {
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(ssrRenderComponent(_component_UIFormMTextField, {
                              modelValue: unref(dataFormParticitpant)[getParticipantIndex(
                                variantIndex,
                                participantIndex
                              )].name,
                              "onUpdate:modelValue": ($event) => unref(dataFormParticitpant)[getParticipantIndex(
                                variantIndex,
                                participantIndex
                              )].name = $event,
                              name: `name` + getParticipantIndex(variantIndex, participantIndex),
                              class: "input-bordered",
                              placeholder: "ex:John Doe"
                            }, null, _parent4, _scopeId3));
                          } else {
                            return [
                              createVNode(_component_UIFormMTextField, {
                                modelValue: unref(dataFormParticitpant)[getParticipantIndex(
                                  variantIndex,
                                  participantIndex
                                )].name,
                                "onUpdate:modelValue": ($event) => unref(dataFormParticitpant)[getParticipantIndex(
                                  variantIndex,
                                  participantIndex
                                )].name = $event,
                                name: `name` + getParticipantIndex(variantIndex, participantIndex),
                                class: "input-bordered",
                                placeholder: "ex:John Doe"
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "name"])
                            ];
                          }
                        }),
                        _: 2
                      }, _parent3, _scopeId2));
                      _push3(ssrRenderComponent(_component_UIFormMGroup, {
                        name: `nationality` + getParticipantIndex(variantIndex, participantIndex),
                        label: "Kebangsaan"
                      }, {
                        default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(ssrRenderComponent(_component_UIFormMSelect, {
                              modelValue: unref(dataFormParticitpant)[getParticipantIndex(
                                variantIndex,
                                participantIndex
                              )].nationality,
                              "onUpdate:modelValue": ($event) => unref(dataFormParticitpant)[getParticipantIndex(
                                variantIndex,
                                participantIndex
                              )].nationality = $event,
                              name: `nationality` + getParticipantIndex(variantIndex, participantIndex),
                              class: "input-bordered",
                              placeholder: "ex: Indonesia"
                            }, {
                              default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                                if (_push5) {
                                  _push5(`<option value=""${_scopeId4}>${ssrInterpolate(_ctx.$t("pilih-kebangsaan"))}</option><!--[-->`);
                                  ssrRenderList(unref(dataCountry), (item2) => {
                                    _push5(`<option${ssrRenderAttr("value", item2.name)}${_scopeId4}>${ssrInterpolate(item2.name)}</option>`);
                                  });
                                  _push5(`<!--]-->`);
                                } else {
                                  return [
                                    createVNode("option", { value: "" }, toDisplayString(_ctx.$t("pilih-kebangsaan")), 1),
                                    (openBlock(true), createBlock(Fragment, null, renderList(unref(dataCountry), (item2) => {
                                      return openBlock(), createBlock("option", {
                                        value: item2.name,
                                        key: item2.name
                                      }, toDisplayString(item2.name), 9, ["value"]);
                                    }), 128))
                                  ];
                                }
                              }),
                              _: 2
                            }, _parent4, _scopeId3));
                          } else {
                            return [
                              createVNode(_component_UIFormMSelect, {
                                modelValue: unref(dataFormParticitpant)[getParticipantIndex(
                                  variantIndex,
                                  participantIndex
                                )].nationality,
                                "onUpdate:modelValue": ($event) => unref(dataFormParticitpant)[getParticipantIndex(
                                  variantIndex,
                                  participantIndex
                                )].nationality = $event,
                                name: `nationality` + getParticipantIndex(variantIndex, participantIndex),
                                class: "input-bordered",
                                placeholder: "ex: Indonesia"
                              }, {
                                default: withCtx(() => [
                                  createVNode("option", { value: "" }, toDisplayString(_ctx.$t("pilih-kebangsaan")), 1),
                                  (openBlock(true), createBlock(Fragment, null, renderList(unref(dataCountry), (item2) => {
                                    return openBlock(), createBlock("option", {
                                      value: item2.name,
                                      key: item2.name
                                    }, toDisplayString(item2.name), 9, ["value"]);
                                  }), 128))
                                ]),
                                _: 2
                              }, 1032, ["modelValue", "onUpdate:modelValue", "name"])
                            ];
                          }
                        }),
                        _: 2
                      }, _parent3, _scopeId2));
                      _push3(`</div></div>`);
                    });
                    _push3(`<!--]--></div>`);
                  });
                  _push3(`<!--]--><div class="flex justify-end"${_scopeId2}><div class="btn btn-md bg-primary"${_scopeId2}><button type="submit" class="text-white"${_scopeId2}>${ssrInterpolate(_ctx.$t("lanjutkan"))}</button></div></div>`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(dataForm).variants, (item, variantIndex) => {
                      return openBlock(), createBlock("div", {
                        class: "rounded-xl grid grid-cols-1 divide-y",
                        key: variantIndex
                      }, [
                        createVNode("div", { class: "my-3" }, toDisplayString(item.quantity > 0 ? item.name : ""), 1),
                        (openBlock(true), createBlock(Fragment, null, renderList(item.quantity, (n, participantIndex) => {
                          return openBlock(), createBlock("div", {
                            class: "p-4",
                            key: participantIndex
                          }, [
                            createVNode(_component_VeeField, {
                              modelValue: unref(dataFormParticitpant)[getParticipantIndex(variantIndex, participantIndex)].variant_id,
                              "onUpdate:modelValue": ($event) => unref(dataFormParticitpant)[getParticipantIndex(variantIndex, participantIndex)].variant_id = $event,
                              type: "text",
                              name: "variant_id",
                              class: "border hidden",
                              id: "variant_id"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-3 gap-4" }, [
                              createVNode(_component_UIFormMGroup, {
                                name: `name` + getParticipantIndex(variantIndex, participantIndex),
                                label: "Nama Lengkap"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_UIFormMTextField, {
                                    modelValue: unref(dataFormParticitpant)[getParticipantIndex(
                                      variantIndex,
                                      participantIndex
                                    )].name,
                                    "onUpdate:modelValue": ($event) => unref(dataFormParticitpant)[getParticipantIndex(
                                      variantIndex,
                                      participantIndex
                                    )].name = $event,
                                    name: `name` + getParticipantIndex(variantIndex, participantIndex),
                                    class: "input-bordered",
                                    placeholder: "ex:John Doe"
                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "name"])
                                ]),
                                _: 2
                              }, 1032, ["name"]),
                              createVNode(_component_UIFormMGroup, {
                                name: `nationality` + getParticipantIndex(variantIndex, participantIndex),
                                label: "Kebangsaan"
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_UIFormMSelect, {
                                    modelValue: unref(dataFormParticitpant)[getParticipantIndex(
                                      variantIndex,
                                      participantIndex
                                    )].nationality,
                                    "onUpdate:modelValue": ($event) => unref(dataFormParticitpant)[getParticipantIndex(
                                      variantIndex,
                                      participantIndex
                                    )].nationality = $event,
                                    name: `nationality` + getParticipantIndex(variantIndex, participantIndex),
                                    class: "input-bordered",
                                    placeholder: "ex: Indonesia"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("option", { value: "" }, toDisplayString(_ctx.$t("pilih-kebangsaan")), 1),
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(dataCountry), (item2) => {
                                        return openBlock(), createBlock("option", {
                                          value: item2.name,
                                          key: item2.name
                                        }, toDisplayString(item2.name), 9, ["value"]);
                                      }), 128))
                                    ]),
                                    _: 2
                                  }, 1032, ["modelValue", "onUpdate:modelValue", "name"])
                                ]),
                                _: 2
                              }, 1032, ["name"])
                            ])
                          ]);
                        }), 128))
                      ]);
                    }), 128)),
                    createVNode("div", { class: "flex justify-end" }, [
                      createVNode("div", { class: "btn btn-md bg-primary" }, [
                        createVNode("button", {
                          ref: "btnSubmit",
                          type: "submit",
                          class: "text-white"
                        }, toDisplayString(_ctx.$t("lanjutkan")), 513)
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 divide-x-2" }, [
                createVNode("div", { class: "space-y-6 py-4" }, [
                  createVNode("h3", { class: "text-2xl font-semibold text-primary-dark" }, toDisplayString(_ctx.$t("pesanan-anda")), 1),
                  createVNode("div", { class: "space-y-4" }, [
                    createVNode(_component_TourSelectedCard, {
                      image: unref(dataForm).tour_image,
                      name: unref(dataForm).tour_name,
                      desk: unref(dataForm).list_location_string
                    }, null, 8, ["image", "name", "desk"])
                  ])
                ]),
                createVNode("div", { class: "p-4 border-2 relative" }, [
                  !unref($isUser) ? (openBlock(), createBlock(_component_NuxtLink, {
                    key: 0,
                    to: "/sign-in",
                    class: "absolute w-full h-full z-[200] bg-opacity-0"
                  })) : createCommentVNode("", true),
                  createVNode("div", { class: "flex flex-col space-y-6" }, [
                    createVNode("div", { class: "flex justify-between items-center" }, [
                      createVNode("div", { class: "text-2xl font-semibold" }, toDisplayString(_ctx.$t("data-pemesan")), 1)
                    ]),
                    createVNode("div", { class: "space-y-4" }, [
                      createVNode(_component_TourOrdererForm, {
                        name: unref(dataFormT).name,
                        email: unref(dataFormT).email,
                        phone: unref(dataFormT).phone,
                        "onUpdate:name": ($event) => unref(dataFormT).name = $event,
                        "onUpdate:email": ($event) => unref(dataFormT).email = $event,
                        "onUpdate:phone": ($event) => unref(dataFormT).phone = $event
                      }, null, 8, ["name", "email", "phone", "onUpdate:name", "onUpdate:email", "onUpdate:phone"])
                    ]),
                    createVNode("div", { class: "flex justify-between items-center" }, [
                      createVNode("div", { class: "text-2xl font-semibold" }, toDisplayString(_ctx.$t("data-peserta")), 1)
                    ]),
                    createVNode("div", { class: "space-y-4" }, [
                      createVNode("div", null, [
                        createVNode(_component_VeeForm, { onSubmit }, {
                          default: withCtx(() => [
                            (openBlock(true), createBlock(Fragment, null, renderList(unref(dataForm).variants, (item, variantIndex) => {
                              return openBlock(), createBlock("div", {
                                class: "rounded-xl grid grid-cols-1 divide-y",
                                key: variantIndex
                              }, [
                                createVNode("div", { class: "my-3" }, toDisplayString(item.quantity > 0 ? item.name : ""), 1),
                                (openBlock(true), createBlock(Fragment, null, renderList(item.quantity, (n, participantIndex) => {
                                  return openBlock(), createBlock("div", {
                                    class: "p-4",
                                    key: participantIndex
                                  }, [
                                    createVNode(_component_VeeField, {
                                      modelValue: unref(dataFormParticitpant)[getParticipantIndex(variantIndex, participantIndex)].variant_id,
                                      "onUpdate:modelValue": ($event) => unref(dataFormParticitpant)[getParticipantIndex(variantIndex, participantIndex)].variant_id = $event,
                                      type: "text",
                                      name: "variant_id",
                                      class: "border hidden",
                                      id: "variant_id"
                                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                                    createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-3 gap-4" }, [
                                      createVNode(_component_UIFormMGroup, {
                                        name: `name` + getParticipantIndex(variantIndex, participantIndex),
                                        label: "Nama Lengkap"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_UIFormMTextField, {
                                            modelValue: unref(dataFormParticitpant)[getParticipantIndex(
                                              variantIndex,
                                              participantIndex
                                            )].name,
                                            "onUpdate:modelValue": ($event) => unref(dataFormParticitpant)[getParticipantIndex(
                                              variantIndex,
                                              participantIndex
                                            )].name = $event,
                                            name: `name` + getParticipantIndex(variantIndex, participantIndex),
                                            class: "input-bordered",
                                            placeholder: "ex:John Doe"
                                          }, null, 8, ["modelValue", "onUpdate:modelValue", "name"])
                                        ]),
                                        _: 2
                                      }, 1032, ["name"]),
                                      createVNode(_component_UIFormMGroup, {
                                        name: `nationality` + getParticipantIndex(variantIndex, participantIndex),
                                        label: "Kebangsaan"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_UIFormMSelect, {
                                            modelValue: unref(dataFormParticitpant)[getParticipantIndex(
                                              variantIndex,
                                              participantIndex
                                            )].nationality,
                                            "onUpdate:modelValue": ($event) => unref(dataFormParticitpant)[getParticipantIndex(
                                              variantIndex,
                                              participantIndex
                                            )].nationality = $event,
                                            name: `nationality` + getParticipantIndex(variantIndex, participantIndex),
                                            class: "input-bordered",
                                            placeholder: "ex: Indonesia"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode("option", { value: "" }, toDisplayString(_ctx.$t("pilih-kebangsaan")), 1),
                                              (openBlock(true), createBlock(Fragment, null, renderList(unref(dataCountry), (item2) => {
                                                return openBlock(), createBlock("option", {
                                                  value: item2.name,
                                                  key: item2.name
                                                }, toDisplayString(item2.name), 9, ["value"]);
                                              }), 128))
                                            ]),
                                            _: 2
                                          }, 1032, ["modelValue", "onUpdate:modelValue", "name"])
                                        ]),
                                        _: 2
                                      }, 1032, ["name"])
                                    ])
                                  ]);
                                }), 128))
                              ]);
                            }), 128)),
                            createVNode("div", { class: "flex justify-end" }, [
                              createVNode("div", { class: "btn btn-md bg-primary" }, [
                                createVNode("button", {
                                  ref: "btnSubmit",
                                  type: "submit",
                                  class: "text-white"
                                }, toDisplayString(_ctx.$t("lanjutkan")), 513)
                              ])
                            ])
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tours/booking/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-8585f339.mjs.map
