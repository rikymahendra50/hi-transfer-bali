import { _ as __nuxt_component_0 } from './TitleBack-14168b7f.mjs';
import { _ as _sfc_main$3 } from './Alert-6ab07811.mjs';
import __nuxt_component_1$1 from './Icon-f8c4e628.mjs';
import { _ as __nuxt_component_4 } from './client-only-53a57ea8.mjs';
import { b as useRouter, d as useRoute, e as useRequestOptions, g as useAsyncData, a as useHead, f as useI18n, h as useRequestHelper, i as useFetch } from '../server.mjs';
import { useSSRContext, defineComponent, computed, withAsyncContext, mergeProps, unref, ref, watch, isRef, withCtx, createVNode, openBlock, createBlock, createCommentVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import { b as useFileDialog } from './index-dea25161.mjs';
import draggable from 'vuedraggable';
import './TransitionTopToBottom-30d56c1a.mjs';
import './config-9e484511.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './index-596a8548.mjs';

const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "CropImage",
  __ssrInlineRender: true,
  props: {
    loading: {
      type: Boolean,
      default: false
    },
    existingImage: {
      type: String,
      default: () => null
    },
    modelValue: {
      type: [File],
      default: () => void 0
    }
  },
  emits: ["cancel", "update:modelValue", "@uploadImage", "deleteImage"],
  setup(__props, { expose: __expose, emit }) {
    const props = __props;
    useI18n();
    const modal = ref(false);
    const image = ref(null);
    computed(() => {
      if (image.value) {
        return URL.createObjectURL(image.value);
      }
      return props.existingImage;
    });
    ref();
    const imageReview = ref(null);
    const imageCropped = ref(null);
    computed(() => {
      return imageReview.value ? URL.createObjectURL(imageReview.value) : null;
    });
    computed(() => {
      return imageCropped.value ? URL.createObjectURL(imageCropped.value) : props.existingImage;
    });
    const { files, open, reset, onChange } = useFileDialog({
      accept: "image/*",
      // Set to accept only image files
      multiple: false
    });
    onChange((files2) => {
      if (!files2) {
        return;
      }
      image.value = files2[0];
      reset();
      modal.value = true;
    });
    function deleteImage() {
      imageCropped.value = null;
      emit("update:modelValue", void 0);
      emit("deleteImage");
    }
    watch(
      () => modal.value,
      (value) => {
        if (!value) {
          image.value = null;
        }
      }
    );
    __expose({
      modal,
      deleteImage
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_4;
      _push(ssrRenderComponent(_component_ClientOnly, _attrs, {}, _parent));
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CropImage.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "ImagesProduct",
  __ssrInlineRender: true,
  props: {
    productSlug: {
      type: String,
      required: true
    },
    imagesData: {
      type: Array
    }
  },
  emits: ["reload"],
  setup(__props, { emit }) {
    const props = __props;
    const { loading, message, setErrorMessage, alertType, setSuccessMessage } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const { locale } = useI18n();
    const cropHelper = ref();
    const arrayChange = ref(false);
    const onDragEnd = () => {
      arrayChange.value = true;
    };
    const images = ref([]);
    const ableToAddMoreImage = computed(() => {
      return images.value.length < 5;
    });
    function removeImage(element) {
      images.value = images.value.filter((image) => image.id !== element.id);
      arrayChange.value = true;
    }
    async function uploadImageToServer(image) {
      var _a, _b, _c, _d;
      loading.value = true;
      const formData = new FormData();
      formData.append("image", image);
      const { data, error } = await useFetch(
        `/admins/tours/${props.productSlug}/images?lang=${locale.value}`,
        {
          method: "POST",
          body: formData,
          ...requestOptions
        },
        "$R7wSCICl0e"
      );
      if (error.value) {
        setErrorMessage((_b = (_a = error.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message);
      } else {
        if ((_c = data.value) == null ? void 0 : _c.data) {
          images.value.push((_d = data.value) == null ? void 0 : _d.data);
          arrayChange.value = true;
        }
        if (cropHelper.value) {
          cropHelper.value.modal = false;
          cropHelper.value.deleteImage();
        }
      }
      loading.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Alert = _sfc_main$3;
      const _component_Icon = __nuxt_component_1$1;
      const _component_CropImage = _sfc_main$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-2" }, _attrs))}><div class="space-y-2">`);
      _push(ssrRenderComponent(_component_Alert, {
        modelValue: unref(message),
        "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
        type: unref(alertType)
      }, null, _parent));
      _push(ssrRenderComponent(unref(draggable), {
        modelValue: unref(images),
        "onUpdate:modelValue": ($event) => isRef(images) ? images.value = $event : null,
        group: "position",
        "item-key": "position",
        class: "grid grid-cols-1 md:grid-cols-3 gap-4",
        onChange: onDragEnd,
        draggable: ".draggable"
      }, {
        item: withCtx(({ element }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="overflow-hidden rounded-lg relative h-full w-full draggable"${_scopeId}><div class="absolute w-full flex justify-end z-10 p-2"${_scopeId}><div${_scopeId}><button class="bg-error rounded-lg p-2 text-white" type="button"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Icon, {
              name: "i-heroicons-trash",
              class: "h-6 w-6"
            }, null, _parent2, _scopeId));
            _push2(`</button></div></div><img${ssrRenderAttr("src", element.image)} alt="image review" class="h-full w-full object-cover max-h-[300px] object-top"${_scopeId}></div>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden rounded-lg relative h-full w-full draggable" }, [
                createVNode("div", { class: "absolute w-full flex justify-end z-10 p-2" }, [
                  createVNode("div", null, [
                    createVNode("button", {
                      class: "bg-error rounded-lg p-2 text-white",
                      type: "button",
                      onClick: ($event) => removeImage(element)
                    }, [
                      createVNode(_component_Icon, {
                        name: "i-heroicons-trash",
                        class: "h-6 w-6"
                      })
                    ], 8, ["onClick"])
                  ])
                ]),
                createVNode("img", {
                  src: element.image,
                  alt: "image review",
                  class: "h-full w-full object-cover max-h-[300px] object-top"
                }, null, 8, ["src"])
              ])
            ];
          }
        }),
        footer: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(ableToAddMoreImage)) {
              _push2(`<div${_scopeId}>`);
              _push2(ssrRenderComponent(_component_CropImage, {
                ref_key: "cropHelper",
                ref: cropHelper,
                loading: unref(loading),
                "on@uploadImage": uploadImageToServer
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              unref(ableToAddMoreImage) ? (openBlock(), createBlock("div", { key: 0 }, [
                createVNode(_component_CropImage, {
                  ref_key: "cropHelper",
                  ref: cropHelper,
                  loading: unref(loading),
                  "on@uploadImage": uploadImageToServer
                }, null, 8, ["loading"])
              ])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      if (unref(arrayChange)) {
        _push(`<div class="space-y-4"><p>Anda telah merubah posisi gambar</p><button type="button"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""}${ssrRenderAttr("loading", unref(loading))} class="btn btn-primary btn-md normal-case"> Simpan </button></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ImagesProduct.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$1;
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "images",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRouter();
    const route = useRoute();
    const { requestOptions } = useRequestOptions();
    const slug = computed(() => {
      return route.params.slug;
    });
    const { data, refresh, pending } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      `tourImageAdmin`,
      () => $fetch(`/admins/tours/${slug.value}/images`, {
        method: "GET",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    function onReload() {
      refresh();
    }
    useHead({
      title: "Product Create"
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_TitleBack = __nuxt_component_0;
      const _component_ImagesProduct = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "m-5 flex flex-col gap-3" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_TitleBack, {
        title: "Kelola gambar paket tur",
        link: "/admin/tour-package"
      }, null, _parent));
      _push(`<div class="h-screen"><div class="h-[500px] m-3">`);
      if (!unref(pending)) {
        _push(ssrRenderComponent(_component_ImagesProduct, {
          productSlug: unref(slug),
          "images-data": (_a = unref(data)) == null ? void 0 : _a.data,
          onReload
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/tour-package/[slug]/images.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=images-468707d7.mjs.map
