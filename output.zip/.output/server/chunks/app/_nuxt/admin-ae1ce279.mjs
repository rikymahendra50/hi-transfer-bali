import { b as useAuth, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_1 from './Icon-7218f0f6.mjs';
import { defineComponent, ref, watch, withCtx, createVNode, unref, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _imports_0 } from './hi-transfer-logo-97c0b5ac.mjs';
import { a as useBreakpoints, b as breakpointsTailwind, o as onClickOutside } from './index-1df0d9ef.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-aab100d3.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "admin",
  __ssrInlineRender: true,
  setup(__props) {
    const linksAllowed = ref([
      {
        to: "/admin",
        icon: "i-heroicons-home",
        label: "Dashboard"
      },
      {
        to: "/admin/vehicles",
        icon: "i-heroicons-truck",
        label: "Vehicles"
      },
      {
        to: "/admin/tours",
        icon: "i-heroicons-calendar",
        label: "Tours"
      }
    ]);
    const breakpoints = useBreakpoints(breakpointsTailwind);
    useAuth();
    const drawer = ref(true);
    const tableOrLaptop = breakpoints.greater("md");
    const aside = ref();
    onClickOutside(aside, () => {
      if (!tableOrLaptop.value && drawer.value)
        drawer.value = false;
    });
    watch(() => tableOrLaptop.value, (value) => {
      if (value && !drawer.value) {
        drawer.value = tableOrLaptop.value;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class=""><div class="px-6 h-24 border-b flex flex-row items-center">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "link link-primary link-hover p-1 underline-offset-8 decoration-4 rounded",
        "active-class": "font-medium",
        to: "/admin"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="logo" class="w-11 h-11"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                alt: "logo",
                class: "w-11 h-11"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      if (!unref(drawer)) {
        _push(`<button class="block lg:hidden" type="button">`);
        _push(ssrRenderComponent(_component_Icon, {
          name: "i-heroicons-bars-3",
          class: "w-6 h-6 opacity-50"
        }, null, _parent));
        _push(`</button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="relative lg:static lg:grid lg:grid-cols-[300px_1fr]">`);
      if (unref(drawer)) {
        _push(`<aside class="absolute lg:static z-50 lg:z-0 min-h-screen w-[300px] border-r bg-white"><div class="flex flex-col h-full"><div class="p-4 flex-grow flex-shrink h-full"><ul class="space-y-3 lg:space-y-3.5"><!--[-->`);
        ssrRenderList(unref(linksAllowed), (item) => {
          _push(`<li>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: item.to,
            class: "inline-flex ring-1 ring-primary ring-offset-1 items-center space-x-2.5 hover:bg-primary text-secondary hover:text-white transition-all duration-500 p-2 rounded-lg group w-full hover:scale-x-95 text-sm",
            "active-class": "bg-primary !text-white"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(_component_Icon, {
                  name: item.icon,
                  class: "h-5 w-5 opacity-80"
                }, null, _parent2, _scopeId));
                _push2(`<span class="text-sm"${_scopeId}>${ssrInterpolate(item.label)}</span>`);
              } else {
                return [
                  createVNode(_component_Icon, {
                    name: item.icon,
                    class: "h-5 w-5 opacity-80"
                  }, null, 8, ["name"]),
                  createVNode("span", { class: "text-sm" }, toDisplayString(item.label), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--></ul></div><div class="mb-16 px-4 mt-10"><div class="border-t py-2"><button type="button" class="flex flex-row space-x-2 items-center text-red-500 font-medium">`);
        _push(ssrRenderComponent(_component_Icon, {
          name: "ic:baseline-logout",
          class: "w-6 h-6"
        }, null, _parent));
        _push(`<span>Logout</span></button></div></div></div></aside>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="w-full absolute lg:static min-h-svh overflow-y-auto space-y-6"><main><div class="p-4 lg:p-8">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></main></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/admin.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=admin-ae1ce279.mjs.map
