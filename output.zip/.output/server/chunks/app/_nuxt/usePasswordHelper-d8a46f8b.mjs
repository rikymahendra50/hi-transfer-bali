import { ref } from 'vue';

function usePasswordHelper() {
  const inputType = ref("password");
  function toggleInputType() {
    inputType.value = inputType.value == "password" ? "text" : "password";
  }
  return { inputType, toggleInputType };
}

export { usePasswordHelper as u };
//# sourceMappingURL=usePasswordHelper-d8a46f8b.mjs.map
