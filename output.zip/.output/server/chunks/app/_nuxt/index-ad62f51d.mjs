import { _ as __nuxt_component_0 } from './TitleAdmin-130db81a.mjs';
import { _ as __nuxt_component_1 } from './ButtonAddAdmin-5d073899.mjs';
import __nuxt_component_0$1 from './Icon-0f6314e3.mjs';
import { ref, withAsyncContext, watch, resolveComponent, withCtx, createVNode, unref, createTextVNode, isRef, withModifiers, useSSRContext, mergeProps } from 'vue';
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttrs } from 'vue/server-renderer';
import { e as useRequestOptions, b as useRouter, d as useRoute, g as useAsyncData, a as useHead, _ as __nuxt_component_0$1$1 } from '../server.mjs';
import { _ as __nuxt_component_2$1 } from './PaginationAdmin-f2cea012.mjs';
import { _ as __nuxt_component_3 } from './Modal-967d83e0.mjs';
import { o as withQuery } from '../../nitro/node-server.mjs';
import { u as useTransport } from './useTransport-bdd5bf0b.mjs';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import './config-3cecc2b8.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './index-a61f78d7.mjs';
import './index-596a8548.mjs';
import './nofication-1c3cca5e.mjs';

const _sfc_main$1 = {
  __name: "StatusTrueOrFalse",
  __ssrInlineRender: true,
  props: {
    trueString: {
      type: String
    },
    falseString: {
      type: String
    },
    trueNumber: {
      type: [Number, Boolean]
    },
    falseNumber: {
      type: [Number, Boolean]
    },
    data: {
      type: [Number, String, Boolean]
    }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["px-3 py-1 w-fit rounded-xl", {
          "bg-[#ECFDF3] text-[#037847]": __props.data === props.trueNumber,
          "bg-[#EF4444] bg-opacity-[12%] text-error": __props.data === props.falseNumber
        }]
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "icon-park-outline:dot",
        class: {
          "text-[#22C55E]": __props.data === props.trueNumber,
          "text-[#EF4444]": __props.data === props.falseNumber
        }
      }, null, _parent));
      _push(` ${ssrInterpolate(__props.data === props.trueNumber ? props.trueString : props.falseString)}</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/StatusTrueOrFalse.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$1;
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    const route = useRoute();
    const page = ref(1);
    if (route.query.page) {
      page.value = Number(route.query.page);
    }
    const showModalDelete = ref(false);
    const currentId = ref(void 0);
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "transport",
      () => $fetch(`/admins/cars?page=${page.value}`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    const { selectedTransport, deleteTransport, loading } = useTransport({
      callback: refresh
    });
    watch(page, (newValue, oldValue) => {
      if (newValue !== oldValue) {
        router.replace(
          withQuery("/admin/transport", {
            page: newValue
          })
        );
      }
    });
    function showModalDeleteFunc(hide, id) {
      showModalDelete.value = !showModalDelete.value;
      hide();
      if (showModalDelete.value) {
        currentId.value = id;
      } else {
        currentId.value = void 0;
      }
    }
    useHead({
      title: "Transport"
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
      const _component_TitleAdmin = __nuxt_component_0;
      const _component_ButtonAddAdmin = __nuxt_component_1;
      const _component_StatusTrueOrFalse = __nuxt_component_2;
      const _component_VDropdown = resolveComponent("VDropdown");
      const _component_Icon = __nuxt_component_0$1;
      const _component_NuxtLink = __nuxt_component_0$1$1;
      const _component_PaginationAdmin = __nuxt_component_2$1;
      const _component_modal = __nuxt_component_3;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_TitleAdmin, {
        title: "Kelola Produk: Transport",
        subTitle: "Kelola daftar mobil Anda disini"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_ButtonAddAdmin, {
              link: "/admin/transport/add",
              name: "Tambah Mobil Baru"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_ButtonAddAdmin, {
                link: "/admin/transport/add",
                name: "Tambah Mobil Baru"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<table class="table"><thead><tr><th><div class="text-[#989393]">Nama Mobil</div></th><th><div>Harga Per KM</div></th><th><div>Status mobil</div></th></tr></thead><tbody><!--[-->`);
      ssrRenderList((_a = unref(data)) == null ? void 0 : _a.data, (item) => {
        _push(`<tr><td class="text-sm font-normal"><div class="font-medium text-[14px] text-black">${ssrInterpolate(item == null ? void 0 : item.name)}</div></td><td class="text-sm font-normal text-[#989393]">${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(item == null ? void 0 : item.price))}</td><td class="text-sm font-normal text-[#989393]">`);
        _push(ssrRenderComponent(_component_StatusTrueOrFalse, {
          trueString: "Tersedia",
          falseString: "Tidak tersedia",
          trueNumber: 1,
          falseNumber: 0,
          data: item == null ? void 0 : item.is_active
        }, null, _parent));
        _push(`</td><td><div class="flex items-center">`);
        _push(ssrRenderComponent(_component_VDropdown, null, {
          popper: withCtx(({ hide }, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="bg-white flex flex-col shadow"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_NuxtLink, {
                to: `/admin/transport/edit/${item == null ? void 0 : item.slug}`,
                class: "hover:bg-orange-400 hover:text-white py-2 px-3"
              }, {
                default: withCtx((_, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Edit `);
                  } else {
                    return [
                      createTextVNode(" Edit ")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`<button type="button" class="hover:bg-red-600 hover:text-white py-2 px-3"${_scopeId}> Delete </button></div>`);
            } else {
              return [
                createVNode("div", { class: "bg-white flex flex-col shadow" }, [
                  createVNode(_component_NuxtLink, {
                    to: `/admin/transport/edit/${item == null ? void 0 : item.slug}`,
                    class: "hover:bg-orange-400 hover:text-white py-2 px-3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Edit ")
                    ]),
                    _: 2
                  }, 1032, ["to"]),
                  createVNode("button", {
                    onClick: ($event) => showModalDeleteFunc(hide, item == null ? void 0 : item.slug),
                    type: "button",
                    class: "hover:bg-red-600 hover:text-white py-2 px-3"
                  }, " Delete ", 8, ["onClick"])
                ])
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex items-center justify-center"${_scopeId}><button class="flex items-center justify-center cursor-pointer"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, {
                name: "pepicons-pencil:dots-y",
                class: "text-[#717171]"
              }, null, _parent2, _scopeId));
              _push2(`</button></div>`);
            } else {
              return [
                createVNode("div", { class: "flex items-center justify-center" }, [
                  createVNode("button", { class: "flex items-center justify-center cursor-pointer" }, [
                    createVNode(_component_Icon, {
                      name: "pepicons-pencil:dots-y",
                      class: "text-[#717171]"
                    })
                  ])
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></td></tr>`);
      });
      _push(`<!--]--></tbody></table><div class="flex flex-col md:flex-row items-center justify-between gap-3 w-full py-3 px-3"><div class="flex items-center gap-3"><div class="py-2 px-3 rounded-[8px]"><p class="font-medium text-[12px] md:text-sm text-[#121212]">${ssrInterpolate((_c = (_b = unref(data)) == null ? void 0 : _b.meta) == null ? void 0 : _c.from)} - ${ssrInterpolate((_e = (_d = unref(data)) == null ? void 0 : _d.meta) == null ? void 0 : _e.to)} of ${ssrInterpolate((_g = (_f = unref(data)) == null ? void 0 : _f.meta) == null ? void 0 : _g.total)} item </p></div></div><div class="font-medium text-[14px] text-[#344054] flex items-center gap-3">`);
      _push(ssrRenderComponent(_component_PaginationAdmin, {
        modelValue: unref(page),
        "onUpdate:modelValue": ($event) => isRef(page) ? page.value = $event : null,
        total: (_i = (_h = unref(data)) == null ? void 0 : _h.meta) == null ? void 0 : _i.total,
        includeFirstLast: false,
        "per-page": (_k = (_j = unref(data)) == null ? void 0 : _j.meta) == null ? void 0 : _k.per_page,
        class: "flex justify-center"
      }, null, _parent));
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_modal, {
        modelValue: unref(showModalDelete),
        "onUpdate:modelValue": ($event) => isRef(showModalDelete) ? showModalDelete.value = $event : null,
        class: "relative w-[90%] sm:w-[60%] lg:w-[40%]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex justify-center items-center flex-col p-2 sm:p-5 lg:p-10 overflow-auto"${_scopeId}><div class="flex flex-col items-center gap-3 lg:gap-5 text-center transition h-full"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Icon, {
              name: "ph:trash-duotone",
              style: { "color": "#ff0000" },
              class: "w-12 h-12 md:w-20 md:h-20"
            }, null, _parent2, _scopeId));
            _push2(`<p${_scopeId}>Apakah anda yakin untuk menghapus transportasi ini ?</p></div><div class="grid grid-cols-1 lg:grid-cols-2 w-full gap-y-4 md:gap-x-6 mt-5"${_scopeId}><div class="btn bg-transparent border shadow"${_scopeId}><span${_scopeId}>Batal</span></div><div class="btn bg-red-600 text-white shadow"${_scopeId}><span${_scopeId}>Hapus</span></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex justify-center items-center flex-col p-2 sm:p-5 lg:p-10 overflow-auto" }, [
                createVNode("div", { class: "flex flex-col items-center gap-3 lg:gap-5 text-center transition h-full" }, [
                  createVNode(_component_Icon, {
                    name: "ph:trash-duotone",
                    style: { "color": "#ff0000" },
                    class: "w-12 h-12 md:w-20 md:h-20"
                  }),
                  createVNode("p", null, "Apakah anda yakin untuk menghapus transportasi ini ?")
                ]),
                createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-2 w-full gap-y-4 md:gap-x-6 mt-5" }, [
                  createVNode("div", {
                    class: "btn bg-transparent border shadow",
                    onClick: ($event) => showModalDelete.value = false
                  }, [
                    createVNode("span", null, "Batal")
                  ], 8, ["onClick"]),
                  createVNode("div", {
                    onClick: withModifiers(($event) => (unref(deleteTransport)(unref(currentId)), showModalDelete.value = false), ["prevent"]),
                    class: "btn bg-red-600 text-white shadow"
                  }, [
                    createVNode("span", null, "Hapus")
                  ], 8, ["onClick"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/transport/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-ad62f51d.mjs.map
