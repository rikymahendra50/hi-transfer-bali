import { _ as __nuxt_component_0 } from './Container-f78810bd.mjs';
import { withCtx, createVNode, createTextVNode, useSSRContext } from 'vue';
import { a as useHead } from '../server.mjs';
import { ssrRenderComponent } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "privacy-policy",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Privacy and policy",
      meta: [
        {
          name: "description",
          content: "Privacy and policy"
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      _push(`<!--[--><div class="h-[100px]"></div><div class="h-[200px] flex items-center justify-center bg-primary"><h3 class="text-[30px] text-white">Privacy and policy</h3></div>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<p class="py-5"${_scopeId}> You should be able to make informed decisions about your personal data. This Privacy Notice explains how PT. HI Transfer Bali, its subsidiaries, affiliates and jointly controlled entities (&quot;Hi Transfer Bali&quot;, &quot;us&quot;, &quot;we&quot;, or &quot;our&quot;) process your Personal Data. Processing includes the collection, recording, holding, organization, structuring, storage, retention, adaptation, alteration, retrieval, consultation, use, disclosure, erasure, or destruction of Personal Data (\u201Cprocess\u201D), both through our website www.baliboat.com and Hi Transfer Bali mobile app (respectively the &quot;Site&quot; or \u201CApps\u201D). <br${_scopeId}><br${_scopeId}> Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci, minus. <br${_scopeId}><br${_scopeId}> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate, fugiat? <br${_scopeId}><br${_scopeId}> Lorem ipsum, dolor sit amet consectetur adipisicing elit. Odit, dignissimos at. Tenetur animi, id quaerat aliquam deserunt iusto esse. Consectetur! </p>`);
          } else {
            return [
              createVNode("p", { class: "py-5" }, [
                createTextVNode(' You should be able to make informed decisions about your personal data. This Privacy Notice explains how PT. HI Transfer Bali, its subsidiaries, affiliates and jointly controlled entities ("Hi Transfer Bali", "us", "we", or "our") process your Personal Data. Processing includes the collection, recording, holding, organization, structuring, storage, retention, adaptation, alteration, retrieval, consultation, use, disclosure, erasure, or destruction of Personal Data (\u201Cprocess\u201D), both through our website www.baliboat.com and Hi Transfer Bali mobile app (respectively the "Site" or \u201CApps\u201D). '),
                createVNode("br"),
                createVNode("br"),
                createTextVNode(" Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci, minus. "),
                createVNode("br"),
                createVNode("br"),
                createTextVNode(" Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate, fugiat? "),
                createVNode("br"),
                createVNode("br"),
                createTextVNode(" Lorem ipsum, dolor sit amet consectetur adipisicing elit. Odit, dignissimos at. Tenetur animi, id quaerat aliquam deserunt iusto esse. Consectetur! ")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/privacy-policy.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=privacy-policy-1107be3c.mjs.map
