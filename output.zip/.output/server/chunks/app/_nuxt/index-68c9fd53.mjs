import { _ as __nuxt_component_0 } from './Container-c0bcb3c6.mjs';
import { _ as _sfc_main$1 } from './Btn-61213793.mjs';
import { _ as _sfc_main$2 } from './MGroup-69a23538.mjs';
import { _ as _sfc_main$3 } from './MSelect-1f220a05.mjs';
import { _ as __nuxt_component_4 } from './Card-5a3bc9b7.mjs';
import { defineComponent, ref, withCtx, createTextVNode, createVNode, unref, openBlock, createBlock, Fragment, renderList, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'clsx';
import 'vee-validate';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const filter = ref({
      sort: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_UIBtn = _sfc_main$1;
      const _component_UIFormMGroup = _sfc_main$2;
      const _component_UIFormMSelect = _sfc_main$3;
      const _component_TourCard = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="h-28"></div><div class="w-full border-b">`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              variant: "primary",
              outlined: "",
              class: "whitespace-nowrap"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Kembali ke Beranda`);
                } else {
                  return [
                    createTextVNode("Kembali ke Beranda")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="w-full"${_scopeId}><div class="flex flex-col lg:flex-row space-y-1 lg:space-y-0 lg:space-x-4 text-lg lg:text-xl font-semibold"${_scopeId}><div class="text-center"${_scopeId}> Bandara Int&#39;l I Gusti Ngurah Rai </div></div><div class="text-zinc-400 text-sm whitespace-nowrap text-center lg:text-left"${_scopeId}> 21 Juni 2024 | 2 Orang </div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full" }, [
                createVNode("div", null, [
                  createVNode(_component_UIBtn, {
                    variant: "primary",
                    outlined: "",
                    class: "whitespace-nowrap"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Kembali ke Beranda")
                    ]),
                    _: 1
                  })
                ]),
                createVNode("div", { class: "w-full" }, [
                  createVNode("div", { class: "flex flex-col lg:flex-row space-y-1 lg:space-y-0 lg:space-x-4 text-lg lg:text-xl font-semibold" }, [
                    createVNode("div", { class: "text-center" }, " Bandara Int'l I Gusti Ngurah Rai ")
                  ]),
                  createVNode("div", { class: "text-zinc-400 text-sm whitespace-nowrap text-center lg:text-left" }, " 21 Juni 2024 | 2 Orang ")
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col space-y-6 mt-4"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><div${_scopeId}> Menampilkan 7 paket tur </div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "sort",
              label: "Urut berdasarkan"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMSelect, {
                    modelValue: unref(filter).sort,
                    "onUpdate:modelValue": ($event) => unref(filter).sort = $event,
                    name: "sort"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<option value=""${_scopeId3}>Semua</option><option value="recommended"${_scopeId3}>Rekomendasi</option>`);
                      } else {
                        return [
                          createVNode("option", { value: "" }, "Semua"),
                          createVNode("option", { value: "recommended" }, "Rekomendasi")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMSelect, {
                      modelValue: unref(filter).sort,
                      "onUpdate:modelValue": ($event) => unref(filter).sort = $event,
                      name: "sort"
                    }, {
                      default: withCtx(() => [
                        createVNode("option", { value: "" }, "Semua"),
                        createVNode("option", { value: "recommended" }, "Rekomendasi")
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="grid grid-cols-1 lg:grid-cols-4 gap-4"${_scopeId}><!--[-->`);
            ssrRenderList(4, (n) => {
              _push2(ssrRenderComponent(_component_TourCard, { key: n }, null, _parent2, _scopeId));
            });
            _push2(`<!--]--></div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col space-y-6 mt-4" }, [
                createVNode("div", { class: "flex justify-between items-center" }, [
                  createVNode("div", null, " Menampilkan 7 paket tur "),
                  createVNode("div", null, [
                    createVNode(_component_UIFormMGroup, {
                      name: "sort",
                      label: "Urut berdasarkan"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormMSelect, {
                          modelValue: unref(filter).sort,
                          "onUpdate:modelValue": ($event) => unref(filter).sort = $event,
                          name: "sort"
                        }, {
                          default: withCtx(() => [
                            createVNode("option", { value: "" }, "Semua"),
                            createVNode("option", { value: "recommended" }, "Rekomendasi")
                          ]),
                          _: 1
                        }, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      _: 1
                    })
                  ])
                ]),
                createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-4 gap-4" }, [
                  (openBlock(), createBlock(Fragment, null, renderList(4, (n) => {
                    return createVNode(_component_TourCard, { key: n });
                  }), 64))
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="h-10"></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tours/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-68c9fd53.mjs.map
