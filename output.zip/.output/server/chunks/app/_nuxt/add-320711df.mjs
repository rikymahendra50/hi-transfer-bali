import { _ as __nuxt_component_0 } from './TitleBack-580f5db2.mjs';
import { _ as __nuxt_component_1 } from './FacilityCar-9615d1f7.mjs';
import { u as useRequestHelper, a as useRequestOptions, b as useRouter, d as useRoute, f as useHead } from '../server.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './Icon-9a1ee2a3.mjs';
import './config-71e93c9c.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'vee-validate';
import './TabItem-142d001b.mjs';
import './client-only-53a57ea8.mjs';
import 'clsx';
import './Group-4dcbb69b.mjs';
import './TextFieldWLabel-0de16bf1.mjs';
import './InputImageCropAdmin-ec5002c2.mjs';
import './index-dea25161.mjs';
import './index-596a8548.mjs';
import './useSchema-10fbf818.mjs';
import 'zod';
import '@vee-validate/zod';
import './useFacility-a11c3060.mjs';
import './nofication-176ebe9f.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "add",
  __ssrInlineRender: true,
  setup(__props) {
    useRequestHelper();
    useRequestOptions();
    useRouter();
    useRoute();
    useHead({
      title: "Add facility car"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TitleBack = __nuxt_component_0;
      const _component_UIFormFacilityCar = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "px-5 py-6 md:px-10 md:py-10" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_TitleBack, {
        link: "/admin/facility-car",
        title: "Tambah fasilitas baru"
      }, null, _parent));
      _push(ssrRenderComponent(_component_UIFormFacilityCar, { buttonTitle: "Tambah Fasilitas" }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/facility-car/add.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=add-320711df.mjs.map
