import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { e as _export_sfc, _ as __nuxt_component_0$1 } from '../server.mjs';
import { _ as _sfc_main$1, a as __nuxt_component_3 } from './client-only-8488a4fd.mjs';
import { mergeProps, withCtx, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _imports_0 } from './hi-transfer-logo-97c0b5ac.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _imports_1 = "" + publicAssetsURL("hi-travel-auth.png");
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0$1;
  const _component_LanguageSwitch = _sfc_main$1;
  const _component_ClientOnly = __nuxt_component_3;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid grid-cols-1 lg:grid-cols-2" }, _attrs))}><div class="flex flex-col w-full"><header class="w-full z-50 py-4 px-4 border-b"><div><nav class="navbar"><div class="flex-1">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "link link-neutral link-hover",
    "active-class": "font-medium",
    to: "/"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="Hi Transfer" class="h-[60px] w-[60px]"${_scopeId}>`);
      } else {
        return [
          createVNode("img", {
            src: _imports_0,
            alt: "Hi Transfer",
            class: "h-[60px] w-[60px]"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="flex-none"><ul class="inline-flex items-center space-x-4"><li>`);
  _push(ssrRenderComponent(_component_LanguageSwitch, null, null, _parent));
  _push(`</li></ul></div></nav></div></header><main class="grid place-items-center h-full">`);
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</main>`);
  _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
  _push(`</div><div class="hidden lg:block"><img${ssrRenderAttr("src", _imports_1)} class="h-screen w-full" alt="auth"></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/auth.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const auth = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { auth as default };
//# sourceMappingURL=auth-034424a7.mjs.map
