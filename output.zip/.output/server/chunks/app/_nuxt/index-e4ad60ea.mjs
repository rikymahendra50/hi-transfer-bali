import __nuxt_component_1 from './Icon-7218f0f6.mjs';
import { useSSRContext, defineComponent, withCtx, createVNode, mergeProps, unref, toRef, computed, ref, createTextVNode, resolveComponent, openBlock, createBlock, Fragment, renderList } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderClass, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseEqual, ssrRenderSlot, ssrRenderList } from 'vue/server-renderer';
import clsx from 'clsx';
import { _ as _sfc_main$9 } from './MGroup-69a23538.mjs';
import { _ as _sfc_main$a } from './MTextField-61174a46.mjs';
import { useField } from 'vee-validate';
import { _ as _sfc_main$b } from './MSelect-1f220a05.mjs';
import { _ as _sfc_main$c } from './Btn-61213793.mjs';
import { a as useBreakpoints, u as useStepper, b as breakpointsTailwind } from './index-1df0d9ef.mjs';
import { d as useHead, e as _export_sfc } from '../server.mjs';
import { _ as __nuxt_component_0$1 } from './Container-c0bcb3c6.mjs';
import { _ as __nuxt_component_4 } from './Card-5a3bc9b7.mjs';
import { _ as __nuxt_component_3 } from './CtaSection-9975e633.mjs';
import './config-aab100d3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  __name: "TabLink",
  __ssrInlineRender: true,
  props: {
    label: {},
    icon: {},
    isActive: { type: Boolean, default: false }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: unref(clsx)("inline-flex space-x-2 items-center text-zinc-400 hover:border-b-2 py-2 hover:bg-green-100 transition-colors duration-300 px-2 hover:text-primary hover:border-primary", {
          "border-b-2 border-primary text-primary": props.isActive
        })
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_Icon, {
        name: props.icon,
        class: "h-5 w-5"
      }, null, _parent));
      _push(`<div class="">${ssrInterpolate(props.label)}</div></div>`);
    };
  }
});
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Share/Menu/TabLink.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "Toggle",
  __ssrInlineRender: true,
  props: {
    name: {},
    label: {},
    modelValue: {},
    disabled: { type: Boolean, default: false },
    trueValue: { default: 1 },
    falseValue: { default: 0 },
    ariaLabel: { default: "toggle" },
    variant: {},
    size: {},
    class: {},
    readonly: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const name = toRef(props, "name");
    const variants = [
      "toggle-primary",
      "toggle-secondary",
      "toggle-accent",
      "toggle-info",
      "toggle-success",
      "toggle-warning",
      "toggle-error"
    ];
    const sizes = [
      "toggle-xs",
      "toggle-sm",
      "toggle-md",
      "toggle-lg"
    ];
    const {
      value,
      errorMessage
    } = useField(name, void 0, {
      syncVModel: true
    });
    const toggleClass = computed(() => {
      return clsx(
        "toggle",
        variants[variants.indexOf(`toggle-${props.variant}`)],
        sizes[sizes.indexOf(`toggle-${props.size}`)],
        props.class
      );
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "form-control w-full" }, _attrs))}><label class="label !justify-start cursor-pointer inline-flex gap-4"><input type="checkbox" class="${ssrRenderClass(unref(toggleClass))}"${ssrRenderAttr("name", props.name)}${ssrIncludeBooleanAttr(props.disabled) ? " disabled" : ""}${ssrIncludeBooleanAttr(ssrLooseEqual(unref(value), props.trueValue)) ? " checked" : ""}${ssrRenderAttr("aria-label", _ctx.ariaLabel)}${ssrIncludeBooleanAttr(props.readonly) ? " readonly" : ""}>`);
      if (props.label || _ctx.$slots.default) {
        _push(`<span class="label-text">`);
        ssrRenderSlot(_ctx.$slots, "default", {}, () => {
          _push(`${ssrInterpolate(props.label)}`);
        }, _push, _parent);
        _push(`</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</label></div>`);
    };
  }
});
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/Toggle.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "Vehicle",
  __ssrInlineRender: true,
  setup(__props) {
    const dataForm = ref({
      pickup_address: "",
      pickup_latitude: 0,
      pickup_longitude: 0,
      destination_address: "",
      destination_latitude: 0,
      destination_longitude: 0,
      round_trip: 0,
      pickup_date: "",
      return_date: "",
      passengers: 1
    });
    const breakpoints = useBreakpoints(breakpointsTailwind);
    const isMobile = breakpoints.smaller("lg");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIFormMGroup = _sfc_main$9;
      const _component_UIFormMTextField = _sfc_main$a;
      const _component_Icon = __nuxt_component_1;
      const _component_UIFormToggle = _sfc_main$7;
      const _component_UIFormMSelect = _sfc_main$b;
      const _component_UIBtn = _sfc_main$c;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-4" }, _attrs))}><div class="grid grid-cols-1 lg:grid-cols-[1fr_50px_1fr] gap-4">`);
      _push(ssrRenderComponent(_component_UIFormMGroup, {
        label: "Jemput Dimana ?",
        name: "pickup_address"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_UIFormMTextField, {
              modelValue: unref(dataForm).pickup_address,
              "onUpdate:modelValue": ($event) => unref(dataForm).pickup_address = $event,
              name: "pickup_address",
              placeholder: "ex:Jalan Pahlawan No. 1"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_UIFormMTextField, {
                modelValue: unref(dataForm).pickup_address,
                "onUpdate:modelValue": ($event) => unref(dataForm).pickup_address = $event,
                name: "pickup_address",
                placeholder: "ex:Jalan Pahlawan No. 1"
              }, null, 8, ["modelValue", "onUpdate:modelValue"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="flex justify-center items-center">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: unref(isMobile) ? "i-heroicons-arrows-up-down" : "i-heroicons-arrows-right-left",
        class: "w-6 h-6"
      }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_UIFormMGroup, {
        label: "Mau Kemana ?",
        name: "destination_address"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_UIFormMTextField, {
              modelValue: unref(dataForm).destination_address,
              "onUpdate:modelValue": ($event) => unref(dataForm).destination_address = $event,
              name: "destination_address",
              placeholder: "ex:Jalan Pahlawan No. 1"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_UIFormMTextField, {
                modelValue: unref(dataForm).destination_address,
                "onUpdate:modelValue": ($event) => unref(dataForm).destination_address = $event,
                name: "destination_address",
                placeholder: "ex:Jalan Pahlawan No. 1"
              }, null, 8, ["modelValue", "onUpdate:modelValue"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="grid grid-cols-1 lg:grid-cols-5 gap-4">`);
      _push(ssrRenderComponent(_component_UIFormToggle, {
        name: "round_trip",
        label: "Pulang - Pergi",
        modelValue: unref(dataForm).round_trip,
        "onUpdate:modelValue": ($event) => unref(dataForm).round_trip = $event,
        "true-value": "1",
        "false-value": "0",
        variant: "primary"
      }, null, _parent));
      _push(ssrRenderComponent(_component_UIFormMGroup, {
        name: "pickup_date",
        label: "Jemput Tanggal"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_UIFormMTextField, {
              name: "pickup_date",
              modelValue: unref(dataForm).pickup_date,
              "onUpdate:modelValue": ($event) => unref(dataForm).pickup_date = $event,
              type: "date",
              placeholder: "ex:2024-01-01"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_UIFormMTextField, {
                name: "pickup_date",
                modelValue: unref(dataForm).pickup_date,
                "onUpdate:modelValue": ($event) => unref(dataForm).pickup_date = $event,
                type: "date",
                placeholder: "ex:2024-01-01"
              }, null, 8, ["modelValue", "onUpdate:modelValue"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_UIFormMGroup, {
        name: "return_date",
        label: "Pulang Balik"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_UIFormMTextField, {
              name: "return_date",
              modelValue: unref(dataForm).return_date,
              "onUpdate:modelValue": ($event) => unref(dataForm).return_date = $event,
              type: "date",
              placeholder: "ex:2024-01-02"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_UIFormMTextField, {
                name: "return_date",
                modelValue: unref(dataForm).return_date,
                "onUpdate:modelValue": ($event) => unref(dataForm).return_date = $event,
                type: "date",
                placeholder: "ex:2024-01-02"
              }, null, 8, ["modelValue", "onUpdate:modelValue"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_UIFormMGroup, {
        name: "passengers",
        label: "Jumlah Penumpang"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_UIFormMSelect, {
              name: "passengers",
              modelValue: unref(dataForm).passengers,
              "onUpdate:modelValue": ($event) => unref(dataForm).passengers = $event
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<option value="1"${_scopeId2}>1 Penumpang</option><option value="2"${_scopeId2}>2 Penumpang</option><option value="3"${_scopeId2}>3 Penumpang</option><option value="4"${_scopeId2}>4 Penumpang</option><option value="5"${_scopeId2}>5 Penumpang</option><option value="6"${_scopeId2}>6 Penumpang</option>`);
                } else {
                  return [
                    createVNode("option", { value: "1" }, "1 Penumpang"),
                    createVNode("option", { value: "2" }, "2 Penumpang"),
                    createVNode("option", { value: "3" }, "3 Penumpang"),
                    createVNode("option", { value: "4" }, "4 Penumpang"),
                    createVNode("option", { value: "5" }, "5 Penumpang"),
                    createVNode("option", { value: "6" }, "6 Penumpang")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_UIFormMSelect, {
                name: "passengers",
                modelValue: unref(dataForm).passengers,
                "onUpdate:modelValue": ($event) => unref(dataForm).passengers = $event
              }, {
                default: withCtx(() => [
                  createVNode("option", { value: "1" }, "1 Penumpang"),
                  createVNode("option", { value: "2" }, "2 Penumpang"),
                  createVNode("option", { value: "3" }, "3 Penumpang"),
                  createVNode("option", { value: "4" }, "4 Penumpang"),
                  createVNode("option", { value: "5" }, "5 Penumpang"),
                  createVNode("option", { value: "6" }, "6 Penumpang")
                ]),
                _: 1
              }, 8, ["modelValue", "onUpdate:modelValue"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div>`);
      _push(ssrRenderComponent(_component_UIBtn, { variant: "primary" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Cari Mobil`);
          } else {
            return [
              createTextVNode("Cari Mobil")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Share/Filter/Vehicle.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "Tour",
  __ssrInlineRender: true,
  setup(__props) {
    const dataForm = ref({
      tour_id: "",
      activity_date: "",
      total_passengers: 1
    });
    const breakpoints = useBreakpoints(breakpointsTailwind);
    breakpoints.smaller("lg");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIFormMGroup = _sfc_main$9;
      const _component_VDropdown = resolveComponent("VDropdown");
      const _component_Icon = __nuxt_component_1;
      const _component_UIFormMTextField = _sfc_main$a;
      const _component_UIBtn = _sfc_main$c;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-4" }, _attrs))}><div>`);
      _push(ssrRenderComponent(_component_UIFormMGroup, {
        name: "tour_id",
        label: "Pilih Destinasi"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_VDropdown, {
              placements: "start",
              distance: "-10",
              skidding: "1",
              "arrow-padding": "1"
            }, {
              popper: withCtx(({ hide }, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="w-full p-4 space-y-4 max-w-5xl"${_scopeId2}><input placeholder="Cari" class="input input-bordered input-sm w-full"${_scopeId2}><div class="space-y-4 overflow-y-auto h-full lg:max-h-[500px]"${_scopeId2}><!--[-->`);
                  ssrRenderList(5, (n) => {
                    _push3(`<div class="grid grid-cols-[150px_1fr] gap-4 hover:bg-primary/10 transition-all duration-300 p-4 rounded-md cursor-pointer"${_scopeId2}><div${_scopeId2}><img alt="" class="w-full h-full object-cover" src="https://placehold.co/100"${_scopeId2}></div><div class="space-y-2"${_scopeId2}><div class="text-sm"${_scopeId2}> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sapiente, sint nobis? Quae iure aperiam culpa obcaecati consequatur temporibus nam fugiat dolore aliquam aut, aliquid omnis ut et rerum molestiae numquam. </div><div${_scopeId2}><div class="text-zinc-400 text-xs"${_scopeId2}>Harga Mulai Dari</div><h4 class="text-lg font-semibold text-primary"${_scopeId2}>Rp. 1.000.000/Orang</h4></div></div></div>`);
                  });
                  _push3(`<!--]--></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "w-full p-4 space-y-4 max-w-5xl" }, [
                      createVNode("input", {
                        placeholder: "Cari",
                        class: "input input-bordered input-sm w-full"
                      }),
                      createVNode("div", { class: "space-y-4 overflow-y-auto h-full lg:max-h-[500px]" }, [
                        (openBlock(), createBlock(Fragment, null, renderList(5, (n) => {
                          return createVNode("div", {
                            key: n,
                            class: "grid grid-cols-[150px_1fr] gap-4 hover:bg-primary/10 transition-all duration-300 p-4 rounded-md cursor-pointer",
                            onClick: ($event) => hide()
                          }, [
                            createVNode("div", null, [
                              createVNode("img", {
                                alt: "",
                                class: "w-full h-full object-cover",
                                src: "https://placehold.co/100"
                              })
                            ]),
                            createVNode("div", { class: "space-y-2" }, [
                              createVNode("div", { class: "text-sm" }, " Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sapiente, sint nobis? Quae iure aperiam culpa obcaecati consequatur temporibus nam fugiat dolore aliquam aut, aliquid omnis ut et rerum molestiae numquam. "),
                              createVNode("div", null, [
                                createVNode("div", { class: "text-zinc-400 text-xs" }, "Harga Mulai Dari"),
                                createVNode("h4", { class: "text-lg font-semibold text-primary" }, "Rp. 1.000.000/Orang")
                              ])
                            ])
                          ], 8, ["onClick"]);
                        }), 64))
                      ])
                    ])
                  ];
                }
              }),
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<button class="text-xs h-9 w-full flex justify-between items-center"${_scopeId2}><div${_scopeId2}>Pilih Destinasi</div><div${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_Icon, { name: "i-heroicons-chevron-down" }, null, _parent3, _scopeId2));
                  _push3(`</div></button>`);
                } else {
                  return [
                    createVNode("button", { class: "text-xs h-9 w-full flex justify-between items-center" }, [
                      createVNode("div", null, "Pilih Destinasi"),
                      createVNode("div", null, [
                        createVNode(_component_Icon, { name: "i-heroicons-chevron-down" })
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_VDropdown, {
                placements: "start",
                distance: "-10",
                skidding: "1",
                "arrow-padding": "1"
              }, {
                popper: withCtx(({ hide }) => [
                  createVNode("div", { class: "w-full p-4 space-y-4 max-w-5xl" }, [
                    createVNode("input", {
                      placeholder: "Cari",
                      class: "input input-bordered input-sm w-full"
                    }),
                    createVNode("div", { class: "space-y-4 overflow-y-auto h-full lg:max-h-[500px]" }, [
                      (openBlock(), createBlock(Fragment, null, renderList(5, (n) => {
                        return createVNode("div", {
                          key: n,
                          class: "grid grid-cols-[150px_1fr] gap-4 hover:bg-primary/10 transition-all duration-300 p-4 rounded-md cursor-pointer",
                          onClick: ($event) => hide()
                        }, [
                          createVNode("div", null, [
                            createVNode("img", {
                              alt: "",
                              class: "w-full h-full object-cover",
                              src: "https://placehold.co/100"
                            })
                          ]),
                          createVNode("div", { class: "space-y-2" }, [
                            createVNode("div", { class: "text-sm" }, " Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sapiente, sint nobis? Quae iure aperiam culpa obcaecati consequatur temporibus nam fugiat dolore aliquam aut, aliquid omnis ut et rerum molestiae numquam. "),
                            createVNode("div", null, [
                              createVNode("div", { class: "text-zinc-400 text-xs" }, "Harga Mulai Dari"),
                              createVNode("h4", { class: "text-lg font-semibold text-primary" }, "Rp. 1.000.000/Orang")
                            ])
                          ])
                        ], 8, ["onClick"]);
                      }), 64))
                    ])
                  ])
                ]),
                default: withCtx(() => [
                  createVNode("button", { class: "text-xs h-9 w-full flex justify-between items-center" }, [
                    createVNode("div", null, "Pilih Destinasi"),
                    createVNode("div", null, [
                      createVNode(_component_Icon, { name: "i-heroicons-chevron-down" })
                    ])
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="grid grid-cols-1 lg:grid-cols-[1fr_1fr_100px] gap-4">`);
      _push(ssrRenderComponent(_component_UIFormMGroup, {
        name: "activity_date",
        label: "Pilih Tanggal"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_UIFormMTextField, {
              name: "activity_date",
              type: "date",
              modelValue: unref(dataForm).activity_date,
              "onUpdate:modelValue": ($event) => unref(dataForm).activity_date = $event,
              placeholder: "ex:2024-01-01"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_UIFormMTextField, {
                name: "activity_date",
                type: "date",
                modelValue: unref(dataForm).activity_date,
                "onUpdate:modelValue": ($event) => unref(dataForm).activity_date = $event,
                placeholder: "ex:2024-01-01"
              }, null, 8, ["modelValue", "onUpdate:modelValue"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_UIFormMGroup, {
        name: "total_passengers",
        label: "Berapa Orang"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_UIFormMTextField, {
              name: "total_passengers",
              modelValue: unref(dataForm).total_passengers,
              "onUpdate:modelValue": ($event) => unref(dataForm).total_passengers = $event,
              placeholder: "ex:1"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_UIFormMTextField, {
                name: "total_passengers",
                modelValue: unref(dataForm).total_passengers,
                "onUpdate:modelValue": ($event) => unref(dataForm).total_passengers = $event,
                placeholder: "ex:1"
              }, null, 8, ["modelValue", "onUpdate:modelValue"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div>`);
      _push(ssrRenderComponent(_component_UIBtn, { variant: "primary" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Cari Tur`);
          } else {
            return [
              createTextVNode("Cari Tur")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Share/Filter/Tour.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "HomeBanner",
  __ssrInlineRender: true,
  setup(__props) {
    const {
      current,
      goTo,
      isCurrent
    } = useStepper([
      "transport",
      "paket-tour"
    ]);
    const slides = [
      {
        title: "Perjalanan Aman dan Nyaman di Bali",
        description: "Armada kendaraan modern dan pengemudi berpengalaman siap mengantar Anda ke mana pun tujuan Anda.",
        image: "/hi-travel-hero.jpeg",
        key: "transport"
      },
      {
        title: "Jelajahi Keajaiban Pulau Dewata",
        description: "Dari pantai hingga gunung, kami siap membawa Anda merasakan pengalaman Bali yang autentik.",
        image: "/second-thumbnail-hero-hi-travel.jpeg",
        key: "paket-tour"
      }
    ];
    const currentSlide = computed(() => {
      return slides.find((slide) => slide.key === current.value);
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d;
      const _component_ShareMenuTabLink = _sfc_main$8;
      const _component_ShareFilterVehicle = _sfc_main$6;
      const _component_ShareFilterTour = _sfc_main$5;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 relative" }, _attrs))} data-v-e04897ab><div class="relative rounded-xl overflow-hidden" data-v-e04897ab><div class="absolute h-full w-full bg-gradient-to-t from-[#121212]/20 to-[#121212]/50 text-center space-y-6" data-v-e04897ab><div class="h-20" data-v-e04897ab></div><h1 class="text-3xl lg:text-5xl text-white font-bold max-w-4xl mx-auto" data-v-e04897ab>${ssrInterpolate((_a = unref(currentSlide)) == null ? void 0 : _a.title)}</h1><p class="text-white text-base lg:text-xl max-w-2xl mx-auto" data-v-e04897ab>${ssrInterpolate((_b = unref(currentSlide)) == null ? void 0 : _b.description)}</p></div>`);
      if ((_c = unref(currentSlide)) == null ? void 0 : _c.image) {
        _push(`<img${ssrRenderAttr("src", (_d = unref(currentSlide)) == null ? void 0 : _d.image)} class="w-full h-[500px] object-cover" alt="hero" data-v-e04897ab>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="lg:absolute z-10 w-full inset-x-0 bottom-0 lg:-bottom-4" data-v-e04897ab><div data-v-e04897ab><div class="max-w-5xl bg-white mx-auto mt-auto bottom-0 p-6 lg:p-2 shadow rounded-lg" data-v-e04897ab><div class="inline-flex" data-v-e04897ab>`);
      _push(ssrRenderComponent(_component_ShareMenuTabLink, {
        label: "Transport",
        icon: "bi:car-front-fill",
        "is-active": unref(isCurrent)("transport"),
        onClick: ($event) => unref(goTo)("transport")
      }, null, _parent));
      _push(ssrRenderComponent(_component_ShareMenuTabLink, {
        label: "Paket Tour",
        icon: "mingcute:umbrella-2-line",
        "is-active": unref(isCurrent)("paket-tour"),
        onClick: ($event) => unref(goTo)("paket-tour")
      }, null, _parent));
      _push(`</div><div class="p-4" data-v-e04897ab>`);
      if (unref(isCurrent)("transport")) {
        _push(`<div data-v-e04897ab>`);
        _push(ssrRenderComponent(_component_ShareFilterVehicle, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isCurrent)("paket-tour")) {
        _push(`<div data-v-e04897ab>`);
        _push(ssrRenderComponent(_component_ShareFilterTour, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div></div>`);
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Hero/HomeBanner.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-e04897ab"]]);
const _sfc_main$3 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_TourCard = __nuxt_component_4;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-6 py-6" }, _attrs))}><h3 class="text-[32px] leading-[40px] font-semibold text-primary-dark"> Paket Tur </h3><div class="grid grid-cols-1 lg:grid-cols-4 gap-6"><!--[-->`);
  ssrRenderList(4, (n) => {
    _push(ssrRenderComponent(_component_TourCard, { key: n }, null, _parent));
  });
  _push(`<!--]--></div></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/HighLight.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Card",
  __ssrInlineRender: true,
  props: {
    step: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-4 border rounded-xl p-4" }, _attrs))}><h4 class="text-primary-dark text-2xl font-bold">${ssrInterpolate(props.step.title)}</h4><div class="text-zinc-400">${ssrInterpolate(props.step.decription)}</div><img${ssrRenderAttr("src", props.step.image)}${ssrRenderAttr("alt", props.step.title)} class="w-full h-[350px] object-cover"></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/StepToJoin/Card.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const steps = ref([
      {
        title: "1.Temukan",
        decription: "Cari mobil penjemputan atau paket tur yang sesuai yang kamu inginkan, ada banyak pilihan buatmu.",
        image: "/hi-travel-feat-1.png"
      },
      {
        title: "2.Bayar",
        decription: "Lakukan pembayaran dengan berbagai metode bayar yang aman, cepat, dan mudah.",
        image: "/hi-travel-feat-2.png"
      },
      {
        title: "3. Selesai",
        decription: "Kamu sudah siap untuk liburan! Informasi tranksasi akan dikirimkan ke emailmu.",
        image: "/hi-travel-feat-3.png"
      }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_StepToJoinCard = _sfc_main$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-6 py-6" }, _attrs))}><h3 class="text-[32px] leading-[40px] font-semibold text-primary-dark"> Pesan di Hi Travel Bali dalam 3 Langkah Mudah </h3><div class="grid grid-cols-1 lg:grid-cols-3 gap-6"><!--[-->`);
      ssrRenderList(unref(steps), (step, index) => {
        _push(ssrRenderComponent(_component_StepToJoinCard, {
          key: index,
          step
        }, null, _parent));
      });
      _push(`<!--]--></div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/StepToJoin/index.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Home"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeroHomeBanner = __nuxt_component_0;
      const _component_UIContainer = __nuxt_component_0$1;
      const _component_TourHighLight = __nuxt_component_2;
      const _component_StepToJoin = _sfc_main$1;
      const _component_ShareCtaSection = __nuxt_component_3;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="h-32"></div>`);
      _push(ssrRenderComponent(_component_HeroHomeBanner, null, null, _parent));
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_TourHighLight, null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_TourHighLight)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_StepToJoin, null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_StepToJoin)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_ShareCtaSection, null, null, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-e4ad60ea.mjs.map
