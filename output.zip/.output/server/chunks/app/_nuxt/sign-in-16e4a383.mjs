import { Form } from 'vee-validate';
import { _ as _sfc_main$1 } from './MGroup-560eed6a.mjs';
import { _ as _sfc_main$2 } from './MTextField-bd75102a.mjs';
import { _ as _sfc_main$3 } from './Btn-577fa59f.mjs';
import { u as useSchema } from './useSchema-f211c259.mjs';
import { e as useI18n, b as useRouter, m as useAuth, f as useHead } from '../server.mjs';
import { defineComponent, mergeProps, unref, withCtx, createVNode, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import 'clsx';
import 'zod';
import '@vee-validate/zod';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "sign-in",
  __ssrInlineRender: true,
  setup(__props) {
    const { loginSchema } = useSchema();
    const { locale, t: $t } = useI18n();
    const router = useRouter();
    function redirectUserProfile() {
      router.push("/admin/profile");
    }
    const { loading, message, alertType, $credentialForm, $login } = useAuth({
      usedBy: "admin",
      callback: redirectUserProfile
    });
    useHead({
      title: "Sign In"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIFormMGroup = _sfc_main$1;
      const _component_UIFormMTextField = _sfc_main$2;
      const _component_UIBtn = _sfc_main$3;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "hero min-h-screen" }, _attrs))}><div class="hero-content text-center"><div class="max-w-full md:w-[450px] lg:max-w-md mt-32"><h1 class="text-2xl md:text-4xl font-bold mb-2 md:mb-4"> Dasbor Admin </h1><p class="text-sm md:text-[18px] text-[#121212] font-normal">${ssrInterpolate(unref($t)("selamat-datang-di-dashboard"))}</p>`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit: unref($login),
        "validation-schema": unref(loginSchema)
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 text-left gap-4 p-4 rounded-md my-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Email",
              name: "email"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "email",
                    modelValue: unref($credentialForm).email,
                    "onUpdate:modelValue": ($event) => unref($credentialForm).email = $event,
                    class: "input-bordered",
                    placeholder: unref($t)("ketik-email-anda")
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "email",
                      modelValue: unref($credentialForm).email,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).email = $event,
                      class: "input-bordered",
                      placeholder: unref($t)("ketik-email-anda")
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Password",
              name: "password"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "password",
                    modelValue: unref($credentialForm).password,
                    "onUpdate:modelValue": ($event) => unref($credentialForm).password = $event,
                    type: "password",
                    class: "input-bordered",
                    placeholder: "********"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "password",
                      modelValue: unref($credentialForm).password,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).password = $event,
                      type: "password",
                      class: "input-bordered",
                      placeholder: "********"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIBtn, {
              variant: "primary",
              type: "submit",
              disabled: unref(loading),
              class: "w-full"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Login`);
                } else {
                  return [
                    createTextVNode("Login")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 text-left gap-4 p-4 rounded-md my-4" }, [
                createVNode(_component_UIFormMGroup, {
                  label: "Email",
                  name: "email"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      name: "email",
                      modelValue: unref($credentialForm).email,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).email = $event,
                      class: "input-bordered",
                      placeholder: unref($t)("ketik-email-anda")
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  label: "Password",
                  name: "password"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      name: "password",
                      modelValue: unref($credentialForm).password,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).password = $event,
                      type: "password",
                      class: "input-bordered",
                      placeholder: "********"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIBtn, {
                  variant: "primary",
                  type: "submit",
                  disabled: unref(loading),
                  class: "w-full"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Login")
                  ]),
                  _: 1
                }, 8, ["disabled"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/sign-in.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=sign-in-16e4a383.mjs.map
