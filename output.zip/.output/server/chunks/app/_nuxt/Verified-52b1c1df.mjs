import { Form, Field, ErrorMessage } from 'vee-validate';
import { _ as _sfc_main$1 } from './Alert-4fa497cc.mjs';
import { _ as _sfc_main$2 } from './InputOTP-4b85403c.mjs';
import { e as useRequestOptions, f as useI18n, u as useAuth, h as useRequestHelper, i as useFetch, k as useNuxtApp } from '../server.mjs';
import { useSSRContext, mergeProps, unref, withCtx, isRef, createVNode, toDisplayString, ref } from 'vue';
import { u as useSchema } from './useSchema-a44a23cb.mjs';
import { ssrRenderComponent, ssrIncludeBooleanAttr, ssrInterpolate } from 'vue/server-renderer';

function useRefund() {
  const stateForm = ref({
    email: ""
  });
  const showPinEmailExpired = ref(false);
  const secondTime = ref(60);
  function countdown() {
    const interval = setInterval(() => {
      if (secondTime.value === 0) {
        clearInterval(interval);
        showPinEmailExpired.value = true;
      } else {
        secondTime.value--;
      }
    }, 1e3);
  }
  return {
    stateForm,
    countdown,
    showPinEmailExpired,
    secondTime
  };
}
const _sfc_main = {
  __name: "Verified",
  __ssrInlineRender: true,
  props: {
    email: String,
    otp: String,
    uuidData: String || Number,
    carOrTour: String
  },
  emits: ["next", "update:otp", "sukses"],
  setup(__props, { emit }) {
    const props = __props;
    const { requestOptions } = useRequestOptions();
    const { locale, t: $t } = useI18n();
    const { $user } = useAuth();
    const { $toast } = useNuxtApp();
    const { stateForm, countdown, showPinEmailExpired, secondTime } = useRefund();
    const { otpSchema } = useSchema();
    const { loading, message, alertType } = useRequestHelper();
    async function onSubmit() {
      var _a2, _b2;
      var _a, _b, _c, _d;
      loading.value = true;
      const { error, data } = await useFetch(
        `/users/${$user.value.uuid}/${props.carOrTour}/${props.uuidData}/refund`,
        {
          method: "POST",
          body: { pin: stateForm.value.otp },
          ...requestOptions
        },
        "$N1weP1OQ2C"
      );
      if (error.value) {
        $toast.error((_a2 = (_b = (_a = error.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message) != null ? _a2 : $t("gagal"));
      } else {
        $toast.success(
          (_b2 = (_d = (_c = data.value) == null ? void 0 : _c.data) == null ? void 0 : _d.message) != null ? _b2 : $t("success-please-check-your-email-step")
        );
        emit("sukses", false);
      }
      loading.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_Alert = _sfc_main$1;
      const _component_VeeField = Field;
      const _component_UIFormInputOTP = _sfc_main$2;
      const _component_VeeErrorMessage = ErrorMessage;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        onSubmit,
        "validation-schema": unref(otpSchema)
      }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 text-left gap-4 p-4 rounded-md w-full"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Alert, {
              modelValue: unref(message),
              "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
              type: unref(alertType)
            }, null, _parent2, _scopeId));
            _push2(`<div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              name: "otp",
              modelValue: unref(stateForm).otp,
              "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_UIFormInputOTP, {
              modelValue: unref(stateForm).otp,
              "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event,
              "is-error": !!(errors == null ? void 0 : errors.otp)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "otp",
              class: "form-error-message"
            }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><button type="submit" class="btn bg-primary text-white shadow w-full py-1"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""}${_scopeId}><span${_scopeId}>${ssrInterpolate(unref($t)("proses-pengembalian"))}</span></button></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 text-left gap-4 p-4 rounded-md w-full" }, [
                createVNode(_component_Alert, {
                  modelValue: unref(message),
                  "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
                  type: unref(alertType)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "type"]),
                createVNode("div", { class: "hidden" }, [
                  createVNode(_component_VeeField, {
                    name: "otp",
                    modelValue: unref(stateForm).otp,
                    "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode(_component_UIFormInputOTP, {
                  modelValue: unref(stateForm).otp,
                  "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event,
                  "is-error": !!(errors == null ? void 0 : errors.otp)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "is-error"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "otp",
                  class: "form-error-message"
                }),
                createVNode("div", null, [
                  createVNode("button", {
                    type: "submit",
                    class: "btn bg-primary text-white shadow w-full py-1",
                    disabled: unref(loading)
                  }, [
                    createVNode("span", null, toDisplayString(unref($t)("proses-pengembalian")), 1)
                  ], 8, ["disabled"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Verified.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main;

export { __nuxt_component_4 as _ };
//# sourceMappingURL=Verified-52b1c1df.mjs.map
