import { j as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_1 from './Icon-f8c4e628.mjs';
import { useSSRContext, mergeProps, withCtx, createVNode, toDisplayString } from 'vue';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "TitleBack",
  __ssrInlineRender: true,
  props: {
    link: {
      type: String
    },
    title: {
      type: String
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_1;
      _push(ssrRenderComponent(_component_NuxtLink, mergeProps({
        to: __props.link,
        class: "font-semibold text-[18px] md:text-[24px] mb-4 flex items-center gap-2 w-fit"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Icon, {
              name: "mingcute:arrow-left-fill",
              class: "text-black"
            }, null, _parent2, _scopeId));
            _push2(`<span${_scopeId}>${ssrInterpolate(__props.title)}</span>`);
          } else {
            return [
              createVNode(_component_Icon, {
                name: "mingcute:arrow-left-fill",
                class: "text-black"
              }),
              createVNode("span", null, toDisplayString(__props.title), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TitleBack.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=TitleBack-14168b7f.mjs.map
