import { _ as __nuxt_component_0 } from './Container-afb1bf23.mjs';
import { defineComponent, computed, withCtx, unref, createVNode, toDisplayString, createTextVNode, openBlock, createBlock, createCommentVNode, useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import { d as useRoute, b as useRouter, e as useI18n, n as __nuxt_component_2, k as _export_sfc } from '../server.mjs';
import { _ as _sfc_main$2 } from './Btn-577fa59f.mjs';
import { u as useVehicleForm } from './vehicleForm-63f1ebb0.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'clsx';

const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid grid-cols-[100px_1fr] border rounded-xl p-2 space-x-2" }, _attrs))}><div class="flex items-center"><div class="rounded-xl overflow-hidden w-[100px] h-[100px]"><img src="https://placehold.co/150" alt="" class="w-full h-full object-cover"></div></div><div class="flex flex-col justify-between space-y-4"><div class="text-lg font-semibold">West Nusa Penida Tour</div><div><div class="text-zinc-400 text-xs">Destinasi</div><div class="text-sm"> Kelingking Cliff - Angel&#39;s Billabong - Broken Beach - Crystal Bay Beach </div></div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/SelectedCard.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "booking",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const router = useRouter();
    const { locale, t: $t } = useI18n();
    useVehicleForm();
    const isTourBookingPage = computed(() => {
      return route.name === "tours-booking";
    });
    computed(() => {
      return route.name === "vehicles-booking";
    });
    const isTourBookingCheckoutPage = computed(() => {
      return route.name === "tours-booking-checkout";
    });
    const gotoCheckout = () => {
      router.push("/tours/booking/checkout");
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_TourSelectedCard = __nuxt_component_1;
      const _component_NuxtPage = __nuxt_component_2;
      const _component_UIBtn = _sfc_main$2;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="h-28"></div>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 divide-x-2"${_scopeId}><div class="space-y-6 py-4"${_scopeId}><h3 class="text-2xl font-semibold text-primary-dark"${_scopeId}>${ssrInterpolate(unref($t)("pesanan-anda"))}</h3><div class="space-y-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_TourSelectedCard, null, null, _parent2, _scopeId));
            _push2(`</div></div><div class="p-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtPage, null, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 divide-x-2" }, [
                createVNode("div", { class: "space-y-6 py-4" }, [
                  createVNode("h3", { class: "text-2xl font-semibold text-primary-dark" }, toDisplayString(unref($t)("pesanan-anda")), 1),
                  createVNode("div", { class: "space-y-4" }, [
                    createVNode(_component_TourSelectedCard)
                  ])
                ]),
                createVNode("div", { class: "p-4" }, [
                  createVNode(_component_NuxtPage)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="w-full border-b border-t">`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex justify-end w-full"${_scopeId}><div${_scopeId}>`);
            if (unref(isTourBookingPage)) {
              _push2(ssrRenderComponent(_component_UIBtn, {
                variant: "primary",
                onClick: gotoCheckout,
                class: "whitespace-nowrap"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(unref($t)("lanjutkan"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(unref($t)("lanjutkan")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (unref(isTourBookingCheckoutPage)) {
              _push2(ssrRenderComponent(_component_UIBtn, {
                variant: "primary",
                onClick: gotoCheckout,
                class: "whitespace-nowrap"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(unref($t)("pesan-dan-bayar"))}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(unref($t)("pesan-dan-bayar")), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex justify-end w-full" }, [
                createVNode("div", null, [
                  unref(isTourBookingPage) ? (openBlock(), createBlock(_component_UIBtn, {
                    key: 0,
                    variant: "primary",
                    onClick: gotoCheckout,
                    class: "whitespace-nowrap"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref($t)("lanjutkan")), 1)
                    ]),
                    _: 1
                  })) : createCommentVNode("", true),
                  unref(isTourBookingCheckoutPage) ? (openBlock(), createBlock(_component_UIBtn, {
                    key: 1,
                    variant: "primary",
                    onClick: gotoCheckout,
                    class: "whitespace-nowrap"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref($t)("pesan-dan-bayar")), 1)
                    ]),
                    _: 1
                  })) : createCommentVNode("", true)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tours/booking.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=booking-0df63b25.mjs.map
