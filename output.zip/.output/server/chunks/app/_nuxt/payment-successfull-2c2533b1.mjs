import { f as useI18n, d as useRoute, a as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import { defineComponent, computed, unref, withCtx, createTextVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "payment-successfull",
  __ssrInlineRender: true,
  setup(__props) {
    const { t: $t } = useI18n();
    const route = useRoute();
    const order_id = computed(() => {
      var _a;
      return (_a = route.query.order) != null ? _a : "";
    });
    useHead({
      title: $t("payment_success_page.title")
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="hero min-h-screen bg-base-200"><div class="hero-content text-center"><div class="max-w-md"><h1 class="text-3xl font-bold">${ssrInterpolate(unref($t)("payment_success_page.title"))}</h1><h3 class="text-2xl font-bold"># ${ssrInterpolate(unref(order_id))}</h3><p class="py-6">${ssrInterpolate(unref($t)("payment_success_page.description"))}</p>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "btn btn-primary"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(unref($t)("get_started_txt"))}`);
          } else {
            return [
              createTextVNode(toDisplayString(unref($t)("get_started_txt")), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/payment-successfull.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=payment-successfull-2c2533b1.mjs.map
