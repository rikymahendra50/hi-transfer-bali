import { f as useI18n, b as useRouter } from '../server.mjs';
import { useSSRContext, computed, mergeProps, unref } from 'vue';
import { u as useTourForm } from './useTourStore-4a6f0bac.mjs';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "Card",
  __ssrInlineRender: true,
  props: {
    id: { type: [String, Number] },
    name: { type: String },
    slug: { type: String },
    description: { type: [String, Array] },
    image: { type: String },
    price: { type: [String, Number] }
  },
  setup(__props) {
    const props = __props;
    const { locale, t: $t } = useI18n();
    useRouter();
    const result = computed(() => {
      return props.description.map((item) => item.name).join(" - ");
    });
    useTourForm({
      callback: () => {
        console.log("Form has been submitted!");
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      _push(`<a${ssrRenderAttrs(mergeProps({
        href: props.slug,
        class: "overflow-hidden rounded-xl space-y-2 border border-zinc-200 shadow-sm group cursor-pointer"
      }, _attrs))}><div class="h-[300px] overflow-hidden"><img${ssrRenderAttr("src", (_a = props.image) != null ? _a : "https://placehold.co/150")}${ssrRenderAttr("alt", __props.image)} class="h-[300px] w-full object-cover group-hover:scale-125 transition-all duration-300"></div><div class="p-3 space-y-4"><div><h4 class="text-xl font-semibold text-primary-dark">${ssrInterpolate(__props.name)}</h4><div class="text-zinc-400 text-sm line-clamp-2">${ssrInterpolate(unref(result))}</div></div><div><div class="text-zinc-400 text-xs">${ssrInterpolate(unref($t)("harga-mulai-dari"))}</div><h4 class="text-xl font-semibold text-primary">${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(__props.price.toString()))} /${ssrInterpolate(unref($t)("orang"))}</h4></div></div></a>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/Card.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main;

export { __nuxt_component_4 as _ };
//# sourceMappingURL=Card-80efc1d3.mjs.map
