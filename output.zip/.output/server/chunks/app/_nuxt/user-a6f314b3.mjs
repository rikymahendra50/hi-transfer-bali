import { n as defineNuxtRouteMiddleware, u as useAuth, o as executeAsync, p as navigateTo } from '../server.mjs';
import 'vue';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'vue/server-renderer';

const user = /* @__PURE__ */ defineNuxtRouteMiddleware(async (to, from) => {
  var _a;
  let __temp, __restore;
  const { $isUser, $user } = useAuth();
  if (!$isUser.value) {
    return [__temp, __restore] = executeAsync(() => navigateTo("/")), __temp = await __temp, __restore(), __temp;
  }
  if (((_a = $user.value) == null ? void 0 : _a.is_active) === 0) {
    return [__temp, __restore] = executeAsync(() => navigateTo("/user/inactive")), __temp = await __temp, __restore(), __temp;
  }
});

export { user as default };
//# sourceMappingURL=user-a6f314b3.mjs.map
