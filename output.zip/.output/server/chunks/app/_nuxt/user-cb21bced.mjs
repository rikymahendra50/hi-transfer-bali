import { l as _export_sfc, _ as __nuxt_component_0$1 } from '../server.mjs';
import { _ as _sfc_main$1 } from './Switch-d01fde47.mjs';
import { _ as _sfc_main$1$1, a as _sfc_main$2 } from './Default-5c3d07d4.mjs';
import { _ as __nuxt_component_4 } from './client-only-53a57ea8.mjs';
import { withCtx, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _imports_0 } from './hi-transfer-logo-97c0b5ac.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import './Icon-ab561e52.mjs';
import './config-3cecc2b8.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './Container-f78810bd.mjs';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0$1;
  const _component_LanguageSwitch = _sfc_main$1;
  const _component_ShareLoginRegister = _sfc_main$1$1;
  const _component_FooterDefault = _sfc_main$2;
  const _component_ClientOnly = __nuxt_component_4;
  _push(`<div${ssrRenderAttrs(_attrs)}><header class="fixed top-0 left-0 right-0 z-50 bg-white py-4 border-b"><div class="max-w-7xl mx-auto"><nav class="navbar"><div class="flex-1">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "link link-neutral link-hover",
    "active-class": "font-medium",
    to: "/"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="Hi Transfer" class="h-[60px] w-[60px]"${_scopeId}>`);
      } else {
        return [
          createVNode("img", {
            src: _imports_0,
            alt: "Hi Transfer",
            class: "h-[60px] w-[60px]"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="flex-none"><ul class="inline-flex items-center space-x-4"><li>`);
  _push(ssrRenderComponent(_component_LanguageSwitch, null, null, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_ShareLoginRegister, null, null, _parent));
  _push(`</li></ul></div></nav></div></header><main>`);
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</main>`);
  _push(ssrRenderComponent(_component_FooterDefault, null, null, _parent));
  _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/user.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const user = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { user as default };
//# sourceMappingURL=user-cb21bced.mjs.map
