import { e as useRequestOptions, h as useRequestHelper, i as useFetch } from '../server.mjs';
import { u as useNotification } from './nofication-1c3cca5e.mjs';
import { ref } from 'vue';

function useDestinations(options = {}) {
  const { requestOptions } = useRequestOptions();
  const { loading, message, alertType, setErrorMessage, transformErrors } = useRequestHelper();
  const { pushNotification } = useNotification();
  const selectedDestinations = ref();
  const dataForm = ref({
    name: void 0
  });
  function resetForm() {
    dataForm.value = {
      name: void 0
    };
  }
  function onSubmit(values, ctx) {
    if (selectedDestinations.value) {
      updateDestinations(ctx);
    } else {
      createDestinations(ctx);
    }
  }
  async function createDestinations(ctx) {
    const formData = new FormData();
    loading.value = true;
    for (const item in dataForm.value) {
      const objectItem = dataForm.value[item];
      formData.append(item, objectItem);
    }
    await $fetch("/admins/locations", {
      method: "POST",
      body: formData,
      ...requestOptions
    }).catch((error) => {
      var _a, _b;
      setErrorMessage((_a = error.data) == null ? void 0 : _a.message);
      ctx.setErrors(transformErrors(error.data));
      pushNotification({
        type: "error",
        text: (_b = error.value.data) == null ? void 0 : _b.message,
        title: "error"
      });
    }).then((data) => {
      var _a;
      if (data) {
        ctx.resetForm();
        pushNotification({
          type: "success",
          text: "Destinations created successfully"
        });
        (_a = options.callback) == null ? void 0 : _a.call(options);
      }
    });
    loading.value = false;
  }
  const updateDestinations = async (ctx) => {
    var _a;
    const formData = new FormData();
    loading.value = true;
    for (const item in dataForm.value) {
      const objectItem = dataForm.value[item];
      formData.append(item, objectItem);
    }
    await $fetch(
      `/admins/locations/${(_a = selectedDestinations.value) == null ? void 0 : _a.id}?_method=PUT`,
      {
        method: "POST",
        body: formData,
        ...requestOptions
      }
    ).catch((error) => {
      var _a2, _b;
      setErrorMessage((_a2 = error.data) == null ? void 0 : _a2.message);
      ctx.setErrors(transformErrors(error.data));
      pushNotification({
        type: "error",
        text: (_b = error.value.data) == null ? void 0 : _b.message,
        title: "error"
      });
    }).then((data) => {
      var _a2;
      if (data) {
        ctx.resetForm();
        pushNotification({
          type: "success",
          text: "Destinations updated successfully"
        });
        resetForm();
        (_a2 = options.callback) == null ? void 0 : _a2.call(options);
      }
    });
    loading.value = false;
  };
  async function deleteDestinations(id) {
    var _a2;
    var _a, _b, _c;
    loading.value = true;
    const { error } = await useFetch(
      `/admins/locations/${id}`,
      {
        method: "DELETE",
        ...requestOptions
      },
      "$ExCMoTkF92"
    );
    if (error.value) {
      setErrorMessage((_a2 = (_b = (_a = error.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message) != null ? _a2 : "Something went wrong");
    } else {
      pushNotification({
        type: "success",
        text: "Destinations deleted successfully"
      });
      (_c = options.callback) == null ? void 0 : _c.call(options);
    }
    loading.value = false;
  }
  return {
    selectedDestinations,
    dataForm,
    onSubmit,
    deleteDestinations,
    loading
  };
}

export { useDestinations as u };
//# sourceMappingURL=useDestinations-bb31ad70.mjs.map
