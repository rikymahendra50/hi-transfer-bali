import { ref } from 'vue';

function useTourForm(options = {}) {
  const dataForm = ref({
    location_id: null,
    activity_date: null,
    tourist_numbers: 1,
    price: void 0,
    product: [],
    forms: [],
    bookingForm: {
      variant: []
    },
    name: void 0,
    email: void 0,
    phone: void 0
  });
  function saveFormData() {
    sessionStorage.setItem("tourFormData", JSON.stringify(dataForm.value));
    console.log("Data tersimpan:", dataForm.value);
  }
  function showSavedTourData() {
    const savedData = sessionStorage.getItem("tourFormData");
    if (savedData) {
      dataForm.value = JSON.parse(savedData);
    }
  }
  function clearSavedTourData() {
    sessionStorage.removeItem("tourFormData");
    console.log("Tour form data dihapus dari sessionStorage");
  }
  function submitForm() {
    console.log("Form submitted:", dataForm.value);
    if (options.callback) {
      options.callback();
    }
  }
  return {
    submitForm,
    showSavedTourData,
    saveFormData,
    // Ganti duplikasi dengan fungsi `saveFormData`
    dataForm,
    clearSavedTourData
  };
}

export { useTourForm as u };
//# sourceMappingURL=useTourStore-2a5da3ea.mjs.map
