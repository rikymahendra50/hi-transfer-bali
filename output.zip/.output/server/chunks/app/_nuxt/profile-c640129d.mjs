import { Form, ErrorMessage } from 'vee-validate';
import { _ as _sfc_main$2 } from './Alert-4fa497cc.mjs';
import { _ as __nuxt_component_1, a as _sfc_main$2$1 } from './ChangePassword-50f45f51.mjs';
import { _ as _sfc_main$3 } from './MGroup-e711cd83.mjs';
import { _ as _sfc_main$4 } from './MTextField-bd75102a.mjs';
import { u as useSchema } from './useSchema-a44a23cb.mjs';
import { u as useAuth, a as useHead, e as useRequestOptions, h as useRequestHelper, f as useI18n, i as useFetch, k as useNuxtApp } from '../server.mjs';
import { u as useNotification } from './nofication-1c3cca5e.mjs';
import { useSSRContext, unref, defineComponent, withCtx, isRef, createVNode, ref, computed } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrIncludeBooleanAttr, ssrRenderAttr } from 'vue/server-renderer';
import './TransitionTopToBottom-a8e40871.mjs';
import './Icon-0f6314e3.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './index-a61f78d7.mjs';
import './index-596a8548.mjs';
import './Group-4dcbb69b.mjs';
import './TransitionX-601819e8.mjs';
import 'clsx';
import './usePasswordHelper-d8a46f8b.mjs';
import 'zod';
import '@vee-validate/zod';

function useProfile(usedBy, callback) {
  const { $user, $fetchAuthProfile } = useAuth();
  const { requestOptions } = useRequestOptions();
  useNotification();
  const { loading, message, alertType, setErrorMessage, transformErrors } = useRequestHelper();
  useI18n();
  const { $toast } = useNuxtApp();
  const dataForm = ref({
    email: "",
    first_name: "",
    last_name: "",
    phone: "",
    image: void 0,
    is_profile_picture_deleted: 0
  });
  const currentUserProfile = computed(() => {
    var _a2;
    var _a;
    return (_a2 = (_a = $user.value) == null ? void 0 : _a.image) != null ? _a2 : "";
  });
  async function updateProfile(values, ctx) {
    var _a2, _b2;
    var _a, _b, _c, _d, _e, _f;
    const formData = new FormData();
    const object = { ...dataForm.value };
    for (const item in object) {
      const objectItem = object[item];
      formData.append(item, objectItem);
    }
    if (!dataForm.value.image) {
      formData.delete("image");
    }
    loading.value = true;
    const { data, error } = await useFetch(
      `/users/profile?_method=PUT`,
      {
        headers: {
          Accept: "application/json"
        },
        method: "post",
        body: formData,
        ...requestOptions
      },
      "$aeNfF1ntZC"
    );
    if (error.value) {
      setErrorMessage((_a = error.value.data) == null ? void 0 : _a.message);
      ctx.setErrors(transformErrors((_b = error.value) == null ? void 0 : _b.data));
      $toast.error((_a2 = (_d = (_c = data.value) == null ? void 0 : _c.data) == null ? void 0 : _d.message) != null ? _a2 : "Fail update profile");
    } else {
      $toast.success((_b2 = (_f = (_e = data.value) == null ? void 0 : _e.data) == null ? void 0 : _f.message) != null ? _b2 : "Success update profile");
      await $fetchAuthProfile();
    }
    loading.value = false;
  }
  return {
    dataForm,
    updateProfile,
    message,
    alertType,
    loading,
    currentUserProfile
  };
}
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Profile",
  __ssrInlineRender: true,
  props: {
    usedBy: {
      type: String,
      default: "user"
    }
  },
  emits: ["reload"],
  setup(__props, { emit }) {
    const props = __props;
    const { updateProfileSchema } = useSchema();
    const {
      loading,
      message,
      alertType,
      dataForm,
      updateProfile,
      currentUserProfile
    } = useProfile(props.usedBy);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_Alert = _sfc_main$2;
      const _component_UIFormAvatar = _sfc_main$2$1;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_UIFormMGroup = _sfc_main$3;
      const _component_UIFormMTextField = _sfc_main$4;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit: unref(updateProfile),
        "validation-schema": unref(updateProfileSchema)
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Alert, {
              modelValue: unref(message),
              "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
              type: unref(alertType)
            }, null, _parent2, _scopeId));
            _push2(`<div class="flex flex-row items-center space-x-2"${_scopeId}><div class="flex-shrink-0"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormAvatar, {
              modelValue: unref(dataForm).image,
              "onUpdate:modelValue": ($event) => unref(dataForm).image = $event,
              "profile-image": unref(currentUserProfile)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "image",
              class: "form-error-message"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="text-sm text-[#506176]"${_scopeId}> Recommended dimensions: 200x200px. Max. file size: 1 MB </div></div>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Nama Pertama",
              name: "first_name"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: unref(dataForm).first_name,
                    "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
                    name: "first_name",
                    class: "input-bordered",
                    placeholder: "ex:jhon"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref(dataForm).first_name,
                      "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
                      name: "first_name",
                      class: "input-bordered",
                      placeholder: "ex:jhon"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Nama terakhir",
              name: "last_name"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: unref(dataForm).last_name,
                    "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
                    name: "last_name",
                    class: "input-bordered",
                    placeholder: "ex:doe"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref(dataForm).last_name,
                      "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
                      name: "last_name",
                      class: "input-bordered",
                      placeholder: "ex:doe"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Email",
              name: "email"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "email",
                    modelValue: unref(dataForm).email,
                    "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                    class: "input-bordered",
                    placeholder: "ex:myemail@gmail.com"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "email",
                      modelValue: unref(dataForm).email,
                      "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                      class: "input-bordered",
                      placeholder: "ex:myemail@gmail.com"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="h-1"${_scopeId}></div><div${_scopeId}><button class="btn btn-primary btn-block" type="submit"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""}${ssrRenderAttr("loading", unref(loading))}${_scopeId}> Update Profile </button></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 gap-4" }, [
                createVNode(_component_Alert, {
                  modelValue: unref(message),
                  "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
                  type: unref(alertType)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "type"]),
                createVNode("div", { class: "flex flex-row items-center space-x-2" }, [
                  createVNode("div", { class: "flex-shrink-0" }, [
                    createVNode(_component_UIFormAvatar, {
                      modelValue: unref(dataForm).image,
                      "onUpdate:modelValue": ($event) => unref(dataForm).image = $event,
                      "profile-image": unref(currentUserProfile)
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "profile-image"]),
                    createVNode(_component_VeeErrorMessage, {
                      name: "image",
                      class: "form-error-message"
                    })
                  ]),
                  createVNode("div", { class: "text-sm text-[#506176]" }, " Recommended dimensions: 200x200px. Max. file size: 1 MB ")
                ]),
                createVNode(_component_UIFormMGroup, {
                  label: "Nama Pertama",
                  name: "first_name"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref(dataForm).first_name,
                      "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
                      name: "first_name",
                      class: "input-bordered",
                      placeholder: "ex:jhon"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  label: "Nama terakhir",
                  name: "last_name"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref(dataForm).last_name,
                      "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
                      name: "last_name",
                      class: "input-bordered",
                      placeholder: "ex:doe"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  label: "Email",
                  name: "email"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      name: "email",
                      modelValue: unref(dataForm).email,
                      "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                      class: "input-bordered",
                      placeholder: "ex:myemail@gmail.com"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode("div", { class: "h-1" }),
                createVNode("div", null, [
                  createVNode("button", {
                    class: "btn btn-primary btn-block",
                    type: "submit",
                    disabled: unref(loading),
                    loading: unref(loading)
                  }, " Update Profile ", 8, ["disabled", "loading"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/Profile.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "profile",
  __ssrInlineRender: true,
  setup(__props) {
    const { $fetchAuthProfile } = useAuth();
    useHead({
      title: "User"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIFormProfile = _sfc_main$1;
      const _component_UIFormChangePassword = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="h-44 sm:h-28"></div><div class="flex justify-center mb-6"><div class="max-w-xl space-y-8 p-4">`);
      _push(ssrRenderComponent(_component_UIFormProfile, {
        onReload: ($event) => unref($fetchAuthProfile)(),
        "used-by": "user"
      }, null, _parent));
      _push(ssrRenderComponent(_component_UIFormChangePassword, { "used-by": "user" }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/profile.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=profile-c640129d.mjs.map
