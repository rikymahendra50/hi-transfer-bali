import { _ as __nuxt_component_0 } from './Container-c0bcb3c6.mjs';
import { useField, Form, ErrorMessage } from 'vee-validate';
import { _ as _sfc_main$4, a as __nuxt_component_0$1 } from './MGroup-69a23538.mjs';
import { _ as _sfc_main$5 } from './MTextField-61174a46.mjs';
import { useSSRContext, defineComponent, ref, mergeProps, withCtx, unref, createVNode, createTextVNode, toRef, inject, watch, computed, readonly } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrInterpolate, ssrRenderClass, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseEqual, ssrRenderSlot, ssrLooseContain } from 'vue/server-renderer';
import clsx from 'clsx';
import __nuxt_component_1 from './Icon-7218f0f6.mjs';
import { _ as _sfc_main$6 } from './MSelect-1f220a05.mjs';
import { _ as _sfc_main$7 } from './Btn-61213793.mjs';
import { d as useHead } from '../server.mjs';
import z from 'zod';
import { toTypedSchema } from '@vee-validate/zod';
import './config-aab100d3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "MTextarea",
  __ssrInlineRender: true,
  props: {
    modelValue: {},
    name: {},
    class: {},
    disabled: { type: Boolean, default: false },
    ariaLabel: {},
    placeholder: {},
    rows: {},
    cols: {},
    readonly: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const name = toRef(props, "name");
    const {
      value: inputValue,
      errorMessage
    } = useField(name, void 0, {
      syncVModel: true
    });
    const { setError } = inject("group-form");
    watch(errorMessage, (value) => {
      if (value) {
        setError(true);
      } else {
        setError(false);
      }
    });
    const textareaInput = computed({
      get() {
        return inputValue.value;
      },
      set(value) {
        inputValue.value = value;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TransitionX = __nuxt_component_0$1;
      const _component_VeeErrorMessage = ErrorMessage;
      _push(`<!--[--><textarea${ssrRenderAttrs(mergeProps({
        class: [unref(clsx)(
          "w-full h-full !outline-none focus:!border-none disabled:bg-gray-50"
        ), "w-full h-full"],
        name: unref(name),
        id: unref(name),
        readonly: "readonly" in _ctx ? _ctx.readonly : unref(readonly),
        disabled: _ctx.disabled,
        "aria-label": _ctx.ariaLabel,
        placeholder: _ctx.placeholder,
        rows: _ctx.rows,
        cols: _ctx.cols
      }, _ctx.$attrs), "textarea")}>${ssrInterpolate(unref(textareaInput))}</textarea>`);
      _push(ssrRenderComponent(_component_TransitionX, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: unref(name),
              class: "form-error-message"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_VeeErrorMessage, {
                name: unref(name),
                class: "form-error-message"
              }, null, 8, ["name"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/MTextarea.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "Radio",
  __ssrInlineRender: true,
  props: {
    name: {},
    label: {},
    modelValue: {},
    value: {},
    disabled: { type: Boolean, default: false },
    ariaLabel: { default: "toggle" },
    variant: {},
    size: {},
    class: {},
    readonly: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const name = toRef(props, "name");
    const variants = [
      "radio-primary",
      "radio-secondary",
      "radio-accent",
      "radio-info",
      "radio-success",
      "radio-warning",
      "radio-error"
    ];
    const sizes = [
      "radio-xs",
      "radio-sm",
      "radio-md",
      "radio-lg"
    ];
    const {
      value,
      errorMessage
    } = useField(name, void 0, {
      syncVModel: true,
      type: "radio"
    });
    const radioClass = computed(() => {
      return clsx(
        "radio",
        variants[variants.indexOf(`radio-${props.variant}`)],
        sizes[sizes.indexOf(`radio-${props.size}`)],
        props.class
      );
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "form-control w-full" }, _attrs))}><label class="py-0 label !justify-start cursor-pointer inline-flex space-x-4"><input type="radio" class="${ssrRenderClass(unref(radioClass))}"${ssrRenderAttr("name", props.name)}${ssrRenderAttr("value", props.value)}${ssrIncludeBooleanAttr(props.disabled) ? " disabled" : ""}${ssrIncludeBooleanAttr(ssrLooseEqual(unref(value), props.value)) ? " checked" : ""}${ssrRenderAttr("aria-label", _ctx.ariaLabel)}${ssrIncludeBooleanAttr(props.readonly) ? " readonly" : ""}>`);
      if (props.label || _ctx.$slots.default) {
        _push(`<span class="label-text">`);
        ssrRenderSlot(_ctx.$slots, "default", {}, () => {
          _push(`${ssrInterpolate(props.label)}`);
        }, _push, _parent);
        _push(`</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</label></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/Radio.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "Checkbox",
  __ssrInlineRender: true,
  props: {
    name: {},
    label: {},
    modelValue: {},
    disabled: { type: Boolean, default: false },
    ariaLabel: { default: "checkbox" },
    value: {},
    variant: {},
    size: {},
    class: {},
    readonly: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const name = toRef(props, "name");
    const variants = [
      "checkbox-primary",
      "checkbox-secondary",
      "checkbox-accent",
      "checkbox-info",
      "checkbox-success",
      "checkbox-warning",
      "checkbox-error"
    ];
    const sizes = [
      "checkbox-xs",
      "checkbox-sm",
      "checkbox-md",
      "checkbox-lg"
    ];
    const {
      value,
      errorMessage
    } = useField(name, void 0, {
      syncVModel: true,
      type: "checkbox"
    });
    const checkboxClass = computed(() => {
      return clsx(
        "checkbox  [--chkfg:white]",
        variants[variants.indexOf(`checkbox-${props.variant}`)],
        sizes[sizes.indexOf(`checkbox-${props.size}`)],
        props.class
      );
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "form-control max-w-full" }, _attrs))}><label class="py-0 label !justify-start cursor-pointer inline-flex gap-4"><input type="checkbox" class="${ssrRenderClass(unref(checkboxClass))}"${ssrRenderAttr("name", props.name)}${ssrIncludeBooleanAttr(props.disabled) ? " disabled" : ""}${ssrIncludeBooleanAttr(Array.isArray(unref(value)) ? ssrLooseContain(unref(value), props.value) : unref(value)) ? " checked" : ""}${ssrRenderAttr("aria-label", _ctx.ariaLabel)}${ssrRenderAttr("value", props.value)}${ssrIncludeBooleanAttr(props.readonly) ? " readonly" : ""}>`);
      if (props.label || _ctx.$slots.default) {
        _push(`<span class="label-text">`);
        ssrRenderSlot(_ctx.$slots, "default", {}, () => {
          _push(`${ssrInterpolate(props.label)}`);
        }, _push, _parent);
        _push(`</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</label></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/Checkbox.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "daisy-example",
  __ssrInlineRender: true,
  setup(__props) {
    const dataForm = ref({
      first_name: "",
      last_name: "",
      email: "",
      gender: "",
      address: "",
      password: "",
      confirm_password: "",
      job: "",
      hobby: []
    });
    const schema = toTypedSchema(
      z.object({
        first_name: z.string().min(1, "First name is required"),
        last_name: z.string().min(1, "Last name is required"),
        gender: z.string().min(1, "Gender is required"),
        email: z.string().email("Please enter a valid email"),
        password: z.string().min(7, "Password should be at least 7 characters").max(50, "Password should be at most 50 characters"),
        confirm_password: z.string().min(7, "Confirm Password should be at least 7 characters").max(50, "Confirm Password should be at most 50 characters")
      })
    );
    function onSubmit() {
      console.log(dataForm.value);
    }
    useHead({
      title: "DaisyUI Example"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_UIFormMGroup = _sfc_main$4;
      const _component_UIFormMTextField = _sfc_main$5;
      const _component_UIFormMTextarea = _sfc_main$3;
      const _component_Icon = __nuxt_component_1;
      const _component_UIFormMSelect = _sfc_main$6;
      const _component_UIFormRadio = _sfc_main$2;
      const _component_UIFormCheckbox = _sfc_main$1;
      const _component_UIBtn = _sfc_main$7;
      _push(ssrRenderComponent(_component_UIContainer, mergeProps({ class: "pb-10" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_VeeForm, {
              "validation-schema": unref(schema),
              onSubmit
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="space-y-3"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_UIFormMGroup, {
                    name: "first_name",
                    label: "First Name"
                  }, {
                    description: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<p${_scopeId3}>Enter your first name</p>`);
                      } else {
                        return [
                          createVNode("p", null, "Enter your first name")
                        ];
                      }
                    }),
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormMTextField, {
                          modelValue: unref(dataForm).first_name,
                          "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
                          name: "first_name",
                          placeholder: "ex: google account"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormMTextField, {
                            modelValue: unref(dataForm).first_name,
                            "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
                            name: "first_name",
                            placeholder: "ex: google account"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_UIFormMGroup, {
                    name: "last_name",
                    label: "Last Name"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormMTextField, {
                          modelValue: unref(dataForm).last_name,
                          "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
                          name: "last_name",
                          placeholder: "ex: google account"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormMTextField, {
                            modelValue: unref(dataForm).last_name,
                            "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
                            name: "last_name",
                            placeholder: "ex: google account"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_UIFormMGroup, {
                    name: "address",
                    label: "Address"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormMTextarea, {
                          name: "address",
                          placeholder: "ex: google account",
                          modelValue: unref(dataForm).address,
                          "onUpdate:modelValue": ($event) => unref(dataForm).address = $event
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormMTextarea, {
                            name: "address",
                            placeholder: "ex: google account",
                            modelValue: unref(dataForm).address,
                            "onUpdate:modelValue": ($event) => unref(dataForm).address = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_UIFormMGroup, {
                    name: "email",
                    label: "Email"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormMTextField, {
                          modelValue: unref(dataForm).email,
                          "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                          name: "email",
                          placeholder: "ex: google account"
                        }, {
                          leftSection: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_Icon, { name: "i-heroicons-envelope" }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_Icon, { name: "i-heroicons-envelope" })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormMTextField, {
                            modelValue: unref(dataForm).email,
                            "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                            name: "email",
                            placeholder: "ex: google account"
                          }, {
                            leftSection: withCtx(() => [
                              createVNode(_component_Icon, { name: "i-heroicons-envelope" })
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_UIFormMGroup, {
                    name: "gender",
                    label: "Gender"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormMSelect, {
                          name: "gender",
                          modelValue: unref(dataForm).gender,
                          "onUpdate:modelValue": ($event) => unref(dataForm).gender = $event,
                          placeholder: "Select gender"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(`<option value="" selected disabled${_scopeId4}>Select gender</option><option value="male"${_scopeId4}>Male</option><option value="female"${_scopeId4}>Female</option>`);
                            } else {
                              return [
                                createVNode("option", {
                                  value: "",
                                  selected: "",
                                  disabled: ""
                                }, "Select gender"),
                                createVNode("option", { value: "male" }, "Male"),
                                createVNode("option", { value: "female" }, "Female")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormMSelect, {
                            name: "gender",
                            modelValue: unref(dataForm).gender,
                            "onUpdate:modelValue": ($event) => unref(dataForm).gender = $event,
                            placeholder: "Select gender"
                          }, {
                            default: withCtx(() => [
                              createVNode("option", {
                                value: "",
                                selected: "",
                                disabled: ""
                              }, "Select gender"),
                              createVNode("option", { value: "male" }, "Male"),
                              createVNode("option", { value: "female" }, "Female")
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_UIFormMGroup, {
                    name: "password",
                    label: "Password"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormMTextField, {
                          modelValue: unref(dataForm).password,
                          "onUpdate:modelValue": ($event) => unref(dataForm).password = $event,
                          name: "password",
                          placeholder: "*********",
                          type: "password"
                        }, {
                          leftSection: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_Icon, { name: "i-heroicons-key" }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_Icon, { name: "i-heroicons-key" })
                              ];
                            }
                          }),
                          rightSection: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_Icon, { name: "i-heroicons-eye" }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_Icon, { name: "i-heroicons-eye" })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormMTextField, {
                            modelValue: unref(dataForm).password,
                            "onUpdate:modelValue": ($event) => unref(dataForm).password = $event,
                            name: "password",
                            placeholder: "*********",
                            type: "password"
                          }, {
                            leftSection: withCtx(() => [
                              createVNode(_component_Icon, { name: "i-heroicons-key" })
                            ]),
                            rightSection: withCtx(() => [
                              createVNode(_component_Icon, { name: "i-heroicons-eye" })
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_UIFormMGroup, {
                    name: "confirm_password",
                    label: "Confirm Password"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormMTextField, {
                          modelValue: unref(dataForm).confirm_password,
                          "onUpdate:modelValue": ($event) => unref(dataForm).confirm_password = $event,
                          name: "confirm_password",
                          placeholder: "*********",
                          type: "password"
                        }, {
                          leftSection: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_Icon, { name: "i-heroicons-key" }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_Icon, { name: "i-heroicons-key" })
                              ];
                            }
                          }),
                          rightSection: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_Icon, { name: "i-heroicons-eye" }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_Icon, { name: "i-heroicons-eye" })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormMTextField, {
                            modelValue: unref(dataForm).confirm_password,
                            "onUpdate:modelValue": ($event) => unref(dataForm).confirm_password = $event,
                            name: "confirm_password",
                            placeholder: "*********",
                            type: "password"
                          }, {
                            leftSection: withCtx(() => [
                              createVNode(_component_Icon, { name: "i-heroicons-key" })
                            ]),
                            rightSection: withCtx(() => [
                              createVNode(_component_Icon, { name: "i-heroicons-eye" })
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_UIFormMGroup, {
                    name: "job",
                    label: "Job"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="flex flex-col space-y-1 py-2"${_scopeId3}>`);
                        _push4(ssrRenderComponent(_component_UIFormRadio, {
                          modelValue: unref(dataForm).job,
                          "onUpdate:modelValue": ($event) => unref(dataForm).job = $event,
                          name: "job",
                          value: "frontend",
                          label: "Frontend",
                          variant: "primary"
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_UIFormRadio, {
                          modelValue: unref(dataForm).job,
                          "onUpdate:modelValue": ($event) => unref(dataForm).job = $event,
                          name: "job",
                          value: "Backend",
                          label: "Backend",
                          variant: "primary"
                        }, null, _parent4, _scopeId3));
                        _push4(`</div>`);
                      } else {
                        return [
                          createVNode("div", { class: "flex flex-col space-y-1 py-2" }, [
                            createVNode(_component_UIFormRadio, {
                              modelValue: unref(dataForm).job,
                              "onUpdate:modelValue": ($event) => unref(dataForm).job = $event,
                              name: "job",
                              value: "frontend",
                              label: "Frontend",
                              variant: "primary"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_component_UIFormRadio, {
                              modelValue: unref(dataForm).job,
                              "onUpdate:modelValue": ($event) => unref(dataForm).job = $event,
                              name: "job",
                              value: "Backend",
                              label: "Backend",
                              variant: "primary"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_UIFormMGroup, {
                    name: "hobby",
                    label: "Hobby"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="flex flex-col space-y-1 py-2"${_scopeId3}>`);
                        _push4(ssrRenderComponent(_component_UIFormCheckbox, {
                          modelValue: unref(dataForm).hobby,
                          "onUpdate:modelValue": ($event) => unref(dataForm).hobby = $event,
                          name: "hobby",
                          value: "music",
                          label: "Music",
                          variant: "primary"
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_UIFormCheckbox, {
                          modelValue: unref(dataForm).hobby,
                          "onUpdate:modelValue": ($event) => unref(dataForm).hobby = $event,
                          name: "hobby",
                          value: "gaming",
                          label: "Gaming",
                          variant: "primary"
                        }, null, _parent4, _scopeId3));
                        _push4(`</div>`);
                      } else {
                        return [
                          createVNode("div", { class: "flex flex-col space-y-1 py-2" }, [
                            createVNode(_component_UIFormCheckbox, {
                              modelValue: unref(dataForm).hobby,
                              "onUpdate:modelValue": ($event) => unref(dataForm).hobby = $event,
                              name: "hobby",
                              value: "music",
                              label: "Music",
                              variant: "primary"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_component_UIFormCheckbox, {
                              modelValue: unref(dataForm).hobby,
                              "onUpdate:modelValue": ($event) => unref(dataForm).hobby = $event,
                              name: "hobby",
                              value: "gaming",
                              label: "Gaming",
                              variant: "primary"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_UIBtn, {
                    type: "submit",
                    variant: "primary",
                    class: "text-white"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Submit`);
                      } else {
                        return [
                          createTextVNode("Submit")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "space-y-3" }, [
                      createVNode(_component_UIFormMGroup, {
                        name: "first_name",
                        label: "First Name"
                      }, {
                        description: withCtx(() => [
                          createVNode("p", null, "Enter your first name")
                        ]),
                        default: withCtx(() => [
                          createVNode(_component_UIFormMTextField, {
                            modelValue: unref(dataForm).first_name,
                            "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
                            name: "first_name",
                            placeholder: "ex: google account"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_UIFormMGroup, {
                        name: "last_name",
                        label: "Last Name"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_UIFormMTextField, {
                            modelValue: unref(dataForm).last_name,
                            "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
                            name: "last_name",
                            placeholder: "ex: google account"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_UIFormMGroup, {
                        name: "address",
                        label: "Address"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_UIFormMTextarea, {
                            name: "address",
                            placeholder: "ex: google account",
                            modelValue: unref(dataForm).address,
                            "onUpdate:modelValue": ($event) => unref(dataForm).address = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_UIFormMGroup, {
                        name: "email",
                        label: "Email"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_UIFormMTextField, {
                            modelValue: unref(dataForm).email,
                            "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                            name: "email",
                            placeholder: "ex: google account"
                          }, {
                            leftSection: withCtx(() => [
                              createVNode(_component_Icon, { name: "i-heroicons-envelope" })
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_UIFormMGroup, {
                        name: "gender",
                        label: "Gender"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_UIFormMSelect, {
                            name: "gender",
                            modelValue: unref(dataForm).gender,
                            "onUpdate:modelValue": ($event) => unref(dataForm).gender = $event,
                            placeholder: "Select gender"
                          }, {
                            default: withCtx(() => [
                              createVNode("option", {
                                value: "",
                                selected: "",
                                disabled: ""
                              }, "Select gender"),
                              createVNode("option", { value: "male" }, "Male"),
                              createVNode("option", { value: "female" }, "Female")
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_UIFormMGroup, {
                        name: "password",
                        label: "Password"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_UIFormMTextField, {
                            modelValue: unref(dataForm).password,
                            "onUpdate:modelValue": ($event) => unref(dataForm).password = $event,
                            name: "password",
                            placeholder: "*********",
                            type: "password"
                          }, {
                            leftSection: withCtx(() => [
                              createVNode(_component_Icon, { name: "i-heroicons-key" })
                            ]),
                            rightSection: withCtx(() => [
                              createVNode(_component_Icon, { name: "i-heroicons-eye" })
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_UIFormMGroup, {
                        name: "confirm_password",
                        label: "Confirm Password"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_UIFormMTextField, {
                            modelValue: unref(dataForm).confirm_password,
                            "onUpdate:modelValue": ($event) => unref(dataForm).confirm_password = $event,
                            name: "confirm_password",
                            placeholder: "*********",
                            type: "password"
                          }, {
                            leftSection: withCtx(() => [
                              createVNode(_component_Icon, { name: "i-heroicons-key" })
                            ]),
                            rightSection: withCtx(() => [
                              createVNode(_component_Icon, { name: "i-heroicons-eye" })
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_UIFormMGroup, {
                        name: "job",
                        label: "Job"
                      }, {
                        default: withCtx(() => [
                          createVNode("div", { class: "flex flex-col space-y-1 py-2" }, [
                            createVNode(_component_UIFormRadio, {
                              modelValue: unref(dataForm).job,
                              "onUpdate:modelValue": ($event) => unref(dataForm).job = $event,
                              name: "job",
                              value: "frontend",
                              label: "Frontend",
                              variant: "primary"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_component_UIFormRadio, {
                              modelValue: unref(dataForm).job,
                              "onUpdate:modelValue": ($event) => unref(dataForm).job = $event,
                              name: "job",
                              value: "Backend",
                              label: "Backend",
                              variant: "primary"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_UIFormMGroup, {
                        name: "hobby",
                        label: "Hobby"
                      }, {
                        default: withCtx(() => [
                          createVNode("div", { class: "flex flex-col space-y-1 py-2" }, [
                            createVNode(_component_UIFormCheckbox, {
                              modelValue: unref(dataForm).hobby,
                              "onUpdate:modelValue": ($event) => unref(dataForm).hobby = $event,
                              name: "hobby",
                              value: "music",
                              label: "Music",
                              variant: "primary"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_component_UIFormCheckbox, {
                              modelValue: unref(dataForm).hobby,
                              "onUpdate:modelValue": ($event) => unref(dataForm).hobby = $event,
                              name: "hobby",
                              value: "gaming",
                              label: "Gaming",
                              variant: "primary"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_UIBtn, {
                        type: "submit",
                        variant: "primary",
                        class: "text-white"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Submit")
                        ]),
                        _: 1
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_VeeForm, {
                "validation-schema": unref(schema),
                onSubmit
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "space-y-3" }, [
                    createVNode(_component_UIFormMGroup, {
                      name: "first_name",
                      label: "First Name"
                    }, {
                      description: withCtx(() => [
                        createVNode("p", null, "Enter your first name")
                      ]),
                      default: withCtx(() => [
                        createVNode(_component_UIFormMTextField, {
                          modelValue: unref(dataForm).first_name,
                          "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
                          name: "first_name",
                          placeholder: "ex: google account"
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_UIFormMGroup, {
                      name: "last_name",
                      label: "Last Name"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormMTextField, {
                          modelValue: unref(dataForm).last_name,
                          "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
                          name: "last_name",
                          placeholder: "ex: google account"
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_UIFormMGroup, {
                      name: "address",
                      label: "Address"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormMTextarea, {
                          name: "address",
                          placeholder: "ex: google account",
                          modelValue: unref(dataForm).address,
                          "onUpdate:modelValue": ($event) => unref(dataForm).address = $event
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_UIFormMGroup, {
                      name: "email",
                      label: "Email"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormMTextField, {
                          modelValue: unref(dataForm).email,
                          "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                          name: "email",
                          placeholder: "ex: google account"
                        }, {
                          leftSection: withCtx(() => [
                            createVNode(_component_Icon, { name: "i-heroicons-envelope" })
                          ]),
                          _: 1
                        }, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_UIFormMGroup, {
                      name: "gender",
                      label: "Gender"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormMSelect, {
                          name: "gender",
                          modelValue: unref(dataForm).gender,
                          "onUpdate:modelValue": ($event) => unref(dataForm).gender = $event,
                          placeholder: "Select gender"
                        }, {
                          default: withCtx(() => [
                            createVNode("option", {
                              value: "",
                              selected: "",
                              disabled: ""
                            }, "Select gender"),
                            createVNode("option", { value: "male" }, "Male"),
                            createVNode("option", { value: "female" }, "Female")
                          ]),
                          _: 1
                        }, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_UIFormMGroup, {
                      name: "password",
                      label: "Password"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormMTextField, {
                          modelValue: unref(dataForm).password,
                          "onUpdate:modelValue": ($event) => unref(dataForm).password = $event,
                          name: "password",
                          placeholder: "*********",
                          type: "password"
                        }, {
                          leftSection: withCtx(() => [
                            createVNode(_component_Icon, { name: "i-heroicons-key" })
                          ]),
                          rightSection: withCtx(() => [
                            createVNode(_component_Icon, { name: "i-heroicons-eye" })
                          ]),
                          _: 1
                        }, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_UIFormMGroup, {
                      name: "confirm_password",
                      label: "Confirm Password"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormMTextField, {
                          modelValue: unref(dataForm).confirm_password,
                          "onUpdate:modelValue": ($event) => unref(dataForm).confirm_password = $event,
                          name: "confirm_password",
                          placeholder: "*********",
                          type: "password"
                        }, {
                          leftSection: withCtx(() => [
                            createVNode(_component_Icon, { name: "i-heroicons-key" })
                          ]),
                          rightSection: withCtx(() => [
                            createVNode(_component_Icon, { name: "i-heroicons-eye" })
                          ]),
                          _: 1
                        }, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_UIFormMGroup, {
                      name: "job",
                      label: "Job"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "flex flex-col space-y-1 py-2" }, [
                          createVNode(_component_UIFormRadio, {
                            modelValue: unref(dataForm).job,
                            "onUpdate:modelValue": ($event) => unref(dataForm).job = $event,
                            name: "job",
                            value: "frontend",
                            label: "Frontend",
                            variant: "primary"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_component_UIFormRadio, {
                            modelValue: unref(dataForm).job,
                            "onUpdate:modelValue": ($event) => unref(dataForm).job = $event,
                            name: "job",
                            value: "Backend",
                            label: "Backend",
                            variant: "primary"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_UIFormMGroup, {
                      name: "hobby",
                      label: "Hobby"
                    }, {
                      default: withCtx(() => [
                        createVNode("div", { class: "flex flex-col space-y-1 py-2" }, [
                          createVNode(_component_UIFormCheckbox, {
                            modelValue: unref(dataForm).hobby,
                            "onUpdate:modelValue": ($event) => unref(dataForm).hobby = $event,
                            name: "hobby",
                            value: "music",
                            label: "Music",
                            variant: "primary"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_component_UIFormCheckbox, {
                            modelValue: unref(dataForm).hobby,
                            "onUpdate:modelValue": ($event) => unref(dataForm).hobby = $event,
                            name: "hobby",
                            value: "gaming",
                            label: "Gaming",
                            variant: "primary"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_UIBtn, {
                      type: "submit",
                      variant: "primary",
                      class: "text-white"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Submit")
                      ]),
                      _: 1
                    })
                  ])
                ]),
                _: 1
              }, 8, ["validation-schema"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/daisy-example.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=daisy-example-8ba80c7c.mjs.map
