import { useSSRContext, defineComponent, resolveComponent, withCtx, createTextVNode, createVNode, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';
import __nuxt_component_1 from './Icon-9a1ee2a3.mjs';
import { f as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import './config-71e93c9c.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "HeadPage",
  __ssrInlineRender: true,
  props: {
    title: { default: "title" },
    description: { default: "description" }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 border-b flex justify-between items-center" }, _attrs))}><div><div>${ssrInterpolate(props.title)}</div><div class="text-sm opacity-80">${ssrInterpolate(props.description)}</div></div><div>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Common/HeadPage.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Orders"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CommonHeadPage = _sfc_main$1;
      const _component_VDropdown = resolveComponent("VDropdown");
      const _component_Icon = __nuxt_component_1;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_CommonHeadPage, {
        title: "Manage Incoming Orders",
        description: "Review, approve, and process orders with ease."
      }, null, _parent));
      _push(`<div class="overflow-x-auto"><table class="table"><thead><tr><th><div class="text-[#989393]">OrderID</div></th><th><div class="text-[#989393]">Customers Name</div></th><th><div class="text-[#989393]">Contact Information</div></th><th><div class="text-[#989393]">Order Type</div></th><th><div class="text-[#989393]">Total Price</div></th><th>Payment Status</th><th></th></tr></thead><tbody><tr><td class="text-sm font-normal text-[#989393]">TP12356780</td><td class="">Cy Ganderton</td><td><div class="text-[#989393] !font-normal">Riky@gmail.com</div></td><td><div class="text-[#989393] !font-normal">Transport</div></td><td>Rp.100.000</td><td><div class="">Paid</div></td><td><div class="flex items-center">`);
      _push(ssrRenderComponent(_component_VDropdown, null, {
        popper: withCtx(({ hide }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-white flex flex-col shadow"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, {
              to: `/admin/orders/order-detail-fastboat/slug`,
              class: "hover:bg-orange-400 hover:text-white py-3 px-5"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Detail `);
                } else {
                  return [
                    createTextVNode(" Detail ")
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<button type="button" class="hover:bg-red-600 hover:text-white py-3 px-5"${_scopeId}> Delete </button></div>`);
          } else {
            return [
              createVNode("div", { class: "bg-white flex flex-col shadow" }, [
                createVNode(_component_NuxtLink, {
                  to: `/admin/orders/order-detail-fastboat/slug`,
                  class: "hover:bg-orange-400 hover:text-white py-3 px-5"
                }, {
                  default: withCtx(() => [
                    createTextVNode(" Detail ")
                  ]),
                  _: 1
                }),
                createVNode("button", {
                  type: "button",
                  class: "hover:bg-red-600 hover:text-white py-3 px-5"
                }, " Delete ")
              ])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex items-center justify-center"${_scopeId}><button class="flex items-center justify-center cursor-pointer"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Icon, {
              name: "pepicons-pencil:dots-y",
              class: "text-[#717171]"
            }, null, _parent2, _scopeId));
            _push2(`</button></div>`);
          } else {
            return [
              createVNode("div", { class: "flex items-center justify-center" }, [
                createVNode("button", { class: "flex items-center justify-center cursor-pointer" }, [
                  createVNode(_component_Icon, {
                    name: "pepicons-pencil:dots-y",
                    class: "text-[#717171]"
                  })
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></td></tr></tbody></table></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/orders/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-e895dd08.mjs.map
