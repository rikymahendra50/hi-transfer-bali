import { _ as __nuxt_component_0 } from './TitleBack-aa5a1267.mjs';
import { _ as __nuxt_component_1 } from './TourPackage-e7f31c71.mjs';
import { u as useSchema } from './useSchema-7a41625c.mjs';
import { f as useI18n, e as useRequestOptions, d as useRoute, a as useHead, g as useAsyncData } from '../server.mjs';
import { computed, withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './Icon-0f6314e3.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'vee-validate';
import './TextFieldWLabel-0de16bf1.mjs';
import './DropdownsTest-7ab0ea03.mjs';
import './index-a61f78d7.mjs';
import './index-596a8548.mjs';
import './TabItem-142d001b.mjs';
import './client-only-53a57ea8.mjs';
import 'clsx';
import './Group-4dcbb69b.mjs';
import './useTourPackage-62984830.mjs';
import './nofication-1c3cca5e.mjs';
import '@tiptap/vue-3';
import '@tiptap/starter-kit';
import '@tiptap/extension-link';
import '@tiptap/extension-text-align';
import '@tiptap/extension-placeholder';
import '@tiptap/extension-table';
import '@tiptap/extension-table-cell';
import '@tiptap/extension-table-header';
import '@tiptap/extension-table-row';
import 'tiptap-extension-resize-image';
import 'zod';
import '@vee-validate/zod';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "edit",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useSchema();
    useI18n();
    const { requestOptions } = useRequestOptions();
    const route = useRoute();
    const slug = computed(() => route.params.slug);
    useHead({
      title: "Edit Paket tur"
    });
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "tours",
      () => $fetch(`/admins/tours/${slug.value}`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_TitleBack = __nuxt_component_0;
      const _component_UIFormTourPackage = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "px-5 py-6 md:px-10 md:py-10" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_TitleBack, {
        title: "Edit tour package",
        link: "/admin/tour-package"
      }, null, _parent));
      _push(ssrRenderComponent(_component_UIFormTourPackage, {
        tourPackage: (_a = unref(data)) == null ? void 0 : _a.data
      }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/tour-package/[slug]/edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=edit-5d41ae3c.mjs.map
