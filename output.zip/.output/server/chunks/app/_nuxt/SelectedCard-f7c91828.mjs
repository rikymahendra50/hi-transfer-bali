import { defineComponent, mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "SelectedCard",
  __ssrInlineRender: true,
  props: {
    name: {
      type: String
    },
    desk: {
      type: String
    },
    image: {
      type: String
    }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid grid-cols-[100px_1fr] border rounded-xl p-2 space-x-2" }, _attrs))}><div class="flex items-center"><div class="rounded-xl overflow-hidden w-[100px] h-[100px]"><img${ssrRenderAttr("src", props.image)} alt="" class="w-full h-full object-cover"></div></div><div class="flex flex-col justify-between space-y-4"><div class="text-lg font-semibold">${ssrInterpolate(props.name)}</div><div><div class="text-zinc-400 text-xs">Destinasi</div><div class="text-sm">${ssrInterpolate(props.desk)}</div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/SelectedCard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=SelectedCard-f7c91828.mjs.map
