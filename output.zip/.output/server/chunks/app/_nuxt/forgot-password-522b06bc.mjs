import { _ as _sfc_main$2, a as _sfc_main$1, b as _sfc_main$3 } from './Change-84ae2ca1.mjs';
import { f as useI18n, b as useRouter, u as useAuth, a as useHead } from '../server.mjs';
import { defineComponent, computed, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { u as useStepper } from './index-dea25161.mjs';
import 'vee-validate';
import './Alert-28d19591.mjs';
import './TransitionTopToBottom-a8e40871.mjs';
import './Icon-ab561e52.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './MGroup-56a6a0a6.mjs';
import './TransitionX-601819e8.mjs';
import 'clsx';
import './MTextField-bd75102a.mjs';
import './Btn-577fa59f.mjs';
import './useSchema-27c20d48.mjs';
import 'zod';
import '@vee-validate/zod';
import './Group-4dcbb69b.mjs';
import './InputOTP-bbb2b053.mjs';
import './index-596a8548.mjs';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "forgot-password",
  __ssrInlineRender: true,
  setup(__props) {
    const { locale, t: $t } = useI18n();
    const router = useRouter();
    const stepper = useStepper({
      "forgot-password": {
        title: $t("lupa-password-?"),
        isValid: () => true
      },
      otp: {
        title: "Verification OTP",
        isValid: () => true
      },
      "change-password": {
        title: $t("change-password"),
        isValid: () => true
      }
    });
    const { $credentialForgotPassword } = useAuth();
    const titleHeader = computed(() => {
      var _a2;
      var _a, _b;
      return (_a2 = (_b = (_a = stepper.current) == null ? void 0 : _a.value) == null ? void 0 : _b.title) != null ? _a2 : $t("lupa-password-?");
    });
    function goToHome() {
      router.push("/");
    }
    useHead({
      title: titleHeader.value
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ForgotPassword = _sfc_main$2;
      const _component_ForgotPasswordVerifiedOTP = _sfc_main$1;
      const _component_ForgotPasswordChange = _sfc_main$3;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "hero min-h-screen" }, _attrs))}><div class="hero-content text-center"><div class="max-w-[500px] border rounded-xl"><div class="py-4 text-center"><h1 class="text-xl font-bold">${ssrInterpolate(unref(stepper).current.value.title)}</h1></div>`);
      if (unref(stepper).isCurrent("forgot-password")) {
        _push(ssrRenderComponent(_component_ForgotPassword, {
          email: unref($credentialForgotPassword).email,
          "onUpdate:email": ($event) => unref($credentialForgotPassword).email = $event,
          onNext: () => unref(stepper).goTo("otp")
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(stepper).isCurrent("otp")) {
        _push(ssrRenderComponent(_component_ForgotPasswordVerifiedOTP, {
          pin: unref($credentialForgotPassword).pin,
          "onUpdate:pin": ($event) => unref($credentialForgotPassword).pin = $event,
          email: unref($credentialForgotPassword).email,
          onNext: () => unref(stepper).goTo("change-password")
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(stepper).isCurrent("change-password")) {
        _push(ssrRenderComponent(_component_ForgotPasswordChange, {
          email: unref($credentialForgotPassword).email,
          pin: unref($credentialForgotPassword).pin,
          onNext: goToHome
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/forgot-password.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=forgot-password-522b06bc.mjs.map
