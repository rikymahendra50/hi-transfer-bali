import { _ as __nuxt_component_0 } from './TitleAdmin-130db81a.mjs';
import { defineComponent, ref, useSSRContext } from 'vue';
import { f as useHead } from '../server.mjs';
import { ssrRenderComponent } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[slug]",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Order detail"
    });
    ref({
      sort: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TitleAdmin = __nuxt_component_0;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_TitleAdmin, {
        title: "Ringkasan Pesanan",
        subTitle: "Informasi lengkap untuk pesanan TP12356780"
      }, null, _parent));
      _push(`<div class="px-5 py-4 flex flex-col gap-3 border-b"><div class="text-gray-500 uppercase">Informasi Pelanggan</div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Nama pelanggan:</p><p>Lorem, ipsum.</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Email:</p><p>coopertorff@mail.com</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold text-sm">Nomor Telepon:</p><p>+6281234567890</p></div></div><div class="px-5 py-4 flex flex-col gap-3 border-b"><div class="text-gray-500 uppercase">Informasi Pemesanan</div><div class="grid gap-3 md:grid-cols-2"><div class="flex flex-col gap-1 text-sm"><p class="text-[#121212] font-semibold">Penjemputan</p><p class="font-normal">Bandara Int&#39;l I Gusti Ngurah Rai</p><p class="font-normal text-[#16161697]"> Jln. Raya Gusti Ngurah Rai, Tuban, Kec. Kuta, Kabupaten Badung, Bali 80362 </p></div><div class="flex flex-col gap-1 text-sm"><p class="text-[#121212] font-semibold">Pengantaran</p><p class="font-normal">The Trans Resort Bali</p><p class="font-normal text-[#16161697]"> Jl. Sunset Road No.30, Kerobokan Kelod, Kec. Kuta Utara, Kabupaten Badung, Bali 80361 </p></div></div></div><div class="px-5 py-4 flex flex-col gap-3 border-b"><div class="text-gray-500 uppercase">Payment Information</div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Payment Method</p><p>Bank Transfer</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Payment Channel</p><p>Bank BCA</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold text-sm">Payment Status</p><p>Paid</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold text-sm">Total Price</p><p>Rp.1.700.000</p></div></div><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/orders/order-detail-fastboat/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-ff3b007f.mjs.map
