import { a as useRequestOptions, u as useRequestHelper, h as useFetch } from '../server.mjs';
import { u as useNotification } from './nofication-176ebe9f.mjs';
import { ref, computed } from 'vue';

function useFacility(options = {}) {
  const { requestOptions } = useRequestOptions();
  const { loading, message, alertType, setErrorMessage, transformErrors } = useRequestHelper();
  const { pushNotification } = useNotification();
  const selectedFacility = ref();
  const dataForm = ref({
    "description[en]": "",
    "description[id]": "",
    image: ""
  });
  function resetForm() {
    dataForm.value = {
      "description[en]": "",
      "description[id]": "",
      image: ""
    };
  }
  const existingImage = computed(() => {
    var _a;
    return (_a = selectedFacility.value) == null ? void 0 : _a.image;
  });
  function onSubmit(values, ctx) {
    if (selectedFacility.value) {
      updateFacility(ctx);
    } else {
      createFacility(ctx);
    }
  }
  async function createFacility(ctx) {
    const formData = new FormData();
    loading.value = true;
    for (const item in dataForm.value) {
      const objectItem = dataForm.value[item];
      formData.append(item, objectItem);
    }
    await $fetch("/admins/facilities", {
      method: "POST",
      body: formData,
      ...requestOptions
    }).catch((error) => {
      var _a;
      setErrorMessage((_a = error.data) == null ? void 0 : _a.message);
      ctx.setErrors(transformErrors(error.data));
    }).then((data) => {
      var _a;
      if (data) {
        ctx.resetForm();
        pushNotification({
          type: "success",
          text: "Facility created successfully"
        });
        (_a = options.callback) == null ? void 0 : _a.call(options);
      }
    });
    loading.value = false;
  }
  const updateFacility = async (ctx) => {
    var _a;
    const formData = new FormData();
    loading.value = true;
    for (const item in dataForm.value) {
      const objectItem = dataForm.value[item];
      formData.append(item, objectItem);
    }
    await $fetch(
      `/admins/facilities/${(_a = selectedFacility.value) == null ? void 0 : _a.id}?_method=PUT`,
      {
        headers: {
          Accept: "application/json"
        },
        method: "POST",
        body: formData,
        ...requestOptions
      }
    ).catch((error) => {
      var _a2;
      setErrorMessage((_a2 = error.data) == null ? void 0 : _a2.message);
      ctx.setErrors(transformErrors(error.data));
    }).then((data) => {
      var _a2;
      if (data) {
        ctx.resetForm();
        pushNotification({
          type: "success",
          text: "Facility updated successfully"
        });
        resetForm();
        (_a2 = options.callback) == null ? void 0 : _a2.call(options);
      }
    });
    loading.value = false;
  };
  async function deleteFacility(id) {
    var _a2;
    var _a, _b, _c;
    loading.value = true;
    const { error } = await useFetch(
      `/admins/facilities/${id}`,
      {
        method: "DELETE",
        ...requestOptions
      },
      "$yDwk1SittD"
    );
    if (error.value) {
      setErrorMessage((_a2 = (_b = (_a = error.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message) != null ? _a2 : "Something went wrong");
    } else {
      pushNotification({
        type: "success",
        text: "Facility deleted successfully"
      });
      (_c = options.callback) == null ? void 0 : _c.call(options);
    }
    loading.value = false;
  }
  return {
    selectedFacility,
    dataForm,
    onSubmit,
    deleteFacility,
    existingImage,
    loading
  };
}

export { useFacility as u };
//# sourceMappingURL=useFacility-798c1e91.mjs.map
