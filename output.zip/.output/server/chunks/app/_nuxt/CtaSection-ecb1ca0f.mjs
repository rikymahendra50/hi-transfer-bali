import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { f as useI18n, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_1 from './Icon-ab561e52.mjs';
import { defineComponent, mergeProps, unref, withCtx, createTextVNode, toDisplayString, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';

const _imports_0 = "" + publicAssetsURL("hi-travel-cta.png");
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "CtaSection",
  __ssrInlineRender: true,
  props: {
    link: {
      type: String,
      default: "#learnmore"
    }
  },
  setup(__props) {
    const props = __props;
    const { locale, t: $t } = useI18n();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "relative" }, _attrs))}><div class="absolute w-full h-full bg-black/50 grid place-items-center"><div class="max-w-xl text-center space-y-6"><h3 class="text-4xl lg:text-5xl font-semibold text-white">${ssrInterpolate(unref($t)("sudah-siap-menjelajahi-bali"))}</h3><p class="text-base lg:text-xl text-white">${ssrInterpolate(unref($t)("enjoy-a-holiday"))}</p><div>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: props.link,
        class: "btn btn-primary text-white font-medium leading-4"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(unref($t)("jelajahi-lebih-lanjut"))} `);
            _push2(ssrRenderComponent(_component_Icon, {
              name: "i-heroicons-arrow-right-20-solid",
              class: "-rotate-45 h-5 w-5"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createTextVNode(toDisplayString(unref($t)("jelajahi-lebih-lanjut")) + " ", 1),
              createVNode(_component_Icon, {
                name: "i-heroicons-arrow-right-20-solid",
                class: "-rotate-45 h-5 w-5"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div><img${ssrRenderAttr("src", _imports_0)} alt="cta" class="w-full h-[490px]"></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Share/CtaSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=CtaSection-ecb1ca0f.mjs.map
