import { ref } from 'vue';
import { h as defineStore } from '../server.mjs';

const useVehicleForm = defineStore("VehicleForm", () => {
  const dataForm = ref({
    name: "",
    email: "",
    phone: ""
  });
  const isLoading = ref(false);
  const btnSubmit = ref();
  function btnSubmitClick() {
    var _a;
    (_a = btnSubmit.value) == null ? void 0 : _a.click();
  }
  return {
    dataForm,
    btnSubmit,
    isLoading,
    btnSubmitClick
  };
});

export { useVehicleForm as u };
//# sourceMappingURL=vehicleForm-b4695968.mjs.map
