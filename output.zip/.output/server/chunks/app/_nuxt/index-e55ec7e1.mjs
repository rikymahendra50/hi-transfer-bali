import { _ as __nuxt_component_0 } from './TitleAdmin-130db81a.mjs';
import { h as useRequestHelper, e as useRequestOptions, b as useRouter, d as useRoute, a as useHead, g as useAsyncData, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_0$2 from './Icon-0f6314e3.mjs';
import { _ as __nuxt_component_2 } from './PaginationAdmin-f2cea012.mjs';
import { ref, withAsyncContext, watch, resolveComponent, mergeProps, withCtx, createTextVNode, createVNode, unref, isRef, useSSRContext } from 'vue';
import { o as withQuery } from '../../nitro/node-server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import './config-3cecc2b8.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    const route = useRoute();
    const page = ref(1);
    useHead({
      title: "Admin list"
    });
    if (route.query.page) {
      page.value = Number(route.query.page);
    }
    const { data, error } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "admin-list",
      () => $fetch(`/admins?page=${page.value}`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    watch(page, (newValue, oldValue) => {
      if (newValue !== oldValue) {
        router.replace(
          withQuery("/admin/admin-list", {
            page: newValue
          })
        );
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
      const _component_TitleAdmin = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_VDropdown = resolveComponent("VDropdown");
      const _component_Icon = __nuxt_component_0$2;
      const _component_PaginationAdmin = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_TitleAdmin, {
        title: "Daftar Admin",
        subTitle: "Kelola daftar admin "
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_NuxtLink, {
              to: "/admin/admin-list/add",
              class: "border-2 py-4 px-6 rounded-[8px] shadow-xs font-medium text-black"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Tambah Admin baru `);
                } else {
                  return [
                    createTextVNode(" Tambah Admin baru ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_NuxtLink, {
                to: "/admin/admin-list/add",
                class: "border-2 py-4 px-6 rounded-[8px] shadow-xs font-medium text-black"
              }, {
                default: withCtx(() => [
                  createTextVNode(" Tambah Admin baru ")
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<table class="table"><thead><tr><th><div class="text-[#989393]">List Admin</div></th><th><div class="text-[#989393]">Email</div></th><th><div class="text-[#989393]">Status</div></th><th></th></tr></thead><tbody><!--[-->`);
      ssrRenderList((_a = unref(data)) == null ? void 0 : _a.data, (item) => {
        _push(`<tr><td class="text-sm font-normal"><div class="font-medium text-[14px] text-black">${ssrInterpolate(item.first_name + " " + item.last_name)}</div></td><td class="text-sm font-normal"><div class="font-medium text-[14px] text-black">${ssrInterpolate(item.email)}</div></td><td class="text-sm font-normal"><div class="font-medium text-[14px] text-black">${ssrInterpolate(item.is_active === 0 ? "Tidak aktif" : "Aktif")}</div></td><td class="text-sm font-normal">`);
        _push(ssrRenderComponent(_component_VDropdown, null, {
          popper: withCtx(({ hide }, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="bg-white flex flex-col shadow"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_NuxtLink, {
                to: `/admin/admin-list/${item.uuid}/edit`,
                class: "hover:bg-orange-400 hover:text-white py-2 px-3"
              }, {
                default: withCtx((_, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Edit `);
                  } else {
                    return [
                      createTextVNode(" Edit ")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "bg-white flex flex-col shadow" }, [
                  createVNode(_component_NuxtLink, {
                    to: `/admin/admin-list/${item.uuid}/edit`,
                    class: "hover:bg-orange-400 hover:text-white py-2 px-3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Edit ")
                    ]),
                    _: 2
                  }, 1032, ["to"])
                ])
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex items-center justify-center"${_scopeId}><button class="flex items-center justify-center cursor-pointer"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, {
                name: "pepicons-pencil:dots-y",
                class: "text-[#717171]"
              }, null, _parent2, _scopeId));
              _push2(`</button></div>`);
            } else {
              return [
                createVNode("div", { class: "flex items-center justify-center" }, [
                  createVNode("button", { class: "flex items-center justify-center cursor-pointer" }, [
                    createVNode(_component_Icon, {
                      name: "pepicons-pencil:dots-y",
                      class: "text-[#717171]"
                    })
                  ])
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</td></tr>`);
      });
      _push(`<!--]--></tbody></table><div class="flex flex-col md:flex-row items-center justify-between gap-3 w-full py-3 px-3"><div class="flex items-center gap-3"><div class="py-2 px-3 rounded-[8px]"><p class="font-medium text-[12px] md:text-sm text-[#121212]">${ssrInterpolate((_c = (_b = unref(data)) == null ? void 0 : _b.meta) == null ? void 0 : _c.from)} - ${ssrInterpolate((_e = (_d = unref(data)) == null ? void 0 : _d.meta) == null ? void 0 : _e.to)} of ${ssrInterpolate((_g = (_f = unref(data)) == null ? void 0 : _f.meta) == null ? void 0 : _g.total)} item </p></div></div><div class="font-medium text-[14px] text-[#344054] flex items-center gap-3">`);
      _push(ssrRenderComponent(_component_PaginationAdmin, {
        modelValue: unref(page),
        "onUpdate:modelValue": ($event) => isRef(page) ? page.value = $event : null,
        total: (_i = (_h = unref(data)) == null ? void 0 : _h.meta) == null ? void 0 : _i.total,
        includeFirstLast: false,
        "per-page": (_k = (_j = unref(data)) == null ? void 0 : _j.meta) == null ? void 0 : _k.per_page,
        class: "flex justify-center"
      }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/admin-list/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-e55ec7e1.mjs.map
