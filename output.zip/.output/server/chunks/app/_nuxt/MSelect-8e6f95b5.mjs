import { defineComponent, toRef, inject, watch, mergeProps, unref, readonly, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderSlot } from 'vue/server-renderer';
import clsx from 'clsx';
import { useField } from 'vee-validate';

const _sfc_main = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "MSelect",
  __ssrInlineRender: true,
  props: {
    modelValue: {},
    name: {},
    class: {},
    disabled: { type: Boolean, default: false },
    ariaLabel: {},
    placeholder: {},
    readonly: { type: Boolean },
    multiple: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const name = toRef(props, "name");
    const { value, errorMessage } = useField(name, void 0, {
      syncVModel: true
    });
    const { setError } = inject("group-form");
    watch(errorMessage, (value2) => {
      if (value2) {
        setError(true);
      } else {
        setError(false);
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<select${ssrRenderAttrs(mergeProps({
        class: unref(clsx)(
          "w-full min-w-[140px] h-9 !outline-none focus:!border-none disabled:bg-gray-50"
        ),
        name: unref(name),
        id: unref(name),
        readonly: "readonly" in _ctx ? _ctx.readonly : unref(readonly),
        disabled: _ctx.disabled,
        "aria-label": _ctx.ariaLabel,
        placeholder: _ctx.placeholder,
        multiple: _ctx.multiple
      }, _ctx.$attrs, _attrs))}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</select>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/MSelect.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=MSelect-8e6f95b5.mjs.map
