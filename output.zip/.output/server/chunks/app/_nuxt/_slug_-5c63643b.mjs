import { _ as __nuxt_component_0 } from './TitleBack-aa5a1267.mjs';
import { _ as __nuxt_component_1 } from './FacilityCar-6d297a5f.mjs';
import { h as useRequestHelper, e as useRequestOptions, b as useRouter, d as useRoute, a as useHead, g as useAsyncData } from '../server.mjs';
import { computed, withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './Icon-0f6314e3.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'vee-validate';
import './TabItem-142d001b.mjs';
import './client-only-53a57ea8.mjs';
import 'clsx';
import './Group-4dcbb69b.mjs';
import './TextFieldWLabel-0de16bf1.mjs';
import './InputImageCropAdmin-7407d8a9.mjs';
import './index-a61f78d7.mjs';
import './index-596a8548.mjs';
import './useSchema-7a41625c.mjs';
import 'zod';
import '@vee-validate/zod';
import './useFacility-d76076e5.mjs';
import './nofication-1c3cca5e.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    useRouter();
    const route = useRoute();
    const slug = computed(() => route.params.slug);
    useHead({
      title: "Edit facility car"
    });
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "facilityDetail",
      () => $fetch(`/admins/facilities/${slug.value}`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_TitleBack = __nuxt_component_0;
      const _component_UIFormFacilityCar = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "px-5 py-6 md:px-10 md:py-10" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_TitleBack, {
        link: "/admin/facility-car",
        title: "Edit fasilitas"
      }, null, _parent));
      _push(ssrRenderComponent(_component_UIFormFacilityCar, {
        buttonTitle: "Edit Fasilitas",
        facility: (_a = unref(data)) == null ? void 0 : _a.data
      }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/facility-car/edit/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-5c63643b.mjs.map
