import { Form, ErrorMessage, Field } from 'vee-validate';
import { _ as _sfc_main$1, a as _sfc_main$2 } from './TabItem-142d001b.mjs';
import { _ as _sfc_main$3 } from './Group-4dcbb69b.mjs';
import { _ as _sfc_main$4 } from './TextFieldWLabel-0de16bf1.mjs';
import { _ as __nuxt_component_2 } from './InputImageCropAdmin-ec5002c2.mjs';
import { b as useRouter, j as __nuxt_component_0$1 } from '../server.mjs';
import { u as useSchema } from './useSchema-2d00eed1.mjs';
import { useSSRContext, mergeProps, unref, withCtx, createVNode, createTextVNode, toDisplayString } from 'vue';
import { u as useFacility } from './useFacility-d76076e5.mjs';
import { ssrRenderComponent, ssrIncludeBooleanAttr, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "FacilityCar",
  __ssrInlineRender: true,
  props: {
    facility: { type: [Array, Object] },
    buttonTitle: {
      type: String
    }
  },
  setup(__props) {
    useSchema();
    const router = useRouter();
    const {
      dataForm,
      onSubmit,
      message,
      alertType,
      loading,
      existingImage,
      selectedFacility
    } = useFacility({ callback: redirect });
    function redirect() {
      router.push("/admin/facility-car");
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_TabContent = _sfc_main$1;
      const _component_TabItem = _sfc_main$2;
      const _component_UIFormGroup = _sfc_main$3;
      const _component_UIFormTextFieldWLabel = _sfc_main$4;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_VeeField = Field;
      const _component_UIFormInputImageCropAdmin = __nuxt_component_2;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({ onSubmit: unref(onSubmit) }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="border shadow-sm rounded-[8px] py-6 px-5 mb-6"${_scopeId}><p class="text-black font-semibold text-[16px]"${_scopeId}>General</p><div class="grid grid-cols-1 mt-1 gap-4"${_scopeId}><p class="text-black font-medium text-[16px] mt-6"${_scopeId}>Nama fasilitas</p>`);
            _push2(ssrRenderComponent(_component_TabContent, null, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_TabItem, {
                    name: "EN",
                    group: "description",
                    checked: "",
                    "is-error": !!errors["description[en]"]
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormGroup, { name: "description" }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_UIFormTextFieldWLabel, {
                                modelValue: unref(dataForm)["description[en]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["description[en]"] = $event,
                                name: "description[en]",
                                label: "Nama fasilitas English",
                                class: "input-bordered",
                                placeholder: "Input nama fasilitas English"
                              }, null, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(_component_VeeErrorMessage, {
                                name: "description[en]",
                                class: "form-error-message"
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_UIFormTextFieldWLabel, {
                                  modelValue: unref(dataForm)["description[en]"],
                                  "onUpdate:modelValue": ($event) => unref(dataForm)["description[en]"] = $event,
                                  name: "description[en]",
                                  label: "Nama fasilitas English",
                                  class: "input-bordered",
                                  placeholder: "Input nama fasilitas English"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                                createVNode(_component_VeeErrorMessage, {
                                  name: "description[en]",
                                  class: "form-error-message"
                                })
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormGroup, { name: "description" }, {
                            default: withCtx(() => [
                              createVNode(_component_UIFormTextFieldWLabel, {
                                modelValue: unref(dataForm)["description[en]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["description[en]"] = $event,
                                name: "description[en]",
                                label: "Nama fasilitas English",
                                class: "input-bordered",
                                placeholder: "Input nama fasilitas English"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_component_VeeErrorMessage, {
                                name: "description[en]",
                                class: "form-error-message"
                              })
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_TabItem, {
                    name: "ID",
                    group: "description",
                    "is-error": !!errors["description[id]"]
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormGroup, { name: "description[id]" }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_UIFormTextFieldWLabel, {
                                modelValue: unref(dataForm)["description[id]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["description[id]"] = $event,
                                name: "description[id]",
                                label: "Nama fasilitas Indonesia",
                                class: "input-bordered",
                                placeholder: "Input nama fasilitas Indonesia"
                              }, null, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(_component_VeeErrorMessage, {
                                name: "description[id]",
                                class: "form-error-message"
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_UIFormTextFieldWLabel, {
                                  modelValue: unref(dataForm)["description[id]"],
                                  "onUpdate:modelValue": ($event) => unref(dataForm)["description[id]"] = $event,
                                  name: "description[id]",
                                  label: "Nama fasilitas Indonesia",
                                  class: "input-bordered",
                                  placeholder: "Input nama fasilitas Indonesia"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                                createVNode(_component_VeeErrorMessage, {
                                  name: "description[id]",
                                  class: "form-error-message"
                                })
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormGroup, { name: "description[id]" }, {
                            default: withCtx(() => [
                              createVNode(_component_UIFormTextFieldWLabel, {
                                modelValue: unref(dataForm)["description[id]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["description[id]"] = $event,
                                name: "description[id]",
                                label: "Nama fasilitas Indonesia",
                                class: "input-bordered",
                                placeholder: "Input nama fasilitas Indonesia"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_component_VeeErrorMessage, {
                                name: "description[id]",
                                class: "form-error-message"
                              })
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_TabItem, {
                      name: "EN",
                      group: "description",
                      checked: "",
                      "is-error": !!errors["description[en]"]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormGroup, { name: "description" }, {
                          default: withCtx(() => [
                            createVNode(_component_UIFormTextFieldWLabel, {
                              modelValue: unref(dataForm)["description[en]"],
                              "onUpdate:modelValue": ($event) => unref(dataForm)["description[en]"] = $event,
                              name: "description[en]",
                              label: "Nama fasilitas English",
                              class: "input-bordered",
                              placeholder: "Input nama fasilitas English"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_component_VeeErrorMessage, {
                              name: "description[en]",
                              class: "form-error-message"
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 2
                    }, 1032, ["is-error"]),
                    createVNode(_component_TabItem, {
                      name: "ID",
                      group: "description",
                      "is-error": !!errors["description[id]"]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormGroup, { name: "description[id]" }, {
                          default: withCtx(() => [
                            createVNode(_component_UIFormTextFieldWLabel, {
                              modelValue: unref(dataForm)["description[id]"],
                              "onUpdate:modelValue": ($event) => unref(dataForm)["description[id]"] = $event,
                              name: "description[id]",
                              label: "Nama fasilitas Indonesia",
                              class: "input-bordered",
                              placeholder: "Input nama fasilitas Indonesia"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                            createVNode(_component_VeeErrorMessage, {
                              name: "description[id]",
                              class: "form-error-message"
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 2
                    }, 1032, ["is-error"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}><div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              type: "file",
              name: "image",
              id: "image",
              modelValue: unref(dataForm).image,
              "onUpdate:modelValue": ($event) => unref(dataForm).image = $event
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_UIFormInputImageCropAdmin, {
              loading: unref(loading),
              label: "Icon",
              name: "image",
              modelValue: unref(dataForm).image,
              "onUpdate:modelValue": ($event) => unref(dataForm).image = $event,
              existingimage: unref(existingImage)
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div><div class="flex items-center justify-between mt-6"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, {
              to: "/admin/transport",
              class: "btn bg-transparent border border-red-600 text-red-500"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Batalkan `);
                } else {
                  return [
                    createTextVNode(" Batalkan ")
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<button type="submit"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""} class="btn bg-primary text-white normal-case !font-medium text-base hover:bg-primary"${_scopeId}>${ssrInterpolate(__props.buttonTitle)}</button></div>`);
          } else {
            return [
              createVNode("div", { class: "border shadow-sm rounded-[8px] py-6 px-5 mb-6" }, [
                createVNode("p", { class: "text-black font-semibold text-[16px]" }, "General"),
                createVNode("div", { class: "grid grid-cols-1 mt-1 gap-4" }, [
                  createVNode("p", { class: "text-black font-medium text-[16px] mt-6" }, "Nama fasilitas"),
                  createVNode(_component_TabContent, null, {
                    default: withCtx(() => [
                      createVNode(_component_TabItem, {
                        name: "EN",
                        group: "description",
                        checked: "",
                        "is-error": !!errors["description[en]"]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_UIFormGroup, { name: "description" }, {
                            default: withCtx(() => [
                              createVNode(_component_UIFormTextFieldWLabel, {
                                modelValue: unref(dataForm)["description[en]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["description[en]"] = $event,
                                name: "description[en]",
                                label: "Nama fasilitas English",
                                class: "input-bordered",
                                placeholder: "Input nama fasilitas English"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_component_VeeErrorMessage, {
                                name: "description[en]",
                                class: "form-error-message"
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 2
                      }, 1032, ["is-error"]),
                      createVNode(_component_TabItem, {
                        name: "ID",
                        group: "description",
                        "is-error": !!errors["description[id]"]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_UIFormGroup, { name: "description[id]" }, {
                            default: withCtx(() => [
                              createVNode(_component_UIFormTextFieldWLabel, {
                                modelValue: unref(dataForm)["description[id]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["description[id]"] = $event,
                                name: "description[id]",
                                label: "Nama fasilitas Indonesia",
                                class: "input-bordered",
                                placeholder: "Input nama fasilitas Indonesia"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                              createVNode(_component_VeeErrorMessage, {
                                name: "description[id]",
                                class: "form-error-message"
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 2
                      }, 1032, ["is-error"])
                    ]),
                    _: 2
                  }, 1024),
                  createVNode("div", null, [
                    createVNode("div", { class: "hidden" }, [
                      createVNode(_component_VeeField, {
                        type: "file",
                        name: "image",
                        id: "image",
                        modelValue: unref(dataForm).image,
                        "onUpdate:modelValue": ($event) => unref(dataForm).image = $event
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    createVNode(_component_UIFormInputImageCropAdmin, {
                      loading: unref(loading),
                      label: "Icon",
                      name: "image",
                      modelValue: unref(dataForm).image,
                      "onUpdate:modelValue": ($event) => unref(dataForm).image = $event,
                      existingimage: unref(existingImage)
                    }, null, 8, ["loading", "modelValue", "onUpdate:modelValue", "existingimage"])
                  ])
                ])
              ]),
              createVNode("div", { class: "flex items-center justify-between mt-6" }, [
                createVNode(_component_NuxtLink, {
                  to: "/admin/transport",
                  class: "btn bg-transparent border border-red-600 text-red-500"
                }, {
                  default: withCtx(() => [
                    createTextVNode(" Batalkan ")
                  ]),
                  _: 1
                }),
                createVNode("button", {
                  type: "submit",
                  disabled: unref(loading),
                  class: "btn bg-primary text-white normal-case !font-medium text-base hover:bg-primary"
                }, toDisplayString(__props.buttonTitle), 9, ["disabled"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/FacilityCar.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main;

export { __nuxt_component_1 as _ };
//# sourceMappingURL=FacilityCar-dbbc4efd.mjs.map
