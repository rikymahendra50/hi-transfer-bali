import { defineComponent, mergeProps, useSSRContext } from 'vue';
import { b as useRouter } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "SelectedCard",
  __ssrInlineRender: true,
  props: {
    name: {
      type: String
    },
    image: {
      type: String
    },
    facilities: {
      type: [Array, Object]
    }
  },
  setup(__props) {
    useRouter();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "border rounded-xl p-4 hover:border-primary hover:shadow shadow-primary" }, _attrs))}><div class="grid min-[400px]:grid-cols-[100px_1fr] lg:grid-cols-[150px_1fr] gap-4"><div class="border rounded-xl overflow-hidden"><img${ssrRenderAttr("src", __props.image)} alt="vehicle" class="w-full h-full xl:h-[150px] object-cover"></div><div class="grid grid-cols-1"><div class="space-y-2"><h4 class="text-lg lg:text-2xl font-semibold">${ssrInterpolate(__props.name)}</h4><div class="flex flex-wrap gap-1 md:gap-3 py-2"><!--[-->`);
      ssrRenderList(__props.facilities, (item) => {
        _push(`<div class="inline-flex space-x-1 items-center"><img${ssrRenderAttr("src", item.image)}${ssrRenderAttr("alt", item.image)} class="w-6 h-6"><div class="text-zinc-400 text-sm whitespace-nowrap">${ssrInterpolate(item.description)}</div></div>`);
      });
      _push(`<!--]--></div></div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vehicle/SelectedCard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=SelectedCard-939884a9.mjs.map
