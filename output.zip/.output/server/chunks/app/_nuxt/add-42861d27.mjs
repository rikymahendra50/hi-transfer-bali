import { _ as __nuxt_component_0 } from './TitleBack-14168b7f.mjs';
import { _ as _sfc_main$1 } from './FormAdmin-2a833399.mjs';
import { a as useHead, b as useRouter, _ as _export_sfc } from '../server.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './Icon-f8c4e628.mjs';
import './config-9e484511.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'vee-validate';
import './Alert-6ab07811.mjs';
import './TransitionTopToBottom-30d56c1a.mjs';
import './Group-4dcbb69b.mjs';
import './TransitionX-055dd228.mjs';
import 'clsx';
import './nofication-1c3cca5e.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

useHead({
  title: "Admin Create"
});
useRouter();
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_TitleBack = __nuxt_component_0;
  const _component_FormAdmin = _sfc_main$1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-6 px-5 py-4" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_TitleBack, {
    link: "/admin/admin-list",
    title: "Tambah Admin"
  }, null, _parent));
  _push(`<div class="grid grid-cols-1 lg:grid-cols-[2fr_1fr]">`);
  _push(ssrRenderComponent(_component_FormAdmin, { onReload: _ctx.reload }, null, _parent));
  _push(`</div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/admin-list/add.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const add = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { add as default };
//# sourceMappingURL=add-42861d27.mjs.map
