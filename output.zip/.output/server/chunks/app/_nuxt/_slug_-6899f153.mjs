import { _ as __nuxt_component_0 } from './TitleAdminBack-edb4ce21.mjs';
import { f as useI18n, a as useHead, h as useRequestHelper, e as useRequestOptions, b as useRouter, d as useRoute, g as useAsyncData } from '../server.mjs';
import { ref, computed, withAsyncContext, unref, withCtx, createVNode, toDisplayString, useSSRContext } from 'vue';
import { u as useFormatDate } from './useFormatDate-4be124f7.mjs';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import { ssrRenderComponent, ssrRenderStyle, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import './Icon-0f6314e3.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { locale, t: $t } = useI18n();
    useHead({
      title: "Order detail"
    });
    ref({
      sort: ""
    });
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    useRouter();
    const route = useRoute();
    ref(1);
    ref(false);
    ref(void 0);
    const slug = computed(() => route.params.slug);
    const { formatDate } = useFormatDate();
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "ordersDetail",
      () => $fetch(`/admins/car-orders/${slug.value}`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b2, _c2, _d2;
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R, _S, _T, _U, _V, _W, _X, _Y, _Z, __, _$, _aa, _ba, _ca, _da, _ea, _fa, _ga, _ha, _ia, _ja, _ka, _la, _ma, _na, _oa, _pa;
      const _component_TitleAdminBack = __nuxt_component_0;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_TitleAdminBack, {
        title: "Ringkasan Pesanan",
        subTitle: `Informasi lengkap untuk pesanan #${(_a2 = (_b = (_a = unref(data)) == null ? void 0 : _a.data) == null ? void 0 : _b.uuid) != null ? _a2 : ""}`,
        link: "/admin/orders/order-cars"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a22, _b22, _c22, _d22, _e2, _f2, _g2, _h2, _i2, _j2, _k2, _l2, _m2, _n2, _o2, _p2, _q2, _r2, _s2, _t2, _u2, _v2, _w2, _x2;
          if (_push2) {
            _push2(`<div${_scopeId}><div class="border-2 shadow-xs p-3 rounded-xl" style="${ssrRenderStyle({
              backgroundColor: ((_b22 = (_a22 = unref(data)) == null ? void 0 : _a22.data) == null ? void 0 : _b22.status) === "waiting_for_payment" ? "#f2ec72" : ((_d22 = (_c22 = unref(data)) == null ? void 0 : _c22.data) == null ? void 0 : _d22.status) === "canceled" ? "#f2727b" : ((_f2 = (_e2 = unref(data)) == null ? void 0 : _e2.data) == null ? void 0 : _f2.status) === "paid" ? "#f2ec72" : ((_h2 = (_g2 = unref(data)) == null ? void 0 : _g2.data) == null ? void 0 : _h2.status) === "failed" ? "#f2727b" : ((_j2 = (_i2 = unref(data)) == null ? void 0 : _i2.data) == null ? void 0 : _j2.status) === "refunding" ? "#f2727b" : "transparent"
            })}"${_scopeId}>${ssrInterpolate((_l2 = (_k2 = unref(data)) == null ? void 0 : _k2.data) == null ? void 0 : _l2.status)}</div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", {
                  class: "border-2 shadow-xs p-3 rounded-xl",
                  style: {
                    backgroundColor: ((_n2 = (_m2 = unref(data)) == null ? void 0 : _m2.data) == null ? void 0 : _n2.status) === "waiting_for_payment" ? "#f2ec72" : ((_p2 = (_o2 = unref(data)) == null ? void 0 : _o2.data) == null ? void 0 : _p2.status) === "canceled" ? "#f2727b" : ((_r2 = (_q2 = unref(data)) == null ? void 0 : _q2.data) == null ? void 0 : _r2.status) === "paid" ? "#f2ec72" : ((_t2 = (_s2 = unref(data)) == null ? void 0 : _s2.data) == null ? void 0 : _t2.status) === "failed" ? "#f2727b" : ((_v2 = (_u2 = unref(data)) == null ? void 0 : _u2.data) == null ? void 0 : _v2.status) === "refunding" ? "#f2727b" : "transparent"
                  }
                }, toDisplayString((_x2 = (_w2 = unref(data)) == null ? void 0 : _w2.data) == null ? void 0 : _x2.status), 5)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="px-5 py-4 flex flex-col gap-3 border-b"><div class="text-gray-500 uppercase text-[12px] font-semibold"> Informasi Pelanggan </div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Nama pelanggan:</p><p>${ssrInterpolate(((_e = (_d = (_c = unref(data)) == null ? void 0 : _c.data) == null ? void 0 : _d.user) == null ? void 0 : _e.first_name) + " " + ((_h = (_g = (_f = unref(data)) == null ? void 0 : _f.data) == null ? void 0 : _g.user) == null ? void 0 : _h.last_name))}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Email:</p><p>${ssrInterpolate((_k = (_j = (_i = unref(data)) == null ? void 0 : _i.data) == null ? void 0 : _j.user) == null ? void 0 : _k.email)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold text-sm">Nomor Telepon:</p><p>${ssrInterpolate((_n = (_m = (_l = unref(data)) == null ? void 0 : _l.data) == null ? void 0 : _m.user) == null ? void 0 : _n.phone)}</p></div></div><div class="px-5 py-6 flex flex-col gap-3 border-b"><div class="text-gray-500 uppercase text-[12px] font-semibold"> Informasi Pemesanan </div><div class="grid md:grid-cols-2 gap-5"><div class="flex flex-col gap-2"><p class="font-semibold text-sm">Penjemputan</p><p class="text-sm">${ssrInterpolate((_q = (_p = (_o = unref(data)) == null ? void 0 : _o.data) == null ? void 0 : _p.details[0]) == null ? void 0 : _q.pickup_name)}</p><div class="text-sm opacity-50"><a class="hover:text-primary font-medium"${ssrRenderAttr("href", `https://maps.google.com/?q=${(_t = (_s = (_r = unref(data)) == null ? void 0 : _r.data) == null ? void 0 : _s.details[0]) == null ? void 0 : _t.pickup_latitude},${(_w = (_v = (_u = unref(data)) == null ? void 0 : _u.data) == null ? void 0 : _v.details[0]) == null ? void 0 : _w.pickup_longitude}`)} target="_blank">${ssrInterpolate((_z = (_y = (_x = unref(data)) == null ? void 0 : _x.data) == null ? void 0 : _y.details[0]) == null ? void 0 : _z.pickup_address)}</a></div><div class="text-sm">${ssrInterpolate((_b2 = unref(formatDate)((_C = (_B = (_A = unref(data)) == null ? void 0 : _A.data) == null ? void 0 : _B.details[0]) == null ? void 0 : _C.activity_date)) != null ? _b2 : "")}</div></div><div class="flex flex-col gap-2"><p class="font-semibold text-sm">Pengantaran</p><p class="text-sm">${ssrInterpolate((_F = (_E = (_D = unref(data)) == null ? void 0 : _D.data) == null ? void 0 : _E.details[0]) == null ? void 0 : _F.destination_name)}</p><div class="text-sm opacity-50"><a target="_blank" class="hover:text-primary font-medium"${ssrRenderAttr("href", `https://maps.google.com/?q=${(_I = (_H = (_G = unref(data)) == null ? void 0 : _G.data) == null ? void 0 : _H.details[0]) == null ? void 0 : _I.destination_latitude},${(_L = (_K = (_J = unref(data)) == null ? void 0 : _J.data) == null ? void 0 : _K.details[0]) == null ? void 0 : _L.destination_longitude}`)}>${ssrInterpolate((_O = (_N = (_M = unref(data)) == null ? void 0 : _M.data) == null ? void 0 : _N.details[0]) == null ? void 0 : _O.destination_address)}</a></div><div class="text-sm"><div class="text-sm">${ssrInterpolate(((_R = (_Q = (_P = unref(data)) == null ? void 0 : _P.data) == null ? void 0 : _Q.details[1]) == null ? void 0 : _R.activity_date) ? unref(formatDate)((_U = (_T = (_S = unref(data)) == null ? void 0 : _S.data) == null ? void 0 : _T.details[1]) == null ? void 0 : _U.activity_date) : unref(formatDate)((_X = (_W = (_V = unref(data)) == null ? void 0 : _V.data) == null ? void 0 : _W.details[0]) == null ? void 0 : _X.activity_date))}</div></div></div></div>`);
      if ((_Z = (_Y = unref(data)) == null ? void 0 : _Y.data) == null ? void 0 : _Z.details) {
        _push(`<div>`);
        if (((_aa = (_$ = (__ = unref(data)) == null ? void 0 : __.data) == null ? void 0 : _$.details) == null ? void 0 : _aa.length) > 1) {
          _push(`<div class="bg-primary py-2 px-4 rounded-xl text-white w-fit"><p>Bolak balik</p></div>`);
        } else if (((_da = (_ca = (_ba = unref(data)) == null ? void 0 : _ba.data) == null ? void 0 : _ca.details) == null ? void 0 : _da.length) == 1) {
          _push(`<div class="bg-primary py-2 px-4 rounded-xl text-white w-fit"><p>Satu arah</p></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="px-5 py-4 flex flex-col gap-3"><div class="text-gray-500 uppercase text-[12px] font-semibold"> Payment Information </div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Payment Method</p><p>${ssrInterpolate((_c2 = (_ga = (_fa = (_ea = unref(data)) == null ? void 0 : _ea.data) == null ? void 0 : _fa.payment) == null ? void 0 : _ga.payment_method) != null ? _c2 : "-")}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Payment Channel</p><p>${ssrInterpolate((_d2 = (_ja = (_ia = (_ha = unref(data)) == null ? void 0 : _ha.data) == null ? void 0 : _ia.payment) == null ? void 0 : _ja.payment_channel) != null ? _d2 : "-")}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Payment Status</p><p>${ssrInterpolate((_ma = (_la = (_ka = unref(data)) == null ? void 0 : _ka.data) == null ? void 0 : _la.payment) == null ? void 0 : _ma.status)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Total Price</p><p>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(
        (_pa = (_oa = (_na = unref(data)) == null ? void 0 : _na.data) == null ? void 0 : _oa.payment) == null ? void 0 : _pa.total_purchased.toString(),
        unref(locale) == "id" ? "IDR" : "usd"
      ))}</p></div></div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/orders/order-detail-car/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-6899f153.mjs.map
