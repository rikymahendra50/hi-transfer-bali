import { defineComponent, toRef, inject, watch, ref, mergeProps, unref, readonly, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderSlot, ssrGetDynamicModelProps } from 'vue/server-renderer';
import clsx from 'clsx';
import { useField } from 'vee-validate';

const _sfc_main = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "MTextField",
  __ssrInlineRender: true,
  props: {
    type: { default: "text" },
    modelValue: {},
    name: {},
    class: {},
    disabled: { type: Boolean, default: false },
    ariaLabel: {},
    placeholder: {},
    readonly: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const name = toRef(props, "name");
    const {
      value,
      errorMessage
    } = useField(name, void 0, {
      syncVModel: true
    });
    const { setError } = inject("group-form");
    watch(errorMessage, (value2) => {
      if (value2) {
        setError(true);
      } else {
        setError(false);
      }
    });
    ref();
    return (_ctx, _push, _parent, _attrs) => {
      let _temp0;
      _push(`<label${ssrRenderAttrs(mergeProps({
        class: unref(clsx)(
          "flex items-center  rounded-lg focus-within:outline-none w-full h-9 overflow-hidden",
          {
            "gap-2": !!_ctx.$slots.leftSection || !!_ctx.$slots.rightSection,
            "pl-0": !_ctx.$slots.leftSection,
            "pr-0": !_ctx.$slots.rightSection
          }
        )
      }, _attrs))}>`);
      if (_ctx.$slots.leftSection) {
        ssrRenderSlot(_ctx.$slots, "leftSection", {}, null, _push, _parent);
      } else {
        _push(`<!---->`);
      }
      _push(`<input${ssrRenderAttrs((_temp0 = mergeProps({
        name: unref(name),
        id: unref(name),
        type: _ctx.type,
        readonly: "readonly" in _ctx ? _ctx.readonly : unref(readonly),
        disabled: _ctx.disabled,
        "aria-label": _ctx.ariaLabel,
        placeholder: _ctx.placeholder,
        class: unref(clsx)("w-full h-full !outline-none focus:!border-none disabled:bg-gray-50", {
          "px-1": !_ctx.$slots.leftSection || !_ctx.$slots.rightSection
        })
      }, _ctx.$attrs), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, unref(value)))))}>`);
      if (_ctx.$slots.rightSection) {
        ssrRenderSlot(_ctx.$slots, "rightSection", {}, null, _push, _parent);
      } else {
        _push(`<!---->`);
      }
      _push(`</label>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/MTextField.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=MTextField-61174a46.mjs.map
