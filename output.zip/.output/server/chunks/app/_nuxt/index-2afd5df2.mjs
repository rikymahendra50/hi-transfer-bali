import { _ as __nuxt_component_0 } from './TitleAdmin-130db81a.mjs';
import { h as useRequestHelper, e as useRequestOptions, b as useRouter, d as useRoute, f as useI18n, a as useHead, g as useAsyncData, j as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_1 from './Icon-f8c4e628.mjs';
import { _ as __nuxt_component_2 } from './PaginationAdmin-f2cea012.mjs';
import { ref, withAsyncContext, watch, resolveComponent, mergeProps, withCtx, createTextVNode, createVNode, unref, isRef, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { u as useTimeoutFn } from './index-596a8548.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-9e484511.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    useRoute();
    useI18n();
    const page = ref(1);
    useHead({
      title: "Admin list"
    });
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "admin-list",
      () => $fetch(`/admins?page=${page.value}`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    const { start, stop } = useTimeoutFn(() => {
      replaceWindow();
    }, 1e3);
    watch(page, (newValue, oldValue) => {
      if (newValue !== oldValue) {
        start();
      }
    });
    function replaceWindow() {
      router.replace(
        withQuery("/admin/user-admin", {
          page: page.value
        })
      );
      refresh();
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
      const _component_TitleAdmin = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_VDropdown = resolveComponent("VDropdown");
      const _component_Icon = __nuxt_component_1;
      const _component_PaginationAdmin = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_TitleAdmin, {
        title: "Daftar Admin",
        subTitle: "Kelola daftar admin "
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_NuxtLink, {
              to: "/admin/admin-list/add",
              class: "border-2 py-4 px-6 rounded-[8px] shadow-xs font-medium text-black"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Tambah Admin baru `);
                } else {
                  return [
                    createTextVNode(" Tambah Admin baru ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_NuxtLink, {
                to: "/admin/admin-list/add",
                class: "border-2 py-4 px-6 rounded-[8px] shadow-xs font-medium text-black"
              }, {
                default: withCtx(() => [
                  createTextVNode(" Tambah Admin baru ")
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<table class="table"><thead><tr><th><div class="text-[#989393]">Profile picture</div></th><th><div class="text-[#989393]">List Admin</div></th><th><div class="text-[#989393]">Email</div></th><th><div class="text-[#989393]">Status</div></th><th></th></tr></thead><tbody><!--[-->`);
      ssrRenderList((_a = unref(data)) == null ? void 0 : _a.data, (item) => {
        var _a2;
        _push(`<tr><td class="text-sm font-normal"><img${ssrRenderAttr("src", (_a2 = item.profile_picture) != null ? _a2 : "-")} alt="" class="rounded-full w-10 h-10"></td><td class="text-sm font-normal"><div class="font-medium text-[14px] text-black">${ssrInterpolate(item.first_name + " " + item.last_name)}</div></td><td class="text-sm font-normal"><div class="font-medium text-[14px] text-black">${ssrInterpolate(item.email)}</div></td><td class="text-sm font-normal"><div class="font-medium text-[14px] text-black">${ssrInterpolate(item.is_active === 0 ? "Tidak aktif" : "Aktif")}</div></td><td class="text-sm font-normal">`);
        _push(ssrRenderComponent(_component_VDropdown, null, {
          popper: withCtx(({ hide }, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="bg-white flex flex-col shadow"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_NuxtLink, {
                to: `/admin/admin-list/${item.uuid}/edit`,
                class: "hover:bg-orange-400 hover:text-white py-2 px-3"
              }, {
                default: withCtx((_, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Edit `);
                  } else {
                    return [
                      createTextVNode(" Edit ")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`<button type="button" class="hover:bg-red-600 hover:text-white py-2 px-3"${_scopeId}> Delete </button></div>`);
            } else {
              return [
                createVNode("div", { class: "bg-white flex flex-col shadow" }, [
                  createVNode(_component_NuxtLink, {
                    to: `/admin/admin-list/${item.uuid}/edit`,
                    class: "hover:bg-orange-400 hover:text-white py-2 px-3"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Edit ")
                    ]),
                    _: 2
                  }, 1032, ["to"]),
                  createVNode("button", {
                    onClick: ($event) => _ctx.showModalDeleteFunc(hide, item.id),
                    type: "button",
                    class: "hover:bg-red-600 hover:text-white py-2 px-3"
                  }, " Delete ", 8, ["onClick"])
                ])
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex items-center justify-center"${_scopeId}><button class="flex items-center justify-center cursor-pointer"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, {
                name: "pepicons-pencil:dots-y",
                class: "text-[#717171]"
              }, null, _parent2, _scopeId));
              _push2(`</button></div>`);
            } else {
              return [
                createVNode("div", { class: "flex items-center justify-center" }, [
                  createVNode("button", { class: "flex items-center justify-center cursor-pointer" }, [
                    createVNode(_component_Icon, {
                      name: "pepicons-pencil:dots-y",
                      class: "text-[#717171]"
                    })
                  ])
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</td></tr>`);
      });
      _push(`<!--]--></tbody></table><div class="flex flex-col md:flex-row items-center justify-between gap-3 w-full py-3 px-3"><div class="flex items-center gap-3"><div class="py-2 px-3 rounded-[8px]"><p class="font-medium text-[12px] md:text-sm text-[#121212]">${ssrInterpolate((_c = (_b = unref(data)) == null ? void 0 : _b.meta) == null ? void 0 : _c.from)} - ${ssrInterpolate((_e = (_d = unref(data)) == null ? void 0 : _d.meta) == null ? void 0 : _e.to)} of ${ssrInterpolate((_g = (_f = unref(data)) == null ? void 0 : _f.meta) == null ? void 0 : _g.total)} item </p></div></div><div class="font-medium text-[14px] text-[#344054] flex items-center gap-3">`);
      _push(ssrRenderComponent(_component_PaginationAdmin, {
        modelValue: unref(page),
        "onUpdate:modelValue": ($event) => isRef(page) ? page.value = $event : null,
        total: (_i = (_h = unref(data)) == null ? void 0 : _h.meta) == null ? void 0 : _i.total,
        includeFirstLast: false,
        "per-page": (_k = (_j = unref(data)) == null ? void 0 : _j.meta) == null ? void 0 : _k.per_page,
        class: "flex justify-center"
      }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/admin-list/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-2afd5df2.mjs.map
