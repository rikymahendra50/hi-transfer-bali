import { defineComponent, computed, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderSlot, ssrInterpolate } from 'vue/server-renderer';
import clsx from 'clsx';

const _sfc_main = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "Btn",
  __ssrInlineRender: true,
  props: {
    type: { default: "button" },
    disabled: { type: Boolean },
    loading: { type: Boolean },
    label: {},
    class: {},
    ariaLabel: {},
    variant: {},
    size: {},
    noAnimation: { type: Boolean },
    shape: {},
    outlined: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const disabledButton = computed(() => props.disabled || props.loading);
    const variant = [
      "btn-neutral",
      "btn-primary",
      "btn-secondary",
      "btn-accent",
      "btn-info",
      "btn-success",
      "btn-warning",
      "btn-error"
    ];
    const size = [
      "btn-xs",
      "btn-sm",
      "btn-md",
      "btn-lg"
    ];
    const shape = [
      "btn-square",
      "btn-circle"
    ];
    const buttonClass = computed(() => {
      const classBtn = [];
      if (props.variant) {
        classBtn.push(variant[variant.indexOf(`btn-${props.variant}`)]);
      }
      if (props.size) {
        classBtn.push(size[size.indexOf(`btn-${props.size}`)]);
      }
      if (props.noAnimation) {
        classBtn.push("no-animation");
      }
      if (props.shape) {
        classBtn.push(shape[shape.indexOf(`btn-${props.shape}`)]);
      }
      if (props.outlined) {
        classBtn.push("btn-outline");
      }
      return clsx("btn", classBtn, props.class);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<button${ssrRenderAttrs(mergeProps({
        class: unref(buttonClass),
        type: props.type,
        disabled: unref(disabledButton),
        "aria-label": props.ariaLabel
      }, _ctx.$attrs, _attrs))}>`);
      if (props.loading) {
        _push(`<span class="loading loading-spinner"></span>`);
      } else {
        _push(`<!---->`);
      }
      ssrRenderSlot(_ctx.$slots, "default", {}, () => {
        _push(`${ssrInterpolate(props.label)}`);
      }, _push, _parent);
      _push(`</button>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Btn.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=Btn-61213793.mjs.map
