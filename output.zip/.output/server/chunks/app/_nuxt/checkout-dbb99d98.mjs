import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import { ref, mergeProps, useSSRContext } from 'vue';
import { k as _export_sfc } from '../server.mjs';
import { _ as __nuxt_component_6 } from './PriceCheckoutInformation-a4421de5.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './FormatMoneyDash-4b79c187.mjs';

const _sfc_main$3 = {};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><div class="grid grid-cols-1 divide-y border rounded-xl"><!--[-->`);
  ssrRenderList(3, (n) => {
    _push(`<div class="p-4"><div class="flex flex-col lg:flex-row lg:justify-between item-center"><div class="text-lg font-semibold flex items-center"> Silvester Wali </div><div class="flex flex-row justify-between space-x-4"><div class="flex flex-col space-y-1"><div class="text-xs text-zinc-400">Kebangsaan</div><div>Indonesia</div></div><div class="flex flex-col space-y-1"><div class="text-xs text-zinc-400">Kategori</div><div>Dewasa</div></div></div></div></div>`);
  });
  _push(`<!--]--></div></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/ParticipantCard.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$2]]);
const _sfc_main$2 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><div class="space-y-4 p-4 border rounded-xl"><div class="flex flex-col lg:flex-row lg:justify-between item-center"><div class="text-lg font-semibold flex items-center"> Silvester Wali </div><div class="flex flex-col lg:flex-row space-y-4 lg:space-y-0 space-x-0 lg:space-x-4"><div class="flex flex-col space-y-1"><div class="text-xs text-zinc-400">Email</div><div>Silvester@example.com</div></div><div class="flex flex-col space-y-1"><div class="text-xs text-zinc-400">Nomor Telepon</div><div>08123456789</div></div></div></div></div></div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/OrdererCard.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-4 border rounded-xl p-4 divide-y" }, _attrs))}><div class="grid grid-cols-[100px_1fr] space-x-2"><div class="rounded-xl overflow-hidden w-[100px] h-[100px]"><img src="https://placehold.co/150" alt="" class="w-full h-full object-cover"></div><div class="flex flex-col justify-between space-y-4"><div class="text-lg font-semibold">West Nusa Penida Tour</div><div><div class="text-zinc-400 text-xs">${ssrInterpolate(_ctx.$t("destinasi"))}</div><div class="text-sm"> Kelingking Cliff - Angel&#39;s Billabong - Broken Beach - Crystal Bay Beach </div></div></div></div><div class="font-semibold py-2">${ssrInterpolate(_ctx.$t("detail-harga"))}</div><div class="flex justify-between items-center py-2"><div class="font-semibold">Dewasa x 2</div><div>Rp. 1.000.000</div></div><div class="flex justify-between items-center py-2"><div class="font-semibold">Anak x 1</div><div>Rp. 1.000.000</div></div><div class="flex justify-between items-center py-2"><div class="font-semibold">${ssrInterpolate(_ctx.$t("total-harga"))}</div><div>Rp. 3.000.000</div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/DetailCheckoutInformation.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = {
  __name: "checkout",
  __ssrInlineRender: true,
  setup(__props) {
    ref({
      sort: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TourParticipantCard = __nuxt_component_0;
      const _component_TourOrdererCard = __nuxt_component_1;
      const _component_TourDetailCheckoutInformation = __nuxt_component_2;
      const _component_TourPriceCheckoutInformation = __nuxt_component_6;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col space-y-6" }, _attrs))}><div class="flex justify-between items-center"><div class="text-2xl font-semibold">${ssrInterpolate(_ctx.$t("data-peserta"))}</div></div><div class="space-y-4">`);
      _push(ssrRenderComponent(_component_TourParticipantCard, null, null, _parent));
      _push(`</div><div class="flex justify-between items-center"><div class="text-2xl font-semibold">${ssrInterpolate(_ctx.$t("data-pemesan"))}</div></div><div class="space-y-4">`);
      _push(ssrRenderComponent(_component_TourOrdererCard, null, null, _parent));
      _push(`</div><div class="flex justify-between items-center"><div class="text-2xl font-semibold">${ssrInterpolate(_ctx.$t("detail-harga"))}</div></div><div class="space-y-4">`);
      _push(ssrRenderComponent(_component_TourDetailCheckoutInformation, null, null, _parent));
      _push(ssrRenderComponent(_component_TourPriceCheckoutInformation, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tours/booking/checkout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=checkout-dbb99d98.mjs.map
