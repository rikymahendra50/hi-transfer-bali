import { _ as __nuxt_component_0 } from './TransitionX-055dd228.mjs';
import { ErrorMessage } from 'vee-validate';
import { defineComponent, ref, provide, mergeProps, unref, withCtx, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderClass, ssrRenderAttr, ssrInterpolate, ssrRenderSlot, ssrRenderComponent } from 'vue/server-renderer';
import clsx from 'clsx';

const _sfc_main = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "MGroup",
  __ssrInlineRender: true,
  props: {
    /**
     * input label
     * @type {string}
     * @example
     */
    label: {
      type: String,
      required: true
    },
    name: {
      type: String,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const isError = ref(false);
    function setError(value) {
      isError.value = value;
    }
    provide("group-form", {
      setError
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TransitionX = __nuxt_component_0;
      const _component_VeeErrorMessage = ErrorMessage;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-0.5 !relative h-auto pb-1" }, _attrs))}><div class="${ssrRenderClass(
        unref(clsx)(
          "grid grid-cols-1 gap-1 text-left border-2 p-1 px-5 rounded-xl relative",
          {
            "border-red-400/80": unref(isError)
          }
        )
      )}"><label${ssrRenderAttr("for", props.name)} class="${ssrRenderClass(
        unref(clsx)(
          "tracking-wide bg-white  absolute -top-3 left-4  px-1 text-sm ext-gray-[#8B8B8B] rounded-lg",
          {
            "text-red-400": unref(isError)
          }
        )
      )}">${ssrInterpolate(props.label)}</label>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div><div class="pl-5">`);
      _push(ssrRenderComponent(_component_TransitionX, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: __props.name,
              class: "form-error-message"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_VeeErrorMessage, {
                name: __props.name,
                class: "form-error-message"
              }, null, 8, ["name"])
            ];
          }
        }),
        _: 1
      }, _parent));
      if (_ctx.$slots.description) {
        _push(`<div class="form-description text-sm">`);
        ssrRenderSlot(_ctx.$slots, "description", {}, null, _push, _parent);
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/MGroup.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=MGroup-c9c56f96.mjs.map
