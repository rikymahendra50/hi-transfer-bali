const useDateFormatter = () => {
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-GB", {
      day: "numeric",
      month: "long",
      year: "numeric"
    });
  };
  return {
    formatDate
  };
};
const useFormatDate = useDateFormatter;

export { useFormatDate as u };
//# sourceMappingURL=useFormatDate-4be124f7.mjs.map
