const IconCSS_vue_vue_type_style_index_0_scoped_2717c442_lang = "span[data-v-2717c442]{background-color:currentColor;display:inline-block;-webkit-mask-image:var(--17e81e26);mask-image:var(--17e81e26);-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-size:100% 100%;mask-size:100% 100%;vertical-align:middle}";

const IconCSSStyles_9ba8332f = [IconCSS_vue_vue_type_style_index_0_scoped_2717c442_lang, IconCSS_vue_vue_type_style_index_0_scoped_2717c442_lang];

export { IconCSSStyles_9ba8332f as default };
//# sourceMappingURL=IconCSS-styles.9ba8332f.mjs.map
