import { Form, Field, ErrorMessage } from 'vee-validate';
import { _ as __nuxt_component_2 } from './InputImageCropAdmin-7407d8a9.mjs';
import { _ as _sfc_main$1 } from './TextFieldWLabel-0de16bf1.mjs';
import { _ as _sfc_main$2, a as __nuxt_component_6, b as __nuxt_component_7 } from './DropdownsTest-7ab0ea03.mjs';
import { e as useRequestOptions, b as useRouter, g as useAsyncData, _ as __nuxt_component_0$1 } from '../server.mjs';
import { u as useSchema } from './useSchema-0246d9f0.mjs';
import { useSSRContext, ref, withAsyncContext, mergeProps, unref, withCtx, isRef, createTextVNode, createVNode, toDisplayString } from 'vue';
import { u as useTransport } from './useTransport-bdd5bf0b.mjs';
import { ssrRenderComponent, ssrIncludeBooleanAttr, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "Transport",
  __ssrInlineRender: true,
  props: {
    transport: {
      type: [Array, Object]
    },
    buttonTitle: {
      type: String
    }
  },
  async setup(__props) {
    let __temp, __restore;
    const props = __props;
    const { transportSchema } = useSchema();
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    function redirect() {
      router.push("/admin/transport");
    }
    const {
      dataForm,
      onSubmit,
      message,
      alertType,
      loading,
      existingImage,
      selectedTransport
    } = useTransport({ callback: redirect });
    const statusActive = ref();
    const dataDropdown = ref([
      {
        id: 1,
        name: "Tersedia",
        value: 1
      },
      {
        id: 2,
        name: "Tidak Tersedia",
        value: 0
      }
    ]);
    function funcGetIdStatus(data2) {
      dataForm.value.is_active = data2;
    }
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "facilities",
      () => $fetch(`/admins/facilities-all`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    ref([]);
    ref([]);
    ref([]);
    function funcGetIdFacility(ids) {
      dataForm.value.facilities = Array.isArray(ids) ? ids : [ids];
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_VeeField = Field;
      const _component_UIFormInputImageCropAdmin = __nuxt_component_2;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_UIFormTextFieldWLabel = _sfc_main$1;
      const _component_UIFormInputNumber = _sfc_main$2;
      const _component_UIFormDropdownOnlyTwo = __nuxt_component_6;
      const _component_UIFormDropdownsTest = __nuxt_component_7;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        "validation-schema": unref(transportSchema),
        onSubmit: unref(onSubmit)
      }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          var _a2, _b2;
          var _a, _b, _c, _d;
          if (_push2) {
            _push2(`<div class="border shadow-sm rounded-[8px] py-4 px-4"${_scopeId}><p class="text-black font-semibold"${_scopeId}>General</p><div${_scopeId}><div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              type: "file",
              name: "image_thumbnail",
              id: "image_thumbnail",
              modelValue: unref(dataForm).image,
              "onUpdate:modelValue": ($event) => unref(dataForm).image = $event
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_UIFormInputImageCropAdmin, {
              loading: unref(loading),
              label: "Foto Mobil",
              name: "image",
              modelValue: unref(dataForm).image,
              "onUpdate:modelValue": ($event) => unref(dataForm).image = $event,
              existingimage: unref(existingImage)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "image",
              class: "text-red-500"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 mt-3 gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormTextFieldWLabel, {
              label: "Nama Mobil",
              name: "mobil",
              placeholder: "Input Mobil",
              modelValue: unref(dataForm).name,
              "onUpdate:modelValue": ($event) => unref(dataForm).name = $event,
              class: "input-bordered shadow-sm focus:outline-none",
              useStarIcon: false
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormInputNumber, {
              label: "Harga",
              name: "price",
              placeholder: "Harga",
              modelValue: unref(dataForm).price,
              "onUpdate:modelValue": ($event) => unref(dataForm).price = $event,
              class: "input-bordered shadow-sm focus:outline-none",
              useStarIcon: false
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormDropdownOnlyTwo, {
              label: "Status Mobil",
              name: "is_active",
              placeholder: "Status Mobil",
              onGetId: funcGetIdStatus,
              modelValue: unref(statusActive),
              "onUpdate:modelValue": ($event) => isRef(statusActive) ? statusActive.value = $event : null,
              dataDropdown: unref(dataDropdown),
              class: "input-bordered shadow-sm focus:outline-none",
              useStarIcon: false
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormInputNumber, {
              label: "Maksimal Penumpang",
              name: "maxpenumpang",
              placeholder: "4",
              modelValue: unref(dataForm).max_person,
              "onUpdate:modelValue": ($event) => unref(dataForm).max_person = $event,
              class: "input-bordered shadow-sm focus:outline-none",
              useStarIcon: false
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_UIFormDropdownsTest, {
              label: "Fasilitas mobil",
              name: "fasilitas_mobil",
              placeholder: "Fasilitas mobil",
              dataDropdown: (_a = unref(data)) == null ? void 0 : _a.data,
              modelValue: unref(dataForm).facilities,
              "onUpdate:modelValue": ($event) => unref(dataForm).facilities = $event,
              dataSelected: (_a2 = (_b = props.transport) == null ? void 0 : _b.facilities) != null ? _a2 : [],
              onGetId: funcGetIdFacility
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex items-center justify-between mt-6"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, {
              to: "/admin/transport",
              class: "btn bg-transparent border border-red-600 text-red-500"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Batalkan `);
                } else {
                  return [
                    createTextVNode(" Batalkan ")
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<button type="submit"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""} class="btn bg-primary text-white normal-case !font-medium text-base hover:bg-primary"${_scopeId}>${ssrInterpolate(__props.buttonTitle)}</button></div>`);
          } else {
            return [
              createVNode("div", { class: "border shadow-sm rounded-[8px] py-4 px-4" }, [
                createVNode("p", { class: "text-black font-semibold" }, "General"),
                createVNode("div", null, [
                  createVNode("div", { class: "hidden" }, [
                    createVNode(_component_VeeField, {
                      type: "file",
                      name: "image_thumbnail",
                      id: "image_thumbnail",
                      modelValue: unref(dataForm).image,
                      "onUpdate:modelValue": ($event) => unref(dataForm).image = $event
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  createVNode(_component_UIFormInputImageCropAdmin, {
                    loading: unref(loading),
                    label: "Foto Mobil",
                    name: "image",
                    modelValue: unref(dataForm).image,
                    "onUpdate:modelValue": ($event) => unref(dataForm).image = $event,
                    existingimage: unref(existingImage)
                  }, null, 8, ["loading", "modelValue", "onUpdate:modelValue", "existingimage"]),
                  createVNode(_component_VeeErrorMessage, {
                    name: "image",
                    class: "text-red-500"
                  })
                ]),
                createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 mt-3 gap-4" }, [
                  createVNode(_component_UIFormTextFieldWLabel, {
                    label: "Nama Mobil",
                    name: "mobil",
                    placeholder: "Input Mobil",
                    modelValue: unref(dataForm).name,
                    "onUpdate:modelValue": ($event) => unref(dataForm).name = $event,
                    class: "input-bordered shadow-sm focus:outline-none",
                    useStarIcon: false
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode(_component_UIFormInputNumber, {
                    label: "Harga",
                    name: "price",
                    placeholder: "Harga",
                    modelValue: unref(dataForm).price,
                    "onUpdate:modelValue": ($event) => unref(dataForm).price = $event,
                    class: "input-bordered shadow-sm focus:outline-none",
                    useStarIcon: false
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode(_component_UIFormDropdownOnlyTwo, {
                    label: "Status Mobil",
                    name: "is_active",
                    placeholder: "Status Mobil",
                    onGetId: funcGetIdStatus,
                    modelValue: unref(statusActive),
                    "onUpdate:modelValue": ($event) => isRef(statusActive) ? statusActive.value = $event : null,
                    dataDropdown: unref(dataDropdown),
                    class: "input-bordered shadow-sm focus:outline-none",
                    useStarIcon: false
                  }, null, 8, ["modelValue", "onUpdate:modelValue", "dataDropdown"]),
                  createVNode(_component_UIFormInputNumber, {
                    label: "Maksimal Penumpang",
                    name: "maxpenumpang",
                    placeholder: "4",
                    modelValue: unref(dataForm).max_person,
                    "onUpdate:modelValue": ($event) => unref(dataForm).max_person = $event,
                    class: "input-bordered shadow-sm focus:outline-none",
                    useStarIcon: false
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode(_component_UIFormDropdownsTest, {
                  label: "Fasilitas mobil",
                  name: "fasilitas_mobil",
                  placeholder: "Fasilitas mobil",
                  dataDropdown: (_c = unref(data)) == null ? void 0 : _c.data,
                  modelValue: unref(dataForm).facilities,
                  "onUpdate:modelValue": ($event) => unref(dataForm).facilities = $event,
                  dataSelected: (_b2 = (_d = props.transport) == null ? void 0 : _d.facilities) != null ? _b2 : [],
                  onGetId: funcGetIdFacility
                }, null, 8, ["dataDropdown", "modelValue", "onUpdate:modelValue", "dataSelected"])
              ]),
              createVNode("div", { class: "flex items-center justify-between mt-6" }, [
                createVNode(_component_NuxtLink, {
                  to: "/admin/transport",
                  class: "btn bg-transparent border border-red-600 text-red-500"
                }, {
                  default: withCtx(() => [
                    createTextVNode(" Batalkan ")
                  ]),
                  _: 1
                }),
                createVNode("button", {
                  type: "submit",
                  disabled: unref(loading),
                  class: "btn bg-primary text-white normal-case !font-medium text-base hover:bg-primary"
                }, toDisplayString(__props.buttonTitle), 9, ["disabled"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/Transport.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main;

export { __nuxt_component_1 as _ };
//# sourceMappingURL=Transport-8813207c.mjs.map
