import { defineComponent, mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "AddressInformation",
  __ssrInlineRender: true,
  props: {
    name: {
      type: String
    },
    locationName: {
      type: String
    },
    locationAddress: {
      type: String
    }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "border rounded-xl p-4 space-y-2" }, _attrs))}><div class="text-xs text-zinc-400">${ssrInterpolate(props.name)}</div><div>${ssrInterpolate(props.locationName)}</div><div class="text-sm text-zinc-400">${ssrInterpolate(props.locationAddress)}</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vehicle/AddressInformation.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=AddressInformation-3373b627.mjs.map
