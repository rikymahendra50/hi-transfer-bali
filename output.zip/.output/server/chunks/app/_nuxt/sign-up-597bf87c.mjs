import { Form } from 'vee-validate';
import { u as useSchema, _ as _sfc_main$1 } from './useSchema-aab15ddc.mjs';
import { _ as _sfc_main$2 } from './MGroup-69a23538.mjs';
import { _ as _sfc_main$3 } from './MTextField-61174a46.mjs';
import __nuxt_component_1 from './Icon-7218f0f6.mjs';
import { _ as _sfc_main$4 } from './Btn-61213793.mjs';
import { b as useAuth, d as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import { u as usePasswordHelper, _ as _sfc_main$5 } from './usePasswordHelper-bd5c09b9.mjs';
import { defineComponent, mergeProps, unref, withCtx, isRef, createVNode, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import 'zod';
import '@vee-validate/zod';
import 'clsx';
import './config-aab100d3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "sign-up",
  __ssrInlineRender: true,
  setup(__props) {
    const { registerSchema } = useSchema();
    const { loading, message, alertType, $credentialForm, $register } = useAuth();
    const { inputType, togglePasswordType } = usePasswordHelper();
    useHead({
      title: "Sign Up"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIAlert = _sfc_main$1;
      const _component_UIFormMGroup = _sfc_main$2;
      const _component_UIFormMTextField = _sfc_main$3;
      const _component_Icon = __nuxt_component_1;
      const _component_UIBtn = _sfc_main$4;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_AuthSocialLogin = _sfc_main$5;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "hero min-h-screen" }, _attrs))}><div class="hero-content text-center"><div class="w-[500px] rounded-xl border"><div class="py-4 text-center"><h1 class="text-xl font-bold">Sign Up</h1></div>`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit: unref($register),
        "validation-schema": unref(registerSchema)
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 gap-4 p-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIAlert, {
              modelValue: unref(message),
              "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
              type: unref(alertType)
            }, null, _parent2, _scopeId));
            _push2(`<div class="grid grid-cols-2 gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "First Name",
              name: "first_name"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: unref($credentialForm).first_name,
                    "onUpdate:modelValue": ($event) => unref($credentialForm).first_name = $event,
                    name: "first_name",
                    class: "input-bordered",
                    placeholder: "ex:jhon"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref($credentialForm).first_name,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).first_name = $event,
                      name: "first_name",
                      class: "input-bordered",
                      placeholder: "ex:jhon"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Last Name",
              name: "last_name"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: unref($credentialForm).last_name,
                    "onUpdate:modelValue": ($event) => unref($credentialForm).last_name = $event,
                    name: "last_name",
                    class: "input-bordered",
                    placeholder: "ex:doe"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref($credentialForm).last_name,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).last_name = $event,
                      name: "last_name",
                      class: "input-bordered",
                      placeholder: "ex:doe"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Email",
              name: "email"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "email",
                    modelValue: unref($credentialForm).email,
                    "onUpdate:modelValue": ($event) => unref($credentialForm).email = $event,
                    class: "input-bordered",
                    placeholder: "ex:myemail@gmail.com"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "email",
                      modelValue: unref($credentialForm).email,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).email = $event,
                      class: "input-bordered",
                      placeholder: "ex:myemail@gmail.com"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Password",
              name: "password"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: unref($credentialForm).password,
                    "onUpdate:modelValue": ($event) => unref($credentialForm).password = $event,
                    name: "password",
                    type: unref(inputType),
                    class: "input-bordered",
                    placeholder: "********"
                  }, {
                    leftSection: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Icon, {
                            name: "i-heroicons-lock-closed",
                            class: "w-5 h-5 text-gray-400"
                          })
                        ];
                      }
                    }),
                    rightSection: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          class: "w-5 h-5 text-gray-400",
                          onClick: unref(togglePasswordType)
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Icon, {
                            name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                            class: "w-5 h-5 text-gray-400",
                            onClick: unref(togglePasswordType)
                          }, null, 8, ["name", "onClick"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref($credentialForm).password,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).password = $event,
                      name: "password",
                      type: unref(inputType),
                      class: "input-bordered",
                      placeholder: "********"
                    }, {
                      leftSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        })
                      ]),
                      rightSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          class: "w-5 h-5 text-gray-400",
                          onClick: unref(togglePasswordType)
                        }, null, 8, ["name", "onClick"])
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue", "type"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Confirm Password",
              name: "confirm_password"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: unref($credentialForm).confirm_password,
                    "onUpdate:modelValue": ($event) => unref($credentialForm).confirm_password = $event,
                    name: "confirm_password",
                    type: unref(inputType),
                    class: "input-bordered",
                    placeholder: "********"
                  }, {
                    leftSection: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Icon, {
                            name: "i-heroicons-lock-closed",
                            class: "w-5 h-5 text-gray-400"
                          })
                        ];
                      }
                    }),
                    rightSection: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          class: "w-5 h-5 text-gray-400",
                          onClick: unref(togglePasswordType)
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Icon, {
                            name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                            class: "w-5 h-5 text-gray-400",
                            onClick: unref(togglePasswordType)
                          }, null, 8, ["name", "onClick"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref($credentialForm).confirm_password,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).confirm_password = $event,
                      name: "confirm_password",
                      type: unref(inputType),
                      class: "input-bordered",
                      placeholder: "********"
                    }, {
                      leftSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        })
                      ]),
                      rightSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          class: "w-5 h-5 text-gray-400",
                          onClick: unref(togglePasswordType)
                        }, null, 8, ["name", "onClick"])
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue", "type"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              variant: "primary",
              type: "submit",
              disabled: unref(loading),
              class: "w-full"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Submit`);
                } else {
                  return [
                    createTextVNode("Submit")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-between items-center"${_scopeId}><div${_scopeId}></div><div class="text-xs text-neutral-400"${_scopeId}><p${_scopeId}>Already have an account? `);
            _push2(ssrRenderComponent(_component_NuxtLink, {
              to: "/sign-in",
              class: "link link-hover"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Sign In `);
                } else {
                  return [
                    createTextVNode("Sign In ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</p></div></div><div class="divider divider-neutral text-neutral-400 text-sm"${_scopeId}>Daftar lebih cepat dengan</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_AuthSocialLogin, null, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 gap-4 p-4" }, [
                createVNode(_component_UIAlert, {
                  modelValue: unref(message),
                  "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
                  type: unref(alertType)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "type"]),
                createVNode("div", { class: "grid grid-cols-2 gap-4" }, [
                  createVNode(_component_UIFormMGroup, {
                    label: "First Name",
                    name: "first_name"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_UIFormMTextField, {
                        modelValue: unref($credentialForm).first_name,
                        "onUpdate:modelValue": ($event) => unref($credentialForm).first_name = $event,
                        name: "first_name",
                        class: "input-bordered",
                        placeholder: "ex:jhon"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_UIFormMGroup, {
                    label: "Last Name",
                    name: "last_name"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_UIFormMTextField, {
                        modelValue: unref($credentialForm).last_name,
                        "onUpdate:modelValue": ($event) => unref($credentialForm).last_name = $event,
                        name: "last_name",
                        class: "input-bordered",
                        placeholder: "ex:doe"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  })
                ]),
                createVNode(_component_UIFormMGroup, {
                  label: "Email",
                  name: "email"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      name: "email",
                      modelValue: unref($credentialForm).email,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).email = $event,
                      class: "input-bordered",
                      placeholder: "ex:myemail@gmail.com"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  label: "Password",
                  name: "password"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref($credentialForm).password,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).password = $event,
                      name: "password",
                      type: unref(inputType),
                      class: "input-bordered",
                      placeholder: "********"
                    }, {
                      leftSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        })
                      ]),
                      rightSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          class: "w-5 h-5 text-gray-400",
                          onClick: unref(togglePasswordType)
                        }, null, 8, ["name", "onClick"])
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue", "type"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  label: "Confirm Password",
                  name: "confirm_password"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref($credentialForm).confirm_password,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).confirm_password = $event,
                      name: "confirm_password",
                      type: unref(inputType),
                      class: "input-bordered",
                      placeholder: "********"
                    }, {
                      leftSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        })
                      ]),
                      rightSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          class: "w-5 h-5 text-gray-400",
                          onClick: unref(togglePasswordType)
                        }, null, 8, ["name", "onClick"])
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue", "type"])
                  ]),
                  _: 1
                }),
                createVNode("div", null, [
                  createVNode(_component_UIBtn, {
                    variant: "primary",
                    type: "submit",
                    disabled: unref(loading),
                    class: "w-full"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Submit")
                    ]),
                    _: 1
                  }, 8, ["disabled"])
                ]),
                createVNode("div", { class: "flex justify-between items-center" }, [
                  createVNode("div"),
                  createVNode("div", { class: "text-xs text-neutral-400" }, [
                    createVNode("p", null, [
                      createTextVNode("Already have an account? "),
                      createVNode(_component_NuxtLink, {
                        to: "/sign-in",
                        class: "link link-hover"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Sign In ")
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                createVNode("div", { class: "divider divider-neutral text-neutral-400 text-sm" }, "Daftar lebih cepat dengan"),
                createVNode("div", null, [
                  createVNode(_component_AuthSocialLogin)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/sign-up.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=sign-up-597bf87c.mjs.map
