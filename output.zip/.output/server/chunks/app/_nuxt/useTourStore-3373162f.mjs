import { h as useRequestHelper, e as useRequestOptions, b as useRouter, k as useNuxtApp } from '../server.mjs';
import { ref } from 'vue';
import { u as useNotification } from './nofication-1c3cca5e.mjs';

function useTourForm(options = {}) {
  const { loading, message, alertType, setErrorMessage, transformErrors } = useRequestHelper();
  const { requestOptions } = useRequestOptions();
  useRouter();
  useNotification();
  const { $toast } = useNuxtApp();
  const dataForm = ref({
    location_id: null,
    location_name: null,
    activity_date: null,
    tour_image: null,
    tour_name: null,
    tour_id: void 0,
    tourist_numbers: 1,
    price: void 0,
    usd_price: void 0,
    product: [],
    forms: [],
    variants: [],
    name: void 0,
    email: void 0,
    phone: void 0,
    list_location: void 0,
    list_location_string: void 0,
    user_uuid: void 0
  });
  function saveFormData() {
    sessionStorage.setItem("tourFormData", JSON.stringify(dataForm.value));
  }
  function showSavedTourData() {
    const savedData = sessionStorage.getItem("tourFormData");
    if (savedData) {
      dataForm.value = JSON.parse(savedData);
    }
  }
  function clearSavedTourData() {
    sessionStorage.removeItem("tourFormData");
  }
  const submitForm = async (ctx) => {
    const formData = new FormData();
    loading.value = true;
    formData.append("pic_name", dataForm.value.name || "");
    formData.append("pic_email", dataForm.value.email || "");
    formData.append("pic_phone_number", dataForm.value.phone || "");
    formData.append("activity_date", dataForm.value.activity_date || "");
    if (dataForm.value.variants) {
      dataForm.value.variants.forEach((variant, index) => {
        formData.append(`products[${index}][id]`, dataForm.value.tour_id);
        formData.append(
          `products[${index}][location_id]`,
          dataForm.value.location_id || ""
        );
        formData.append(`products[${index}][name]`, variant.description);
        formData.append(`products[${index}][variant_id]`, variant.id);
        formData.append(`products[${index}][quantity]`, variant.quantity);
      });
    }
    if (dataForm.value.forms) {
      dataForm.value.forms.forEach((item, index) => {
        formData.append(`forms[${index}][product_id]`, dataForm.value.tour_id);
        formData.append(`forms[${index}][name]`, item.name);
        formData.append(`forms[${index}][variant_id]`, item.variant_id);
        formData.append(`forms[${index}][nationality]`, item.nationality);
      });
    }
    await $fetch(
      `/users/${dataForm.value.user_uuid}/tour-orders`,
      {
        headers: {
          Accept: "application/json"
        },
        method: "POST",
        body: formData,
        ...requestOptions
      }
    ).catch((error) => {
      var _a2;
      var _a;
      $toast.error((_a2 = (_a = error == null ? void 0 : error.data) == null ? void 0 : _a.message) != null ? _a2 : "Fail");
    }).then((data) => {
      var _a, _b;
      if (data) {
        window.location.replace((_a = data.data) == null ? void 0 : _a.payment_url);
        (_b = options.callback) == null ? void 0 : _b.call(options);
      }
    });
    loading.value = false;
  };
  return {
    submitForm,
    showSavedTourData,
    saveFormData,
    dataForm,
    clearSavedTourData,
    loading
  };
}

export { useTourForm as u };
//# sourceMappingURL=useTourStore-3373162f.mjs.map
