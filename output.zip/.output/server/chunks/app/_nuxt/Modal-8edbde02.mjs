import __nuxt_component_1 from './Icon-f8c4e628.mjs';
import { useSSRContext, defineComponent, ref, computed, watch, nextTick, unref, mergeProps } from 'vue';
import { ssrRenderTeleport, ssrRenderClass, ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot } from 'vue/server-renderer';
import { o as onClickOutside } from './index-dea25161.mjs';
import { _ as _export_sfc } from '../server.mjs';

const _sfc_main = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "Modal",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      type: Boolean,
      default: false
    },
    clickOutside: {
      type: Boolean,
      default: false
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { expose: __expose, emit }) {
    const props = __props;
    const modal = ref(null);
    const showModal = computed({
      get() {
        return props.modelValue;
      },
      set(value) {
        emit("update:modelValue", value);
      }
    });
    function hideModal() {
      showModal.value = false;
    }
    watch(showModal, (newValue) => {
      if (newValue) {
        nextTick(() => {
          onClickOutside(modal, () => {
            if (props.clickOutside) {
              hideModal();
            }
          });
        });
      }
    });
    __expose({
      hideModal
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_1;
      ssrRenderTeleport(_push, (_push2) => {
        if (unref(showModal)) {
          _push2(`<div class="modal-background" data-v-20db6a88></div>`);
        } else {
          _push2(`<!---->`);
        }
        if (unref(showModal)) {
          _push2(`<dialog class="${ssrRenderClass([{
            "modal-open": unref(showModal)
          }, "modal !z-[9999] !bg-transparent"])}" data-v-20db6a88><div${ssrRenderAttrs(mergeProps({ class: "modal-content rounded-[10px] !bg-white py-3 px-3" }, _ctx.$attrs, {
            ref_key: "modal",
            ref: modal
          }))} data-v-20db6a88>`);
          if (unref(showModal)) {
            _push2(`<!--[--><div class="flex items-end justify-end pb-4" data-v-20db6a88><div class="border px-1 w-[24px] h-[24px] flex items-center rounded-md cursor-pointer" data-v-20db6a88>`);
            _push2(ssrRenderComponent(_component_Icon, {
              name: "mingcute:close-fill",
              class: "text-[#64748B]"
            }, null, _parent));
            _push2(`</div></div>`);
            ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent);
            _push2(`<!--]-->`);
          } else {
            _push2(`<!---->`);
          }
          _push2(`</div></dialog>`);
        } else {
          _push2(`<!---->`);
        }
      }, "body", false, _parent);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Modal.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-20db6a88"]]);

export { __nuxt_component_3 as _ };
//# sourceMappingURL=Modal-8edbde02.mjs.map
