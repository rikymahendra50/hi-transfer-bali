import { e as useRequestOptions, h as useRequestHelper, i as useFetch } from '../server.mjs';
import { u as useNotification } from './nofication-1c3cca5e.mjs';
import { ref, computed } from 'vue';

function useTransport(options = {}) {
  const { requestOptions } = useRequestOptions();
  const { loading, message, alertType, setErrorMessage, transformErrors } = useRequestHelper();
  const { pushNotification } = useNotification();
  const selectedTransport = ref();
  const dataForm = ref({
    name: void 0,
    is_active: void 0,
    price: void 0,
    max_person: void 0,
    image: void 0,
    facilities: []
  });
  function resetForm() {
    dataForm.value = {
      name: void 0,
      is_active: void 0,
      price: void 0,
      max_person: void 0,
      image: void 0,
      facilities: []
    };
  }
  const existingImage = computed(() => {
    var _a;
    return (_a = selectedTransport.value) == null ? void 0 : _a.image;
  });
  function onSubmit(values, ctx) {
    if (selectedTransport.value) {
      updateTransport(ctx);
    } else {
      createTransport(ctx);
    }
  }
  const createTransport = async (ctx) => {
    const formData = new FormData();
    loading.value = true;
    const uniqueFacilities = [...new Set(dataForm.value.facilities)];
    for (const item in dataForm.value) {
      if (item === "facilities") {
        uniqueFacilities.forEach((facility, index) => {
          formData.append(`facilities[${index}]`, facility);
        });
      } else {
        const objectItem = dataForm.value[item];
        formData.append(item, objectItem);
      }
    }
    await $fetch("/admins/cars", {
      headers: { Accept: "Application/json" },
      method: "POST",
      body: formData,
      ...requestOptions
    }).catch((error) => {
      var _a, _b;
      setErrorMessage((_a = error.data) == null ? void 0 : _a.message);
      ctx.setErrors(transformErrors(error.data));
      pushNotification({
        type: "error",
        text: (_b = error.value.data) == null ? void 0 : _b.message,
        title: "error"
      });
    }).then((data) => {
      var _a;
      if (data) {
        ctx.resetForm();
        pushNotification({
          type: "success",
          text: "Transport created successfully"
        });
        (_a = options.callback) == null ? void 0 : _a.call(options);
      }
    });
    loading.value = false;
  };
  const updateTransport = async (ctx) => {
    var _a;
    const formData = new FormData();
    loading.value = true;
    for (const item in dataForm.value) {
      if (item === "facilities") {
        dataForm.value.facilities.forEach((facility, index) => {
          formData.append(`facilities[${index}]`, facility);
        });
      } else {
        const objectItem = dataForm.value[item];
        formData.append(item, objectItem);
      }
    }
    if (!dataForm.value.image) {
      formData.delete("image");
    }
    await $fetch(
      `/admins/cars/${(_a = selectedTransport.value) == null ? void 0 : _a.slug}?_method=PUT`,
      {
        headers: {
          Accept: "Application/json"
        },
        method: "POST",
        body: formData,
        ...requestOptions
      }
    ).catch((error) => {
      var _a2, _b;
      setErrorMessage((_a2 = error.data) == null ? void 0 : _a2.message);
      ctx.setErrors(transformErrors(error.data));
      pushNotification({
        type: "error",
        text: (_b = error.value.data) == null ? void 0 : _b.message,
        title: "error"
      });
    }).then((data) => {
      var _a2;
      if (data) {
        ctx.resetForm();
        pushNotification({
          type: "success",
          text: "Transport updated successfully"
        });
        resetForm();
        (_a2 = options.callback) == null ? void 0 : _a2.call(options);
      }
    });
    loading.value = false;
  };
  async function deleteTransport(slug) {
    var _a2;
    var _a, _b, _c;
    loading.value = true;
    const { error } = await useFetch(
      `/admins/cars/${slug}`,
      {
        method: "DELETE",
        ...requestOptions
      },
      "$hFPjlGq3hK"
    );
    if (error.value) {
      setErrorMessage((_a2 = (_b = (_a = error.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message) != null ? _a2 : "Something went wrong");
    } else {
      pushNotification({
        type: "success",
        text: "Transport deleted successfully"
      });
      (_c = options.callback) == null ? void 0 : _c.call(options);
    }
    loading.value = false;
  }
  return {
    selectedTransport,
    dataForm,
    existingImage,
    onSubmit,
    deleteTransport,
    loading
  };
}

export { useTransport as u };
//# sourceMappingURL=useTransport-bdd5bf0b.mjs.map
