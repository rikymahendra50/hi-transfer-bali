import { e as useI18n } from '../server.mjs';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import { useSSRContext, unref } from 'vue';
import { ssrRenderAttrs, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "PriceCheckoutInformation",
  __ssrInlineRender: true,
  props: {
    price: {
      type: [String, Number]
    }
  },
  setup(__props) {
    const props = __props;
    const { locale, t: $t } = useI18n();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="space-y-4 p-4 border rounded-xl"><div class="flex flex-col lg:flex-row lg:justify-between item-center"><div>${ssrInterpolate(unref($t)("yang-harus-kamu-bayar"))}</div><div class="text-lg font-semibold text-primary">${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(props.price))}</div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/PriceCheckoutInformation.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main;

export { __nuxt_component_6 as _ };
//# sourceMappingURL=PriceCheckoutInformation-a4421de5.mjs.map
