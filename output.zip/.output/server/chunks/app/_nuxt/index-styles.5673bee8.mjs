const Map_vue_vue_type_style_index_0_scoped_b6d9e555_lang = ".input[data-v-b6d9e555]{--tw-bg-opacity:1;background-color:#fff;background-color:rgb(255 255 255/var(--tw-bg-opacity));z-index:10}";

const ModalMap_vue_vue_type_style_index_0_scoped_224a6874_lang = ".modal-background[data-v-224a6874]{background-color:hsla(0,0%,100%,.2)}.modal[data-v-224a6874],.modal-background[data-v-224a6874]{height:100%;left:0;position:fixed;top:0;width:100%}.modal[data-v-224a6874]{align-items:center;display:flex;justify-content:center}.modal-open[data-v-224a6874]{overflow:hidden}.modal-content[data-v-224a6874]{background-color:#fff;box-shadow:0 4px 6px rgba(0,0,0,.1)}";

const HomeBanner_vue_vue_type_style_index_0_scoped_13b818ff_lang = ".fade-enter-active[data-v-13b818ff]{transition:all .3s ease-out}.fade-leave-active[data-v-13b818ff]{transition:all .8s cubic-bezier(1,.5,.8,1)}.fade-enter-from[data-v-13b818ff],.fade-leave-to[data-v-13b818ff]{opacity:0;transform:translateX(20px)}";

const indexStyles_5673bee8 = [Map_vue_vue_type_style_index_0_scoped_b6d9e555_lang, ModalMap_vue_vue_type_style_index_0_scoped_224a6874_lang, HomeBanner_vue_vue_type_style_index_0_scoped_13b818ff_lang];

export { indexStyles_5673bee8 as default };
//# sourceMappingURL=index-styles.5673bee8.mjs.map
