import { e as useI18n, _ as __nuxt_component_0$1 } from '../server.mjs';
import { useSSRContext, computed, mergeProps, withCtx, unref, createVNode, toDisplayString } from 'vue';
import { u as useTourForm } from './useTourStore-096c47bc.mjs';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "Card",
  __ssrInlineRender: true,
  props: {
    id: { type: [String, Number] },
    name: { type: String },
    slug: { type: String },
    description: { type: [String, Array] },
    image: { type: String },
    price: { type: [String, Number] }
  },
  setup(__props) {
    const props = __props;
    const { locale, t: $t } = useI18n();
    const result = computed(() => {
      return props.description.map((item) => item.name).join(" - ");
    });
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedTourData,
      clearSavedTourData
    } = useTourForm({
      callback: () => {
        alert("Form has been submitted!");
      }
    });
    function goToTourBooking(id, image, name, price, description) {
      showSavedTourData();
      dataForm.value.tour_id = id;
      dataForm.value.tour_image = image;
      dataForm.value.tour_name = name;
      dataForm.value.price = price;
      dataForm.value.list_location = description;
      dataForm.value.list_location_string = result.value;
      saveFormData();
      console.log(
        "Ini dari card tour, harusnya menyimpan image, name dan harga dari tour",
        dataForm.value
      );
      router.push("/vehicles/booking");
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(ssrRenderComponent(_component_NuxtLink, mergeProps({
        to: __props.slug,
        onClick: ($event) => goToTourBooking(__props.id, props.image, __props.name, __props.price, __props.description),
        class: "overflow-hidden rounded-xl space-y-2 border border-zinc-200 shadow-sm group"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div class="h-[300px] overflow-hidden"${_scopeId}><img${ssrRenderAttr("src", (_a = props.image) != null ? _a : "https://placehold.co/150")}${ssrRenderAttr("alt", __props.image)} class="h-[300px] w-full object-cover group-hover:scale-125 transition-all duration-300"${_scopeId}></div><div class="p-3 space-y-4"${_scopeId}><div${_scopeId}><h4 class="text-xl font-semibold text-primary-dark"${_scopeId}>${ssrInterpolate(__props.name)}</h4><div class="text-zinc-400 text-sm line-clamp-2"${_scopeId}>${ssrInterpolate(unref(result))}</div></div><div${_scopeId}><div class="text-zinc-400 text-xs"${_scopeId}>${ssrInterpolate(unref($t)("harga-mulai-dari"))}</div><h4 class="text-xl font-semibold text-primary"${_scopeId}>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(__props.price.toString()))} /${ssrInterpolate(unref($t)("orang"))}</h4></div></div>`);
          } else {
            return [
              createVNode("div", { class: "h-[300px] overflow-hidden" }, [
                createVNode("img", {
                  src: (_b = props.image) != null ? _b : "https://placehold.co/150",
                  alt: __props.image,
                  class: "h-[300px] w-full object-cover group-hover:scale-125 transition-all duration-300"
                }, null, 8, ["src", "alt"])
              ]),
              createVNode("div", { class: "p-3 space-y-4" }, [
                createVNode("div", null, [
                  createVNode("h4", { class: "text-xl font-semibold text-primary-dark" }, toDisplayString(__props.name), 1),
                  createVNode("div", { class: "text-zinc-400 text-sm line-clamp-2" }, toDisplayString(unref(result)), 1)
                ]),
                createVNode("div", null, [
                  createVNode("div", { class: "text-zinc-400 text-xs" }, toDisplayString(unref($t)("harga-mulai-dari")), 1),
                  createVNode("h4", { class: "text-xl font-semibold text-primary" }, toDisplayString(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(__props.price.toString())) + " /" + toDisplayString(unref($t)("orang")), 1)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/Card.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main;

export { __nuxt_component_4 as _ };
//# sourceMappingURL=Card-b5cc841d.mjs.map
