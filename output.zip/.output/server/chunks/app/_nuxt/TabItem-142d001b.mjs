import { _ as __nuxt_component_4 } from './client-only-53a57ea8.mjs';
import { defineComponent, useSSRContext, ref, unref } from 'vue';
import { ssrRenderComponent, ssrRenderClass, ssrRenderAttr, ssrIncludeBooleanAttr, ssrRenderSlot } from 'vue/server-renderer';
import clsx from 'clsx';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "TabContent",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_4;
      _push(ssrRenderComponent(_component_ClientOnly, _attrs, {}, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TabContent.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "TabItem",
  __ssrInlineRender: true,
  props: {
    name: {},
    checked: { type: Boolean },
    group: { default: "tab" },
    isError: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    ref(props.checked);
    ref(null);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><input role="tab" type="radio" class="${ssrRenderClass(
        unref(clsx)("tab", {
          "text-error": _ctx.isError,
          "[--tab-border-color:border-red-500]": _ctx.isError
        })
      )}"${ssrRenderAttr("name", props.group)}${ssrIncludeBooleanAttr(_ctx.checked) ? " checked" : ""}${ssrRenderAttr("aria-label", _ctx.name)}${ssrRenderAttr("value", _ctx.name)}><div role="tabpanel" class="${ssrRenderClass(
        unref(clsx)("tab-content  p-2 rounded", {
          "border-base-200": !_ctx.isError,
          "border-error": _ctx.isError
        })
      )}">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TabItem.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main$1 as _, _sfc_main as a };
//# sourceMappingURL=TabItem-142d001b.mjs.map
