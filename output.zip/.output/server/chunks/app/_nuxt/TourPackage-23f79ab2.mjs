import { useField, Form, ErrorMessage, Field, FieldArray } from 'vee-validate';
import { _ as _sfc_main$5 } from './TextFieldWLabel-0de16bf1.mjs';
import { _ as _sfc_main$2$1, a as __nuxt_component_6, b as __nuxt_component_7 } from './DropdownsTest-e2f0d57d.mjs';
import { _ as _sfc_main$1$1, a as _sfc_main$6 } from './TabItem-142d001b.mjs';
import { _ as _sfc_main$7 } from './Group-4dcbb69b.mjs';
import { _ as __nuxt_component_4 } from './client-only-53a57ea8.mjs';
import { useSSRContext, defineComponent, toRef, computed, ref, watch, mergeProps, unref, withAsyncContext, withCtx, isRef, createVNode, withDirectives, vModelCheckbox, createTextVNode, openBlock, createBlock, createCommentVNode, Fragment, renderList } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrInterpolate, ssrRenderSlot, ssrLooseEqual, ssrGetDynamicModelProps, ssrRenderList } from 'vue/server-renderer';
import { u as useTourPackage } from './useTourPackage-653e033f.mjs';
import { useEditor } from '@tiptap/vue-3';
import StarterKit from '@tiptap/starter-kit';
import Link from '@tiptap/extension-link';
import TextAlign from '@tiptap/extension-text-align';
import Placeholder from '@tiptap/extension-placeholder';
import Table from '@tiptap/extension-table';
import TableCell from '@tiptap/extension-table-cell';
import TableHeader from '@tiptap/extension-table-header';
import TableRow from '@tiptap/extension-table-row';
import ImageResize from 'tiptap-extension-resize-image';
import { b as useFileDialog, c as useEventListener } from './index-dea25161.mjs';
import { e as useRequestOptions, d as useRoute, b as useRouter, g as useAsyncData, _ as __nuxt_component_0$1, l as _export_sfc } from '../server.mjs';
import __nuxt_component_1$1 from './Icon-ab561e52.mjs';
import { u as useSchema } from './useSchema-79d12b54.mjs';

const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "SpTextarea",
  __ssrInlineRender: true,
  props: {
    modelValue: String,
    name: {
      type: String,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const name = toRef(props, "name");
    const {
      value: inputValue,
      errorMessage,
      handleBlur,
      handleChange,
      meta
    } = useField(name, void 0, {
      syncVModel: true
    });
    computed(() => {
      const arr = ["textarea"];
      if (!meta.touched) {
        return arr;
      }
      if (!!errorMessage.value) {
        arr.push("textarea-error");
      }
      return arr.join(" ");
    });
    computed({
      get() {
        return inputValue.value;
      },
      set(value) {
        inputValue.value = value;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_4;
      _push(ssrRenderComponent(_component_ClientOnly, _attrs, {}, _parent));
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/SpTextarea.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "Editor",
  __ssrInlineRender: true,
  props: {
    modelValue: { default: "" },
    isErrors: { type: Boolean, default: false },
    withImage: { type: Boolean, default: true }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit }) {
    const props = __props;
    const { imageTourPackageUpload } = useTourPackage();
    const uploading = ref(false);
    const contentClass = computed(() => {
      if (props.isErrors) {
        return "prose !max-w-none p-2 min-h-[200px] w-full border border-red-400 rounded-md  outline-none rounded-md";
      }
      return "prose !max-w-none p-2 min-h-[200px]  w-full  border border-gray-200 rounded-md outline-none rounded-md";
    });
    const editor = useEditor({
      content: props.modelValue,
      extensions: [
        StarterKit,
        Link.configure(),
        TextAlign.configure({
          types: ["heading", "paragraph", "image"],
          defaultAlignment: "left"
        }),
        Placeholder.configure({
          placeholder: ({ node }) => {
            if (node.type.name === "paragraph") {
              return "What\u2019s the title?";
            }
            return "Can you add some further context?";
          }
        }),
        Table.configure({
          resizable: true,
          HTMLAttributes: {
            class: "table table-sm border"
          }
        }),
        TableRow,
        TableHeader.configure({
          HTMLAttributes: {
            class: "border"
          }
        }),
        TableCell.configure({
          HTMLAttributes: {
            class: "border"
          }
        }),
        ImageResize
      ],
      editorProps: {
        attributes: {
          class: contentClass.value
        }
      },
      onUpdate(ctx) {
        var _a;
        emit("update:modelValue", (_a = ctx == null ? void 0 : ctx.editor) == null ? void 0 : _a.getHTML());
      }
    });
    function addPhoto({ url }) {
      var _a;
      (_a = editor.value) == null ? void 0 : _a.chain().focus().setImage({ src: url, alt: "Hi Transfer" }).run();
    }
    const { open, reset, onChange } = useFileDialog({
      accept: "image/*",
      // Set to accept only image files
      multiple: false
    });
    onChange(async (files) => {
      if (!files) {
        return;
      }
      uploading.value = true;
      const file = files[0];
      if (file.size > 1 * 1024 * 1024) {
        return alert("File size should be less than 1MB");
      }
      const url = await imageTourPackageUpload(file);
      if (url) {
        addPhoto({
          url
        });
      }
      uploading.value = false;
      reset();
    });
    watch(
      () => props.modelValue,
      (value) => {
        var _a, _b;
        if (((_a = editor.value) == null ? void 0 : _a.getHTML()) === value) {
          return;
        }
        (_b = editor.value) == null ? void 0 : _b.commands.setContent(value, false);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_4;
      _push(ssrRenderComponent(_component_ClientOnly, _attrs, {}, _parent));
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/Editor.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_10 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-d10a4958"]]);
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "CollapseForm",
  __ssrInlineRender: true,
  props: {
    title: String
  },
  setup(__props) {
    const props = __props;
    const details = ref();
    const isOpen = ref(false);
    useEventListener(details, "toggle", () => {
      var _a2;
      var _a;
      isOpen.value = (_a2 = (_a = details.value) == null ? void 0 : _a.open) != null ? _a2 : false;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_1$1;
      _push(`<details${ssrRenderAttrs(mergeProps({
        ref_key: "details",
        ref: details,
        class: "p-2 transition-all duration-500 rounded"
      }, _attrs))}><summary class="flex flex-row items-center font-semibold cursor-pointer text-sm text-[#8C8C8C]"><span class="grow relative after:w-full after:h-0.5 after:bg-[#8C8C8C]/20 after:absolute after:my-auto after:ml-3 after:mr-3 after:top-1/2 overflow-hidden">${ssrInterpolate(props.title)}</span>`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "i-heroicons-chevron-down",
        class: [{ "rotate-180": unref(isOpen) }, "w-5 h-5 transition-all duration-300"]
      }, null, _parent));
      _push(`</summary><div class="transition-all duration-500 mt-1">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></details>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CollapseForm.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "TurVariant",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      type: Array,
      default: () => []
    },
    errors: {
      type: Object,
      default: () => ({})
    }
  },
  emits: ["reload", "update:modelValue"],
  setup(__props, { emit }) {
    const props = __props;
    const state = ref([]);
    watch(
      state,
      (value) => {
        emit("update:modelValue", value);
      },
      {
        deep: true,
        immediate: false
      }
    );
    function getErrors(key) {
      var _a;
      return !!((_a = props.errors) == null ? void 0 : _a[key]);
    }
    function addProductVariant() {
      state.value.push({
        name: "",
        price: "",
        description: {
          en: "",
          id: ""
        }
      });
    }
    const showRemoveButton = computed(() => {
      return state.value ? state.value.length > 1 : false;
    });
    function removerVariant(idx) {
      var _a;
      (_a = state.value) == null ? void 0 : _a.splice(idx, 1);
    }
    function showButtonAdd(idx) {
      var _a, _b;
      if (((_a = state.value) == null ? void 0 : _a.length) <= 0)
        return true;
      return idx === ((_b = state.value) == null ? void 0 : _b.length) - 1;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeFieldArray = FieldArray;
      const _component_CollapseForm = _sfc_main$2;
      const _component_UIFormTextFieldWLabel = _sfc_main$5;
      const _component_UIFormInputNumber = _sfc_main$2$1;
      const _component_TabContent = _sfc_main$1$1;
      const _component_TabItem = _sfc_main$6;
      const _component_UIFormGroup = _sfc_main$7;
      const _component_UIFormSpTextarea = _sfc_main$4;
      const _component_VeeField = Field;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "" }, _attrs))}><div class="font-medium my-2 border-b py-2">Tour Variants</div>`);
      _push(ssrRenderComponent(_component_VeeFieldArray, {
        name: "product_variants",
        class: "space-y-6 border-2 border-red-600"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(state.value, (dataForm, index) => {
              _push2(`<div class="space-y-8"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_CollapseForm, {
                title: `Variant ${index + 1}`,
                open: ""
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="space-y-6"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_component_UIFormTextFieldWLabel, {
                      label: "Nama",
                      name: `product_variants[${index}].name`,
                      placeholder: "Name",
                      modelValue: dataForm.name,
                      "onUpdate:modelValue": ($event) => dataForm.name = $event,
                      class: "input-bordered shadow-sm focus:outline-none",
                      useStarIcon: false
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_UIFormInputNumber, {
                      label: "Harga",
                      name: `product_variants[${index}].price`,
                      placeholder: "Price",
                      modelValue: dataForm.price,
                      "onUpdate:modelValue": ($event) => dataForm.price = $event,
                      class: "input-bordered shadow-sm focus:outline-none",
                      useStarIcon: false
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_TabContent, null, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(_component_TabItem, {
                            name: "EN",
                            group: "description",
                            checked: "",
                            "is-error": getErrors(`product_variants[${index}].description`)
                          }, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(_component_UIFormGroup, {
                                  label: "Description",
                                  name: `product_variants[${index}].description`
                                }, {
                                  default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                    if (_push6) {
                                      _push6(ssrRenderComponent(_component_UIFormSpTextarea, {
                                        name: `product_variants[${index}].description`,
                                        modelValue: dataForm.description.en,
                                        "onUpdate:modelValue": ($event) => dataForm.description.en = $event,
                                        class: "select-bordered",
                                        placeholder: "e.g. My Blog Description"
                                      }, null, _parent6, _scopeId5));
                                    } else {
                                      return [
                                        createVNode(_component_UIFormSpTextarea, {
                                          name: `product_variants[${index}].description`,
                                          modelValue: dataForm.description.en,
                                          "onUpdate:modelValue": ($event) => dataForm.description.en = $event,
                                          class: "select-bordered",
                                          placeholder: "e.g. My Blog Description"
                                        }, null, 8, ["name", "modelValue", "onUpdate:modelValue"])
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(_component_UIFormGroup, {
                                    label: "Description",
                                    name: `product_variants[${index}].description`
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_UIFormSpTextarea, {
                                        name: `product_variants[${index}].description`,
                                        modelValue: dataForm.description.en,
                                        "onUpdate:modelValue": ($event) => dataForm.description.en = $event,
                                        class: "select-bordered",
                                        placeholder: "e.g. My Blog Description"
                                      }, null, 8, ["name", "modelValue", "onUpdate:modelValue"])
                                    ]),
                                    _: 2
                                  }, 1032, ["name"])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                          _push4(ssrRenderComponent(_component_TabItem, {
                            name: "ID",
                            group: "description",
                            "is-error": getErrors(`product_variants[${index}].id_description`)
                          }, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(_component_UIFormGroup, {
                                  label: "(ID) Description",
                                  name: `product_variants[${index}].id_description`
                                }, {
                                  default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                    if (_push6) {
                                      _push6(ssrRenderComponent(_component_UIFormSpTextarea, {
                                        name: `product_variants[${index}].id_description`,
                                        modelValue: dataForm.description.id,
                                        "onUpdate:modelValue": ($event) => dataForm.description.id = $event,
                                        class: "select-bordered",
                                        placeholder: "e.g. My Blog Description"
                                      }, null, _parent6, _scopeId5));
                                    } else {
                                      return [
                                        createVNode(_component_UIFormSpTextarea, {
                                          name: `product_variants[${index}].id_description`,
                                          modelValue: dataForm.description.id,
                                          "onUpdate:modelValue": ($event) => dataForm.description.id = $event,
                                          class: "select-bordered",
                                          placeholder: "e.g. My Blog Description"
                                        }, null, 8, ["name", "modelValue", "onUpdate:modelValue"])
                                      ];
                                    }
                                  }),
                                  _: 2
                                }, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(_component_UIFormGroup, {
                                    label: "(ID) Description",
                                    name: `product_variants[${index}].id_description`
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_UIFormSpTextarea, {
                                        name: `product_variants[${index}].id_description`,
                                        modelValue: dataForm.description.id,
                                        "onUpdate:modelValue": ($event) => dataForm.description.id = $event,
                                        class: "select-bordered",
                                        placeholder: "e.g. My Blog Description"
                                      }, null, 8, ["name", "modelValue", "onUpdate:modelValue"])
                                    ]),
                                    _: 2
                                  }, 1032, ["name"])
                                ];
                              }
                            }),
                            _: 2
                          }, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(_component_TabItem, {
                              name: "EN",
                              group: "description",
                              checked: "",
                              "is-error": getErrors(`product_variants[${index}].description`)
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_UIFormGroup, {
                                  label: "Description",
                                  name: `product_variants[${index}].description`
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_UIFormSpTextarea, {
                                      name: `product_variants[${index}].description`,
                                      modelValue: dataForm.description.en,
                                      "onUpdate:modelValue": ($event) => dataForm.description.en = $event,
                                      class: "select-bordered",
                                      placeholder: "e.g. My Blog Description"
                                    }, null, 8, ["name", "modelValue", "onUpdate:modelValue"])
                                  ]),
                                  _: 2
                                }, 1032, ["name"])
                              ]),
                              _: 2
                            }, 1032, ["is-error"]),
                            createVNode(_component_TabItem, {
                              name: "ID",
                              group: "description",
                              "is-error": getErrors(`product_variants[${index}].id_description`)
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_UIFormGroup, {
                                  label: "(ID) Description",
                                  name: `product_variants[${index}].id_description`
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_UIFormSpTextarea, {
                                      name: `product_variants[${index}].id_description`,
                                      modelValue: dataForm.description.id,
                                      "onUpdate:modelValue": ($event) => dataForm.description.id = $event,
                                      class: "select-bordered",
                                      placeholder: "e.g. My Blog Description"
                                    }, null, 8, ["name", "modelValue", "onUpdate:modelValue"])
                                  ]),
                                  _: 2
                                }, 1032, ["name"])
                              ]),
                              _: 2
                            }, 1032, ["is-error"])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                    _push3(`<div class="hidden"${_scopeId2}>`);
                    _push3(ssrRenderComponent(_component_VeeField, {
                      name: `product_variants[${index}].description`,
                      modelValue: dataForm.description.en,
                      "onUpdate:modelValue": ($event) => dataForm.description.en = $event
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_VeeField, {
                      name: `product_variants[${index}].id_description`,
                      modelValue: dataForm.description.id,
                      "onUpdate:modelValue": ($event) => dataForm.description.id = $event
                    }, null, _parent3, _scopeId2));
                    _push3(`</div>`);
                    if (showRemoveButton.value) {
                      _push3(`<div${_scopeId2}><button class="btn btn-base border-red-500 bg-transparent border text-red-500 mt-2"${_scopeId2}> Remove Variant </button></div>`);
                    } else {
                      _push3(`<!---->`);
                    }
                    _push3(`</div>`);
                  } else {
                    return [
                      createVNode("div", { class: "space-y-6" }, [
                        createVNode(_component_UIFormTextFieldWLabel, {
                          label: "Nama",
                          name: `product_variants[${index}].name`,
                          placeholder: "Name",
                          modelValue: dataForm.name,
                          "onUpdate:modelValue": ($event) => dataForm.name = $event,
                          class: "input-bordered shadow-sm focus:outline-none",
                          useStarIcon: false
                        }, null, 8, ["name", "modelValue", "onUpdate:modelValue"]),
                        createVNode(_component_UIFormInputNumber, {
                          label: "Harga",
                          name: `product_variants[${index}].price`,
                          placeholder: "Price",
                          modelValue: dataForm.price,
                          "onUpdate:modelValue": ($event) => dataForm.price = $event,
                          class: "input-bordered shadow-sm focus:outline-none",
                          useStarIcon: false
                        }, null, 8, ["name", "modelValue", "onUpdate:modelValue"]),
                        createVNode(_component_TabContent, null, {
                          default: withCtx(() => [
                            createVNode(_component_TabItem, {
                              name: "EN",
                              group: "description",
                              checked: "",
                              "is-error": getErrors(`product_variants[${index}].description`)
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_UIFormGroup, {
                                  label: "Description",
                                  name: `product_variants[${index}].description`
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_UIFormSpTextarea, {
                                      name: `product_variants[${index}].description`,
                                      modelValue: dataForm.description.en,
                                      "onUpdate:modelValue": ($event) => dataForm.description.en = $event,
                                      class: "select-bordered",
                                      placeholder: "e.g. My Blog Description"
                                    }, null, 8, ["name", "modelValue", "onUpdate:modelValue"])
                                  ]),
                                  _: 2
                                }, 1032, ["name"])
                              ]),
                              _: 2
                            }, 1032, ["is-error"]),
                            createVNode(_component_TabItem, {
                              name: "ID",
                              group: "description",
                              "is-error": getErrors(`product_variants[${index}].id_description`)
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_UIFormGroup, {
                                  label: "(ID) Description",
                                  name: `product_variants[${index}].id_description`
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_UIFormSpTextarea, {
                                      name: `product_variants[${index}].id_description`,
                                      modelValue: dataForm.description.id,
                                      "onUpdate:modelValue": ($event) => dataForm.description.id = $event,
                                      class: "select-bordered",
                                      placeholder: "e.g. My Blog Description"
                                    }, null, 8, ["name", "modelValue", "onUpdate:modelValue"])
                                  ]),
                                  _: 2
                                }, 1032, ["name"])
                              ]),
                              _: 2
                            }, 1032, ["is-error"])
                          ]),
                          _: 2
                        }, 1024),
                        createVNode("div", { class: "hidden" }, [
                          createVNode(_component_VeeField, {
                            name: `product_variants[${index}].description`,
                            modelValue: dataForm.description.en,
                            "onUpdate:modelValue": ($event) => dataForm.description.en = $event
                          }, null, 8, ["name", "modelValue", "onUpdate:modelValue"]),
                          createVNode(_component_VeeField, {
                            name: `product_variants[${index}].id_description`,
                            modelValue: dataForm.description.id,
                            "onUpdate:modelValue": ($event) => dataForm.description.id = $event
                          }, null, 8, ["name", "modelValue", "onUpdate:modelValue"])
                        ]),
                        showRemoveButton.value ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode("button", {
                            onClick: ($event) => removerVariant(index),
                            class: "btn btn-base border-red-500 bg-transparent border text-red-500 mt-2"
                          }, " Remove Variant ", 8, ["onClick"])
                        ])) : createCommentVNode("", true)
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</div>`);
            });
            _push2(`<!--]-->`);
            if (showButtonAdd(state.value.length - 1)) {
              _push2(`<div${_scopeId}><button class="btn btn-base border-primary bg-transparent border text-primary mt-2"${_scopeId}> Tambah Variant </button></div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(state.value, (dataForm, index) => {
                return openBlock(), createBlock("div", {
                  class: "space-y-8",
                  key: index
                }, [
                  createVNode(_component_CollapseForm, {
                    title: `Variant ${index + 1}`,
                    open: ""
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "space-y-6" }, [
                        createVNode(_component_UIFormTextFieldWLabel, {
                          label: "Nama",
                          name: `product_variants[${index}].name`,
                          placeholder: "Name",
                          modelValue: dataForm.name,
                          "onUpdate:modelValue": ($event) => dataForm.name = $event,
                          class: "input-bordered shadow-sm focus:outline-none",
                          useStarIcon: false
                        }, null, 8, ["name", "modelValue", "onUpdate:modelValue"]),
                        createVNode(_component_UIFormInputNumber, {
                          label: "Harga",
                          name: `product_variants[${index}].price`,
                          placeholder: "Price",
                          modelValue: dataForm.price,
                          "onUpdate:modelValue": ($event) => dataForm.price = $event,
                          class: "input-bordered shadow-sm focus:outline-none",
                          useStarIcon: false
                        }, null, 8, ["name", "modelValue", "onUpdate:modelValue"]),
                        createVNode(_component_TabContent, null, {
                          default: withCtx(() => [
                            createVNode(_component_TabItem, {
                              name: "EN",
                              group: "description",
                              checked: "",
                              "is-error": getErrors(`product_variants[${index}].description`)
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_UIFormGroup, {
                                  label: "Description",
                                  name: `product_variants[${index}].description`
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_UIFormSpTextarea, {
                                      name: `product_variants[${index}].description`,
                                      modelValue: dataForm.description.en,
                                      "onUpdate:modelValue": ($event) => dataForm.description.en = $event,
                                      class: "select-bordered",
                                      placeholder: "e.g. My Blog Description"
                                    }, null, 8, ["name", "modelValue", "onUpdate:modelValue"])
                                  ]),
                                  _: 2
                                }, 1032, ["name"])
                              ]),
                              _: 2
                            }, 1032, ["is-error"]),
                            createVNode(_component_TabItem, {
                              name: "ID",
                              group: "description",
                              "is-error": getErrors(`product_variants[${index}].id_description`)
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_UIFormGroup, {
                                  label: "(ID) Description",
                                  name: `product_variants[${index}].id_description`
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_UIFormSpTextarea, {
                                      name: `product_variants[${index}].id_description`,
                                      modelValue: dataForm.description.id,
                                      "onUpdate:modelValue": ($event) => dataForm.description.id = $event,
                                      class: "select-bordered",
                                      placeholder: "e.g. My Blog Description"
                                    }, null, 8, ["name", "modelValue", "onUpdate:modelValue"])
                                  ]),
                                  _: 2
                                }, 1032, ["name"])
                              ]),
                              _: 2
                            }, 1032, ["is-error"])
                          ]),
                          _: 2
                        }, 1024),
                        createVNode("div", { class: "hidden" }, [
                          createVNode(_component_VeeField, {
                            name: `product_variants[${index}].description`,
                            modelValue: dataForm.description.en,
                            "onUpdate:modelValue": ($event) => dataForm.description.en = $event
                          }, null, 8, ["name", "modelValue", "onUpdate:modelValue"]),
                          createVNode(_component_VeeField, {
                            name: `product_variants[${index}].id_description`,
                            modelValue: dataForm.description.id,
                            "onUpdate:modelValue": ($event) => dataForm.description.id = $event
                          }, null, 8, ["name", "modelValue", "onUpdate:modelValue"])
                        ]),
                        showRemoveButton.value ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode("button", {
                            onClick: ($event) => removerVariant(index),
                            class: "btn btn-base border-red-500 bg-transparent border text-red-500 mt-2"
                          }, " Remove Variant ", 8, ["onClick"])
                        ])) : createCommentVNode("", true)
                      ])
                    ]),
                    _: 2
                  }, 1032, ["title"])
                ]);
              }), 128)),
              showButtonAdd(state.value.length - 1) ? (openBlock(), createBlock("div", { key: 0 }, [
                createVNode("button", {
                  onClick: addProductVariant,
                  class: "btn btn-base border-primary bg-transparent border text-primary mt-2"
                }, " Tambah Variant ")
              ])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/TurVariant.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_12 = _sfc_main$1;
const _sfc_main = {
  __name: "TourPackage",
  __ssrInlineRender: true,
  props: { tourPackage: { type: [Array, Object] } },
  async setup(__props) {
    let __temp, __restore;
    const props = __props;
    const { tourPackageSchema, tourPackageSchemaEdit } = useSchema();
    const { requestOptions } = useRequestOptions();
    useRoute();
    const {
      dataForm,
      onSubmit,
      message,
      alertType,
      loading,
      existingImage,
      selectedTourPackage
    } = useTourPackage({ callback: redirect });
    const router = useRouter();
    const statusActive = ref();
    const isVaried = computed(() => {
      return dataForm.value.is_varied;
    });
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "locations",
      () => $fetch(`/admins/locations-all`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    function funcGetIdLocation(ids) {
      dataForm.value.locations = Array.isArray(ids) ? ids : [ids];
    }
    function funcGetIdStatus(data2) {
      dataForm.value.is_active = data2;
    }
    function redirect() {
      router.push("/admin/tour-package");
    }
    const dataDropdown = ref([
      {
        id: 1,
        name: "Tersedia",
        value: 1
      },
      {
        id: 2,
        name: "Tidak Tersedia",
        value: 0
      }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIFormTextFieldWLabel = _sfc_main$5;
      const _component_UIFormInputNumber = _sfc_main$2$1;
      const _component_UIFormDropdownOnlyTwo = __nuxt_component_6;
      const _component_UIFormDropdownsTest = __nuxt_component_7;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_TabContent = _sfc_main$1$1;
      const _component_TabItem = _sfc_main$6;
      const _component_UIFormGroup = _sfc_main$7;
      const _component_UIFormSpTextarea = _sfc_main$4;
      const _component_UIFormEditor = __nuxt_component_10;
      const _component_VeeField = Field;
      const _component_UIFormTurVariant = __nuxt_component_12;
      const _component_NuxtLink = __nuxt_component_0$1;
      let _temp0;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        "validation-schema": props.tourPackage ? unref(tourPackageSchemaEdit) : unref(tourPackageSchema),
        onSubmit: unref(onSubmit)
      }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          var _a2, _b2;
          var _a, _b, _c, _d;
          if (_push2) {
            _push2(`<div class="border shadow-sm rounded-[8px] py-6 px-5 mb-6"${_scopeId}><p class="text-black font-semibold text-[16px]"${_scopeId}>General</p><div class="grid grid-cols-1 md:grid-cols-2 mt-1 gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormTextFieldWLabel, {
              label: "Nama paket",
              name: "name",
              placeholder: "Input paket",
              modelValue: unref(dataForm).name,
              "onUpdate:modelValue": ($event) => unref(dataForm).name = $event,
              class: "input-bordered shadow-sm focus:outline-none",
              useStarIcon: false
            }, null, _parent2, _scopeId));
            if (props.tourPackage) {
              _push2(ssrRenderComponent(_component_UIFormTextFieldWLabel, {
                label: "Harga",
                name: "price",
                placeholder: "Harga",
                modelValue: unref(dataForm).price,
                "onUpdate:modelValue": ($event) => unref(dataForm).price = $event,
                class: "input-bordered shadow-sm focus:outline-none",
                useStarIcon: false,
                disabled: unref(isVaried) === true || unref(isVaried) === 1
              }, null, _parent2, _scopeId));
            } else if (!props.tourPackage) {
              _push2(ssrRenderComponent(_component_UIFormInputNumber, {
                label: "Harga",
                name: "price",
                placeholder: "Harga",
                modelValue: unref(dataForm).price,
                "onUpdate:modelValue": ($event) => unref(dataForm).price = $event,
                class: "input-bordered shadow-sm focus:outline-none",
                useStarIcon: false
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(ssrRenderComponent(_component_UIFormInputNumber, {
              label: "Max person",
              name: "max_person",
              placeholder: "Max person",
              modelValue: unref(dataForm).max_person,
              "onUpdate:modelValue": ($event) => unref(dataForm).max_person = $event,
              class: "input-bordered shadow-sm focus:outline-none",
              useStarIcon: false
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormDropdownOnlyTwo, {
              label: "Status Active",
              name: "is_active",
              placeholder: "Status Active",
              onGetId: funcGetIdStatus,
              modelValue: unref(statusActive),
              "onUpdate:modelValue": ($event) => isRef(statusActive) ? statusActive.value = $event : null,
              dataDropdown: unref(dataDropdown),
              class: "input-bordered shadow-sm focus:outline-none",
              useStarIcon: false
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormDropdownsTest, {
              label: "Locations",
              name: "locations",
              placeholder: "Locations",
              class: "mt-1",
              dataDropdown: (_a = unref(data)) == null ? void 0 : _a.data,
              modelValue: unref(dataForm).locations,
              "onUpdate:modelValue": ($event) => unref(dataForm).locations = $event,
              dataSelected: (_a2 = (_b = props.tourPackage) == null ? void 0 : _b.locations) != null ? _a2 : [],
              onGetId: funcGetIdLocation
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "locations",
              class: "form-error-message"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_TabContent, null, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_TabItem, {
                    name: "EN",
                    group: "meta",
                    checked: "",
                    "is-error": !!errors["meta[en]"]
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormGroup, {
                          label: "Meta Description",
                          name: "meta[en]"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_UIFormSpTextarea, {
                                name: "meta[en]",
                                modelValue: unref(dataForm)["meta[en]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["meta[en]"] = $event,
                                class: "select-bordered",
                                placeholder: "e.g. My Blog Description"
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_UIFormSpTextarea, {
                                  name: "meta[en]",
                                  modelValue: unref(dataForm)["meta[en]"],
                                  "onUpdate:modelValue": ($event) => unref(dataForm)["meta[en]"] = $event,
                                  class: "select-bordered",
                                  placeholder: "e.g. My Blog Description"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormGroup, {
                            label: "Meta Description",
                            name: "meta[en]"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_UIFormSpTextarea, {
                                name: "meta[en]",
                                modelValue: unref(dataForm)["meta[en]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["meta[en]"] = $event,
                                class: "select-bordered",
                                placeholder: "e.g. My Blog Description"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_TabItem, {
                    name: "ID",
                    group: "meta",
                    "is-error": !!errors["meta[id]"]
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormGroup, {
                          label: "(ID) Meta Description",
                          name: "meta"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_UIFormSpTextarea, {
                                name: "meta[id]",
                                modelValue: unref(dataForm)["meta[id]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["meta[id]"] = $event,
                                class: "select-bordered",
                                placeholder: "e.g. My Blog Description"
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_UIFormSpTextarea, {
                                  name: "meta[id]",
                                  modelValue: unref(dataForm)["meta[id]"],
                                  "onUpdate:modelValue": ($event) => unref(dataForm)["meta[id]"] = $event,
                                  class: "select-bordered",
                                  placeholder: "e.g. My Blog Description"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormGroup, {
                            label: "(ID) Meta Description",
                            name: "meta"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_UIFormSpTextarea, {
                                name: "meta[id]",
                                modelValue: unref(dataForm)["meta[id]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["meta[id]"] = $event,
                                class: "select-bordered",
                                placeholder: "e.g. My Blog Description"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_TabItem, {
                      name: "EN",
                      group: "meta",
                      checked: "",
                      "is-error": !!errors["meta[en]"]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormGroup, {
                          label: "Meta Description",
                          name: "meta[en]"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_UIFormSpTextarea, {
                              name: "meta[en]",
                              modelValue: unref(dataForm)["meta[en]"],
                              "onUpdate:modelValue": ($event) => unref(dataForm)["meta[en]"] = $event,
                              class: "select-bordered",
                              placeholder: "e.g. My Blog Description"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 2
                    }, 1032, ["is-error"]),
                    createVNode(_component_TabItem, {
                      name: "ID",
                      group: "meta",
                      "is-error": !!errors["meta[id]"]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormGroup, {
                          label: "(ID) Meta Description",
                          name: "meta"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_UIFormSpTextarea, {
                              name: "meta[id]",
                              modelValue: unref(dataForm)["meta[id]"],
                              "onUpdate:modelValue": ($event) => unref(dataForm)["meta[id]"] = $event,
                              class: "select-bordered",
                              placeholder: "e.g. My Blog Description"
                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                          ]),
                          _: 1
                        })
                      ]),
                      _: 2
                    }, 1032, ["is-error"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div></div><div class="border shadow-sm rounded-[8px] py-6 px-5"${_scopeId}><p class="text-black font-semibold text-[16px] mb-3"${_scopeId}>Ringkasan</p>`);
            _push2(ssrRenderComponent(_component_TabContent, null, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_TabItem, {
                    name: "EN",
                    group: "description",
                    checked: "",
                    "is-error": !!errors["description[en]"]
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormGroup, {
                          label: "Ringkasan English",
                          name: "description[en]"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_UIFormEditor, {
                                modelValue: unref(dataForm)["description[en]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["description[en]"] = $event,
                                "is-errors": !!errors.description
                              }, null, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(_component_VeeErrorMessage, {
                                name: "description[en]",
                                class: "form-error-message"
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_UIFormEditor, {
                                  modelValue: unref(dataForm)["description[en]"],
                                  "onUpdate:modelValue": ($event) => unref(dataForm)["description[en]"] = $event,
                                  "is-errors": !!errors.description
                                }, null, 8, ["modelValue", "onUpdate:modelValue", "is-errors"]),
                                createVNode(_component_VeeErrorMessage, {
                                  name: "description[en]",
                                  class: "form-error-message"
                                })
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormGroup, {
                            label: "Ringkasan English",
                            name: "description[en]"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_UIFormEditor, {
                                modelValue: unref(dataForm)["description[en]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["description[en]"] = $event,
                                "is-errors": !!errors.description
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "is-errors"]),
                              createVNode(_component_VeeErrorMessage, {
                                name: "description[en]",
                                class: "form-error-message"
                              })
                            ]),
                            _: 2
                          }, 1024)
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_TabItem, {
                    name: "ID",
                    group: "description",
                    "is-error": !!errors["description[id]"]
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormGroup, {
                          label: "Ringkasan Indonesia",
                          name: "description_id"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_UIFormEditor, {
                                modelValue: unref(dataForm)["description[id]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["description[id]"] = $event,
                                "is-errors": !!(errors == null ? void 0 : errors["description[id]"])
                              }, null, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(_component_VeeErrorMessage, {
                                name: "description_id",
                                class: "form-error-message"
                              }, null, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_UIFormEditor, {
                                  modelValue: unref(dataForm)["description[id]"],
                                  "onUpdate:modelValue": ($event) => unref(dataForm)["description[id]"] = $event,
                                  "is-errors": !!(errors == null ? void 0 : errors["description[id]"])
                                }, null, 8, ["modelValue", "onUpdate:modelValue", "is-errors"]),
                                createVNode(_component_VeeErrorMessage, {
                                  name: "description_id",
                                  class: "form-error-message"
                                })
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormGroup, {
                            label: "Ringkasan Indonesia",
                            name: "description_id"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_UIFormEditor, {
                                modelValue: unref(dataForm)["description[id]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["description[id]"] = $event,
                                "is-errors": !!(errors == null ? void 0 : errors["description[id]"])
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "is-errors"]),
                              createVNode(_component_VeeErrorMessage, {
                                name: "description_id",
                                class: "form-error-message"
                              })
                            ]),
                            _: 2
                          }, 1024)
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_TabItem, {
                      name: "EN",
                      group: "description",
                      checked: "",
                      "is-error": !!errors["description[en]"]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormGroup, {
                          label: "Ringkasan English",
                          name: "description[en]"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_UIFormEditor, {
                              modelValue: unref(dataForm)["description[en]"],
                              "onUpdate:modelValue": ($event) => unref(dataForm)["description[en]"] = $event,
                              "is-errors": !!errors.description
                            }, null, 8, ["modelValue", "onUpdate:modelValue", "is-errors"]),
                            createVNode(_component_VeeErrorMessage, {
                              name: "description[en]",
                              class: "form-error-message"
                            })
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1032, ["is-error"]),
                    createVNode(_component_TabItem, {
                      name: "ID",
                      group: "description",
                      "is-error": !!errors["description[id]"]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormGroup, {
                          label: "Ringkasan Indonesia",
                          name: "description_id"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_UIFormEditor, {
                              modelValue: unref(dataForm)["description[id]"],
                              "onUpdate:modelValue": ($event) => unref(dataForm)["description[id]"] = $event,
                              "is-errors": !!(errors == null ? void 0 : errors["description[id]"])
                            }, null, 8, ["modelValue", "onUpdate:modelValue", "is-errors"]),
                            createVNode(_component_VeeErrorMessage, {
                              name: "description_id",
                              class: "form-error-message"
                            })
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1032, ["is-error"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              name: "description[en]",
              modelValue: unref(dataForm)["description[en]"],
              "onUpdate:modelValue": ($event) => unref(dataForm)["description[en]"] = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeField, {
              name: "description[id]",
              modelValue: unref(dataForm)["description[id]"],
              "onUpdate:modelValue": ($event) => unref(dataForm)["description[id]"] = $event
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              name: "meta[en]",
              modelValue: unref(dataForm)["meta[en]"],
              "onUpdate:modelValue": ($event) => unref(dataForm)["meta[en]"] = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeField, {
              name: "meta[id]",
              modelValue: unref(dataForm)["meta[id]"],
              "onUpdate:modelValue": ($event) => unref(dataForm)["meta[id]"] = $event
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="form-control max-w-max mt-3"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              name: "is_varied",
              value: unref(dataForm).is_varied
            }, {
              default: withCtx(({ field }, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<label class="label cursor-pointer"${_scopeId2}><input${ssrRenderAttrs((_temp0 = mergeProps({
                    type: "checkbox",
                    class: "toggle toggle-primary"
                  }, field, {
                    checked: ssrLooseEqual(unref(dataForm).is_varied, 1),
                    "true-value": 1,
                    "false-value": 0
                  }), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, unref(dataForm).is_varied))))}${_scopeId2}><span class="label-text ml-2"${_scopeId2}>Varied</span></label>`);
                } else {
                  return [
                    createVNode("label", { class: "label cursor-pointer" }, [
                      withDirectives(createVNode("input", mergeProps({
                        type: "checkbox",
                        class: "toggle toggle-primary"
                      }, field, {
                        "onUpdate:modelValue": ($event) => unref(dataForm).is_varied = $event,
                        "true-value": 1,
                        "false-value": 0
                      }), null, 16, ["onUpdate:modelValue"]), [
                        [vModelCheckbox, unref(dataForm).is_varied]
                      ]),
                      createVNode("span", { class: "label-text ml-2" }, "Varied")
                    ])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div><div class=""${_scopeId}>`);
            if (unref(isVaried)) {
              _push2(ssrRenderComponent(_component_UIFormTurVariant, {
                modelValue: unref(dataForm).variants,
                "onUpdate:modelValue": ($event) => unref(dataForm).variants = $event,
                locations: props.locations,
                errors
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="flex items-center justify-between mt-6"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, {
              to: "/admin/transport",
              class: "btn bg-transparent border border-red-600 text-red-500"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Batalkan `);
                } else {
                  return [
                    createTextVNode(" Batalkan ")
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<button type="submit" class="btn bg-primary text-white normal-case !font-medium text-base hover:bg-primary"${_scopeId}> Simpan paket </button></div>`);
          } else {
            return [
              createVNode("div", { class: "border shadow-sm rounded-[8px] py-6 px-5 mb-6" }, [
                createVNode("p", { class: "text-black font-semibold text-[16px]" }, "General"),
                createVNode("div", { class: "grid grid-cols-1 md:grid-cols-2 mt-1 gap-4" }, [
                  createVNode(_component_UIFormTextFieldWLabel, {
                    label: "Nama paket",
                    name: "name",
                    placeholder: "Input paket",
                    modelValue: unref(dataForm).name,
                    "onUpdate:modelValue": ($event) => unref(dataForm).name = $event,
                    class: "input-bordered shadow-sm focus:outline-none",
                    useStarIcon: false
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  props.tourPackage ? (openBlock(), createBlock(_component_UIFormTextFieldWLabel, {
                    key: 0,
                    label: "Harga",
                    name: "price",
                    placeholder: "Harga",
                    modelValue: unref(dataForm).price,
                    "onUpdate:modelValue": ($event) => unref(dataForm).price = $event,
                    class: "input-bordered shadow-sm focus:outline-none",
                    useStarIcon: false,
                    disabled: unref(isVaried) === true || unref(isVaried) === 1
                  }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled"])) : !props.tourPackage ? (openBlock(), createBlock(_component_UIFormInputNumber, {
                    key: 1,
                    label: "Harga",
                    name: "price",
                    placeholder: "Harga",
                    modelValue: unref(dataForm).price,
                    "onUpdate:modelValue": ($event) => unref(dataForm).price = $event,
                    class: "input-bordered shadow-sm focus:outline-none",
                    useStarIcon: false
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])) : createCommentVNode("", true),
                  createVNode(_component_UIFormInputNumber, {
                    label: "Max person",
                    name: "max_person",
                    placeholder: "Max person",
                    modelValue: unref(dataForm).max_person,
                    "onUpdate:modelValue": ($event) => unref(dataForm).max_person = $event,
                    class: "input-bordered shadow-sm focus:outline-none",
                    useStarIcon: false
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode(_component_UIFormDropdownOnlyTwo, {
                    label: "Status Active",
                    name: "is_active",
                    placeholder: "Status Active",
                    onGetId: funcGetIdStatus,
                    modelValue: unref(statusActive),
                    "onUpdate:modelValue": ($event) => isRef(statusActive) ? statusActive.value = $event : null,
                    dataDropdown: unref(dataDropdown),
                    class: "input-bordered shadow-sm focus:outline-none",
                    useStarIcon: false
                  }, null, 8, ["modelValue", "onUpdate:modelValue", "dataDropdown"]),
                  createVNode(_component_UIFormDropdownsTest, {
                    label: "Locations",
                    name: "locations",
                    placeholder: "Locations",
                    class: "mt-1",
                    dataDropdown: (_c = unref(data)) == null ? void 0 : _c.data,
                    modelValue: unref(dataForm).locations,
                    "onUpdate:modelValue": ($event) => unref(dataForm).locations = $event,
                    dataSelected: (_b2 = (_d = props.tourPackage) == null ? void 0 : _d.locations) != null ? _b2 : [],
                    onGetId: funcGetIdLocation
                  }, null, 8, ["dataDropdown", "modelValue", "onUpdate:modelValue", "dataSelected"]),
                  createVNode(_component_VeeErrorMessage, {
                    name: "locations",
                    class: "form-error-message"
                  }),
                  createVNode(_component_TabContent, null, {
                    default: withCtx(() => [
                      createVNode(_component_TabItem, {
                        name: "EN",
                        group: "meta",
                        checked: "",
                        "is-error": !!errors["meta[en]"]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_UIFormGroup, {
                            label: "Meta Description",
                            name: "meta[en]"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_UIFormSpTextarea, {
                                name: "meta[en]",
                                modelValue: unref(dataForm)["meta[en]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["meta[en]"] = $event,
                                class: "select-bordered",
                                placeholder: "e.g. My Blog Description"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 2
                      }, 1032, ["is-error"]),
                      createVNode(_component_TabItem, {
                        name: "ID",
                        group: "meta",
                        "is-error": !!errors["meta[id]"]
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_UIFormGroup, {
                            label: "(ID) Meta Description",
                            name: "meta"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_UIFormSpTextarea, {
                                name: "meta[id]",
                                modelValue: unref(dataForm)["meta[id]"],
                                "onUpdate:modelValue": ($event) => unref(dataForm)["meta[id]"] = $event,
                                class: "select-bordered",
                                placeholder: "e.g. My Blog Description"
                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                            ]),
                            _: 1
                          })
                        ]),
                        _: 2
                      }, 1032, ["is-error"])
                    ]),
                    _: 2
                  }, 1024)
                ])
              ]),
              createVNode("div", { class: "border shadow-sm rounded-[8px] py-6 px-5" }, [
                createVNode("p", { class: "text-black font-semibold text-[16px] mb-3" }, "Ringkasan"),
                createVNode(_component_TabContent, null, {
                  default: withCtx(() => [
                    createVNode(_component_TabItem, {
                      name: "EN",
                      group: "description",
                      checked: "",
                      "is-error": !!errors["description[en]"]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormGroup, {
                          label: "Ringkasan English",
                          name: "description[en]"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_UIFormEditor, {
                              modelValue: unref(dataForm)["description[en]"],
                              "onUpdate:modelValue": ($event) => unref(dataForm)["description[en]"] = $event,
                              "is-errors": !!errors.description
                            }, null, 8, ["modelValue", "onUpdate:modelValue", "is-errors"]),
                            createVNode(_component_VeeErrorMessage, {
                              name: "description[en]",
                              class: "form-error-message"
                            })
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1032, ["is-error"]),
                    createVNode(_component_TabItem, {
                      name: "ID",
                      group: "description",
                      "is-error": !!errors["description[id]"]
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormGroup, {
                          label: "Ringkasan Indonesia",
                          name: "description_id"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_UIFormEditor, {
                              modelValue: unref(dataForm)["description[id]"],
                              "onUpdate:modelValue": ($event) => unref(dataForm)["description[id]"] = $event,
                              "is-errors": !!(errors == null ? void 0 : errors["description[id]"])
                            }, null, 8, ["modelValue", "onUpdate:modelValue", "is-errors"]),
                            createVNode(_component_VeeErrorMessage, {
                              name: "description_id",
                              class: "form-error-message"
                            })
                          ]),
                          _: 2
                        }, 1024)
                      ]),
                      _: 2
                    }, 1032, ["is-error"])
                  ]),
                  _: 2
                }, 1024),
                createVNode("div", { class: "hidden" }, [
                  createVNode(_component_VeeField, {
                    name: "description[en]",
                    modelValue: unref(dataForm)["description[en]"],
                    "onUpdate:modelValue": ($event) => unref(dataForm)["description[en]"] = $event
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode(_component_VeeField, {
                    name: "description[id]",
                    modelValue: unref(dataForm)["description[id]"],
                    "onUpdate:modelValue": ($event) => unref(dataForm)["description[id]"] = $event
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ])
              ]),
              createVNode("div", { class: "hidden" }, [
                createVNode(_component_VeeField, {
                  name: "meta[en]",
                  modelValue: unref(dataForm)["meta[en]"],
                  "onUpdate:modelValue": ($event) => unref(dataForm)["meta[en]"] = $event
                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode(_component_VeeField, {
                  name: "meta[id]",
                  modelValue: unref(dataForm)["meta[id]"],
                  "onUpdate:modelValue": ($event) => unref(dataForm)["meta[id]"] = $event
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "form-control max-w-max mt-3" }, [
                createVNode(_component_VeeField, {
                  name: "is_varied",
                  value: unref(dataForm).is_varied
                }, {
                  default: withCtx(({ field }) => [
                    createVNode("label", { class: "label cursor-pointer" }, [
                      withDirectives(createVNode("input", mergeProps({
                        type: "checkbox",
                        class: "toggle toggle-primary"
                      }, field, {
                        "onUpdate:modelValue": ($event) => unref(dataForm).is_varied = $event,
                        "true-value": 1,
                        "false-value": 0
                      }), null, 16, ["onUpdate:modelValue"]), [
                        [vModelCheckbox, unref(dataForm).is_varied]
                      ]),
                      createVNode("span", { class: "label-text ml-2" }, "Varied")
                    ])
                  ]),
                  _: 1
                }, 8, ["value"])
              ]),
              createVNode("div", { class: "" }, [
                unref(isVaried) ? (openBlock(), createBlock(_component_UIFormTurVariant, {
                  key: 0,
                  modelValue: unref(dataForm).variants,
                  "onUpdate:modelValue": ($event) => unref(dataForm).variants = $event,
                  locations: props.locations,
                  errors
                }, null, 8, ["modelValue", "onUpdate:modelValue", "locations", "errors"])) : createCommentVNode("", true)
              ]),
              createVNode("div", { class: "flex items-center justify-between mt-6" }, [
                createVNode(_component_NuxtLink, {
                  to: "/admin/transport",
                  class: "btn bg-transparent border border-red-600 text-red-500"
                }, {
                  default: withCtx(() => [
                    createTextVNode(" Batalkan ")
                  ]),
                  _: 1
                }),
                createVNode("button", {
                  type: "submit",
                  class: "btn bg-primary text-white normal-case !font-medium text-base hover:bg-primary"
                }, " Simpan paket ")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/TourPackage.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main;

export { __nuxt_component_1 as _ };
//# sourceMappingURL=TourPackage-23f79ab2.mjs.map
