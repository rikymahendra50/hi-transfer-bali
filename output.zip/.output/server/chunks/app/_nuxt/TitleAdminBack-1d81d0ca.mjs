import { j as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_1 from './Icon-f8c4e628.mjs';
import { useSSRContext, mergeProps, withCtx, createVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';

const _sfc_main = {
  __name: "TitleAdminBack",
  __ssrInlineRender: true,
  props: {
    title: { type: String },
    subTitle: {
      type: String
    },
    link: {
      type: String
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex items-center justify-between border-b mx-3" }, _attrs))}><div class="flex items-center gap-3">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: __props.link }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Icon, {
              name: "mingcute:arrow-left-fill",
              class: "text-black w-5 h-5"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Icon, {
                name: "mingcute:arrow-left-fill",
                class: "text-black w-5 h-5"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="flex flex-col gap-1"><p class="text-[#121212] text-[18px] font-semibold text-lg md:text-xl">${ssrInterpolate(__props.title)}</p><p class="text-[14px] text-gray-500">${ssrInterpolate(__props.subTitle)}</p></div></div><div class="flex flex-col md:flex-row gap-4 md:gap-0 md:justify-between px-5 items-end md:items-center py-6 md:py-4"><div class="">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TitleAdminBack.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=TitleAdminBack-1d81d0ca.mjs.map
