import { e as useI18n, _ as __nuxt_component_0$1 } from '../server.mjs';
import { useSSRContext, computed, mergeProps, withCtx, unref, createVNode, toDisplayString } from 'vue';
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "Card",
  __ssrInlineRender: true,
  props: {
    name: { type: String },
    slug: { type: String },
    description: { type: [String, Array] },
    image: { type: String },
    price: { type: [String, Number] }
  },
  setup(__props) {
    const props = __props;
    const { locale, t: $t } = useI18n();
    const result = computed(() => {
      return props.description.map((item) => item.name).join(" - ");
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(ssrRenderComponent(_component_NuxtLink, mergeProps({
        to: __props.slug,
        class: "overflow-hidden rounded-xl space-y-2 border border-zinc-200 shadow-sm group"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div class="h-[300px] overflow-hidden"${_scopeId}><img${ssrRenderAttr("src", (_a = props.image) != null ? _a : "https://placehold.co/150")}${ssrRenderAttr("alt", __props.image)} class="h-[300px] w-full object-cover group-hover:scale-125 transition-all duration-300"${_scopeId}></div><div class="p-3 space-y-4"${_scopeId}><div${_scopeId}><h4 class="text-xl font-semibold text-primary-dark"${_scopeId}>${ssrInterpolate(__props.name)}</h4><div class="text-zinc-400 text-sm line-clamp-2"${_scopeId}>${ssrInterpolate(unref(result))}</div></div><div${_scopeId}><div class="text-zinc-400 text-xs"${_scopeId}>${ssrInterpolate(unref($t)("harga-mulai-dari"))}</div><h4 class="text-xl font-semibold text-primary"${_scopeId}> Rp. ${ssrInterpolate(__props.price)} /${ssrInterpolate(unref($t)("orang"))}</h4></div></div>`);
          } else {
            return [
              createVNode("div", { class: "h-[300px] overflow-hidden" }, [
                createVNode("img", {
                  src: (_b = props.image) != null ? _b : "https://placehold.co/150",
                  alt: __props.image,
                  class: "h-[300px] w-full object-cover group-hover:scale-125 transition-all duration-300"
                }, null, 8, ["src", "alt"])
              ]),
              createVNode("div", { class: "p-3 space-y-4" }, [
                createVNode("div", null, [
                  createVNode("h4", { class: "text-xl font-semibold text-primary-dark" }, toDisplayString(__props.name), 1),
                  createVNode("div", { class: "text-zinc-400 text-sm line-clamp-2" }, toDisplayString(unref(result)), 1)
                ]),
                createVNode("div", null, [
                  createVNode("div", { class: "text-zinc-400 text-xs" }, toDisplayString(unref($t)("harga-mulai-dari")), 1),
                  createVNode("h4", { class: "text-xl font-semibold text-primary" }, " Rp. " + toDisplayString(__props.price) + " /" + toDisplayString(unref($t)("orang")), 1)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/Card.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main;

export { __nuxt_component_2 as _ };
//# sourceMappingURL=Card-e8b82c06.mjs.map
