import { _ as __nuxt_component_0 } from './TitleAdmin-130db81a.mjs';
import { u as useRequestHelper, a as useRequestOptions, b as useRouter, d as useRoute, e as useI18n, f as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import { mergeProps, withCtx, createTextVNode, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useRequestHelper();
    useRequestOptions();
    useRouter();
    useRoute();
    useI18n();
    useHead({
      title: "Admin list"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TitleAdmin = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_TitleAdmin, {
        title: "Daftar Admin",
        subTitle: "Kelola daftar admin "
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_NuxtLink, {
              to: "/admin/admin-list/add",
              class: "border-2 py-4 px-6 rounded-[8px] shadow-xs font-medium text-black"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Tambah Admin baru `);
                } else {
                  return [
                    createTextVNode(" Tambah Admin baru ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_NuxtLink, {
                to: "/admin/admin-list/add",
                class: "border-2 py-4 px-6 rounded-[8px] shadow-xs font-medium text-black"
              }, {
                default: withCtx(() => [
                  createTextVNode(" Tambah Admin baru ")
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/admin-list/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-b4f084db.mjs.map
