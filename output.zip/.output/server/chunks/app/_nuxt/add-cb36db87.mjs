import { _ as __nuxt_component_0 } from './TitleBack-aa5a1267.mjs';
import { _ as __nuxt_component_1 } from './Destinations-486ec13e.mjs';
import { h as useRequestHelper, e as useRequestOptions, b as useRouter, d as useRoute, a as useHead } from '../server.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './Icon-0f6314e3.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'vee-validate';
import './TextFieldWLabel-0de16bf1.mjs';
import './useSchema-0246d9f0.mjs';
import 'zod';
import '@vee-validate/zod';
import './useDestinations-bb31ad70.mjs';
import './nofication-1c3cca5e.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "add",
  __ssrInlineRender: true,
  setup(__props) {
    useRequestHelper();
    useRequestOptions();
    useRouter();
    useRoute();
    useHead({
      title: "Add Destinasi"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TitleBack = __nuxt_component_0;
      const _component_UIFormDestinations = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "px-5 py-6 md:px-10 md:py-10" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_TitleBack, {
        link: "/admin/destinations",
        title: "Tambah Destinasi Baru"
      }, null, _parent));
      _push(ssrRenderComponent(_component_UIFormDestinations, { buttonTitle: "Tambah destinasi" }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/destinations/add.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=add-cb36db87.mjs.map
