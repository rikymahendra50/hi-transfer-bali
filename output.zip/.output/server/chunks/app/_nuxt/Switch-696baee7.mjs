import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { f as useI18n } from '../server.mjs';
import { defineComponent, computed, resolveComponent, withCtx, createVNode, unref, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';

const _imports_0 = "" + publicAssetsURL("united-kingdom.png");
const _imports_1 = "" + publicAssetsURL("indonesia.png");
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Switch",
  __ssrInlineRender: true,
  setup(__props) {
    const { setLocale, locale } = useI18n();
    function changeLocale(lang) {
      setLocale(lang);
      window.location.reload();
    }
    const language = computed(() => {
      if (locale.value == "id") {
        return {
          image: "/indonesia.png",
          label: "Indonesia"
        };
      }
      return {
        image: "/united-kingdom.png",
        label: "English"
      };
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VDropdown = resolveComponent("VDropdown");
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_VDropdown, null, {
        popper: withCtx(({ hide }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="p-2"${_scopeId}><ul class="flex flex-col space-y-2"${_scopeId}><li class="py-2 inline-flex space-x-3 cursor-pointer hover:outline-zinc-300 hover:border-zinc-200 hover:rounded-md px-3 hover:bg-primary hover:text-white"${_scopeId}><img${ssrRenderAttr("src", _imports_0)} alt="english" class="w-5 h-5"${_scopeId}><div${_scopeId}>English</div></li><li class="py-2 inline-flex space-x-3 cursor-pointer hover:outline-zinc-300 hover:border-zinc-200 hover:bg-primary hover:text-white hover:rounded-md px-3"${_scopeId}><img${ssrRenderAttr("src", _imports_1)} alt="indonesia" class="w-5 h-5"${_scopeId}><div${_scopeId}>Indonesia</div></li></ul></div>`);
          } else {
            return [
              createVNode("div", { class: "p-2" }, [
                createVNode("ul", { class: "flex flex-col space-y-2" }, [
                  createVNode("li", {
                    onClick: ($event) => (hide(), changeLocale("en")),
                    class: "py-2 inline-flex space-x-3 cursor-pointer hover:outline-zinc-300 hover:border-zinc-200 hover:rounded-md px-3 hover:bg-primary hover:text-white"
                  }, [
                    createVNode("img", {
                      src: _imports_0,
                      alt: "english",
                      class: "w-5 h-5"
                    }),
                    createVNode("div", null, "English")
                  ], 8, ["onClick"]),
                  createVNode("li", {
                    onClick: ($event) => (hide(), changeLocale("id")),
                    class: "py-2 inline-flex space-x-3 cursor-pointer hover:outline-zinc-300 hover:border-zinc-200 hover:bg-primary hover:text-white hover:rounded-md px-3"
                  }, [
                    createVNode("img", {
                      src: _imports_1,
                      alt: "indonesia",
                      class: "w-5 h-5"
                    }),
                    createVNode("div", null, "Indonesia")
                  ], 8, ["onClick"])
                ])
              ])
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<button class="btn btn-outline border-zinc-300 hover:bg-transparent hover:outline-zinc-300 group hover:border-primary"${_scopeId}><img${ssrRenderAttr("src", unref(language).image)}${ssrRenderAttr("alt", unref(language).label)} class="w-5 h-5"${_scopeId}><div class="group-hover:text-primary"${_scopeId}>${ssrInterpolate(unref(language).label)}</div></button>`);
          } else {
            return [
              createVNode("button", { class: "btn btn-outline border-zinc-300 hover:bg-transparent hover:outline-zinc-300 group hover:border-primary" }, [
                createVNode("img", {
                  src: unref(language).image,
                  alt: unref(language).label,
                  class: "w-5 h-5"
                }, null, 8, ["src", "alt"]),
                createVNode("div", { class: "group-hover:text-primary" }, toDisplayString(unref(language).label), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Language/Switch.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=Switch-696baee7.mjs.map
