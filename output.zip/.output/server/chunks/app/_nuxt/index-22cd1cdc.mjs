import { _ as __nuxt_component_0 } from './TitleAdmin-130db81a.mjs';
import { _ as __nuxt_component_2 } from './PaginationAdmin-f2cea012.mjs';
import { u as useRequestHelper, a as useRequestOptions, b as useRouter, d as useRoute, f as useHead, g as useAsyncData } from '../server.mjs';
import { ref, withAsyncContext, unref, isRef, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    useRouter();
    useRoute();
    useHead({
      title: "Destinasi"
    });
    const page = ref(1);
    ref(false);
    ref(void 0);
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "users",
      () => $fetch(`/admins/users?page=${page.value}`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
      const _component_TitleAdmin = __nuxt_component_0;
      const _component_PaginationAdmin = __nuxt_component_2;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_TitleAdmin, {
        title: "Pengguna",
        subTitle: "Kelola daftar pengguna Anda disini"
      }, null, _parent));
      _push(`<table class="table"><thead><tr><th><div class="text-[#989393]">Full Name</div></th><th><div>Email</div></th><th><div>Phone Number</div></th><th><div>Status</div></th><th></th></tr></thead><tbody><!--[-->`);
      ssrRenderList((_a = unref(data)) == null ? void 0 : _a.data, (item) => {
        _push(`<tr><td class="text-sm font-normal"><div class="font-medium text-[14px] text-black">${ssrInterpolate(item.first_name)} ${ssrInterpolate(item.last_name)}</div></td><td class="text-sm font-normal text-[#989393]">${ssrInterpolate(item.email)}</td><td class="text-sm font-normal text-[#989393]"><div class="px-3 py-1 w-fit rounded-xl">${ssrInterpolate(item.phone)}</div></td><td><div>${ssrInterpolate(item.is_active === 1 ? "Aktif" : "Tidak Aktif")}</div></td><td><div class="flex items-center"></div></td></tr>`);
      });
      _push(`<!--]--></tbody></table><div class="flex flex-col md:flex-row items-center justify-between gap-3 w-full py-3 px-3"><div class="flex items-center gap-3"><div class="py-2 px-3 rounded-[8px]"><p class="font-medium text-[12px] md:text-sm text-[#121212]">${ssrInterpolate((_c = (_b = unref(data)) == null ? void 0 : _b.meta) == null ? void 0 : _c.from)} - ${ssrInterpolate((_e = (_d = unref(data)) == null ? void 0 : _d.meta) == null ? void 0 : _e.to)} of ${ssrInterpolate((_g = (_f = unref(data)) == null ? void 0 : _f.meta) == null ? void 0 : _g.total)} Pengguna </p></div></div><div class="font-medium text-[14px] text-[#344054] flex items-center gap-3">`);
      _push(ssrRenderComponent(_component_PaginationAdmin, {
        modelValue: unref(page),
        "onUpdate:modelValue": ($event) => isRef(page) ? page.value = $event : null,
        total: (_i = (_h = unref(data)) == null ? void 0 : _h.meta) == null ? void 0 : _i.total,
        includeFirstLast: false,
        "per-page": (_k = (_j = unref(data)) == null ? void 0 : _j.meta) == null ? void 0 : _k.per_page,
        class: "flex justify-center"
      }, null, _parent));
      _push(`</div></div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/users/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-22cd1cdc.mjs.map
