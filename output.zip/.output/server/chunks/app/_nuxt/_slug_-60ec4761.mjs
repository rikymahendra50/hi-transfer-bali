import { _ as __nuxt_component_0 } from './Container-f78810bd.mjs';
import { d as useRoute, e as useRequestOptions, u as useAuth, g as useAsyncData, a as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_1 from './Icon-ab561e52.mjs';
import { _ as __nuxt_component_3 } from './Modal-a6268183.mjs';
import { _ as __nuxt_component_4 } from './Verified-3d6e7b39.mjs';
import { computed, ref, withAsyncContext, withCtx, createVNode, unref, toDisplayString, openBlock, createBlock, createCommentVNode, isRef, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-3cecc2b8.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './index-dea25161.mjs';
import './index-596a8548.mjs';
import 'vee-validate';
import './Alert-f7c32dd8.mjs';
import './TransitionTopToBottom-a8e40871.mjs';
import './InputOTP-bbb2b053.mjs';
import './useSchema-79d12b54.mjs';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    const route = useRoute();
    const slug = computed(() => {
      var _a2;
      return (_a2 = route == null ? void 0 : route.params) == null ? void 0 : _a2.slug;
    });
    const { requestOptions } = useRequestOptions();
    const { $user } = useAuth();
    ref(1);
    const showModalRefund = ref(false);
    ref(void 0);
    const {
      data: carsOrderDetail,
      error: errorCars,
      refresh: refreshCar
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "carsOrderDetail",
      () => {
        var _a2;
        return $fetch(`/users/${(_a2 = $user.value) == null ? void 0 : _a2.uuid}/car-orders/${slug.value}`, {
          headers: {
            Accept: "application/json"
          },
          method: "get",
          ...requestOptions
        });
      }
    )), __temp = await __temp, __restore(), __temp);
    console.log(carsOrderDetail.value, slug.value, (_a = $user.value) == null ? void 0 : _a.uuid);
    function showModalRefundFunc(id) {
      showModalRefund.value = !showModalRefund.value;
    }
    useHead({ title: "Order Summary" });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_1;
      const _component_modal = __nuxt_component_3;
      const _component_Verified = __nuxt_component_4;
      _push(`<!--[--><div class="h-28"></div><div class="w-full border-b">`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R, _S, _T, _U, _V, _W, _X, _Y, _Z, __, _$, _aa, _ba, _ca, _da, _ea, _fa, _ga, _ha, _ia, _ja, _ka, _la, _ma, _na, _oa, _pa, _qa, _ra;
          if (_push2) {
            _push2(`<div class="flex items-center gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, { to: "/user" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_Icon, {
                    name: "formkit:arrowleft",
                    class: "text-black w-7 h-7"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_Icon, {
                      name: "formkit:arrowleft",
                      class: "text-black w-7 h-7"
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="flex flex-col gap-1"${_scopeId}><p class="text-black text-[18px] font-medium"${_scopeId}>${ssrInterpolate(_ctx.$t("ringkasan-pesanan"))}</p><span${_scopeId}>${ssrInterpolate(_ctx.$t("informasi-lengkap-pesanan"))} #${ssrInterpolate((_b = (_a2 = unref(carsOrderDetail)) == null ? void 0 : _a2.data) == null ? void 0 : _b.uuid)}</span></div></div><div class="py-10"${_scopeId}><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("informasi-pelanggan"))}</div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("nama-pelanggan"))}:</p><p${_scopeId}>${ssrInterpolate((_e = (_d = (_c = unref(carsOrderDetail)) == null ? void 0 : _c.data) == null ? void 0 : _d.user) == null ? void 0 : _e.first_name)}\xA0${ssrInterpolate((_h = (_g = (_f = unref(carsOrderDetail)) == null ? void 0 : _f.data) == null ? void 0 : _g.user) == null ? void 0 : _h.last_name)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Email:</p><p${_scopeId}>${ssrInterpolate((_k = (_j = (_i = unref(carsOrderDetail)) == null ? void 0 : _i.data) == null ? void 0 : _j.user) == null ? void 0 : _k.email)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("nomor-telepon"))}:</p><p${_scopeId}>${ssrInterpolate((_n = (_m = (_l = unref(carsOrderDetail)) == null ? void 0 : _l.data) == null ? void 0 : _m.user) == null ? void 0 : _n.phone)}</p></div></div><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("informasi-pemesanan"))}</div><div class="grid gap-3 md:grid-cols-2"${_scopeId}><div class="flex flex-col gap-1 text-sm"${_scopeId}><p class="text-[#121212] font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("penjeputan"))}</p><p class="font-normal"${_scopeId}>${ssrInterpolate((_p = (_o = unref(carsOrderDetail)) == null ? void 0 : _o.data) == null ? void 0 : _p.details[0].pickup_name)}</p><p class="font-normal text-[#16161697]"${_scopeId}>${ssrInterpolate((_r = (_q = unref(carsOrderDetail)) == null ? void 0 : _q.data) == null ? void 0 : _r.details[0].pickup_address)}</p></div><div class="flex flex-col gap-1 text-sm"${_scopeId}><p class="text-[#121212] font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("pengantaran"))}</p><p class="font-normal"${_scopeId}>${ssrInterpolate((_t = (_s = unref(carsOrderDetail)) == null ? void 0 : _s.data) == null ? void 0 : _t.details[0].destination_name)}</p><p class="font-normal text-[#16161697]"${_scopeId}>${ssrInterpolate((_v = (_u = unref(carsOrderDetail)) == null ? void 0 : _u.data) == null ? void 0 : _v.details[0].destination_address)}</p></div></div></div><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("payment-information"))}</div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("payment-method"))}</p><p${_scopeId}>${ssrInterpolate((_x = (_w = unref(carsOrderDetail)) == null ? void 0 : _w.data) == null ? void 0 : _x.payment_method)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Promo</p><p${_scopeId}>${ssrInterpolate((_z = (_y = unref(carsOrderDetail)) == null ? void 0 : _y.data) == null ? void 0 : _z.promo_amount)}</p></div>`);
            if ((_B = (_A = unref(carsOrderDetail)) == null ? void 0 : _A.data) == null ? void 0 : _B.refund_status) {
              _push2(`<div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Refund status</p><p${_scopeId}>${ssrInterpolate((_D = (_C = unref(carsOrderDetail)) == null ? void 0 : _C.data) == null ? void 0 : _D.refund_status)}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("payment-status"))}</p><p${_scopeId}>${ssrInterpolate((_F = (_E = unref(carsOrderDetail)) == null ? void 0 : _E.data) == null ? void 0 : _F.payment_status)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("total-price"))}</p><p${_scopeId}>Rp.${ssrInterpolate((_H = (_G = unref(carsOrderDetail)) == null ? void 0 : _G.data) == null ? void 0 : _H.total_purchased)}</p></div></div></div><div class="flex items-center justify-end"${_scopeId}>`);
            if (((_J = (_I = unref(carsOrderDetail)) == null ? void 0 : _I.data) == null ? void 0 : _J.payment_status) === "paid") {
              _push2(`<button type="button" class="border-2 shadow-sm rounded-lg py-2 px-4"${_scopeId}><p${_scopeId}>Payment refund</p></button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex items-center gap-4" }, [
                createVNode(_component_NuxtLink, { to: "/user" }, {
                  default: withCtx(() => [
                    createVNode(_component_Icon, {
                      name: "formkit:arrowleft",
                      class: "text-black w-7 h-7"
                    })
                  ]),
                  _: 1
                }),
                createVNode("div", { class: "flex flex-col gap-1" }, [
                  createVNode("p", { class: "text-black text-[18px] font-medium" }, toDisplayString(_ctx.$t("ringkasan-pesanan")), 1),
                  createVNode("span", null, toDisplayString(_ctx.$t("informasi-lengkap-pesanan")) + " #" + toDisplayString((_L = (_K = unref(carsOrderDetail)) == null ? void 0 : _K.data) == null ? void 0 : _L.uuid), 1)
                ])
              ]),
              createVNode("div", { class: "py-10" }, [
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(_ctx.$t("informasi-pelanggan")), 1),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, toDisplayString(_ctx.$t("nama-pelanggan")) + ":", 1),
                    createVNode("p", null, toDisplayString((_O = (_N = (_M = unref(carsOrderDetail)) == null ? void 0 : _M.data) == null ? void 0 : _N.user) == null ? void 0 : _O.first_name) + "\xA0" + toDisplayString((_R = (_Q = (_P = unref(carsOrderDetail)) == null ? void 0 : _P.data) == null ? void 0 : _Q.user) == null ? void 0 : _R.last_name), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, "Email:"),
                    createVNode("p", null, toDisplayString((_U = (_T = (_S = unref(carsOrderDetail)) == null ? void 0 : _S.data) == null ? void 0 : _T.user) == null ? void 0 : _U.email), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(_ctx.$t("nomor-telepon")) + ":", 1),
                    createVNode("p", null, toDisplayString((_X = (_W = (_V = unref(carsOrderDetail)) == null ? void 0 : _V.data) == null ? void 0 : _W.user) == null ? void 0 : _X.phone), 1)
                  ])
                ]),
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(_ctx.$t("informasi-pemesanan")), 1),
                  createVNode("div", { class: "grid gap-3 md:grid-cols-2" }, [
                    createVNode("div", { class: "flex flex-col gap-1 text-sm" }, [
                      createVNode("p", { class: "text-[#121212] font-semibold" }, toDisplayString(_ctx.$t("penjeputan")), 1),
                      createVNode("p", { class: "font-normal" }, toDisplayString((_Z = (_Y = unref(carsOrderDetail)) == null ? void 0 : _Y.data) == null ? void 0 : _Z.details[0].pickup_name), 1),
                      createVNode("p", { class: "font-normal text-[#16161697]" }, toDisplayString((_$ = (__ = unref(carsOrderDetail)) == null ? void 0 : __.data) == null ? void 0 : _$.details[0].pickup_address), 1)
                    ]),
                    createVNode("div", { class: "flex flex-col gap-1 text-sm" }, [
                      createVNode("p", { class: "text-[#121212] font-semibold" }, toDisplayString(_ctx.$t("pengantaran")), 1),
                      createVNode("p", { class: "font-normal" }, toDisplayString((_ba = (_aa = unref(carsOrderDetail)) == null ? void 0 : _aa.data) == null ? void 0 : _ba.details[0].destination_name), 1),
                      createVNode("p", { class: "font-normal text-[#16161697]" }, toDisplayString((_da = (_ca = unref(carsOrderDetail)) == null ? void 0 : _ca.data) == null ? void 0 : _da.details[0].destination_address), 1)
                    ])
                  ])
                ]),
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(_ctx.$t("payment-information")), 1),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, toDisplayString(_ctx.$t("payment-method")), 1),
                    createVNode("p", null, toDisplayString((_fa = (_ea = unref(carsOrderDetail)) == null ? void 0 : _ea.data) == null ? void 0 : _fa.payment_method), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, "Promo"),
                    createVNode("p", null, toDisplayString((_ha = (_ga = unref(carsOrderDetail)) == null ? void 0 : _ga.data) == null ? void 0 : _ha.promo_amount), 1)
                  ]),
                  ((_ja = (_ia = unref(carsOrderDetail)) == null ? void 0 : _ia.data) == null ? void 0 : _ja.refund_status) ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm"
                  }, [
                    createVNode("p", { class: "font-semibold" }, "Refund status"),
                    createVNode("p", null, toDisplayString((_la = (_ka = unref(carsOrderDetail)) == null ? void 0 : _ka.data) == null ? void 0 : _la.refund_status), 1)
                  ])) : createCommentVNode("", true),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(_ctx.$t("payment-status")), 1),
                    createVNode("p", null, toDisplayString((_na = (_ma = unref(carsOrderDetail)) == null ? void 0 : _ma.data) == null ? void 0 : _na.payment_status), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(_ctx.$t("total-price")), 1),
                    createVNode("p", null, "Rp." + toDisplayString((_pa = (_oa = unref(carsOrderDetail)) == null ? void 0 : _oa.data) == null ? void 0 : _pa.total_purchased), 1)
                  ])
                ])
              ]),
              createVNode("div", { class: "flex items-center justify-end" }, [
                ((_ra = (_qa = unref(carsOrderDetail)) == null ? void 0 : _qa.data) == null ? void 0 : _ra.payment_status) === "paid" ? (openBlock(), createBlock("button", {
                  key: 0,
                  type: "button",
                  onClick: ($event) => showModalRefundFunc(),
                  class: "border-2 shadow-sm rounded-lg py-2 px-4"
                }, [
                  createVNode("p", null, "Payment refund")
                ], 8, ["onClick"])) : createCommentVNode("", true)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_modal, {
        modelValue: unref(showModalRefund),
        "onUpdate:modelValue": ($event) => isRef(showModalRefund) ? showModalRefund.value = $event : null,
        class: "relative w-[90%] sm:w-[60%] lg:w-[40%]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex justify-center items-center flex-col px-2 sm:px-4 lg:px-5 overflow-auto"${_scopeId}><div class="flex flex-col gap-3 lg:gap-5 transition h-full"${_scopeId}><p class="font-semibold text-xl"${_scopeId}>${ssrInterpolate(_ctx.$t("pengembalian-pembayaran"))}</p><p class="text-[12px] border-b border-gray-500 pb-3"${_scopeId}>${ssrInterpolate(_ctx.$t("silakan-periksa-kotak-masuk"))}</p></div><div class="w-full"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Verified, null, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex justify-center items-center flex-col px-2 sm:px-4 lg:px-5 overflow-auto" }, [
                createVNode("div", { class: "flex flex-col gap-3 lg:gap-5 transition h-full" }, [
                  createVNode("p", { class: "font-semibold text-xl" }, toDisplayString(_ctx.$t("pengembalian-pembayaran")), 1),
                  createVNode("p", { class: "text-[12px] border-b border-gray-500 pb-3" }, toDisplayString(_ctx.$t("silakan-periksa-kotak-masuk")), 1)
                ]),
                createVNode("div", { class: "w-full" }, [
                  createVNode(_component_Verified)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/order/order-summary/car/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-60ec4761.mjs.map
