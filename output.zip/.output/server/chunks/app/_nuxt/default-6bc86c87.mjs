import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { e as _export_sfc, _ as __nuxt_component_0$1 } from '../server.mjs';
import { _ as _sfc_main$2 } from './Switch-aa6ebe42.mjs';
import { _ as __nuxt_component_0 } from './Container-c0bcb3c6.mjs';
import __nuxt_component_1 from './Icon-7218f0f6.mjs';
import { useSSRContext, defineComponent, mergeProps, withCtx, unref, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, createTextVNode } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _imports_0$1, a as __nuxt_component_3 } from './hi-transfer-logo-b59d4475.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-aab100d3.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';

function useCompanyBase() {
  const contact = [
    {
      title: "Address",
      label: "Jl. Amerta Br. Dinas Kaja , Desa/Kelurahan Busungbiu, Kec. Busungbiu, Kab. Buleleng, Provinsi Bali,Kode Pos: 81154",
      link: "https://maps.app.goo.gl/3XkGAE8Erm2wsdLZA"
    },
    {
      title: "Phone",
      label: "087782660007",
      link: "tel:+6287782660007"
    },
    {
      title: "Email",
      label: "dekpericab@gmail.com",
      link: "mailto:dekpericab@gmail.com"
    }
  ];
  const socialMedias = [
    {
      icon: "ic:baseline-facebook",
      label: "Facebook",
      link: "#",
      external: true
    },
    {
      icon: "ri:twitter-x-fill",
      label: "X/Twitter",
      link: "#",
      external: true
    },
    {
      icon: "ri:instagram-fill",
      label: "Instagram",
      link: "#",
      external: true
    },
    {
      icon: "ri:youtube-fill",
      label: "Youtube",
      link: "#",
      external: true
    }
  ];
  return {
    socialMedias,
    contact
  };
}
const _imports_0 = "" + publicAssetsURL("hi-travel-white-logo.png");
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Default",
  __ssrInlineRender: true,
  setup(__props) {
    const fullYear = (/* @__PURE__ */ new Date()).getFullYear();
    const { contact, socialMedias } = useCompanyBase();
    const links = [
      {
        group: "Layanan Kami",
        items: [
          {
            icon: "",
            label: "Transport",
            link: "#"
          },
          {
            icon: "",
            label: "Packet Tour",
            link: "#"
          }
        ]
      },
      {
        group: "Pusat Bantuan",
        items: [
          {
            icon: "",
            label: "Kebijakan Privasi",
            link: "#"
          },
          {
            icon: "",
            label: "Syarat dan Ketentuan",
            link: "#"
          },
          {
            icon: "",
            label: "Ketentuan Pengembalian Dana",
            link: "#"
          }
        ]
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_Icon = __nuxt_component_1;
      _push(`<footer${ssrRenderAttrs(mergeProps({ class: "bg-secondary text-white py-5" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col w-full space-y-6"${_scopeId}><div class="flex flex-col lg:flex-row lg:justify-between space-x-0 lg:space-x-8"${_scopeId}><div class="flex flex-col space-y-4 w-full"${_scopeId}><img${ssrRenderAttr("src", _imports_0)} alt="hi-travel logo white" class="h-[60px] w-[60px] object-cover"${_scopeId}><div class="h-0.5 w-[80%] bg-zinc-300"${_scopeId}></div><div${_scopeId}></div></div><div class="max-w-4xl"${_scopeId}><div class="grid grid-cols-1 lg:grid-cols-[1fr_1fr_110px_1fr] gap-6 lg:gap-2"${_scopeId}><!--[-->`);
            ssrRenderList(links, (link) => {
              _push2(`<div class="flex flex-col space-y-4"${_scopeId}><h4 class="text-base font-semibold"${_scopeId}>${ssrInterpolate(link.group)}</h4><ul class="space-y-1"${_scopeId}><!--[-->`);
              ssrRenderList(link.items, (item) => {
                _push2(`<li${_scopeId}><a${ssrRenderAttr("to", item.link)} class="link link-hover text-sm"${_scopeId}>${ssrInterpolate(item.label)}</a></li>`);
              });
              _push2(`<!--]--></ul></div>`);
            });
            _push2(`<!--]--><div class="flex flex-col space-y-4"${_scopeId}><h4 class="text-base font-semibold"${_scopeId}>Ikuti kami di</h4><ul class="space-y-1"${_scopeId}><!--[-->`);
            ssrRenderList(unref(socialMedias), (item) => {
              _push2(`<li${_scopeId}><a${ssrRenderAttr("to", item.link)} target="_blank" class="link link-hover inline-flex space-x-2"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, {
                name: item.icon,
                class: "w-4 h-4"
              }, null, _parent2, _scopeId));
              _push2(`<div class="text-sm"${_scopeId}>${ssrInterpolate(item.label)}</div></a></li>`);
            });
            _push2(`<!--]--></ul></div><div class="flex flex-col space-y-4"${_scopeId}><h4 class="text-base font-semibold"${_scopeId}>Kontak Kami</h4><ul class="space-y-1"${_scopeId}><!--[-->`);
            ssrRenderList(unref(contact), (item) => {
              _push2(`<li${_scopeId}><div class="font-semibold"${_scopeId}>${ssrInterpolate(item.title)}</div><a${ssrRenderAttr("href", item.link)} target="_blank" class="link link-hover inline-flex"${_scopeId}><div class="text-xs"${_scopeId}>${ssrInterpolate(item.label)}</div></a></li>`);
            });
            _push2(`<!--]--></ul></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col w-full space-y-6" }, [
                createVNode("div", { class: "flex flex-col lg:flex-row lg:justify-between space-x-0 lg:space-x-8" }, [
                  createVNode("div", { class: "flex flex-col space-y-4 w-full" }, [
                    createVNode("img", {
                      src: _imports_0,
                      alt: "hi-travel logo white",
                      class: "h-[60px] w-[60px] object-cover"
                    }),
                    createVNode("div", { class: "h-0.5 w-[80%] bg-zinc-300" }),
                    createVNode("div")
                  ]),
                  createVNode("div", { class: "max-w-4xl" }, [
                    createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-[1fr_1fr_110px_1fr] gap-6 lg:gap-2" }, [
                      (openBlock(), createBlock(Fragment, null, renderList(links, (link) => {
                        return createVNode("div", {
                          key: link.group,
                          class: "flex flex-col space-y-4"
                        }, [
                          createVNode("h4", { class: "text-base font-semibold" }, toDisplayString(link.group), 1),
                          createVNode("ul", { class: "space-y-1" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(link.items, (item) => {
                              return openBlock(), createBlock("li", {
                                key: item.label
                              }, [
                                createVNode("a", {
                                  to: item.link,
                                  class: "link link-hover text-sm"
                                }, toDisplayString(item.label), 9, ["to"])
                              ]);
                            }), 128))
                          ])
                        ]);
                      }), 64)),
                      createVNode("div", { class: "flex flex-col space-y-4" }, [
                        createVNode("h4", { class: "text-base font-semibold" }, "Ikuti kami di"),
                        createVNode("ul", { class: "space-y-1" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(socialMedias), (item) => {
                            return openBlock(), createBlock("li", {
                              key: item.label
                            }, [
                              createVNode("a", {
                                to: item.link,
                                target: "_blank",
                                class: "link link-hover inline-flex space-x-2"
                              }, [
                                createVNode(_component_Icon, {
                                  name: item.icon,
                                  class: "w-4 h-4"
                                }, null, 8, ["name"]),
                                createVNode("div", { class: "text-sm" }, toDisplayString(item.label), 1)
                              ], 8, ["to"])
                            ]);
                          }), 128))
                        ])
                      ]),
                      createVNode("div", { class: "flex flex-col space-y-4" }, [
                        createVNode("h4", { class: "text-base font-semibold" }, "Kontak Kami"),
                        createVNode("ul", { class: "space-y-1" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(contact), (item) => {
                            return openBlock(), createBlock("li", {
                              key: item.label
                            }, [
                              createVNode("div", { class: "font-semibold" }, toDisplayString(item.title), 1),
                              createVNode("a", {
                                href: item.link,
                                target: "_blank",
                                class: "link link-hover inline-flex"
                              }, [
                                createVNode("div", { class: "text-xs" }, toDisplayString(item.label), 1)
                              ], 8, ["href"])
                            ]);
                          }), 128))
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="h-0.5 w-full bg-zinc-300"></div>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="h-8 w-full text-center"${_scopeId}><p${_scopeId}>\xA9${ssrInterpolate(unref(fullYear))} Hi Transfer Bali. All rights reserved. | Design &amp; Development by <a href="https://spdigitalagency.com" target="_blank"${_scopeId}>s.p. Digital</a></p></div>`);
          } else {
            return [
              createVNode("div", { class: "h-8 w-full text-center" }, [
                createVNode("p", null, [
                  createTextVNode("\xA9" + toDisplayString(unref(fullYear)) + " Hi Transfer Bali. All rights reserved. | Design & Development by ", 1),
                  createVNode("a", {
                    href: "https://spdigitalagency.com",
                    target: "_blank"
                  }, "s.p. Digital")
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</footer>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer/Default.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0$1;
  const _component_LanguageSwitch = _sfc_main$2;
  const _component_FooterDefault = _sfc_main$1;
  const _component_ClientOnly = __nuxt_component_3;
  _push(`<div${ssrRenderAttrs(_attrs)}><header class="fixed top-0 left-0 right-0 z-50 bg-white py-4 border-b"><div class="max-w-7xl mx-auto"><nav class="navbar"><div class="flex-1">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "link link-neutral link-hover",
    "active-class": "font-medium",
    to: "/"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img${ssrRenderAttr("src", _imports_0$1)} alt="Hi Transfer" class="h-[60px] w-[60px]"${_scopeId}>`);
      } else {
        return [
          createVNode("img", {
            src: _imports_0$1,
            alt: "Hi Transfer",
            class: "h-[60px] w-[60px]"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="flex-none"><ul class="inline-flex items-center space-x-4"><li>`);
  _push(ssrRenderComponent(_component_LanguageSwitch, null, null, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "btn btn-primary btn-outline",
    to: "/sign-in"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Masuk`);
      } else {
        return [
          createTextVNode("Masuk")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li>`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    class: "btn btn-primary",
    to: "/sign-up"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Daftar`);
      } else {
        return [
          createTextVNode("Daftar")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></div></nav></div></header><main>`);
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</main>`);
  _push(ssrRenderComponent(_component_FooterDefault, null, null, _parent));
  _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _default = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { _default as default };
//# sourceMappingURL=default-6bc86c87.mjs.map
