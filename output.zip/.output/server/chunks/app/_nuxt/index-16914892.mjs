import { Form } from 'vee-validate';
import { _ as _sfc_main$3 } from './MGroup-560eed6a.mjs';
import { _ as _sfc_main$4 } from './MTextField-bd75102a.mjs';
import { useSSRContext, ref, mergeProps, unref, defineComponent, watch, withCtx, createVNode, openBlock, createBlock, Fragment, renderList } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import { useRouter } from 'vue-router';
import { _ as _sfc_main$5 } from './MSelect-8e6f95b5.mjs';
import { m as useAuth, a as useRequestOptions, b as useRouter$1, s as storeToRefs } from '../server.mjs';
import { u as useVehicleForm } from './vehicleForm-63f1ebb0.mjs';
import { u as useTourForm } from './useTourStore-2a5da3ea.mjs';
import 'clsx';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "OrdererForm",
  __ssrInlineRender: true,
  props: {
    name: {
      type: String,
      required: false,
      default: void 0
    },
    email: {
      type: String,
      required: false,
      default: void 0
    },
    phone: {
      type: String,
      required: false,
      default: void 0
    }
  },
  emits: ["update:name", "update:email", "update:phone"],
  setup(__props, { emit }) {
    const props = __props;
    const router = useRouter();
    const dataForm = ref({
      name: props.name,
      email: props.email,
      phone: props.phone
    });
    watch(
      () => props.name,
      (newName) => {
        dataForm.value.name = newName;
      }
    );
    watch(
      () => props.email,
      (newEmail) => {
        dataForm.value.email = newEmail;
      }
    );
    watch(
      () => props.phone,
      (newPhone) => {
        dataForm.value.phone = newPhone;
      }
    );
    function onSubmit() {
      router.push("/vehicles/checkout");
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIFormMGroup = _sfc_main$3;
      const _component_UIFormMTextField = _sfc_main$4;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_VeeForm, { onSubmit }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 lg:grid-cols-3 p-4 gap-4 border rounded-xl"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "name",
              label: "Nama Lengkap"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: dataForm.value.name,
                    "onUpdate:modelValue": ($event) => dataForm.value.name = $event,
                    name: "name",
                    class: "input-bordered",
                    placeholder: "ex:John Doe",
                    onInput: ($event) => emit("update:name", $event.target.value)
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: dataForm.value.name,
                      "onUpdate:modelValue": ($event) => dataForm.value.name = $event,
                      name: "name",
                      class: "input-bordered",
                      placeholder: "ex:John Doe",
                      onInput: ($event) => emit("update:name", $event.target.value)
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "onInput"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "email",
              label: "Email"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: dataForm.value.email,
                    "onUpdate:modelValue": ($event) => dataForm.value.email = $event,
                    name: "email",
                    class: "input-bordered",
                    placeholder: "ex:myemail@gmail.com",
                    onInput: ($event) => emit("update:email", $event.target.value)
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: dataForm.value.email,
                      "onUpdate:modelValue": ($event) => dataForm.value.email = $event,
                      name: "email",
                      class: "input-bordered",
                      placeholder: "ex:myemail@gmail.com",
                      onInput: ($event) => emit("update:email", $event.target.value)
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "onInput"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "phone",
              label: "Phone"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: dataForm.value.phone,
                    "onUpdate:modelValue": ($event) => dataForm.value.phone = $event,
                    name: "phone",
                    class: "input-bordered",
                    placeholder: "ex:081234567890",
                    onInput: ($event) => emit("update:phone", $event.target.value)
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: dataForm.value.phone,
                      "onUpdate:modelValue": ($event) => dataForm.value.phone = $event,
                      name: "phone",
                      class: "input-bordered",
                      placeholder: "ex:081234567890",
                      onInput: ($event) => emit("update:phone", $event.target.value)
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "onInput"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="hidden"${_scopeId}><button type="submit"${_scopeId}>submit</button></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-3 p-4 gap-4 border rounded-xl" }, [
                createVNode(_component_UIFormMGroup, {
                  name: "name",
                  label: "Nama Lengkap"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: dataForm.value.name,
                      "onUpdate:modelValue": ($event) => dataForm.value.name = $event,
                      name: "name",
                      class: "input-bordered",
                      placeholder: "ex:John Doe",
                      onInput: ($event) => emit("update:name", $event.target.value)
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "onInput"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  name: "email",
                  label: "Email"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: dataForm.value.email,
                      "onUpdate:modelValue": ($event) => dataForm.value.email = $event,
                      name: "email",
                      class: "input-bordered",
                      placeholder: "ex:myemail@gmail.com",
                      onInput: ($event) => emit("update:email", $event.target.value)
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "onInput"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  name: "phone",
                  label: "Phone"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: dataForm.value.phone,
                      "onUpdate:modelValue": ($event) => dataForm.value.phone = $event,
                      name: "phone",
                      class: "input-bordered",
                      placeholder: "ex:081234567890",
                      onInput: ($event) => emit("update:phone", $event.target.value)
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "onInput"])
                  ]),
                  _: 1
                }),
                createVNode("div", { class: "hidden" }, [
                  createVNode("button", {
                    ref: "btnSubmit",
                    type: "submit"
                  }, "submit", 512)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/OrdererForm.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "ParticipantForm",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter$1();
    const store = useVehicleForm();
    const { dataForm, btnSubmit } = storeToRefs(store);
    function onSubmit() {
      router.push("/vehicles/checkout");
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIFormMGroup = _sfc_main$3;
      const _component_UIFormMTextField = _sfc_main$4;
      const _component_UIFormMSelect = _sfc_main$5;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_VeeForm, { onSubmit }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="border rounded-xl grid grid-cols-1 divide-y"${_scopeId}><!--[-->`);
            ssrRenderList(3, (n, i) => {
              _push2(`<div class="p-4"${_scopeId}><div class="grid grid-cols-1 lg:grid-cols-3 gap-4"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_UIFormMGroup, {
                name: "name",
                label: "Nama Lengkap"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_UIFormMTextField, {
                      modelValue: unref(dataForm).name,
                      "onUpdate:modelValue": ($event) => unref(dataForm).name = $event,
                      name: "name",
                      class: "input-bordered",
                      placeholder: "ex:John Doe"
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_component_UIFormMTextField, {
                        modelValue: unref(dataForm).name,
                        "onUpdate:modelValue": ($event) => unref(dataForm).name = $event,
                        name: "name",
                        class: "input-bordered",
                        placeholder: "ex:John Doe"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_UIFormMGroup, {
                name: "nationality",
                label: "Kebangsaan"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_UIFormMSelect, {
                      modelValue: unref(dataForm).email,
                      "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                      name: "email",
                      class: "input-bordered",
                      placeholder: "ex: Indonesia"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<option value=""${_scopeId3}>Pilih Kebangsaan</option><option value="Indonesia"${_scopeId3}>Indonesia</option><option value="Malaysia"${_scopeId3}>Malaysia</option><option value="Singapura"${_scopeId3}>Singapura</option>`);
                        } else {
                          return [
                            createVNode("option", { value: "" }, "Pilih Kebangsaan"),
                            createVNode("option", { value: "Indonesia" }, "Indonesia"),
                            createVNode("option", { value: "Malaysia" }, "Malaysia"),
                            createVNode("option", { value: "Singapura" }, "Singapura")
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_component_UIFormMSelect, {
                        modelValue: unref(dataForm).email,
                        "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                        name: "email",
                        class: "input-bordered",
                        placeholder: "ex: Indonesia"
                      }, {
                        default: withCtx(() => [
                          createVNode("option", { value: "" }, "Pilih Kebangsaan"),
                          createVNode("option", { value: "Indonesia" }, "Indonesia"),
                          createVNode("option", { value: "Malaysia" }, "Malaysia"),
                          createVNode("option", { value: "Singapura" }, "Singapura")
                        ]),
                        _: 1
                      }, 8, ["modelValue", "onUpdate:modelValue"])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_UIFormMGroup, {
                name: "category",
                label: "Kategori"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_UIFormMSelect, {
                      modelValue: unref(dataForm).email,
                      "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                      name: "category",
                      class: "input-bordered",
                      placeholder: "ex: Dewasa"
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<option value=""${_scopeId3}>Kategori</option><option value="dewasa"${_scopeId3}>Dewasa</option><option value="anak"${_scopeId3}>Anak</option>`);
                        } else {
                          return [
                            createVNode("option", { value: "" }, "Kategori"),
                            createVNode("option", { value: "dewasa" }, "Dewasa"),
                            createVNode("option", { value: "anak" }, "Anak")
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_component_UIFormMSelect, {
                        modelValue: unref(dataForm).email,
                        "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                        name: "category",
                        class: "input-bordered",
                        placeholder: "ex: Dewasa"
                      }, {
                        default: withCtx(() => [
                          createVNode("option", { value: "" }, "Kategori"),
                          createVNode("option", { value: "dewasa" }, "Dewasa"),
                          createVNode("option", { value: "anak" }, "Anak")
                        ]),
                        _: 1
                      }, 8, ["modelValue", "onUpdate:modelValue"])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`<div class="hidden"${_scopeId}><button type="submit"${_scopeId}>submit</button></div></div></div>`);
            });
            _push2(`<!--]--></div>`);
          } else {
            return [
              createVNode("div", { class: "border rounded-xl grid grid-cols-1 divide-y" }, [
                (openBlock(), createBlock(Fragment, null, renderList(3, (n, i) => {
                  return createVNode("div", {
                    class: "p-4",
                    key: i
                  }, [
                    createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-3 gap-4" }, [
                      createVNode(_component_UIFormMGroup, {
                        name: "name",
                        label: "Nama Lengkap"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_UIFormMTextField, {
                            modelValue: unref(dataForm).name,
                            "onUpdate:modelValue": ($event) => unref(dataForm).name = $event,
                            name: "name",
                            class: "input-bordered",
                            placeholder: "ex:John Doe"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_UIFormMGroup, {
                        name: "nationality",
                        label: "Kebangsaan"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_UIFormMSelect, {
                            modelValue: unref(dataForm).email,
                            "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                            name: "email",
                            class: "input-bordered",
                            placeholder: "ex: Indonesia"
                          }, {
                            default: withCtx(() => [
                              createVNode("option", { value: "" }, "Pilih Kebangsaan"),
                              createVNode("option", { value: "Indonesia" }, "Indonesia"),
                              createVNode("option", { value: "Malaysia" }, "Malaysia"),
                              createVNode("option", { value: "Singapura" }, "Singapura")
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_UIFormMGroup, {
                        name: "category",
                        label: "Kategori"
                      }, {
                        default: withCtx(() => [
                          createVNode(_component_UIFormMSelect, {
                            modelValue: unref(dataForm).email,
                            "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                            name: "category",
                            class: "input-bordered",
                            placeholder: "ex: Dewasa"
                          }, {
                            default: withCtx(() => [
                              createVNode("option", { value: "" }, "Kategori"),
                              createVNode("option", { value: "dewasa" }, "Dewasa"),
                              createVNode("option", { value: "anak" }, "Anak")
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        _: 1
                      }),
                      createVNode("div", { class: "hidden" }, [
                        createVNode("button", {
                          ref_for: true,
                          ref_key: "btnSubmit",
                          ref: btnSubmit,
                          type: "submit"
                        }, "submit", 512)
                      ])
                    ])
                  ]);
                }), 64))
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/ParticipantForm.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useAuth();
    useRequestOptions();
    useTourForm({
      callback: () => {
        alert("Form has been submitted!");
      }
    });
    const dataFormT = ref({
      name: void 0,
      email: void 0,
      phone: void 0
    });
    ref({
      sort: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TourOrdererForm = _sfc_main$2;
      const _component_TourParticipantForm = _sfc_main$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col space-y-6" }, _attrs))}><div class="flex justify-between items-center"><div class="text-2xl font-semibold">${ssrInterpolate(_ctx.$t("data-pemesan"))}</div></div><div class="space-y-4">`);
      _push(ssrRenderComponent(_component_TourOrdererForm, {
        name: unref(dataFormT).name,
        email: unref(dataFormT).email,
        phone: unref(dataFormT).phone,
        "onUpdate:name": ($event) => unref(dataFormT).name = $event,
        "onUpdate:email": ($event) => unref(dataFormT).email = $event,
        "onUpdate:phone": ($event) => unref(dataFormT).phone = $event
      }, null, _parent));
      _push(`</div><div class="flex justify-between items-center"><div class="text-2xl font-semibold">${ssrInterpolate(_ctx.$t("data-peserta"))}</div></div><div class="space-y-4">`);
      _push(ssrRenderComponent(_component_TourParticipantForm, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tours/booking/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-16914892.mjs.map
