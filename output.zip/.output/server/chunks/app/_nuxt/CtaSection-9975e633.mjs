import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { e as _export_sfc, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_1 from './Icon-7218f0f6.mjs';
import { mergeProps, withCtx, createTextVNode, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';

const _imports_0 = "" + publicAssetsURL("hi-travel-cta.png");
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0$1;
  const _component_Icon = __nuxt_component_1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "relative" }, _attrs))}><div class="absolute w-full h-full bg-black/50 grid place-items-center"><div class="max-w-xl text-center space-y-6"><h3 class="text-4xl lg:text-5xl font-semibold text-white">Sudah siap menjelajahi keajaiban Bali?</h3><p class="text-base lg:text-xl text-white"> Enjoy a holiday experience in Bali with exciting activities and easy access to purchasing transport with Hi Travel Bali </p><div>`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/",
    class: "btn btn-primary text-white font-medium leading-4"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Jelajahi Lebih Lanjut `);
        _push2(ssrRenderComponent(_component_Icon, {
          name: "i-heroicons-arrow-right-20-solid",
          class: "-rotate-45 h-5 w-5"
        }, null, _parent2, _scopeId));
      } else {
        return [
          createTextVNode("Jelajahi Lebih Lanjut "),
          createVNode(_component_Icon, {
            name: "i-heroicons-arrow-right-20-solid",
            class: "-rotate-45 h-5 w-5"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div><img${ssrRenderAttr("src", _imports_0)} alt="cta" class="w-full h-[490px]"></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Share/CtaSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_3 as _ };
//# sourceMappingURL=CtaSection-9975e633.mjs.map
