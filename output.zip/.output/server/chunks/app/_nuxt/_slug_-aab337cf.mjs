import { _ as __nuxt_component_0 } from './Container-afb1bf23.mjs';
import { d as useRoute, a as useRequestOptions, m as useAuth, g as useAsyncData, f as useHead, _ as __nuxt_component_0$1, e as useI18n, u as useRequestHelper, h as useFetch } from '../server.mjs';
import __nuxt_component_1 from './Icon-9a1ee2a3.mjs';
import { _ as __nuxt_component_3 } from './Modal-7e1682f2.mjs';
import { Form, Field, ErrorMessage } from 'vee-validate';
import { _ as _sfc_main$2 } from './Alert-ad006b11.mjs';
import { _ as _sfc_main$3 } from './InputOTP-bbb2b053.mjs';
import { computed, ref, withAsyncContext, withCtx, createVNode, unref, toDisplayString, openBlock, createBlock, createCommentVNode, isRef, useSSRContext, mergeProps, createTextVNode } from 'vue';
import { u as useSchema } from './useSchema-f211c259.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-71e93c9c.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './index-df4194e4.mjs';
import './TransitionTopToBottom-3d1af8ef.mjs';
import 'zod';
import '@vee-validate/zod';

function useRefund() {
  const stateForm = ref({
    email: ""
  });
  const showPinEmailExpired = ref(false);
  const secondTime = ref(60);
  function countdown() {
    const interval = setInterval(() => {
      if (secondTime.value === 0) {
        clearInterval(interval);
        showPinEmailExpired.value = true;
      } else {
        secondTime.value--;
      }
    }, 1e3);
  }
  return {
    stateForm,
    countdown,
    showPinEmailExpired,
    secondTime
  };
}
const _sfc_main$1 = {
  __name: "Verified",
  __ssrInlineRender: true,
  props: {
    email: String,
    otp: String
  },
  emits: ["next", "update:otp"],
  setup(__props, { emit }) {
    const props = __props;
    const { requestOptions } = useRequestOptions();
    const { locale, t: $t } = useI18n();
    const { stateForm, countdown, showPinEmailExpired, secondTime } = useRefund();
    const { otpSchema } = useSchema();
    const { loading, message, alertType } = useRequestHelper();
    function updateToParent() {
      emit("update:otp", stateForm.value.otp);
      emit("next");
    }
    function resentEmail() {
      showPinEmailExpired.value = false;
      secondTime.value = 60;
      countdown();
      useFetch("/admins/resend-email-verification", {
        method: "POST",
        body: { email: stateForm.value.email },
        ...requestOptions
      }, "$N1weP1OQ2C");
    }
    async function onSubmit() {
      loading.value = true;
      const { error } = await useFetch("/admins/forget-password/verify-pin", {
        method: "POST",
        body: JSON.stringify({
          email: props.email,
          pin: stateForm.value.otp
        }),
        ...requestOptions
      }, "$x3rGCD3toy");
      if (error.value)
        ;
      else {
        updateToParent();
      }
      loading.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_Alert = _sfc_main$2;
      const _component_VeeField = Field;
      const _component_UIFormInputOTP = _sfc_main$3;
      const _component_VeeErrorMessage = ErrorMessage;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        onSubmit,
        "validation-schema": unref(otpSchema)
      }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 text-left gap-4 p-4 rounded-md w-full"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Alert, {
              modelValue: unref(message),
              "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
              type: unref(alertType)
            }, null, _parent2, _scopeId));
            _push2(`<div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              name: "otp",
              modelValue: unref(stateForm).otp,
              "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_UIFormInputOTP, {
              modelValue: unref(stateForm).otp,
              "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event,
              "is-error": !!(errors == null ? void 0 : errors.otp)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "otp",
              class: "form-error-message"
            }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><button type="submit" class="btn bg-primary text-white shadow w-full py-1"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""}${_scopeId}><span${_scopeId}>${ssrInterpolate(unref($t)("proses-pengembalian"))}</span></button></div>`);
            if (unref(showPinEmailExpired)) {
              _push2(`<div${_scopeId}><p class="text-sm"${_scopeId}>${ssrInterpolate(unref($t)("jika-tidak-menerima-email"))} <span class="link text-primary" role="button"${_scopeId}>${ssrInterpolate(unref($t)("klik-disini"))}</span></p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div${_scopeId}>`);
            if (unref(secondTime) > 0) {
              _push2(`<div class="text-gray-400 text-sm"${_scopeId}>${ssrInterpolate(unref($t)("pin-berlaku-selama"))} <span class="whitespace-nowrap"${_scopeId}>${ssrInterpolate(unref(secondTime))} ${ssrInterpolate(unref($t)("second"))}. </span></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (unref(showPinEmailExpired)) {
              _push2(`<div class="text-error text-sm"${_scopeId}>${ssrInterpolate(unref($t)("otp-expired"))}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 text-left gap-4 p-4 rounded-md w-full" }, [
                createVNode(_component_Alert, {
                  modelValue: unref(message),
                  "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
                  type: unref(alertType)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "type"]),
                createVNode("div", { class: "hidden" }, [
                  createVNode(_component_VeeField, {
                    name: "otp",
                    modelValue: unref(stateForm).otp,
                    "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode(_component_UIFormInputOTP, {
                  modelValue: unref(stateForm).otp,
                  "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event,
                  "is-error": !!(errors == null ? void 0 : errors.otp)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "is-error"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "otp",
                  class: "form-error-message"
                }),
                createVNode("div", null, [
                  createVNode("button", {
                    type: "submit",
                    class: "btn bg-primary text-white shadow w-full py-1",
                    disabled: unref(loading)
                  }, [
                    createVNode("span", null, toDisplayString(unref($t)("proses-pengembalian")), 1)
                  ], 8, ["disabled"])
                ]),
                unref(showPinEmailExpired) ? (openBlock(), createBlock("div", { key: 0 }, [
                  createVNode("p", { class: "text-sm" }, [
                    createTextVNode(toDisplayString(unref($t)("jika-tidak-menerima-email")) + " ", 1),
                    createVNode("span", {
                      class: "link text-primary",
                      onClick: resentEmail,
                      role: "button"
                    }, toDisplayString(unref($t)("klik-disini")), 1)
                  ])
                ])) : createCommentVNode("", true),
                createVNode("div", null, [
                  unref(secondTime) > 0 ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "text-gray-400 text-sm"
                  }, [
                    createTextVNode(toDisplayString(unref($t)("pin-berlaku-selama")) + " ", 1),
                    createVNode("span", { class: "whitespace-nowrap" }, toDisplayString(unref(secondTime)) + " " + toDisplayString(unref($t)("second")) + ". ", 1)
                  ])) : createCommentVNode("", true),
                  unref(showPinEmailExpired) ? (openBlock(), createBlock("div", {
                    key: 1,
                    class: "text-error text-sm"
                  }, toDisplayString(unref($t)("otp-expired")), 1)) : createCommentVNode("", true)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Verified.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main$1;
const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    const route = useRoute();
    const slug = computed(() => {
      var _a2;
      return (_a2 = route == null ? void 0 : route.params) == null ? void 0 : _a2.slug;
    });
    const { requestOptions } = useRequestOptions();
    const { $user } = useAuth();
    ref(1);
    const showModalRefund = ref(false);
    ref(void 0);
    const {
      data: carsOrderDetail,
      error: errorCars,
      refresh: refreshCar
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "carsOrderDetail",
      () => {
        var _a2;
        return $fetch(`/users/${(_a2 = $user.value) == null ? void 0 : _a2.uuid}/car-orders/${slug.value}`, {
          headers: {
            Accept: "application/json"
          },
          method: "get",
          ...requestOptions
        });
      }
    )), __temp = await __temp, __restore(), __temp);
    console.log(carsOrderDetail.value, slug.value, (_a = $user.value) == null ? void 0 : _a.uuid);
    function showModalRefundFunc(id) {
      showModalRefund.value = !showModalRefund.value;
    }
    useHead({ title: "Order Summary" });
    return (_ctx, _push, _parent, _attrs) => {
      var _a2;
      const _component_UIContainer = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_1;
      const _component_modal = __nuxt_component_3;
      const _component_Verified = __nuxt_component_4;
      _push(`<!--[--><div class="h-28"></div><div class="w-full border-b">`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a3, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R, _S, _T, _U, _V, _W, _X, _Y, _Z, __, _$, _aa, _ba, _ca, _da, _ea, _fa, _ga, _ha, _ia, _ja, _ka, _la, _ma, _na;
          if (_push2) {
            _push2(`<div class="flex items-center gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, { to: "/user" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_Icon, {
                    name: "formkit:arrowleft",
                    class: "text-black w-7 h-7"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_Icon, {
                      name: "formkit:arrowleft",
                      class: "text-black w-7 h-7"
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="flex flex-col gap-1"${_scopeId}><p class="text-black text-[18px] font-medium"${_scopeId}>${ssrInterpolate(_ctx.$t("ringkasan-pesanan"))}</p><span${_scopeId}>${ssrInterpolate(_ctx.$t("informasi-lengkap-pesanan"))} #${ssrInterpolate((_b = (_a3 = unref(carsOrderDetail)) == null ? void 0 : _a3.data) == null ? void 0 : _b.uuid)}</span></div></div><div class="py-10"${_scopeId}><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("informasi-pelanggan"))}</div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("nama-pelanggan"))}:</p><p${_scopeId}>${ssrInterpolate((_e = (_d = (_c = unref(carsOrderDetail)) == null ? void 0 : _c.data) == null ? void 0 : _d.user) == null ? void 0 : _e.first_name)}\xA0${ssrInterpolate((_h = (_g = (_f = unref(carsOrderDetail)) == null ? void 0 : _f.data) == null ? void 0 : _g.user) == null ? void 0 : _h.last_name)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Email:</p><p${_scopeId}>${ssrInterpolate((_k = (_j = (_i = unref(carsOrderDetail)) == null ? void 0 : _i.data) == null ? void 0 : _j.user) == null ? void 0 : _k.email)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("nomor-telepon"))}:</p><p${_scopeId}>${ssrInterpolate((_n = (_m = (_l = unref(carsOrderDetail)) == null ? void 0 : _l.data) == null ? void 0 : _m.user) == null ? void 0 : _n.phone)}</p></div></div><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("informasi-pemesanan"))}</div><div class="grid gap-3 md:grid-cols-2"${_scopeId}><div class="flex flex-col gap-1 text-sm"${_scopeId}><p class="text-[#121212] font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("penjeputan"))}</p><p class="font-normal"${_scopeId}>${ssrInterpolate((_p = (_o = unref(carsOrderDetail)) == null ? void 0 : _o.data) == null ? void 0 : _p.details[0].pickup_name)}</p><p class="font-normal text-[#16161697]"${_scopeId}>${ssrInterpolate((_r = (_q = unref(carsOrderDetail)) == null ? void 0 : _q.data) == null ? void 0 : _r.details[0].pickup_address)}</p></div><div class="flex flex-col gap-1 text-sm"${_scopeId}><p class="text-[#121212] font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("pengantaran"))}</p><p class="font-normal"${_scopeId}>${ssrInterpolate((_t = (_s = unref(carsOrderDetail)) == null ? void 0 : _s.data) == null ? void 0 : _t.details[0].destination_name)}</p><p class="font-normal text-[#16161697]"${_scopeId}>${ssrInterpolate((_v = (_u = unref(carsOrderDetail)) == null ? void 0 : _u.data) == null ? void 0 : _v.details[0].destination_address)}</p></div></div></div><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("payment-information"))}</div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("payment-method"))}</p><p${_scopeId}>${ssrInterpolate((_x = (_w = unref(carsOrderDetail)) == null ? void 0 : _w.data) == null ? void 0 : _x.payment_method)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Promo</p><p${_scopeId}>${ssrInterpolate((_z = (_y = unref(carsOrderDetail)) == null ? void 0 : _y.data) == null ? void 0 : _z.promo_amount)}</p></div>`);
            if ((_B = (_A = unref(carsOrderDetail)) == null ? void 0 : _A.data) == null ? void 0 : _B.refund_status) {
              _push2(`<div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Refund status</p><p${_scopeId}>${ssrInterpolate((_D = (_C = unref(carsOrderDetail)) == null ? void 0 : _C.data) == null ? void 0 : _D.refund_status)}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("payment-status"))}</p><p${_scopeId}>${ssrInterpolate((_F = (_E = unref(carsOrderDetail)) == null ? void 0 : _E.data) == null ? void 0 : _F.payment_status)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("total-price"))}</p><p${_scopeId}>Rp.${ssrInterpolate((_H = (_G = unref(carsOrderDetail)) == null ? void 0 : _G.data) == null ? void 0 : _H.total_purchased)}</p></div></div></div><div class="flex items-center justify-end"${_scopeId}><button type="button" class="border-2 shadow-sm rounded-lg py-2 px-4"${_scopeId}><p${_scopeId}>Payment refund</p></button></div>`);
          } else {
            return [
              createVNode("div", { class: "flex items-center gap-4" }, [
                createVNode(_component_NuxtLink, { to: "/user" }, {
                  default: withCtx(() => [
                    createVNode(_component_Icon, {
                      name: "formkit:arrowleft",
                      class: "text-black w-7 h-7"
                    })
                  ]),
                  _: 1
                }),
                createVNode("div", { class: "flex flex-col gap-1" }, [
                  createVNode("p", { class: "text-black text-[18px] font-medium" }, toDisplayString(_ctx.$t("ringkasan-pesanan")), 1),
                  createVNode("span", null, toDisplayString(_ctx.$t("informasi-lengkap-pesanan")) + " #" + toDisplayString((_J = (_I = unref(carsOrderDetail)) == null ? void 0 : _I.data) == null ? void 0 : _J.uuid), 1)
                ])
              ]),
              createVNode("div", { class: "py-10" }, [
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(_ctx.$t("informasi-pelanggan")), 1),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, toDisplayString(_ctx.$t("nama-pelanggan")) + ":", 1),
                    createVNode("p", null, toDisplayString((_M = (_L = (_K = unref(carsOrderDetail)) == null ? void 0 : _K.data) == null ? void 0 : _L.user) == null ? void 0 : _M.first_name) + "\xA0" + toDisplayString((_P = (_O = (_N = unref(carsOrderDetail)) == null ? void 0 : _N.data) == null ? void 0 : _O.user) == null ? void 0 : _P.last_name), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, "Email:"),
                    createVNode("p", null, toDisplayString((_S = (_R = (_Q = unref(carsOrderDetail)) == null ? void 0 : _Q.data) == null ? void 0 : _R.user) == null ? void 0 : _S.email), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(_ctx.$t("nomor-telepon")) + ":", 1),
                    createVNode("p", null, toDisplayString((_V = (_U = (_T = unref(carsOrderDetail)) == null ? void 0 : _T.data) == null ? void 0 : _U.user) == null ? void 0 : _V.phone), 1)
                  ])
                ]),
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(_ctx.$t("informasi-pemesanan")), 1),
                  createVNode("div", { class: "grid gap-3 md:grid-cols-2" }, [
                    createVNode("div", { class: "flex flex-col gap-1 text-sm" }, [
                      createVNode("p", { class: "text-[#121212] font-semibold" }, toDisplayString(_ctx.$t("penjeputan")), 1),
                      createVNode("p", { class: "font-normal" }, toDisplayString((_X = (_W = unref(carsOrderDetail)) == null ? void 0 : _W.data) == null ? void 0 : _X.details[0].pickup_name), 1),
                      createVNode("p", { class: "font-normal text-[#16161697]" }, toDisplayString((_Z = (_Y = unref(carsOrderDetail)) == null ? void 0 : _Y.data) == null ? void 0 : _Z.details[0].pickup_address), 1)
                    ]),
                    createVNode("div", { class: "flex flex-col gap-1 text-sm" }, [
                      createVNode("p", { class: "text-[#121212] font-semibold" }, toDisplayString(_ctx.$t("pengantaran")), 1),
                      createVNode("p", { class: "font-normal" }, toDisplayString((_$ = (__ = unref(carsOrderDetail)) == null ? void 0 : __.data) == null ? void 0 : _$.details[0].destination_name), 1),
                      createVNode("p", { class: "font-normal text-[#16161697]" }, toDisplayString((_ba = (_aa = unref(carsOrderDetail)) == null ? void 0 : _aa.data) == null ? void 0 : _ba.details[0].destination_address), 1)
                    ])
                  ])
                ]),
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(_ctx.$t("payment-information")), 1),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, toDisplayString(_ctx.$t("payment-method")), 1),
                    createVNode("p", null, toDisplayString((_da = (_ca = unref(carsOrderDetail)) == null ? void 0 : _ca.data) == null ? void 0 : _da.payment_method), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, "Promo"),
                    createVNode("p", null, toDisplayString((_fa = (_ea = unref(carsOrderDetail)) == null ? void 0 : _ea.data) == null ? void 0 : _fa.promo_amount), 1)
                  ]),
                  ((_ha = (_ga = unref(carsOrderDetail)) == null ? void 0 : _ga.data) == null ? void 0 : _ha.refund_status) ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm"
                  }, [
                    createVNode("p", { class: "font-semibold" }, "Refund status"),
                    createVNode("p", null, toDisplayString((_ja = (_ia = unref(carsOrderDetail)) == null ? void 0 : _ia.data) == null ? void 0 : _ja.refund_status), 1)
                  ])) : createCommentVNode("", true),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(_ctx.$t("payment-status")), 1),
                    createVNode("p", null, toDisplayString((_la = (_ka = unref(carsOrderDetail)) == null ? void 0 : _ka.data) == null ? void 0 : _la.payment_status), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(_ctx.$t("total-price")), 1),
                    createVNode("p", null, "Rp." + toDisplayString((_na = (_ma = unref(carsOrderDetail)) == null ? void 0 : _ma.data) == null ? void 0 : _na.total_purchased), 1)
                  ])
                ])
              ]),
              createVNode("div", { class: "flex items-center justify-end" }, [
                createVNode("button", {
                  type: "button",
                  onClick: ($event) => showModalRefundFunc(),
                  class: "border-2 shadow-sm rounded-lg py-2 px-4"
                }, [
                  createVNode("p", null, "Payment refund")
                ], 8, ["onClick"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_modal, {
        modelValue: unref(showModalRefund),
        "onUpdate:modelValue": ($event) => isRef(showModalRefund) ? showModalRefund.value = $event : null,
        class: "relative w-[90%] sm:w-[60%] lg:w-[40%]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex justify-center items-center flex-col px-2 sm:px-4 lg:px-5 overflow-auto"${_scopeId}><div class="flex flex-col gap-3 lg:gap-5 transition h-full"${_scopeId}><p class="font-semibold text-xl"${_scopeId}>Pengembalian Pembayaran</p><p class="text-[12px] border-b border-gray-500 pb-3"${_scopeId}> Silakan periksa kotak masuk email Anda untuk mendapatkan PIN verifikasi untuk proses pengembalian dana, lalu ketik di kolom di bawah ini. </p></div><div class="w-full"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Verified, null, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex justify-center items-center flex-col px-2 sm:px-4 lg:px-5 overflow-auto" }, [
                createVNode("div", { class: "flex flex-col gap-3 lg:gap-5 transition h-full" }, [
                  createVNode("p", { class: "font-semibold text-xl" }, "Pengembalian Pembayaran"),
                  createVNode("p", { class: "text-[12px] border-b border-gray-500 pb-3" }, " Silakan periksa kotak masuk email Anda untuk mendapatkan PIN verifikasi untuk proses pengembalian dana, lalu ketik di kolom di bawah ini. ")
                ]),
                createVNode("div", { class: "w-full" }, [
                  createVNode(_component_Verified)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<pre>    ${ssrInterpolate((_a2 = unref(carsOrderDetail)) == null ? void 0 : _a2.data)}
  </pre><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/order/order-summary/car/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-aab337cf.mjs.map
