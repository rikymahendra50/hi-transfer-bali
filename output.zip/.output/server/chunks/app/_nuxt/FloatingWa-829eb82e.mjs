import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import __nuxt_component_0 from './Icon-0f6314e3.mjs';
import { b as useRouter, e as useRequestOptions, u as useAuth, g as useAsyncData, f as useI18n, l as _export_sfc, _ as __nuxt_component_0$1 } from '../server.mjs';
import { defineComponent, withAsyncContext, resolveComponent, unref, withCtx, createVNode, withModifiers, openBlock, createBlock, createCommentVNode, createTextVNode, toDisplayString, useSSRContext, mergeProps, Fragment, renderList } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import { _ as __nuxt_component_0$2 } from './Container-f78810bd.mjs';

const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "LoginRegister",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRouter();
    const { requestOptions } = useRequestOptions();
    const { $isLoggedIn, $isUser, $logout } = useAuth();
    const {
      data: userProfile,
      error: errorUsers,
      refresh: refreshUsers
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "userProfile",
      () => $fetch(`/users/profile`, {
        headers: {
          Accept: "application/json"
        },
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VDropdown = resolveComponent("VDropdown");
      const _component_Icon = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      if (unref($isLoggedIn)) {
        _push(`<div class="">`);
        if (unref($isUser)) {
          _push(`<div>`);
          _push(ssrRenderComponent(_component_VDropdown, null, {
            popper: withCtx(({ hide }, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<div class="my-1 py-1 flex flex-col px-2"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_NuxtLink, {
                  onClick: hide,
                  to: "/user/profile",
                  class: "hover:bg-primary px-3 lg:px-5 py-2 lg:py-3 rounded-lg hover:text-white"
                }, {
                  default: withCtx((_, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<p${_scopeId2}>Profile</p>`);
                    } else {
                      return [
                        createVNode("p", null, "Profile")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(ssrRenderComponent(_component_NuxtLink, {
                  to: "/user",
                  onClick: hide,
                  class: "hover:bg-primary px-3 lg:px-5 py-2 lg:py-3 rounded-lg hover:text-white"
                }, {
                  default: withCtx((_, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<p${_scopeId2}>Orders</p>`);
                    } else {
                      return [
                        createVNode("p", null, "Orders")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`<button class="hover:bg-red-500 hover:border-2 px-3 lg:px-5 py-2 lg:py-3 rounded-lg text-red-600 hover:text-white"${_scopeId}> Logout </button></div>`);
              } else {
                return [
                  createVNode("div", { class: "my-1 py-1 flex flex-col px-2" }, [
                    createVNode(_component_NuxtLink, {
                      onClick: withModifiers(hide, ["prevent"]),
                      to: "/user/profile",
                      class: "hover:bg-primary px-3 lg:px-5 py-2 lg:py-3 rounded-lg hover:text-white"
                    }, {
                      default: withCtx(() => [
                        createVNode("p", null, "Profile")
                      ]),
                      _: 2
                    }, 1032, ["onClick"]),
                    createVNode(_component_NuxtLink, {
                      to: "/user",
                      onClick: withModifiers(hide, ["prevent"]),
                      class: "hover:bg-primary px-3 lg:px-5 py-2 lg:py-3 rounded-lg hover:text-white"
                    }, {
                      default: withCtx(() => [
                        createVNode("p", null, "Orders")
                      ]),
                      _: 2
                    }, 1032, ["onClick"]),
                    createVNode("button", {
                      onClick: [
                        withModifiers(hide, ["prevent"]),
                        unref($logout)
                      ],
                      class: "hover:bg-red-500 hover:border-2 px-3 lg:px-5 py-2 lg:py-3 rounded-lg text-red-600 hover:text-white"
                    }, " Logout ", 8, ["onClick"])
                  ])
                ];
              }
            }),
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x;
              if (_push2) {
                _push2(`<button type="button" class="flex items-center gap-2 btn-outline group btn border border-gray-400 group hover:bg-primary rounded-md hover:border-white group"${_scopeId}>`);
                if (unref($isUser) && ((_b = (_a = unref(userProfile)) == null ? void 0 : _a.data) == null ? void 0 : _b.image)) {
                  _push2(`<img${ssrRenderAttr("src", (_d = (_c = unref(userProfile)) == null ? void 0 : _c.data) == null ? void 0 : _d.image)} alt="image" class="max-w-[30px] rounded-full group-hover:border-2"${_scopeId}>`);
                } else if (unref($isUser) && ((_f = (_e = unref(userProfile)) == null ? void 0 : _e.data) == null ? void 0 : _f.image) === "" || ((_h = (_g = unref(userProfile)) == null ? void 0 : _g.data) == null ? void 0 : _h.image) === null) {
                  _push2(ssrRenderComponent(_component_Icon, {
                    name: "gg:profile",
                    class: "text-black w-5 h-5 group-hover:text-white"
                  }, null, _parent2, _scopeId));
                } else {
                  _push2(`<!---->`);
                }
                _push2(` ${ssrInterpolate(((_j = (_i = unref(userProfile)) == null ? void 0 : _i.data) == null ? void 0 : _j.first_name) + " " + ((_l = (_k = unref(userProfile)) == null ? void 0 : _k.data) == null ? void 0 : _l.last_name))}</button>`);
              } else {
                return [
                  createVNode("button", {
                    type: "button",
                    class: "flex items-center gap-2 btn-outline group btn border border-gray-400 group hover:bg-primary rounded-md hover:border-white group"
                  }, [
                    unref($isUser) && ((_n = (_m = unref(userProfile)) == null ? void 0 : _m.data) == null ? void 0 : _n.image) ? (openBlock(), createBlock("img", {
                      key: 0,
                      src: (_p = (_o = unref(userProfile)) == null ? void 0 : _o.data) == null ? void 0 : _p.image,
                      alt: "image",
                      class: "max-w-[30px] rounded-full group-hover:border-2"
                    }, null, 8, ["src"])) : unref($isUser) && ((_r = (_q = unref(userProfile)) == null ? void 0 : _q.data) == null ? void 0 : _r.image) === "" || ((_t = (_s = unref(userProfile)) == null ? void 0 : _s.data) == null ? void 0 : _t.image) === null ? (openBlock(), createBlock(_component_Icon, {
                      key: 1,
                      name: "gg:profile",
                      class: "text-black w-5 h-5 group-hover:text-white"
                    })) : createCommentVNode("", true),
                    createTextVNode(" " + toDisplayString(((_v = (_u = unref(userProfile)) == null ? void 0 : _u.data) == null ? void 0 : _v.first_name) + " " + ((_x = (_w = unref(userProfile)) == null ? void 0 : _w.data) == null ? void 0 : _x.last_name)), 1)
                  ])
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</div>`);
        } else {
          _push(`<div class="">`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: "/admin/orders",
            type: "button",
            class: "flex items-center gap-2 btn-outline rounded-none group btn border border-gray-400 group hover:bg-red-600"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Dashboard `);
              } else {
                return [
                  createTextVNode(" Dashboard ")
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</div>`);
        }
        _push(`</div>`);
      } else {
        _push(`<div class="flex items-center gap-2">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          class: "btn btn-primary",
          to: "/sign-up"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$t("daftar"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$t("daftar")), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_NuxtLink, {
          class: "btn btn-primary btn-outline",
          to: "/sign-in"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(_ctx.$t("masuk"))}`);
            } else {
              return [
                createTextVNode(toDisplayString(_ctx.$t("masuk")), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Share/LoginRegister.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
function useCompanyBase() {
  const contact = [
    {
      title: "Address",
      label: "Jl. Amerta Br. Dinas Kaja , Desa/Kelurahan Busungbiu, Kec. Busungbiu, Kab. Buleleng, Provinsi Bali,Kode Pos: 81154",
      link: "https://maps.app.goo.gl/3XkGAE8Erm2wsdLZA"
    },
    {
      title: "Phone",
      label: "087782660007",
      link: "tel:+6287782660007"
    },
    {
      title: "Email",
      label: "dekpericab@gmail.com",
      link: "mailto:dekpericab@gmail.com"
    }
  ];
  const socialMedias = [
    {
      icon: "ic:baseline-facebook",
      label: "Facebook",
      link: "#",
      external: true
    },
    {
      icon: "ri:twitter-x-fill",
      label: "X/Twitter",
      link: "#",
      external: true
    },
    {
      icon: "ri:instagram-fill",
      label: "Instagram",
      link: "#",
      external: true
    },
    {
      icon: "ri:youtube-fill",
      label: "Youtube",
      link: "#",
      external: true
    }
  ];
  return {
    socialMedias,
    contact
  };
}
const _imports_0 = "" + publicAssetsURL("hi-travel-white-logo.png");
const _imports_1 = "" + publicAssetsURL("kada-global-logo.svg");
const _imports_2 = "" + publicAssetsURL("logo-xendit.svg");
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Default",
  __ssrInlineRender: true,
  setup(__props) {
    const fullYear = (/* @__PURE__ */ new Date()).getFullYear();
    const { locale, t: $t } = useI18n();
    const { contact, socialMedias } = useCompanyBase();
    const links = [
      {
        group: $t("layanan-kami"),
        items: [
          {
            icon: "",
            label: "Transport",
            link: "/#learnmore"
          },
          {
            icon: "",
            label: "Packet Tour",
            link: "/#learnmore"
          }
        ]
      },
      {
        group: $t("pusat-bantuan"),
        items: [
          {
            icon: "",
            label: $t("kebijakan-privasi"),
            link: "/privacy-policy"
          },
          {
            icon: "",
            label: $t("syarat-dan-ketentuan"),
            link: "/terms-condition"
          },
          {
            icon: "",
            label: $t("ketentuan-dan-pengembalian-dana"),
            link: "/terms-and-refunds"
          }
        ]
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0$2;
      const _component_Icon = __nuxt_component_0;
      _push(`<footer${ssrRenderAttrs(mergeProps({ class: "bg-secondary text-white h-fit pt-10 pb-20 md:pt-5 md:pb-5" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col w-full space-y-6"${_scopeId}><div class="flex flex-col lg:flex-row lg:justify-between space-x-0 lg:space-x-8"${_scopeId}><div class="flex flex-col space-y-4 w-full"${_scopeId}><div class="flex items-center gap-4"${_scopeId}><img${ssrRenderAttr("src", _imports_0)} alt="hi-travel logo white" class="h-[60px] w-[60px] object-cover"${_scopeId}><div class="flex flex-col gap-2 border-l pl-3 border-opacity-20"${_scopeId}><p${_scopeId}>${ssrInterpolate(unref($t)("bagian-dari"))}</p><img${ssrRenderAttr("src", _imports_1)} alt="kada-global-logo"${_scopeId}></div></div><div class="h-0.5 w-[80%] bg-zinc-300"${_scopeId}></div><div class="flex flex-col gap-2"${_scopeId}>${ssrInterpolate(unref($t)("pembayaranmu-aman-dengan"))} <img${ssrRenderAttr("src", _imports_2)} alt="logo-xendit" class="w-[100px]"${_scopeId}></div></div><div class="max-w-2xl"${_scopeId}><div class="grid grid-cols-1 lg:grid-cols-[1fr_1fr_110px_1fr] gap-6 lg:gap-2"${_scopeId}><!--[-->`);
            ssrRenderList(links, (link) => {
              _push2(`<div class="flex flex-col space-y-4"${_scopeId}><h4 class="text-base font-semibold"${_scopeId}>${ssrInterpolate(link.group)}</h4><ul class="space-y-1"${_scopeId}><!--[-->`);
              ssrRenderList(link.items, (item) => {
                _push2(`<li${_scopeId}><a${ssrRenderAttr("href", item.link)} class="link link-hover text-sm"${_scopeId}>${ssrInterpolate(item.label)}</a></li>`);
              });
              _push2(`<!--]--></ul></div>`);
            });
            _push2(`<!--]--><div class="flex flex-col space-y-4"${_scopeId}><h4 class="text-base font-semibold"${_scopeId}>Ikuti kami di</h4><ul class="space-y-1"${_scopeId}><!--[-->`);
            ssrRenderList(unref(socialMedias), (item) => {
              _push2(`<li${_scopeId}><a${ssrRenderAttr("to", item.link)} target="_blank" class="link link-hover inline-flex space-x-2"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, {
                name: item.icon,
                class: "w-4 h-4"
              }, null, _parent2, _scopeId));
              _push2(`<div class="text-sm"${_scopeId}>${ssrInterpolate(item.label)}</div></a></li>`);
            });
            _push2(`<!--]--></ul></div><div class="flex flex-col space-y-4"${_scopeId}><h4 class="text-base font-semibold"${_scopeId}>${ssrInterpolate(unref($t)("kontak-kami"))}</h4><ul class="space-y-1"${_scopeId}><!--[-->`);
            ssrRenderList(unref(contact), (item) => {
              _push2(`<li${_scopeId}><div class="font-semibold"${_scopeId}>${ssrInterpolate(item.title)}</div><a${ssrRenderAttr("href", item.link)} target="_blank" class="link link-hover inline-flex"${_scopeId}><div class="text-sm"${_scopeId}>${ssrInterpolate(item.label)}</div></a></li>`);
            });
            _push2(`<!--]--></ul></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col w-full space-y-6" }, [
                createVNode("div", { class: "flex flex-col lg:flex-row lg:justify-between space-x-0 lg:space-x-8" }, [
                  createVNode("div", { class: "flex flex-col space-y-4 w-full" }, [
                    createVNode("div", { class: "flex items-center gap-4" }, [
                      createVNode("img", {
                        src: _imports_0,
                        alt: "hi-travel logo white",
                        class: "h-[60px] w-[60px] object-cover"
                      }),
                      createVNode("div", { class: "flex flex-col gap-2 border-l pl-3 border-opacity-20" }, [
                        createVNode("p", null, toDisplayString(unref($t)("bagian-dari")), 1),
                        createVNode("img", {
                          src: _imports_1,
                          alt: "kada-global-logo"
                        })
                      ])
                    ]),
                    createVNode("div", { class: "h-0.5 w-[80%] bg-zinc-300" }),
                    createVNode("div", { class: "flex flex-col gap-2" }, [
                      createTextVNode(toDisplayString(unref($t)("pembayaranmu-aman-dengan")) + " ", 1),
                      createVNode("img", {
                        src: _imports_2,
                        alt: "logo-xendit",
                        class: "w-[100px]"
                      })
                    ])
                  ]),
                  createVNode("div", { class: "max-w-2xl" }, [
                    createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-[1fr_1fr_110px_1fr] gap-6 lg:gap-2" }, [
                      (openBlock(), createBlock(Fragment, null, renderList(links, (link) => {
                        return createVNode("div", {
                          key: link.group,
                          class: "flex flex-col space-y-4"
                        }, [
                          createVNode("h4", { class: "text-base font-semibold" }, toDisplayString(link.group), 1),
                          createVNode("ul", { class: "space-y-1" }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(link.items, (item) => {
                              return openBlock(), createBlock("li", {
                                key: item.label
                              }, [
                                createVNode("a", {
                                  href: item.link,
                                  class: "link link-hover text-sm"
                                }, toDisplayString(item.label), 9, ["href"])
                              ]);
                            }), 128))
                          ])
                        ]);
                      }), 64)),
                      createVNode("div", { class: "flex flex-col space-y-4" }, [
                        createVNode("h4", { class: "text-base font-semibold" }, "Ikuti kami di"),
                        createVNode("ul", { class: "space-y-1" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(socialMedias), (item) => {
                            return openBlock(), createBlock("li", {
                              key: item.label
                            }, [
                              createVNode("a", {
                                to: item.link,
                                target: "_blank",
                                class: "link link-hover inline-flex space-x-2"
                              }, [
                                createVNode(_component_Icon, {
                                  name: item.icon,
                                  class: "w-4 h-4"
                                }, null, 8, ["name"]),
                                createVNode("div", { class: "text-sm" }, toDisplayString(item.label), 1)
                              ], 8, ["to"])
                            ]);
                          }), 128))
                        ])
                      ]),
                      createVNode("div", { class: "flex flex-col space-y-4" }, [
                        createVNode("h4", { class: "text-base font-semibold" }, toDisplayString(unref($t)("kontak-kami")), 1),
                        createVNode("ul", { class: "space-y-1" }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(unref(contact), (item) => {
                            return openBlock(), createBlock("li", {
                              key: item.label
                            }, [
                              createVNode("div", { class: "font-semibold" }, toDisplayString(item.title), 1),
                              createVNode("a", {
                                href: item.link,
                                target: "_blank",
                                class: "link link-hover inline-flex"
                              }, [
                                createVNode("div", { class: "text-sm" }, toDisplayString(item.label), 1)
                              ], 8, ["href"])
                            ]);
                          }), 128))
                        ])
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="h-0.5 w-full"></div>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="h-2 w-full text-center pt-4"${_scopeId}><p class="text-sm"${_scopeId}> \xA9${ssrInterpolate(unref(fullYear))} Hi Transfer Bali. All rights reserved. | Design &amp; Development by <a href="https://spdigitalagency.com" target="_blank"${_scopeId}>s.p. Digital</a></p></div>`);
          } else {
            return [
              createVNode("div", { class: "h-2 w-full text-center pt-4" }, [
                createVNode("p", { class: "text-sm" }, [
                  createTextVNode(" \xA9" + toDisplayString(unref(fullYear)) + " Hi Transfer Bali. All rights reserved. | Design & Development by ", 1),
                  createVNode("a", {
                    href: "https://spdigitalagency.com",
                    target: "_blank"
                  }, "s.p. Digital")
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</footer>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer/Default.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "SectionChat",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/SectionChat.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_5 = _sfc_main$1;
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_Icon = __nuxt_component_0;
  _push(`<div${ssrRenderAttrs(mergeProps({
    href: "https://api.whatsapp.com/send?phone=6282342044966&text=halo",
    class: "fixed bottom-[15px] left-[18px] md:bottom-[25px] md:left-[25px] w-[50px] h-[50px] md:w-[60px] md:h-[60px] bg-primary rounded-full flex items-center justify-center z-[99999]",
    target: "_blank"
  }, _attrs))} data-v-8db13346>`);
  _push(ssrRenderComponent(_component_Icon, {
    name: "ic:baseline-whatsapp",
    class: "text-white w-7 h-7"
  }, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/FloatingWa.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-8db13346"]]);

export { _sfc_main$3 as _, _sfc_main$2 as a, __nuxt_component_5 as b, __nuxt_component_6 as c };
//# sourceMappingURL=FloatingWa-829eb82e.mjs.map
