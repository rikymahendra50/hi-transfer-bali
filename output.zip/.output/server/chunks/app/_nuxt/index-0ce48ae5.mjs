import { _ as __nuxt_component_0 } from './Container-f78810bd.mjs';
import __nuxt_component_0$1 from './Icon-0f6314e3.mjs';
import { _ as __nuxt_component_2 } from './PaginationAdmin-f2cea012.mjs';
import { h as useRequestHelper, e as useRequestOptions, b as useRouter, d as useRoute, f as useI18n, u as useAuth, a as useHead, g as useAsyncData } from '../server.mjs';
import { ref, withAsyncContext, watch, withCtx, unref, isRef, createVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, createCommentVNode, useSSRContext } from 'vue';
import { o as withQuery } from '../../nitro/node-server.mjs';
import { u as useFormatDate } from './useFormatDate-4be124f7.mjs';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderClass, ssrRenderList } from 'vue/server-renderer';
import './config-3cecc2b8.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    useRoute();
    const { locale, t: $t } = useI18n();
    const pageCars = ref(1);
    const pageTours = ref(1);
    ref("Paid");
    const { $logout, $user } = useAuth();
    const { formatDate } = useFormatDate();
    useHead({ title: "User" });
    const currentOrder = ref("order-transport");
    const {
      data: cars,
      error: errorCars,
      refresh: refreshCars
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "cars",
      () => {
        var _a;
        return $fetch(`/users/${(_a = $user.value) == null ? void 0 : _a.uuid}/car-orders?page=${pageCars.value}`, {
          headers: {
            Accept: "application/json"
          },
          method: "get",
          ...requestOptions
        });
      }
    )), __temp = await __temp, __restore(), __temp);
    const {
      data: tours,
      error: errorTours,
      refresh: refreshTours
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "tours",
      () => {
        var _a;
        return $fetch(`/users/${(_a = $user.value) == null ? void 0 : _a.uuid}/tour-orders?page=${pageTours.value}`, {
          headers: {
            Accept: "application/json"
          },
          method: "get",
          ...requestOptions
        });
      }
    )), __temp = await __temp, __restore(), __temp);
    function choseOrder(orderName) {
      currentOrder.value = orderName;
    }
    const changeRoute = async (e, route) => {
      e.preventDefault();
      await useRouter().push(route);
    };
    watch(pageCars, (newValue, oldValue) => {
      if (newValue !== oldValue) {
        replaceWindowCars();
      }
    });
    watch(pageTours, (newValue, oldValue) => {
      if (newValue !== oldValue) {
        replaceWindowTours();
      }
    });
    function replaceWindowCars() {
      router.replace(
        withQuery("/user", {
          pagecars: pageCars.value
        })
      );
      refreshCars();
    }
    function replaceWindowTours() {
      router.replace(
        withQuery("/user", {
          pagetours: pageTours.value
        })
      );
      refreshTours();
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_Icon = __nuxt_component_0$1;
      const _component_PaginationAdmin = __nuxt_component_2;
      _push(`<!--[--><div class="h-44 sm:h-28"></div><div class="w-full border-b">`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R;
          if (_push2) {
            _push2(`<div class="text-black font-semibold text-2xl"${_scopeId}>${ssrInterpolate(unref($t)("order-saya"))}</div><div class="w-fit flex items-center mt-5 rounded-[8px] bg-[#7878801F] bg-opacity-[12%] py-2 px-2 gap-2"${_scopeId}><div class="${ssrRenderClass([{
              "bg-transparent": unref(currentOrder) !== "order-transport",
              "bg-white": unref(currentOrder) === "order-transport"
            }, "py-2 px-14 rounded-[7px] flex items-center cursor-pointer"])}"${_scopeId}><p class="text-black font-semibold text-sm"${_scopeId}>${ssrInterpolate(unref($t)("transport"))}</p></div><div class="${ssrRenderClass([{
              "bg-transparent": unref(currentOrder) !== "order-tourpackage",
              "bg-white": unref(currentOrder) === "order-tourpackage"
            }, "py-2 px-14 rounded-[7px] flex items-center cursor-pointer"])}"${_scopeId}><p class="text-black font-semibold text-sm"${_scopeId}>${ssrInterpolate(unref($t)("paket-tour"))}</p></div></div>`);
            if (unref(currentOrder) === "order-transport") {
              _push2(`<div class="overflow-x-auto rounded-lg mt-5 bg-white mb-5 md:w-[100%]"${_scopeId}><table class="table table-xs md:table-md md:w-full rounded-t-xl table-fixed w-[500px]"${_scopeId}><thead class="h-12"${_scopeId}><tr${_scopeId}><th class="font-medium text-[#667085] bg-[#FCFCFD] whitespace-nowrap w-[200px]"${_scopeId}> Booking ID </th><th class="font-medium text-[#667085] bg-[#FCFCFD] w-[200px]"${_scopeId}>${ssrInterpolate(unref($t)("destinasi"))}</th><th class="font-medium text-[#667085] bg-[#FCFCFD] w-[200px]"${_scopeId}> Type </th><th class="font-medium text-[#667085] bg-[#FCFCFD] w-[200px]"${_scopeId}>${ssrInterpolate(unref($t)("date"))}</th><th class="font-medium text-[#667085] bg-[#FCFCFD] w-[200px]"${_scopeId}>${ssrInterpolate(unref($t)("pricing"))}</th><th class="font-medium text-[#667085] bg-[#FCFCFD] w-[200px]"${_scopeId}>${ssrInterpolate(unref($t)("order-status"))}</th></tr></thead><tbody${_scopeId}><!--[-->`);
              ssrRenderList((_a = unref(cars)) == null ? void 0 : _a.data, (item) => {
                _push2(`<tr class="last:border-b transition-colors duration-300 my-2 cursor-pointer"${_scopeId}><td${_scopeId}><div class=""${_scopeId}>#${ssrInterpolate(item.uuid)}</div></td><td${_scopeId}><div class="font-semibold"${_scopeId}>${ssrInterpolate(item.destination)}</div></td><td${_scopeId}><div class="font-semibold"${_scopeId}>${ssrInterpolate(item.type)}</div></td><td${_scopeId}><div class=""${_scopeId}>${ssrInterpolate(unref(formatDate)(item.activity_date))} ${ssrInterpolate("-")} ${ssrInterpolate(unref(formatDate)(item.return_date))}</div></td><td${_scopeId}><div class=""${_scopeId}>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(item.grand_total_purchased))}</div></td><td${_scopeId}><div class="${ssrRenderClass([{
                  "bg-[#22C55E] text-[#22C55E]": item.status === "paid",
                  "bg-[#EF4444] bg-opacity-[12%] text-error": item.status !== "paid",
                  "bg-[#ffe922] text-black": item.status == "waiting_for_payment"
                }, "flex items-center gap-1 bg-opacity-10 w-fit px-3 py-1 rounded-[16px]"])}"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_Icon, { name: "icon-park-outline:dot" }, null, _parent2, _scopeId));
                _push2(`<p class="font-medium text-[12px]"${_scopeId}>${ssrInterpolate(item.status)}</p></div></td></tr>`);
              });
              _push2(`<!--]--></tbody></table><div class="flex flex-col md:flex-row items-center justify-between gap-3 w-full py-3 px-3"${_scopeId}><div class="flex items-center gap-3"${_scopeId}><div class="py-2 px-3 rounded-[8px]"${_scopeId}><p class="font-medium text-[12px] md:text-sm text-[#121212]"${_scopeId}>${ssrInterpolate((_c = (_b = unref(cars)) == null ? void 0 : _b.meta) == null ? void 0 : _c.from)} - ${ssrInterpolate((_e = (_d = unref(cars)) == null ? void 0 : _d.meta) == null ? void 0 : _e.to)} of ${ssrInterpolate((_g = (_f = unref(cars)) == null ? void 0 : _f.meta) == null ? void 0 : _g.total)} data </p></div></div><div class="font-medium text-[14px] text-[#344054] flex items-center gap-3"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_PaginationAdmin, {
                modelValue: unref(pageCars),
                "onUpdate:modelValue": ($event) => isRef(pageCars) ? pageCars.value = $event : null,
                total: (_i = (_h = unref(cars)) == null ? void 0 : _h.meta) == null ? void 0 : _i.total,
                includeFirstLast: false,
                "per-page": (_k = (_j = unref(cars)) == null ? void 0 : _j.meta) == null ? void 0 : _k.per_page,
                class: "flex justify-center"
              }, null, _parent2, _scopeId));
              _push2(`</div></div></div>`);
            } else if (unref(currentOrder) === "order-tourpackage") {
              _push2(`<div class="overflow-x-auto border rounded-lg mt-5 bg-white mb-5 md:w-[100%]"${_scopeId}><table class="table table-xs md:table-md md:w-full rounded-t-xl table-fixed w-[500px]"${_scopeId}><thead class="h-12"${_scopeId}><tr${_scopeId}><th class="font-medium text-[#667085] bg-[#FCFCFD] whitespace-nowrap w-[200px]"${_scopeId}> Booking ID </th><th class="font-medium text-[#667085] bg-[#FCFCFD] w-[200px]"${_scopeId}>${ssrInterpolate(unref($t)("destinasi"))}</th><th class="font-medium text-[#667085] bg-[#FCFCFD] w-[200px]"${_scopeId}>${ssrInterpolate(unref($t)("tanggal-keberangkatan"))}</th><th class="font-medium text-[#667085] bg-[#FCFCFD] w-[200px]"${_scopeId}>${ssrInterpolate(unref($t)("pricing"))}</th><th class="font-medium text-[#667085] bg-[#FCFCFD] w-[200px]"${_scopeId}>${ssrInterpolate(unref($t)("order-status"))}</th></tr></thead><tbody${_scopeId}><!--[-->`);
              ssrRenderList((_l = unref(tours)) == null ? void 0 : _l.data, (item) => {
                _push2(`<tr class="last:border-b transition-colors duration-300 my-2 cursor-pointer"${_scopeId}><td${_scopeId}><div class=""${_scopeId}>#${ssrInterpolate(item.uuid)}</div></td><td${_scopeId}><div class="line-clamp-2 font-semibold"${_scopeId}>${ssrInterpolate(item == null ? void 0 : item.product_thumbnail.name)}</div></td><td${_scopeId}><div class=""${_scopeId}>${ssrInterpolate(unref(formatDate)(item.activity_date))}</div></td><td${_scopeId}><div class=""${_scopeId}>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(item.grand_total_purchased))}</div></td><td${_scopeId}><div class="${ssrRenderClass([{
                  "bg-[#22C55E] text-[#22C55E]": item.status == "paid",
                  "bg-[#EF4444] bg-opacity-[12%] text-error": item.status !== "paid",
                  "bg-[#ffe922] text-black": item.status == "waiting_for_payment"
                }, "flex items-center gap-1 bg-opacity-10 w-fit px-3 py-1 rounded-[16px]"])}"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_Icon, { name: "icon-park-outline:dot" }, null, _parent2, _scopeId));
                _push2(`<p class="font-medium text-[12px]"${_scopeId}>${ssrInterpolate(item.status)}</p></div></td></tr>`);
              });
              _push2(`<!--]--></tbody></table><div class="flex flex-col md:flex-row items-center justify-between gap-3 w-full py-3 px-3"${_scopeId}><div class="flex items-center gap-3"${_scopeId}><div class="py-2 px-3 rounded-[8px]"${_scopeId}><p class="font-medium text-[12px] md:text-sm text-[#121212]"${_scopeId}>${ssrInterpolate((_n = (_m = unref(tours)) == null ? void 0 : _m.meta) == null ? void 0 : _n.from)} - ${ssrInterpolate((_p = (_o = unref(tours)) == null ? void 0 : _o.meta) == null ? void 0 : _p.to)} of ${ssrInterpolate((_r = (_q = unref(tours)) == null ? void 0 : _q.meta) == null ? void 0 : _r.total)} item </p></div></div><div class="font-medium text-[14px] text-[#344054] flex items-center gap-3"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_PaginationAdmin, {
                modelValue: unref(pageTours),
                "onUpdate:modelValue": ($event) => isRef(pageTours) ? pageTours.value = $event : null,
                total: (_t = (_s = unref(tours)) == null ? void 0 : _s.meta) == null ? void 0 : _t.total,
                includeFirstLast: false,
                "per-page": (_v = (_u = unref(tours)) == null ? void 0 : _u.meta) == null ? void 0 : _v.per_page,
                class: "flex justify-center"
              }, null, _parent2, _scopeId));
              _push2(`</div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              createVNode("div", { class: "text-black font-semibold text-2xl" }, toDisplayString(unref($t)("order-saya")), 1),
              createVNode("div", { class: "w-fit flex items-center mt-5 rounded-[8px] bg-[#7878801F] bg-opacity-[12%] py-2 px-2 gap-2" }, [
                createVNode("div", {
                  class: ["py-2 px-14 rounded-[7px] flex items-center cursor-pointer", {
                    "bg-transparent": unref(currentOrder) !== "order-transport",
                    "bg-white": unref(currentOrder) === "order-transport"
                  }],
                  onClick: ($event) => choseOrder("order-transport")
                }, [
                  createVNode("p", { class: "text-black font-semibold text-sm" }, toDisplayString(unref($t)("transport")), 1)
                ], 10, ["onClick"]),
                createVNode("div", {
                  class: ["py-2 px-14 rounded-[7px] flex items-center cursor-pointer", {
                    "bg-transparent": unref(currentOrder) !== "order-tourpackage",
                    "bg-white": unref(currentOrder) === "order-tourpackage"
                  }],
                  onClick: ($event) => choseOrder("order-tourpackage")
                }, [
                  createVNode("p", { class: "text-black font-semibold text-sm" }, toDisplayString(unref($t)("paket-tour")), 1)
                ], 10, ["onClick"])
              ]),
              unref(currentOrder) === "order-transport" ? (openBlock(), createBlock("div", {
                key: 0,
                class: "overflow-x-auto rounded-lg mt-5 bg-white mb-5 md:w-[100%]"
              }, [
                createVNode("table", { class: "table table-xs md:table-md md:w-full rounded-t-xl table-fixed w-[500px]" }, [
                  createVNode("thead", { class: "h-12" }, [
                    createVNode("tr", null, [
                      createVNode("th", { class: "font-medium text-[#667085] bg-[#FCFCFD] whitespace-nowrap w-[200px]" }, " Booking ID "),
                      createVNode("th", { class: "font-medium text-[#667085] bg-[#FCFCFD] w-[200px]" }, toDisplayString(unref($t)("destinasi")), 1),
                      createVNode("th", { class: "font-medium text-[#667085] bg-[#FCFCFD] w-[200px]" }, " Type "),
                      createVNode("th", { class: "font-medium text-[#667085] bg-[#FCFCFD] w-[200px]" }, toDisplayString(unref($t)("date")), 1),
                      createVNode("th", { class: "font-medium text-[#667085] bg-[#FCFCFD] w-[200px]" }, toDisplayString(unref($t)("pricing")), 1),
                      createVNode("th", { class: "font-medium text-[#667085] bg-[#FCFCFD] w-[200px]" }, toDisplayString(unref($t)("order-status")), 1)
                    ])
                  ]),
                  createVNode("tbody", null, [
                    (openBlock(true), createBlock(Fragment, null, renderList((_w = unref(cars)) == null ? void 0 : _w.data, (item) => {
                      return openBlock(), createBlock("tr", {
                        class: "last:border-b transition-colors duration-300 my-2 cursor-pointer",
                        onClick: ($event) => changeRoute(
                          $event,
                          `/user/order/order-summary/car/${item.uuid}`
                        ),
                        key: item.id
                      }, [
                        createVNode("td", null, [
                          createVNode("div", { class: "" }, "#" + toDisplayString(item.uuid), 1)
                        ]),
                        createVNode("td", null, [
                          createVNode("div", { class: "font-semibold" }, toDisplayString(item.destination), 1)
                        ]),
                        createVNode("td", null, [
                          createVNode("div", { class: "font-semibold" }, toDisplayString(item.type), 1)
                        ]),
                        createVNode("td", null, [
                          createVNode("div", { class: "" }, toDisplayString(unref(formatDate)(item.activity_date)) + " " + toDisplayString("-") + " " + toDisplayString(unref(formatDate)(item.return_date)), 1)
                        ]),
                        createVNode("td", null, [
                          createVNode("div", { class: "" }, toDisplayString(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(item.grand_total_purchased)), 1)
                        ]),
                        createVNode("td", null, [
                          createVNode("div", {
                            class: ["flex items-center gap-1 bg-opacity-10 w-fit px-3 py-1 rounded-[16px]", {
                              "bg-[#22C55E] text-[#22C55E]": item.status === "paid",
                              "bg-[#EF4444] bg-opacity-[12%] text-error": item.status !== "paid",
                              "bg-[#ffe922] text-black": item.status == "waiting_for_payment"
                            }]
                          }, [
                            createVNode(_component_Icon, { name: "icon-park-outline:dot" }),
                            createVNode("p", { class: "font-medium text-[12px]" }, toDisplayString(item.status), 1)
                          ], 2)
                        ])
                      ], 8, ["onClick"]);
                    }), 128))
                  ])
                ]),
                createVNode("div", { class: "flex flex-col md:flex-row items-center justify-between gap-3 w-full py-3 px-3" }, [
                  createVNode("div", { class: "flex items-center gap-3" }, [
                    createVNode("div", { class: "py-2 px-3 rounded-[8px]" }, [
                      createVNode("p", { class: "font-medium text-[12px] md:text-sm text-[#121212]" }, toDisplayString((_y = (_x = unref(cars)) == null ? void 0 : _x.meta) == null ? void 0 : _y.from) + " - " + toDisplayString((_A = (_z = unref(cars)) == null ? void 0 : _z.meta) == null ? void 0 : _A.to) + " of " + toDisplayString((_C = (_B = unref(cars)) == null ? void 0 : _B.meta) == null ? void 0 : _C.total) + " data ", 1)
                    ])
                  ]),
                  createVNode("div", { class: "font-medium text-[14px] text-[#344054] flex items-center gap-3" }, [
                    createVNode(_component_PaginationAdmin, {
                      modelValue: unref(pageCars),
                      "onUpdate:modelValue": ($event) => isRef(pageCars) ? pageCars.value = $event : null,
                      total: (_E = (_D = unref(cars)) == null ? void 0 : _D.meta) == null ? void 0 : _E.total,
                      includeFirstLast: false,
                      "per-page": (_G = (_F = unref(cars)) == null ? void 0 : _F.meta) == null ? void 0 : _G.per_page,
                      class: "flex justify-center"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "total", "per-page"])
                  ])
                ])
              ])) : unref(currentOrder) === "order-tourpackage" ? (openBlock(), createBlock("div", {
                key: 1,
                class: "overflow-x-auto border rounded-lg mt-5 bg-white mb-5 md:w-[100%]"
              }, [
                createVNode("table", { class: "table table-xs md:table-md md:w-full rounded-t-xl table-fixed w-[500px]" }, [
                  createVNode("thead", { class: "h-12" }, [
                    createVNode("tr", null, [
                      createVNode("th", { class: "font-medium text-[#667085] bg-[#FCFCFD] whitespace-nowrap w-[200px]" }, " Booking ID "),
                      createVNode("th", { class: "font-medium text-[#667085] bg-[#FCFCFD] w-[200px]" }, toDisplayString(unref($t)("destinasi")), 1),
                      createVNode("th", { class: "font-medium text-[#667085] bg-[#FCFCFD] w-[200px]" }, toDisplayString(unref($t)("tanggal-keberangkatan")), 1),
                      createVNode("th", { class: "font-medium text-[#667085] bg-[#FCFCFD] w-[200px]" }, toDisplayString(unref($t)("pricing")), 1),
                      createVNode("th", { class: "font-medium text-[#667085] bg-[#FCFCFD] w-[200px]" }, toDisplayString(unref($t)("order-status")), 1)
                    ])
                  ]),
                  createVNode("tbody", null, [
                    (openBlock(true), createBlock(Fragment, null, renderList((_H = unref(tours)) == null ? void 0 : _H.data, (item) => {
                      return openBlock(), createBlock("tr", {
                        class: "last:border-b transition-colors duration-300 my-2 cursor-pointer",
                        onClick: ($event) => changeRoute(
                          $event,
                          `/user/order/order-summary/tour/${item.uuid}`
                        ),
                        key: item.id
                      }, [
                        createVNode("td", null, [
                          createVNode("div", { class: "" }, "#" + toDisplayString(item.uuid), 1)
                        ]),
                        createVNode("td", null, [
                          createVNode("div", { class: "line-clamp-2 font-semibold" }, toDisplayString(item == null ? void 0 : item.product_thumbnail.name), 1)
                        ]),
                        createVNode("td", null, [
                          createVNode("div", { class: "" }, toDisplayString(unref(formatDate)(item.activity_date)), 1)
                        ]),
                        createVNode("td", null, [
                          createVNode("div", { class: "" }, toDisplayString(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(item.grand_total_purchased)), 1)
                        ]),
                        createVNode("td", null, [
                          createVNode("div", {
                            class: ["flex items-center gap-1 bg-opacity-10 w-fit px-3 py-1 rounded-[16px]", {
                              "bg-[#22C55E] text-[#22C55E]": item.status == "paid",
                              "bg-[#EF4444] bg-opacity-[12%] text-error": item.status !== "paid",
                              "bg-[#ffe922] text-black": item.status == "waiting_for_payment"
                            }]
                          }, [
                            createVNode(_component_Icon, { name: "icon-park-outline:dot" }),
                            createVNode("p", { class: "font-medium text-[12px]" }, toDisplayString(item.status), 1)
                          ], 2)
                        ])
                      ], 8, ["onClick"]);
                    }), 128))
                  ])
                ]),
                createVNode("div", { class: "flex flex-col md:flex-row items-center justify-between gap-3 w-full py-3 px-3" }, [
                  createVNode("div", { class: "flex items-center gap-3" }, [
                    createVNode("div", { class: "py-2 px-3 rounded-[8px]" }, [
                      createVNode("p", { class: "font-medium text-[12px] md:text-sm text-[#121212]" }, toDisplayString((_J = (_I = unref(tours)) == null ? void 0 : _I.meta) == null ? void 0 : _J.from) + " - " + toDisplayString((_L = (_K = unref(tours)) == null ? void 0 : _K.meta) == null ? void 0 : _L.to) + " of " + toDisplayString((_N = (_M = unref(tours)) == null ? void 0 : _M.meta) == null ? void 0 : _N.total) + " item ", 1)
                    ])
                  ]),
                  createVNode("div", { class: "font-medium text-[14px] text-[#344054] flex items-center gap-3" }, [
                    createVNode(_component_PaginationAdmin, {
                      modelValue: unref(pageTours),
                      "onUpdate:modelValue": ($event) => isRef(pageTours) ? pageTours.value = $event : null,
                      total: (_P = (_O = unref(tours)) == null ? void 0 : _O.meta) == null ? void 0 : _P.total,
                      includeFirstLast: false,
                      "per-page": (_R = (_Q = unref(tours)) == null ? void 0 : _Q.meta) == null ? void 0 : _R.per_page,
                      class: "flex justify-center"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "total", "per-page"])
                  ])
                ])
              ])) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-0ce48ae5.mjs.map
