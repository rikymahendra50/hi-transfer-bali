function __unimport_FormatMoneyDash(price, currency = "IDR") {
  var _a;
  if (!price)
    return;
  const [start, end] = price.split(" - ").map(parseFloat);
  if (start && end) {
    let formattedStart = start == null ? void 0 : start.toLocaleString(setCountryCurrency(currency), {
      style: "currency",
      currency
    });
    let formattedEnd = end == null ? void 0 : end.toLocaleString(setCountryCurrency(currency), {
      style: "currency",
      currency
    });
    return `${replaceCurrencySymbol(
      formattedStart,
      currency
    )} - ${replaceCurrencySymbol(formattedEnd, currency)}`;
  }
  if (isNaN(parseInt(price))) {
    return "-";
  }
  let formatted = (_a = parseFloat(price)) == null ? void 0 : _a.toLocaleString(
    setCountryCurrency(currency),
    { style: "currency", currency }
  );
  return replaceCurrencySymbol(formatted, currency);
}
function setCountryCurrency(currency = "IDR") {
  switch (currency) {
    case "IDR":
      return "id-ID";
    case "USD":
      return "en-US";
    case "JPY":
      return "ja-JP";
    case "CNY":
      return "zh-CN";
    default:
      return "id-ID";
  }
}
function replaceCurrencySymbol(formattedString, currency) {
  switch (currency) {
    case "IDR":
      return formattedString.replace("Rp", "IDR");
    case "USD":
      return formattedString.replace("$", "USD");
    case "JPY":
      return formattedString.replace("\xA5", "JPY");
    case "CNY":
      return formattedString.replace("\xA5", "CNY");
    default:
      return formattedString;
  }
}

export { __unimport_FormatMoneyDash as _ };
//# sourceMappingURL=FormatMoneyDash-4b79c187.mjs.map
