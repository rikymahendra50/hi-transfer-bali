import { h as defineStore, b as useAuth, s as storeToRefs, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_1 from './Icon-7218f0f6.mjs';
import { useSSRContext, ref, defineComponent, watch, withCtx, createVNode, unref, toDisplayString, computed, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderSlot, ssrRenderTeleport } from 'vue/server-renderer';
import { _ as _imports_0, a as __nuxt_component_3 } from './hi-transfer-logo-b59d4475.mjs';
import { a as useBreakpoints, b as breakpointsTailwind, o as onClickOutside } from './index-1df0d9ef.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-aab100d3.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "NotificationItem",
  __ssrInlineRender: true,
  props: {
    notification: {},
    timer: {}
  },
  emits: ["close", "update:timer"],
  setup(__props, { emit }) {
    const props = __props;
    const interfallMaxClose = computed({
      get() {
        return props.timer;
      },
      set(value) {
        emit("update:timer", value);
      }
    });
    const alertClass = computed(() => {
      switch (props.notification.type) {
        case "success":
          return "alert-success";
        case "error":
          return "alert-error";
        case "warning":
          return "alert-warning";
        case "info":
          return "alert-info";
      }
    });
    function countdown() {
      const interval = setInterval(() => {
        if (interfallMaxClose.value === 0) {
          close();
          clearInterval(interval);
        } else {
          interfallMaxClose.value--;
        }
      }, 100);
    }
    function close() {
      emit("close");
    }
    watch(
      () => props.notification.id,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          countdown();
        }
      },
      { immediate: false }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["alert flex flex-col", unref(alertClass)]
      }, _attrs))}><div class="flex flex-row flex-grow mx-auto min-w-[200px] space-x-2"><div class="w-full flex flex-col flex-grow">`);
      if (props.notification.title) {
        _push(`<strong class="tracking-wide">${ssrInterpolate(props.notification.title)}</strong>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<span class="max-w-[300px] whitespace-pre-wrap leading-4 tracking-normal text-left">${ssrInterpolate(props.notification.text)}</span></div><div class="w-6 h-6 p-0.5 flex items-center justify-center hover:bg-white rounded-full transition-all duration-300" role="button">`);
      _push(ssrRenderComponent(_component_Icon, { name: "i-heroicons-x-circle" }, null, _parent));
      _push(`</div></div><progress class="progress bg-white !h-0.5 transition duration-500 ease-out"${ssrRenderAttr("value", unref(interfallMaxClose))} min="0" max="60"></progress></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/NotificationItem.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const useNotification = defineStore("Notification", () => {
  const messages = ref([]);
  function pushNotification(notification) {
    messages.value.push({
      id: (/* @__PURE__ */ new Date()).getTime(),
      ...notification,
      timer: 60
    });
  }
  function clearNotification() {
    messages.value = [];
  }
  return {
    messages,
    pushNotification,
    clearNotification
  };
});
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Notification",
  __ssrInlineRender: true,
  setup(__props) {
    const store = useNotification();
    const { messages } = storeToRefs(store);
    function closeByID(id) {
      messages.value = [...messages.value.filter((message) => message.id !== id)];
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UINotificationItem = _sfc_main$2;
      ssrRenderTeleport(_push, (_push2) => {
        if (unref(messages).length) {
          _push2(`<div class="toast toast-top toast-end !z-[9999] p-2"><!--[-->`);
          ssrRenderList(unref(messages), (notification, index) => {
            _push2(ssrRenderComponent(_component_UINotificationItem, {
              key: index,
              notification,
              timer: notification.timer,
              "onUpdate:timer": ($event) => notification.timer = $event,
              onClose: ($event) => closeByID(notification.id)
            }, null, _parent));
          });
          _push2(`<!--]--></div>`);
        } else {
          _push2(`<!---->`);
        }
      }, "body", false, _parent);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Notification.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "admin",
  __ssrInlineRender: true,
  setup(__props) {
    const links = ref([
      {
        title: "Orders",
        links: [
          {
            to: "/admin",
            label: "Orders",
            icon: "bx:list-ol"
          }
        ]
      },
      {
        title: "Products",
        links: [
          {
            to: "/admin/transport",
            label: "Transport",
            icon: "ic:round-directions-car"
          },
          {
            to: "/admin/tours",
            label: "Tour Activities",
            icon: "icon-park-outline:beach-umbrella"
          }
        ]
      },
      {
        title: "Locations",
        links: [
          {
            to: "/admin/locations",
            label: "Locations",
            icon: "ph:map-pin-line"
          }
        ]
      },
      {
        title: "Promo",
        links: [
          {
            to: "/admin/promo",
            label: "Promo",
            icon: "heroicons:receipt-percent"
          }
        ]
      },
      {
        title: "Others",
        links: [
          {
            to: "/admin/blog",
            label: "Blog",
            icon: "heroicons:newspaper"
          }
        ]
      },
      {
        title: "Users",
        links: [
          {
            to: "/admin/users",
            label: "Users",
            icon: "i-heroicons-user-group"
          },
          {
            to: "/admin/users/admins",
            label: "Admins",
            icon: "i-heroicons-user-group"
          }
        ]
      }
    ]);
    const breakpoints = useBreakpoints(breakpointsTailwind);
    useAuth();
    const drawer = ref(true);
    const tableOrLaptop = breakpoints.greater("md");
    const aside = ref();
    onClickOutside(aside, () => {
      if (!tableOrLaptop.value && drawer.value)
        drawer.value = false;
    });
    watch(() => tableOrLaptop.value, (value) => {
      if (value && !drawer.value) {
        drawer.value = tableOrLaptop.value;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_1;
      const _component_UINotification = _sfc_main$1;
      const _component_ClientOnly = __nuxt_component_3;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class=""><div class="px-6 h-24 border-b flex flex-row items-center">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "link link-primary-dark-full link-hover p-1 underline-offset-8 decoration-4 rounded",
        "active-class": "font-medium",
        to: "/admin"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="logo" class="w-11 h-11"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                alt: "logo",
                class: "w-11 h-11"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      if (!unref(drawer)) {
        _push(`<button class="block lg:hidden" type="button">`);
        _push(ssrRenderComponent(_component_Icon, {
          name: "i-heroicons-bars-3",
          class: "w-6 h-6 opacity-50"
        }, null, _parent));
        _push(`</button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="relative lg:static lg:grid lg:grid-cols-[300px_1fr]">`);
      if (unref(drawer)) {
        _push(`<aside class="absolute lg:static z-50 lg:z-0 min-h-screen w-[300px] border-r bg-white"><div class="flex flex-col h-full"><div class="p-4 flex-grow flex-shrink h-full space-y-8 max-h-screen overflow-y-auto scrollbar-thin scroll-smooth"><!--[-->`);
        ssrRenderList(unref(links), (link) => {
          _push(`<div class="space-y-2"><h4 class="font-semibold text-zinc-400">${ssrInterpolate(link.title)}</h4><ul class="space-y-2 lg:space-y-3.5"><!--[-->`);
          ssrRenderList(link.links, (itemChild) => {
            _push(`<li>`);
            _push(ssrRenderComponent(_component_NuxtLink, {
              to: itemChild.to,
              class: "inline-flex ring-1 ring-zinc-300 ring-offset-1 items-center space-x-2.5 hover:bg-primary-dark-full hover:ring-primary-dark-full text-zinc-400 hover:text-white transition-all duration-500 p-3 rounded-lg group w-full hover:scale-x-95 text-sm",
              "active-class": "bg-primary !text-white !ring-primary",
              "exact-active-class": "bg-primary-dark-full !text-white !ring-primary-dark-full"
            }, {
              default: withCtx((_, _push2, _parent2, _scopeId) => {
                if (_push2) {
                  _push2(ssrRenderComponent(_component_Icon, {
                    name: itemChild.icon,
                    class: "h-5 w-5 opacity-80"
                  }, null, _parent2, _scopeId));
                  _push2(`<span class="text-sm"${_scopeId}>${ssrInterpolate(itemChild.label)}</span>`);
                } else {
                  return [
                    createVNode(_component_Icon, {
                      name: itemChild.icon,
                      class: "h-5 w-5 opacity-80"
                    }, null, 8, ["name"]),
                    createVNode("span", { class: "text-sm" }, toDisplayString(itemChild.label), 1)
                  ];
                }
              }),
              _: 2
            }, _parent));
            _push(`</li>`);
          });
          _push(`<!--]--></ul></div>`);
        });
        _push(`<!--]--></div><div class="mb-16 px-4 mt-10"><div class="border-t py-2"><button type="button" class="flex flex-row space-x-2 items-center text-red-500 font-medium">`);
        _push(ssrRenderComponent(_component_Icon, {
          name: "ic:baseline-logout",
          class: "w-6 h-6"
        }, null, _parent));
        _push(`<span>Logout</span></button></div></div></div></aside>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="w-full absolute lg:static min-h-svh overflow-y-auto space-y-6"><main>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</main>`);
      _push(ssrRenderComponent(_component_UINotification, null, null, _parent));
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/admin.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=admin-aa78f4b5.mjs.map
