import { defineComponent, ref, computed, watch, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderAttr, ssrRenderClass } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "InputOTP",
  __ssrInlineRender: true,
  props: {
    inputLength: {
      type: Number,
      default: () => 6
    },
    modelValue: {
      type: [String, Number]
    },
    isError: {
      type: Boolean,
      default: false
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit }) {
    const prop = __props;
    ref([]);
    const length = computed(() => prop.inputLength);
    const fieldValues = ref([]);
    const composite = computed(() => {
      const nonNullFields = fieldValues.value.filter((value) => value);
      if (length.value !== nonNullFields.length) {
        return "";
      }
      return nonNullFields.join("");
    });
    watch(composite, () => {
      if (composite.value) {
        emit("update:modelValue", composite.value);
      } else {
        emit("update:modelValue", "");
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "inline-flex space-x-2.5" }, _attrs))}><!--[-->`);
      ssrRenderList(unref(length), (i) => {
        _push(`<input type="text"${ssrRenderAttr("value", unref(fieldValues)[i - 1])} class="${ssrRenderClass([{ "input-error": __props.isError }, "input input-bordered h-14 px-3.5"])}" maxlength="1">`);
      });
      _push(`<!--]--></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/InputOTP.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=InputOTP-bbb2b053.mjs.map
