import { _ as __nuxt_component_0 } from './Container-afb1bf23.mjs';
import { _ as _sfc_main$2 } from './Btn-577fa59f.mjs';
import __nuxt_component_1 from './Icon-9a1ee2a3.mjs';
import { _ as _sfc_main$3 } from './AddressInformation-3373b627.mjs';
import { Form } from 'vee-validate';
import { _ as _sfc_main$5 } from './MGroup-560eed6a.mjs';
import { _ as _sfc_main$6 } from './MTextField-bd75102a.mjs';
import { useSSRContext, ref, withCtx, unref, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, createCommentVNode, defineComponent, watch } from 'vue';
import { f as useHead, u as useRequestHelper, a as useRequestOptions, b as useRouter, d as useRoute, e as useI18n, m as useAuth } from '../server.mjs';
import { u as useSchema } from './useSchema-f211c259.mjs';
import { u as useTourForm } from './useCarStore-af843668.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttrs } from 'vue/server-renderer';
import { _ as _sfc_main$4 } from './SelectedCard-939884a9.mjs';
import 'clsx';
import './config-71e93c9c.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'zod';
import '@vee-validate/zod';
import './nofication-176ebe9f.mjs';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "OrdererForm",
  __ssrInlineRender: true,
  props: {
    name: {
      type: String,
      required: false
    },
    email: {
      type: String,
      required: false
    },
    phone: {
      type: [String, Number],
      required: false
    }
  },
  emits: ["update:name", "update:email", "update:phone"],
  setup(__props, { emit }) {
    const props = __props;
    useRouter();
    useSchema();
    useTourForm({
      callback: () => {
        alert("Form has been submitted!");
      }
    });
    const dataFormProfile = ref({
      name: props.name,
      email: props.email,
      phone: props.phone
    });
    watch(
      () => props.name,
      (newName) => {
        dataFormProfile.value.name = newName;
      }
    );
    watch(
      () => props.email,
      (newEmail) => {
        dataFormProfile.value.email = newEmail;
      }
    );
    watch(
      () => props.phone,
      (newPhone) => {
        dataFormProfile.value.phone = newPhone;
      }
    );
    function onSubmit() {
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIFormMGroup = _sfc_main$5;
      const _component_UIFormMTextField = _sfc_main$6;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_VeeForm, { onSubmit }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="space-y-4 p-4 border rounded-xl"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "name",
              label: "Nama Lengkap"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: unref(dataFormProfile).name,
                    "onUpdate:modelValue": ($event) => unref(dataFormProfile).name = $event,
                    name: "name",
                    class: "input-bordered",
                    placeholder: "Ketik Nama Lengkap Anda"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref(dataFormProfile).name,
                      "onUpdate:modelValue": ($event) => unref(dataFormProfile).name = $event,
                      name: "name",
                      class: "input-bordered",
                      placeholder: "Ketik Nama Lengkap Anda"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "email",
              label: "Email"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: unref(dataFormProfile).email,
                    "onUpdate:modelValue": ($event) => unref(dataFormProfile).email = $event,
                    name: "email",
                    class: "input-bordered",
                    placeholder: "Ketik Email Anda"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref(dataFormProfile).email,
                      "onUpdate:modelValue": ($event) => unref(dataFormProfile).email = $event,
                      name: "email",
                      class: "input-bordered",
                      placeholder: "Ketik Email Anda"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "phone",
              label: "Nomor Telepon"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: unref(dataFormProfile).phone,
                    "onUpdate:modelValue": ($event) => unref(dataFormProfile).phone = $event,
                    name: "phone",
                    class: "input-bordered",
                    placeholder: "Ketik Nomor Telepon"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref(dataFormProfile).phone,
                      "onUpdate:modelValue": ($event) => unref(dataFormProfile).phone = $event,
                      name: "phone",
                      class: "input-bordered",
                      placeholder: "Ketik Nomor Telepon"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="hidden"${_scopeId}><button type="submit"${_scopeId}>submit</button></div></div>`);
          } else {
            return [
              createVNode("div", { class: "space-y-4 p-4 border rounded-xl" }, [
                createVNode(_component_UIFormMGroup, {
                  name: "name",
                  label: "Nama Lengkap"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref(dataFormProfile).name,
                      "onUpdate:modelValue": ($event) => unref(dataFormProfile).name = $event,
                      name: "name",
                      class: "input-bordered",
                      placeholder: "Ketik Nama Lengkap Anda"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  name: "email",
                  label: "Email"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref(dataFormProfile).email,
                      "onUpdate:modelValue": ($event) => unref(dataFormProfile).email = $event,
                      name: "email",
                      class: "input-bordered",
                      placeholder: "Ketik Email Anda"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  name: "phone",
                  label: "Nomor Telepon"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref(dataFormProfile).phone,
                      "onUpdate:modelValue": ($event) => unref(dataFormProfile).phone = $event,
                      name: "phone",
                      class: "input-bordered",
                      placeholder: "Ketik Nomor Telepon"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode("div", { class: "hidden" }, [
                  createVNode("button", {
                    ref: "internalSubmit",
                    type: "submit"
                  }, "submit", 512)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vehicle/OrdererForm.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "booking",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Booking Detail"
    });
    ref({
      sort: ""
    });
    useRequestHelper();
    useRequestOptions();
    const router = useRouter();
    useRoute();
    const { locale, t: $t } = useI18n();
    useAuth();
    ref("");
    ref("");
    useHead({
      title: "Vehicle"
    });
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedCarData,
      clearSavedCarData
    } = useTourForm({
      callback: () => {
        alert("Form has been submitted!");
      }
    });
    const vehicleForm = ref(null);
    const dataFormT = ref({
      user_uuid: void 0,
      name: void 0,
      email: void 0,
      phone: void 0
    });
    function submitFormT() {
      vehicleForm.value.$refs.internalSubmit.click();
      dataForm.value.user_uuid = dataFormT.value.user_uuid;
      dataForm.value.name = dataFormT.value.name;
      dataForm.value.email = dataFormT.value.email;
      dataForm.value.phone = dataFormT.value.phone;
      saveFormData();
      router.push("/vehicles/checkout");
    }
    function goToHomePage() {
      clearSavedCarData();
      router.push({ path: "/?cars" });
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_UIBtn = _sfc_main$2;
      const _component_Icon = __nuxt_component_1;
      const _component_VehicleAddressInformation = _sfc_main$3;
      const _component_VehicleOrdererForm = _sfc_main$1;
      const _component_VehicleSelectedCard = _sfc_main$4;
      _push(`<!--[--><div class="h-28"></div><div class="w-full border-b">`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              onClick: goToHomePage,
              variant: "primary",
              outlined: "",
              class: "whitespace-nowrap"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref($t)("kembali-ke-beranda"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref($t)("kembali-ke-beranda")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
            if (unref(dataForm).location_pickup_address || unref(dataForm).location_return_address) {
              _push2(`<div class="w-full flex flex-col gap-2"${_scopeId}><div class="flex flex-col lg:flex-row space-y-1 lg:space-y-0 lg:space-x-4 text-lg 2xl:text-xl font-semibold"${_scopeId}><div class="text-start"${_scopeId}>${ssrInterpolate(unref(dataForm).location_pickup_address)}</div><div class="hidden lg:block text-center"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, {
                name: "i-heroicons-arrow-right",
                class: "w-4 h-4"
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="block lg:hidden text-center"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, {
                name: "i-heroicons-arrow-down",
                class: "w-4 h-4"
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="text-start"${_scopeId}>${ssrInterpolate(unref(dataForm).location_return_address)}</div></div><div class="text-zinc-400 text-sm whitespace-nowrap text-center lg:text-left"${_scopeId}>${ssrInterpolate(unref(dataForm).pickup_date)} \xA0 | \xA0 ${ssrInterpolate(unref(dataForm).passengers)} ${ssrInterpolate(unref($t)("penumpang"))}</div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full" }, [
                createVNode("div", null, [
                  createVNode(_component_UIBtn, {
                    onClick: goToHomePage,
                    variant: "primary",
                    outlined: "",
                    class: "whitespace-nowrap"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref($t)("kembali-ke-beranda")), 1)
                    ]),
                    _: 1
                  })
                ]),
                unref(dataForm).location_pickup_address || unref(dataForm).location_return_address ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "w-full flex flex-col gap-2"
                }, [
                  createVNode("div", { class: "flex flex-col lg:flex-row space-y-1 lg:space-y-0 lg:space-x-4 text-lg 2xl:text-xl font-semibold" }, [
                    createVNode("div", { class: "text-start" }, toDisplayString(unref(dataForm).location_pickup_address), 1),
                    createVNode("div", { class: "hidden lg:block text-center" }, [
                      createVNode(_component_Icon, {
                        name: "i-heroicons-arrow-right",
                        class: "w-4 h-4"
                      })
                    ]),
                    createVNode("div", { class: "block lg:hidden text-center" }, [
                      createVNode(_component_Icon, {
                        name: "i-heroicons-arrow-down",
                        class: "w-4 h-4"
                      })
                    ]),
                    createVNode("div", { class: "text-start" }, toDisplayString(unref(dataForm).location_return_address), 1)
                  ]),
                  createVNode("div", { class: "text-zinc-400 text-sm whitespace-nowrap text-center lg:text-left" }, toDisplayString(unref(dataForm).pickup_date) + " \xA0 | \xA0 " + toDisplayString(unref(dataForm).passengers) + " " + toDisplayString(unref($t)("penumpang")), 1)
                ])) : createCommentVNode("", true)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 divide-x-2"${_scopeId}><div class="space-y-6 py-4"${_scopeId}><h3 class="text-2xl font-semibold text-primary-dark"${_scopeId}>${ssrInterpolate(unref($t)("perjalanan-anda"))}</h3>`);
            if (unref(dataForm).location_pickup_name && unref(dataForm).location_return_name) {
              _push2(`<div class="space-y-4"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_VehicleAddressInformation, {
                name: unref($t)("penjemputan"),
                locationName: unref(dataForm).location_pickup_name,
                locationAddress: unref(dataForm).location_pickup_address
              }, null, _parent2, _scopeId));
              _push2(`<div class="divider text-xs text-zinc-400"${_scopeId}>${ssrInterpolate(unref($t)("perjalananmu-sekitar"))} ${ssrInterpolate(unref(dataForm).distance_text)}</div>`);
              _push2(ssrRenderComponent(_component_VehicleAddressInformation, {
                name: unref($t)("tujuan"),
                locationName: unref(dataForm).location_return_name,
                locationAddress: unref(dataForm).location_return_address
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="p-4"${_scopeId}><div class="flex flex-col space-y-6"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><div class="text-2xl font-semibold"${_scopeId}>${ssrInterpolate(unref($t)("data-pemesan"))}</div></div><div class="space-y-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VehicleOrdererForm, {
              ref_key: "vehicleForm",
              ref: vehicleForm,
              name: unref(dataFormT).name,
              email: unref(dataFormT).email,
              phone: unref(dataFormT).phone,
              "onUpdate:name": ($event) => unref(dataFormT).name = $event,
              "onUpdate:email": ($event) => unref(dataFormT).email = $event,
              "onUpdate:phone": ($event) => unref(dataFormT).phone = $event
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-between items-center"${_scopeId}><div class="text-2xl font-semibold"${_scopeId}>${ssrInterpolate(unref($t)("detail-mobil"))}</div></div><div class="space-y-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VehicleSelectedCard, {
              name: unref(dataForm).name_car,
              image: unref(dataForm).image,
              facilities: unref(dataForm).facilities
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex items-center justify-end"${_scopeId}><div class="btn btn-primary"${_scopeId}><p${_scopeId}>${ssrInterpolate(unref($t)("lanjutkan"))}</p></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 divide-x-2" }, [
                createVNode("div", { class: "space-y-6 py-4" }, [
                  createVNode("h3", { class: "text-2xl font-semibold text-primary-dark" }, toDisplayString(unref($t)("perjalanan-anda")), 1),
                  unref(dataForm).location_pickup_name && unref(dataForm).location_return_name ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "space-y-4"
                  }, [
                    createVNode(_component_VehicleAddressInformation, {
                      name: unref($t)("penjemputan"),
                      locationName: unref(dataForm).location_pickup_name,
                      locationAddress: unref(dataForm).location_pickup_address
                    }, null, 8, ["name", "locationName", "locationAddress"]),
                    createVNode("div", { class: "divider text-xs text-zinc-400" }, toDisplayString(unref($t)("perjalananmu-sekitar")) + " " + toDisplayString(unref(dataForm).distance_text), 1),
                    createVNode(_component_VehicleAddressInformation, {
                      name: unref($t)("tujuan"),
                      locationName: unref(dataForm).location_return_name,
                      locationAddress: unref(dataForm).location_return_address
                    }, null, 8, ["name", "locationName", "locationAddress"])
                  ])) : createCommentVNode("", true)
                ]),
                createVNode("div", { class: "p-4" }, [
                  createVNode("div", { class: "flex flex-col space-y-6" }, [
                    createVNode("div", { class: "flex justify-between items-center" }, [
                      createVNode("div", { class: "text-2xl font-semibold" }, toDisplayString(unref($t)("data-pemesan")), 1)
                    ]),
                    createVNode("div", { class: "space-y-4" }, [
                      createVNode(_component_VehicleOrdererForm, {
                        ref_key: "vehicleForm",
                        ref: vehicleForm,
                        name: unref(dataFormT).name,
                        email: unref(dataFormT).email,
                        phone: unref(dataFormT).phone,
                        "onUpdate:name": ($event) => unref(dataFormT).name = $event,
                        "onUpdate:email": ($event) => unref(dataFormT).email = $event,
                        "onUpdate:phone": ($event) => unref(dataFormT).phone = $event
                      }, null, 8, ["name", "email", "phone", "onUpdate:name", "onUpdate:email", "onUpdate:phone"])
                    ]),
                    createVNode("div", { class: "flex justify-between items-center" }, [
                      createVNode("div", { class: "text-2xl font-semibold" }, toDisplayString(unref($t)("detail-mobil")), 1)
                    ]),
                    createVNode("div", { class: "space-y-4" }, [
                      createVNode(_component_VehicleSelectedCard, {
                        name: unref(dataForm).name_car,
                        image: unref(dataForm).image,
                        facilities: unref(dataForm).facilities
                      }, null, 8, ["name", "image", "facilities"])
                    ]),
                    createVNode("div", { class: "flex items-center justify-end" }, [
                      createVNode("div", {
                        class: "btn btn-primary",
                        onClick: submitFormT
                      }, [
                        createVNode("p", null, toDisplayString(unref($t)("lanjutkan")), 1)
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/vehicles/booking.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=booking-0ccbd346.mjs.map
