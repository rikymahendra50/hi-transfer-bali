import { _ as __nuxt_component_0 } from './TitleBack-5f778ce2.mjs';
import { _ as __nuxt_component_1 } from './Transport-21610161.mjs';
import { u as useSchema } from './useSchema-901b4879.mjs';
import { f as useI18n, e as useRequestOptions, d as useRoute, a as useHead, g as useAsyncData } from '../server.mjs';
import { defineComponent, computed, withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './Icon-ab561e52.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'vee-validate';
import './InputImageCropAdmin-ec5002c2.mjs';
import './client-only-53a57ea8.mjs';
import './index-dea25161.mjs';
import './index-596a8548.mjs';
import './TextFieldWLabel-0de16bf1.mjs';
import './DropdownsTest-e2f0d57d.mjs';
import './useTransport-bdd5bf0b.mjs';
import './nofication-1c3cca5e.mjs';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useSchema();
    useI18n();
    const { requestOptions } = useRequestOptions();
    const route = useRoute();
    useHead({
      title: "Edit Transport"
    });
    const slug = computed(() => route.params.slug);
    const { data } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "car",
      () => $fetch(`/admins/cars/${slug.value}`, {
        method: "GET",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_TitleBack = __nuxt_component_0;
      const _component_UIFormTransport = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "px-5 py-6 md:px-10 md:py-10" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_TitleBack, {
        title: "Edit Mobil",
        link: "/admin/transport"
      }, null, _parent));
      _push(ssrRenderComponent(_component_UIFormTransport, {
        transport: (_a = unref(data)) == null ? void 0 : _a.data,
        buttonTitle: "Simpan mobil"
      }, null, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/transport/edit/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-e04db06d.mjs.map
