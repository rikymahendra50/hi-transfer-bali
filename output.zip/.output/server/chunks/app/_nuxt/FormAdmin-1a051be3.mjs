import { useField, Form, Field, ErrorMessage } from 'vee-validate';
import { _ as _sfc_main$2 } from './Alert-f7c32dd8.mjs';
import { _ as _sfc_main$3 } from './Group-4dcbb69b.mjs';
import { _ as __nuxt_component_0 } from './TransitionX-601819e8.mjs';
import { useSSRContext, defineComponent, unref, withCtx, isRef, createVNode, mergeProps, withDirectives, vModelCheckbox, toDisplayString, openBlock, createBlock, Fragment, createCommentVNode, toRef, computed, ref, readonly } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrLooseEqual, ssrGetDynamicModelProps, ssrInterpolate, ssrRenderAttr, ssrIncludeBooleanAttr, ssrRenderClass, ssrRenderSlot } from 'vue/server-renderer';
import clsx from 'clsx';
import { f as useI18n, e as useRequestOptions, h as useRequestHelper, i as useFetch } from '../server.mjs';
import { u as useNotification } from './nofication-1c3cca5e.mjs';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "TextField",
  __ssrInlineRender: true,
  props: {
    type: { default: "text" },
    modelValue: {},
    name: {},
    class: {},
    disabled: { type: Boolean, default: false },
    ariaLabel: {},
    placeholder: {},
    variant: {},
    size: {},
    ghost: { type: Boolean },
    bordered: { type: Boolean, default: true },
    readonly: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const name = toRef(props, "name");
    const {
      value,
      errorMessage,
      handleBlur,
      handleChange,
      meta
    } = useField(name, void 0, {
      syncVModel: true
    });
    const variant = [
      "input-neutral",
      "input-primary",
      "input-secondary",
      "input-accent",
      "input-info",
      "input-success",
      "input-warning",
      "input-error"
    ];
    const size = [
      "input-xs",
      "input-sm",
      "input-md",
      "input-lg"
    ];
    const className = computed(() => {
      const arr = [];
      const inputClass = [];
      if (props.bordered && !props.ghost) {
        inputClass.push("input-bordered");
      }
      if (props.variant) {
        inputClass.push(variant[variant.indexOf(`input-${props.variant}`)]);
      }
      if (props.size) {
        inputClass.push(size[size.indexOf(`input-${props.size}`)]);
      }
      if (props.ghost) {
        inputClass.push("input-ghost");
      }
      if (!!errorMessage.value) {
        arr.push("input-error");
      }
      return clsx(arr.join(" "), inputClass.join(" "), props.class);
    });
    ref();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TransitionX = __nuxt_component_0;
      const _component_VeeErrorMessage = ErrorMessage;
      let _temp0;
      _push(`<!--[--><label class="${ssrRenderClass(unref(clsx)(
        "flex items-center input overflow-hidden",
        unref(className),
        {
          "gap-2": !!_ctx.$slots.leftSection || !!_ctx.$slots.rightSection,
          "pl-0": !_ctx.$slots.leftSection,
          "pr-0": !_ctx.$slots.rightSection
        }
      ))}">`);
      if (_ctx.$slots.leftSection) {
        ssrRenderSlot(_ctx.$slots, "leftSection", {}, null, _push, _parent);
      } else {
        _push(`<!---->`);
      }
      _push(`<input${ssrRenderAttrs((_temp0 = mergeProps({
        name: unref(name),
        id: unref(name),
        type: _ctx.type,
        readonly: "readonly" in _ctx ? _ctx.readonly : unref(readonly),
        disabled: _ctx.disabled,
        "aria-label": _ctx.ariaLabel,
        placeholder: _ctx.placeholder,
        class: unref(clsx)("w-full h-full", {
          "px-4": !_ctx.$slots.leftSection || !_ctx.$slots.rightSection
        })
      }, _ctx.$attrs), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, unref(value)))))}>`);
      if (_ctx.$slots.rightSection) {
        ssrRenderSlot(_ctx.$slots, "rightSection", {}, null, _push, _parent);
      } else {
        _push(`<!---->`);
      }
      _push(`</label>`);
      _push(ssrRenderComponent(_component_TransitionX, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: unref(name),
              class: "form-error-message"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_VeeErrorMessage, {
                name: unref(name),
                class: "form-error-message"
              }, null, 8, ["name"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/TextField.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
function useAdmin(options) {
  useI18n();
  const { requestOptions } = useRequestOptions();
  const { message, loading, setErrorMessage, alertType, transformErrors } = useRequestHelper();
  const { pushNotification } = useNotification();
  const selectedItem = ref();
  const adminFeature = ref([]);
  const dataForm = ref({
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    is_active: 1,
    password: "",
    confirm_password: ""
    // permissions: [
    //   {
    //     feature_id: "",
    //     type: "",
    //   },
    // ],
  });
  const allFeaturesSelected = computed(() => {
    return dataForm.value.permissions.map((el) => el.feature_id);
  });
  const isEditMode = computed(() => {
    return !!selectedItem.value;
  });
  function resetForm() {
    dataForm.value = {
      first_name: "",
      last_name: "",
      email: "",
      phone: "",
      is_active: 1
      // permissions: [
      //   {
      //     feature_id: "",
      //     type: "",
      //   },
      // ],
    };
  }
  function onSubmit(values, ctx) {
    if (selectedItem.value) {
      updateAdmin(ctx);
    } else {
      createAdmin(ctx);
    }
  }
  async function createAdmin(ctx) {
    var _a2;
    var _a, _b, _c, _d;
    loading.value = true;
    const { error } = await useFetch(
      `/admins`,
      {
        method: "POST",
        body: { ...dataForm.value },
        ...requestOptions
      },
      "$xzovE68efu"
    );
    if (error.value) {
      setErrorMessage((_a2 = (_b = (_a = error.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message) != null ? _a2 : "Error");
      ctx.setErrors(transformErrors((_c = error.value) == null ? void 0 : _c.data));
    } else {
      pushNotification({
        type: "success",
        text: "Sukses menambah admin baru"
      });
      resetForm();
      (_d = options.callback) == null ? void 0 : _d.call(options);
    }
    loading.value = false;
  }
  async function updateAdmin(ctx) {
    var _a, _b, _c, _d, _e;
    loading.value = true;
    const { error } = await useFetch(
      `/admins/${(_a = selectedItem.value) == null ? void 0 : _a.uuid}?_method=PUT`,
      {
        method: "POST",
        body: { ...dataForm.value },
        ...requestOptions
      },
      "$dC7zBQie9B"
    );
    if (error.value) {
      setErrorMessage((_c = (_b = error.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message);
      ctx.setErrors(transformErrors((_d = error.value) == null ? void 0 : _d.data));
    } else {
      pushNotification({
        type: "success",
        text: "Sukses edit admin"
      });
      resetForm();
      (_e = options.callback) == null ? void 0 : _e.call(options);
    }
    loading.value = false;
  }
  return {
    dataForm,
    selectedItem,
    message,
    alertType,
    loading,
    adminFeature,
    isEditMode,
    allFeaturesSelected,
    // addMorePermission,
    // removePermission,
    onSubmit
  };
}
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "FormAdmin",
  __ssrInlineRender: true,
  props: { user: { type: [String, Number, Array, Object] } },
  emits: ["reload"],
  setup(__props, { emit }) {
    function reload() {
      emit("reload");
    }
    const {
      dataForm,
      onSubmit,
      loading,
      message,
      alertType,
      selectedItem,
      adminFeature,
      isEditMode,
      // addMorePermission,
      // removePermission,
      allFeaturesSelected
    } = useAdmin({
      callback: reload
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_Alert = _sfc_main$2;
      const _component_UIFormGroup = _sfc_main$3;
      const _component_UIFormTextField = _sfc_main$1;
      const _component_VeeField = Field;
      let _temp0;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_VeeForm, { onSubmit: unref(onSubmit) }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col space-y-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Alert, {
              modelValue: unref(message),
              "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
              type: unref(alertType)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormGroup, {
              name: "first_name",
              label: "First Name"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormTextField, {
                    name: "first_name",
                    modelValue: unref(dataForm).first_name,
                    "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
                    class: "input-bordered",
                    placeholder: "ex:John"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormTextField, {
                      name: "first_name",
                      modelValue: unref(dataForm).first_name,
                      "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
                      class: "input-bordered",
                      placeholder: "ex:John"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormGroup, {
              name: "last_name",
              label: "Last Name"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormTextField, {
                    name: "last_name",
                    modelValue: unref(dataForm).last_name,
                    "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
                    class: "input-bordered",
                    placeholder: "ex:Doe"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormTextField, {
                      name: "last_name",
                      modelValue: unref(dataForm).last_name,
                      "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
                      class: "input-bordered",
                      placeholder: "ex:Doe"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormGroup, {
              name: "email",
              label: "Email"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormTextField, {
                    name: "email",
                    modelValue: unref(dataForm).email,
                    "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                    class: "input-bordered",
                    placeholder: "ex:myemail@gmail.com"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormTextField, {
                      name: "email",
                      modelValue: unref(dataForm).email,
                      "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                      class: "input-bordered",
                      placeholder: "ex:myemail@gmail.com"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="h-2"${_scopeId}></div>`);
            if (!unref(isEditMode)) {
              _push2(`<!--[-->`);
              _push2(ssrRenderComponent(_component_UIFormGroup, {
                name: "password",
                label: "Password"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_UIFormTextField, {
                      name: "password",
                      modelValue: unref(dataForm).password,
                      "onUpdate:modelValue": ($event) => unref(dataForm).password = $event,
                      class: "input-bordered",
                      type: "password",
                      placeholder: "********"
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_component_UIFormTextField, {
                        name: "password",
                        modelValue: unref(dataForm).password,
                        "onUpdate:modelValue": ($event) => unref(dataForm).password = $event,
                        class: "input-bordered",
                        type: "password",
                        placeholder: "********"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_UIFormGroup, {
                name: "confirm_password",
                label: "Confirm Password"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_UIFormTextField, {
                      name: "confirm_password",
                      modelValue: unref(dataForm).confirm_password,
                      "onUpdate:modelValue": ($event) => unref(dataForm).confirm_password = $event,
                      class: "input-bordered",
                      type: "password",
                      placeholder: "********"
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_component_UIFormTextField, {
                        name: "confirm_password",
                        modelValue: unref(dataForm).confirm_password,
                        "onUpdate:modelValue": ($event) => unref(dataForm).confirm_password = $event,
                        class: "input-bordered",
                        type: "password",
                        placeholder: "********"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`<!--]-->`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div${_scopeId}><div class="form-control"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              name: "is_active",
              value: unref(dataForm).is_active
            }, {
              default: withCtx(({ field }, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<label class="label cursor-pointer"${_scopeId2}><input${ssrRenderAttrs((_temp0 = mergeProps({
                    type: "checkbox",
                    class: "toggle",
                    "true-value": 1,
                    "false-value": 0,
                    checked: ssrLooseEqual(unref(dataForm).is_active, 1)
                  }, field), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, unref(dataForm).is_active))))}${_scopeId2}><span class="label-text"${_scopeId2}>${ssrInterpolate(unref(dataForm).is_active ? "Active" : "Inactive")}</span></label>`);
                } else {
                  return [
                    createVNode("label", { class: "label cursor-pointer" }, [
                      withDirectives(createVNode("input", mergeProps({
                        type: "checkbox",
                        class: "toggle",
                        "true-value": 1,
                        "false-value": 0,
                        "onUpdate:modelValue": ($event) => unref(dataForm).is_active = $event
                      }, field), null, 16, ["onUpdate:modelValue"]), [
                        [vModelCheckbox, unref(dataForm).is_active]
                      ]),
                      createVNode("span", { class: "label-text" }, toDisplayString(unref(dataForm).is_active ? "Active" : "Inactive"), 1)
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div${_scopeId}><button type="submit" class="btn btn-primary btn-block"${ssrRenderAttr("loading", unref(loading))}${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""}${_scopeId}> Submit </button></div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col space-y-2" }, [
                createVNode(_component_Alert, {
                  modelValue: unref(message),
                  "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
                  type: unref(alertType)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "type"]),
                createVNode(_component_UIFormGroup, {
                  name: "first_name",
                  label: "First Name"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormTextField, {
                      name: "first_name",
                      modelValue: unref(dataForm).first_name,
                      "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
                      class: "input-bordered",
                      placeholder: "ex:John"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormGroup, {
                  name: "last_name",
                  label: "Last Name"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormTextField, {
                      name: "last_name",
                      modelValue: unref(dataForm).last_name,
                      "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
                      class: "input-bordered",
                      placeholder: "ex:Doe"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormGroup, {
                  name: "email",
                  label: "Email"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormTextField, {
                      name: "email",
                      modelValue: unref(dataForm).email,
                      "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                      class: "input-bordered",
                      placeholder: "ex:myemail@gmail.com"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode("div", { class: "h-2" }),
                !unref(isEditMode) ? (openBlock(), createBlock(Fragment, { key: 0 }, [
                  createVNode(_component_UIFormGroup, {
                    name: "password",
                    label: "Password"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_UIFormTextField, {
                        name: "password",
                        modelValue: unref(dataForm).password,
                        "onUpdate:modelValue": ($event) => unref(dataForm).password = $event,
                        class: "input-bordered",
                        type: "password",
                        placeholder: "********"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  }),
                  createVNode(_component_UIFormGroup, {
                    name: "confirm_password",
                    label: "Confirm Password"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_UIFormTextField, {
                        name: "confirm_password",
                        modelValue: unref(dataForm).confirm_password,
                        "onUpdate:modelValue": ($event) => unref(dataForm).confirm_password = $event,
                        class: "input-bordered",
                        type: "password",
                        placeholder: "********"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  })
                ], 64)) : createCommentVNode("", true),
                createVNode("div", null, [
                  createVNode("div", { class: "form-control" }, [
                    createVNode(_component_VeeField, {
                      name: "is_active",
                      value: unref(dataForm).is_active
                    }, {
                      default: withCtx(({ field }) => [
                        createVNode("label", { class: "label cursor-pointer" }, [
                          withDirectives(createVNode("input", mergeProps({
                            type: "checkbox",
                            class: "toggle",
                            "true-value": 1,
                            "false-value": 0,
                            "onUpdate:modelValue": ($event) => unref(dataForm).is_active = $event
                          }, field), null, 16, ["onUpdate:modelValue"]), [
                            [vModelCheckbox, unref(dataForm).is_active]
                          ]),
                          createVNode("span", { class: "label-text" }, toDisplayString(unref(dataForm).is_active ? "Active" : "Inactive"), 1)
                        ])
                      ]),
                      _: 1
                    }, 8, ["value"])
                  ])
                ]),
                createVNode("div", null, [
                  createVNode("button", {
                    type: "submit",
                    class: "btn btn-primary btn-block",
                    loading: unref(loading),
                    disabled: unref(loading)
                  }, " Submit ", 8, ["loading", "disabled"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/FormAdmin.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=FormAdmin-1a051be3.mjs.map
