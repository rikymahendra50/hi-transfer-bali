import { Form, Field, ErrorMessage } from 'vee-validate';
import { _ as _sfc_main$1 } from './Alert-ad006b11.mjs';
import { _ as _sfc_main$2 } from './InputOTP-bbb2b053.mjs';
import { a as useRequestOptions, e as useI18n, u as useRequestHelper, h as useFetch } from '../server.mjs';
import { useSSRContext, mergeProps, unref, withCtx, isRef, createVNode, toDisplayString, openBlock, createBlock, createTextVNode, createCommentVNode, ref } from 'vue';
import { u as useSchema } from './useSchema-10fbf818.mjs';
import { ssrRenderComponent, ssrIncludeBooleanAttr, ssrInterpolate } from 'vue/server-renderer';

function useRefund() {
  const stateForm = ref({
    email: ""
  });
  const showPinEmailExpired = ref(false);
  const secondTime = ref(60);
  function countdown() {
    const interval = setInterval(() => {
      if (secondTime.value === 0) {
        clearInterval(interval);
        showPinEmailExpired.value = true;
      } else {
        secondTime.value--;
      }
    }, 1e3);
  }
  return {
    stateForm,
    countdown,
    showPinEmailExpired,
    secondTime
  };
}
const _sfc_main = {
  __name: "Verified",
  __ssrInlineRender: true,
  props: {
    email: String,
    otp: String
  },
  emits: ["next", "update:otp"],
  setup(__props, { emit }) {
    const props = __props;
    const { requestOptions } = useRequestOptions();
    const { locale, t: $t } = useI18n();
    const { stateForm, countdown, showPinEmailExpired, secondTime } = useRefund();
    const { otpSchema } = useSchema();
    const { loading, message, alertType } = useRequestHelper();
    function updateToParent() {
      emit("update:otp", stateForm.value.otp);
      emit("next");
    }
    function resentEmail() {
      showPinEmailExpired.value = false;
      secondTime.value = 60;
      countdown();
      useFetch("/admins/resend-email-verification", {
        method: "POST",
        body: { email: stateForm.value.email },
        ...requestOptions
      }, "$N1weP1OQ2C");
    }
    async function onSubmit() {
      loading.value = true;
      const { error } = await useFetch("/admins/forget-password/verify-pin", {
        method: "POST",
        body: JSON.stringify({
          email: props.email,
          pin: stateForm.value.otp
        }),
        ...requestOptions
      }, "$x3rGCD3toy");
      if (error.value)
        ;
      else {
        updateToParent();
      }
      loading.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_Alert = _sfc_main$1;
      const _component_VeeField = Field;
      const _component_UIFormInputOTP = _sfc_main$2;
      const _component_VeeErrorMessage = ErrorMessage;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        onSubmit,
        "validation-schema": unref(otpSchema)
      }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 text-left gap-4 p-4 rounded-md w-full"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Alert, {
              modelValue: unref(message),
              "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
              type: unref(alertType)
            }, null, _parent2, _scopeId));
            _push2(`<div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              name: "otp",
              modelValue: unref(stateForm).otp,
              "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_UIFormInputOTP, {
              modelValue: unref(stateForm).otp,
              "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event,
              "is-error": !!(errors == null ? void 0 : errors.otp)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "otp",
              class: "form-error-message"
            }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><button type="submit" class="btn bg-primary text-white shadow w-full py-1"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""}${_scopeId}><span${_scopeId}>${ssrInterpolate(unref($t)("proses-pengembalian"))}</span></button></div>`);
            if (unref(showPinEmailExpired)) {
              _push2(`<div${_scopeId}><p class="text-sm"${_scopeId}>${ssrInterpolate(unref($t)("jika-tidak-menerima-email"))} <span class="link text-primary" role="button"${_scopeId}>${ssrInterpolate(unref($t)("klik-disini"))}</span></p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div${_scopeId}>`);
            if (unref(secondTime) > 0) {
              _push2(`<div class="text-gray-400 text-sm"${_scopeId}>${ssrInterpolate(unref($t)("pin-berlaku-selama"))} <span class="whitespace-nowrap"${_scopeId}>${ssrInterpolate(unref(secondTime))} ${ssrInterpolate(unref($t)("second"))}. </span></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (unref(showPinEmailExpired)) {
              _push2(`<div class="text-error text-sm"${_scopeId}>${ssrInterpolate(unref($t)("otp-expired"))}</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 text-left gap-4 p-4 rounded-md w-full" }, [
                createVNode(_component_Alert, {
                  modelValue: unref(message),
                  "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
                  type: unref(alertType)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "type"]),
                createVNode("div", { class: "hidden" }, [
                  createVNode(_component_VeeField, {
                    name: "otp",
                    modelValue: unref(stateForm).otp,
                    "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode(_component_UIFormInputOTP, {
                  modelValue: unref(stateForm).otp,
                  "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event,
                  "is-error": !!(errors == null ? void 0 : errors.otp)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "is-error"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "otp",
                  class: "form-error-message"
                }),
                createVNode("div", null, [
                  createVNode("button", {
                    type: "submit",
                    class: "btn bg-primary text-white shadow w-full py-1",
                    disabled: unref(loading)
                  }, [
                    createVNode("span", null, toDisplayString(unref($t)("proses-pengembalian")), 1)
                  ], 8, ["disabled"])
                ]),
                unref(showPinEmailExpired) ? (openBlock(), createBlock("div", { key: 0 }, [
                  createVNode("p", { class: "text-sm" }, [
                    createTextVNode(toDisplayString(unref($t)("jika-tidak-menerima-email")) + " ", 1),
                    createVNode("span", {
                      class: "link text-primary",
                      onClick: resentEmail,
                      role: "button"
                    }, toDisplayString(unref($t)("klik-disini")), 1)
                  ])
                ])) : createCommentVNode("", true),
                createVNode("div", null, [
                  unref(secondTime) > 0 ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "text-gray-400 text-sm"
                  }, [
                    createTextVNode(toDisplayString(unref($t)("pin-berlaku-selama")) + " ", 1),
                    createVNode("span", { class: "whitespace-nowrap" }, toDisplayString(unref(secondTime)) + " " + toDisplayString(unref($t)("second")) + ". ", 1)
                  ])) : createCommentVNode("", true),
                  unref(showPinEmailExpired) ? (openBlock(), createBlock("div", {
                    key: 1,
                    class: "text-error text-sm"
                  }, toDisplayString(unref($t)("otp-expired")), 1)) : createCommentVNode("", true)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Verified.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main;

export { __nuxt_component_4 as _ };
//# sourceMappingURL=Verified-ef3c6fe5.mjs.map
