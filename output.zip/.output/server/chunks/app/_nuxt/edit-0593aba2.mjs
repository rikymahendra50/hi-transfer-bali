import { _ as __nuxt_component_0 } from './TitleBack-5f778ce2.mjs';
import { _ as _sfc_main$1 } from './FormAdmin-c1ca36a9.mjs';
import { a as useHead, b as useRouter, d as useRoute, e as useRequestOptions, f as useI18n, g as useAsyncData, u as useAuth } from '../server.mjs';
import { defineComponent, computed, withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './Icon-ab561e52.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'vee-validate';
import './Alert-f7c32dd8.mjs';
import './TransitionTopToBottom-a8e40871.mjs';
import './Group-4dcbb69b.mjs';
import './TransitionX-601819e8.mjs';
import 'clsx';
import './nofication-1c3cca5e.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

function usePermission() {
  const { $user } = useAuth();
  const links = [
    {
      label: "Orders",
      icon: "bi:list-ol",
      to: "/admin/orders",
      name: "order"
    },
    {
      label: "Blog",
      icon: "i-heroicons-newspaper",
      to: "/admin/blog",
      name: "article"
    },
    {
      label: "Users",
      icon: "i-heroicons-users",
      to: "/admin/users",
      name: "user"
    },
    {
      label: "Product Addons",
      icon: "i-heroicons-cube",
      to: "/admin/addons",
      name: "additional"
    },
    {
      label: "Product",
      icon: "i-heroicons-cube",
      to: "/admin/products",
      name: "product"
    },
    {
      label: "Facility Locations",
      icon: "i-heroicons-map-pin",
      to: "/admin/facility-locations",
      name: "facilityLocation"
    },
    {
      label: "Locations",
      icon: "i-heroicons-map-pin",
      to: "/admin/locations",
      name: "location"
    },
    {
      label: "Contacts",
      icon: "i-heroicons-phone",
      to: "/admin/contacts",
      name: "contact"
    },
    {
      label: "Admins",
      icon: "i-heroicons-user-group",
      to: "/admin/user-admin",
      name: "admin"
    },
    {
      label: "Settings",
      icon: "i-heroicons-cog-6-tooth",
      to: "/admin/settings",
      name: "settings"
    }
  ];
  const userPermission = computed(() => {
    var _a2;
    var _a;
    return (_a2 = (_a = $user.value) == null ? void 0 : _a.permissions) != null ? _a2 : [];
  });
  function hasPermission(name) {
    var _a;
    if (((_a = $user.value) == null ? void 0 : _a.id) === 1) {
      return true;
    }
    const permission = userPermission.value.find(
      (el) => el.feature_name === name
    );
    if (!permission)
      return false;
    return (permission == null ? void 0 : permission.type) === "full";
  }
  function hasPermissionVisit(name) {
    var _a;
    if (((_a = $user.value) == null ? void 0 : _a.id) === 1) {
      return true;
    }
    return !!userPermission.value.find((el) => el.feature_name === name);
  }
  const linksAllowed = computed(() => {
    var _a, _b, _c;
    if (((_a = $user.value) == null ? void 0 : _a.id) === 1) {
      return links;
    }
    const defaultPermission = ["settings"];
    const userPermission2 = [
      ...defaultPermission,
      ...((_c = (_b = $user.value) == null ? void 0 : _b.permissions) == null ? void 0 : _c.map((el) => el.feature_name)) || []
    ];
    return links.filter((el) => {
      return userPermission2.includes(el.name);
    });
  });
  return {
    linksAllowed,
    hasPermission,
    hasPermissionVisit
  };
}
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "edit",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useHead({
      title: "Edit Create"
    });
    const router = useRouter();
    const route = useRoute();
    usePermission();
    const { requestOptions } = useRequestOptions();
    const { locale } = useI18n();
    const uuid = computed(() => {
      return route.params.uuid;
    });
    const { data } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "adminuserdetail",
      () => $fetch(`/admins/${uuid.value}?lang=${locale.value}`, {
        method: "GET",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    const reload = () => {
      router.push("/admin/admin-list");
    };
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_TitleBack = __nuxt_component_0;
      const _component_FormAdmin = _sfc_main$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-6 px-5 py-4" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_TitleBack, {
        link: "/admin/admin-list",
        title: "Edit Admin"
      }, null, _parent));
      _push(`<div class="grid grid-cols-1 lg:grid-cols-[2fr_1fr]">`);
      _push(ssrRenderComponent(_component_FormAdmin, {
        onReload: reload,
        user: (_a = unref(data)) == null ? void 0 : _a.data
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/admin-list/[uuid]/edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=edit-0593aba2.mjs.map
