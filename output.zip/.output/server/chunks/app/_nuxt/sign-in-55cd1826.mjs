import { Form } from 'vee-validate';
import { _ as _sfc_main$1 } from './Alert-129c5078.mjs';
import { _ as _sfc_main$2 } from './MGroup-e711cd83.mjs';
import { _ as _sfc_main$3 } from './MTextField-bd75102a.mjs';
import __nuxt_component_0 from './Icon-0f6314e3.mjs';
import { _ as _sfc_main$4 } from './Btn-577fa59f.mjs';
import { b as useRouter, u as useAuth, a as useHead, f as useI18n, _ as __nuxt_component_0$1 } from '../server.mjs';
import { u as useSchema } from './useSchema-a44a23cb.mjs';
import { u as usePasswordHelper } from './usePasswordHelper-d8a46f8b.mjs';
import { defineComponent, unref, withCtx, isRef, createVNode, createTextVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import './TransitionTopToBottom-a8e40871.mjs';
import './TransitionX-601819e8.mjs';
import 'clsx';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "sign-in",
  __ssrInlineRender: true,
  setup(__props) {
    const { loginSchema } = useSchema();
    const { inputType, toggleInputType } = usePasswordHelper();
    const router = useRouter();
    function redirectUserProfile() {
      router.push("/user/profile");
    }
    const { loading, message, alertType, $credentialForm, $login } = useAuth({
      usedBy: "user",
      callback: redirectUserProfile
    });
    useHead({
      title: "Sign In"
    });
    const { locale, t: $t } = useI18n();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIAlert = _sfc_main$1;
      const _component_UIFormMGroup = _sfc_main$2;
      const _component_UIFormMTextField = _sfc_main$3;
      const _component_Icon = __nuxt_component_0;
      const _component_UIBtn = _sfc_main$4;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div><div class="w-full lg:w-[500px] border rounded-xl"><div class="py-4"><h1 class="text-xl text-center font-bold">Sign In</h1></div>`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit: unref($login),
        "validation-schema": unref(loginSchema)
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 gap-4 p-6"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIAlert, {
              modelValue: unref(message),
              "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
              type: unref(alertType)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Email",
              name: "email"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "email",
                    modelValue: unref($credentialForm).email,
                    "onUpdate:modelValue": ($event) => unref($credentialForm).email = $event,
                    class: "input-bordered",
                    placeholder: "ex:myemail@gmail.com"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "email",
                      modelValue: unref($credentialForm).email,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).email = $event,
                      class: "input-bordered",
                      placeholder: "ex:myemail@gmail.com"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Password",
              name: "password"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "password",
                    modelValue: unref($credentialForm).password,
                    "onUpdate:modelValue": ($event) => unref($credentialForm).password = $event,
                    type: unref(inputType),
                    class: "input-bordered",
                    placeholder: "********"
                  }, {
                    leftSection: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Icon, {
                            name: "i-heroicons-lock-closed",
                            class: "w-5 h-5 text-gray-400"
                          })
                        ];
                      }
                    }),
                    rightSection: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          class: "w-5 h-5 text-gray-400",
                          onClick: unref(toggleInputType)
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Icon, {
                            name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                            class: "w-5 h-5 text-gray-400",
                            onClick: unref(toggleInputType)
                          }, null, 8, ["name", "onClick"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "password",
                      modelValue: unref($credentialForm).password,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).password = $event,
                      type: unref(inputType),
                      class: "input-bordered",
                      placeholder: "********"
                    }, {
                      leftSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        })
                      ]),
                      rightSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          class: "w-5 h-5 text-gray-400",
                          onClick: unref(toggleInputType)
                        }, null, 8, ["name", "onClick"])
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue", "type"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              variant: "primary",
              type: "submit",
              disabled: unref(loading),
              class: "w-full"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Submit`);
                } else {
                  return [
                    createTextVNode("Submit")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="flex justify-between items-center mt-1"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, {
              class: "link link-hover text-xs text-neutral-400",
              to: "/forgot-password"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref($t)("lupa-password-?"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref($t)("lupa-password-?")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="text-xs text-neutral-400"${_scopeId}><p${_scopeId}>${ssrInterpolate(unref($t)("tidak-punya-akun"))} `);
            _push2(ssrRenderComponent(_component_NuxtLink, {
              to: "/sign-up",
              class: "link link-hover"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Sign Up`);
                } else {
                  return [
                    createTextVNode("Sign Up")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</p></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 gap-4 p-6" }, [
                createVNode(_component_UIAlert, {
                  modelValue: unref(message),
                  "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
                  type: unref(alertType)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "type"]),
                createVNode(_component_UIFormMGroup, {
                  label: "Email",
                  name: "email"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      name: "email",
                      modelValue: unref($credentialForm).email,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).email = $event,
                      class: "input-bordered",
                      placeholder: "ex:myemail@gmail.com"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  label: "Password",
                  name: "password"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      name: "password",
                      modelValue: unref($credentialForm).password,
                      "onUpdate:modelValue": ($event) => unref($credentialForm).password = $event,
                      type: unref(inputType),
                      class: "input-bordered",
                      placeholder: "********"
                    }, {
                      leftSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        })
                      ]),
                      rightSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          class: "w-5 h-5 text-gray-400",
                          onClick: unref(toggleInputType)
                        }, null, 8, ["name", "onClick"])
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue", "type"])
                  ]),
                  _: 1
                }),
                createVNode("div", null, [
                  createVNode(_component_UIBtn, {
                    variant: "primary",
                    type: "submit",
                    disabled: unref(loading),
                    class: "w-full"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Submit")
                    ]),
                    _: 1
                  }, 8, ["disabled"]),
                  createVNode("div", { class: "flex justify-between items-center mt-1" }, [
                    createVNode("div", null, [
                      createVNode(_component_NuxtLink, {
                        class: "link link-hover text-xs text-neutral-400",
                        to: "/forgot-password"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(unref($t)("lupa-password-?")), 1)
                        ]),
                        _: 1
                      })
                    ]),
                    createVNode("div", { class: "text-xs text-neutral-400" }, [
                      createVNode("p", null, [
                        createTextVNode(toDisplayString(unref($t)("tidak-punya-akun")) + " ", 1),
                        createVNode(_component_NuxtLink, {
                          to: "/sign-up",
                          class: "link link-hover"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Sign Up")
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/sign-in.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=sign-in-55cd1826.mjs.map
