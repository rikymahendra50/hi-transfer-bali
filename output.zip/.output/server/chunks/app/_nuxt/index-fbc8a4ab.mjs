import { _ as _sfc_main$2 } from './MGroup-69a23538.mjs';
import { _ as _sfc_main$3 } from './MSelect-1f220a05.mjs';
import __nuxt_component_1 from './Icon-7218f0f6.mjs';
import { _ as _sfc_main$4 } from './Btn-61213793.mjs';
import { useSSRContext, ref, mergeProps, withCtx, unref, createVNode, defineComponent, createTextVNode } from 'vue';
import { a as useRouter } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import 'vee-validate';
import 'clsx';
import './config-aab100d3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Card",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter();
    function goToVehicleBooking() {
      router.push("/vehicles/booking");
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_1;
      const _component_UIBtn = _sfc_main$4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "border rounded-xl p-4 hover:border-primary hover:shadow shadow-primary" }, _attrs))}><div class="grid grid-cols-[100px_1fr] lg:grid-cols-[150px_1fr] gap-4"><div><div class="border rounded-xl overflow-hidden max-h-max"><img src="https://placehold.co/150" alt="vehicle" class="w-full h-[100px] xl:h-[150px] object-cover"></div></div><div class="grid grid-cols-1 xl:grid-cols-[1fr_170px] gap-6"><div class="space-y-2 border-0 xl:border-r"><h4 class="text-xl lg:text-2xl font-semibold">Standar (Hatchback)</h4><div class="grid grid-cols-1 md:grid-cols-2 gap-1 lg:p-4"><div class="inline-flex space-x-1">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "i-heroicons-users",
        class: "w-5 h-5 text-primary"
      }, null, _parent));
      _push(`<div class="text-zinc-400 text-sm whitespace-nowrap"> Hingga 4 Penumpang </div></div><div class="inline-flex space-x-1">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "i-heroicons-briefcase",
        class: "w-5 h-5 text-primary"
      }, null, _parent));
      _push(`<div class="text-zinc-400 text-sm whitespace-nowrap"> Muat 4 Koper </div></div><div class="inline-flex space-x-1">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "mingcute:steering-wheel-fill",
        class: "w-5 h-5 text-primary"
      }, null, _parent));
      _push(`<div class="text-zinc-400 text-sm whitespace-nowrap"> Termasuk Sopir </div></div><div class="inline-flex space-x-1">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "i-heroicons-check-circle",
        class: "w-5 h-5 text-primary"
      }, null, _parent));
      _push(`<div class="text-zinc-400 text-sm whitespace-nowrap"> Gratis Tol &amp; Parkir </div></div></div></div><div class="flex flex-col justify-between space-y-4"><h4 class="text-xl font-semibold text-primary xl:text-right">Rp152.000</h4><div>`);
      _push(ssrRenderComponent(_component_UIBtn, {
        onClick: goToVehicleBooking,
        variant: "primary",
        outlined: "",
        class: "w-full"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Pesan Sekarang`);
          } else {
            return [
              createTextVNode("Pesan Sekarang")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vehicle/Card.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const filter = ref({
      sort: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIFormMGroup = _sfc_main$2;
      const _component_UIFormMSelect = _sfc_main$3;
      const _component_VehicleCard = _sfc_main$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col space-y-6" }, _attrs))}><div class="flex justify-between items-center"><div> Menampilkan 7 mobil </div><div>`);
      _push(ssrRenderComponent(_component_UIFormMGroup, {
        name: "sort",
        label: "Urut berdasarkan"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_UIFormMSelect, {
              modelValue: unref(filter).sort,
              "onUpdate:modelValue": ($event) => unref(filter).sort = $event,
              name: "sort"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<option value=""${_scopeId2}>Semua</option><option value="recommended"${_scopeId2}>Rekomendasi</option>`);
                } else {
                  return [
                    createVNode("option", { value: "" }, "Semua"),
                    createVNode("option", { value: "recommended" }, "Rekomendasi")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_UIFormMSelect, {
                modelValue: unref(filter).sort,
                "onUpdate:modelValue": ($event) => unref(filter).sort = $event,
                name: "sort"
              }, {
                default: withCtx(() => [
                  createVNode("option", { value: "" }, "Semua"),
                  createVNode("option", { value: "recommended" }, "Rekomendasi")
                ]),
                _: 1
              }, 8, ["modelValue", "onUpdate:modelValue"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="space-y-4"><!--[-->`);
      ssrRenderList(4, (n) => {
        _push(ssrRenderComponent(_component_VehicleCard, { key: n }, null, _parent));
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/vehicles/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-fbc8a4ab.mjs.map
