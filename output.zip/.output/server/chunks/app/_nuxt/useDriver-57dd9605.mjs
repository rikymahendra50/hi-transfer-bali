import { a as useRequestOptions, u as useRequestHelper, h as useFetch } from '../server.mjs';
import { u as useNotification } from './nofication-176ebe9f.mjs';
import { ref } from 'vue';

function useDriver(options = {}) {
  const { requestOptions } = useRequestOptions();
  const { loading, message, alertType, setErrorMessage, transformErrors } = useRequestHelper();
  const { pushNotification } = useNotification();
  const selectedDriver = ref();
  const dataForm = ref({
    name: void 0,
    phone: void 0,
    driver: void 0
  });
  function resetForm() {
    dataForm.value = {
      name: void 0,
      phone: void 0,
      driver: void 0
    };
  }
  function onSubmit(values, ctx) {
    if (selectedDriver.value) {
      updateDriver(ctx);
    } else {
      createDriver(ctx);
    }
  }
  async function createDriver(ctx) {
    const formData = new FormData();
    loading.value = true;
    for (const item in dataForm.value) {
      const objectItem = dataForm.value[item];
      formData.append(item, objectItem);
    }
    await $fetch("/admins/drivers", {
      method: "POST",
      body: formData,
      ...requestOptions
    }).catch((error) => {
      var _a, _b;
      setErrorMessage((_a = error.data) == null ? void 0 : _a.message);
      ctx.setErrors(transformErrors(error.data));
      pushNotification({
        type: "error",
        text: (_b = error.value.data) == null ? void 0 : _b.message,
        title: "error"
      });
    }).then((data) => {
      var _a;
      if (data) {
        ctx.resetForm();
        pushNotification({
          type: "success",
          text: "Driver created successfully"
        });
        (_a = options.callback) == null ? void 0 : _a.call(options);
      }
    });
    loading.value = false;
  }
  const updateDriver = async (ctx) => {
    var _a;
    const formData = new FormData();
    loading.value = true;
    for (const item in dataForm.value) {
      const objectItem = dataForm.value[item];
      formData.append(item, objectItem);
    }
    await $fetch(
      `/admins/drivers/${(_a = selectedDriver.value) == null ? void 0 : _a.id}?_method=PUT`,
      {
        method: "POST",
        body: formData,
        ...requestOptions
      }
    ).catch((error) => {
      var _a2, _b;
      setErrorMessage((_a2 = error.data) == null ? void 0 : _a2.message);
      ctx.setErrors(transformErrors(error.data));
      pushNotification({
        type: "error",
        text: (_b = error.value.data) == null ? void 0 : _b.message,
        title: "error"
      });
    }).then((data) => {
      var _a2;
      if (data) {
        ctx.resetForm();
        pushNotification({
          type: "success",
          text: "Driver updated successfully"
        });
        resetForm();
        (_a2 = options.callback) == null ? void 0 : _a2.call(options);
      }
    });
    loading.value = false;
  };
  async function deleteDriver(id) {
    var _a2;
    var _a, _b, _c;
    loading.value = true;
    const { error } = await useFetch(
      `/admins/drivers/${id}`,
      {
        method: "DELETE",
        ...requestOptions
      },
      "$A38RXgDuEE"
    );
    if (error.value) {
      setErrorMessage((_a2 = (_b = (_a = error.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message) != null ? _a2 : "Something went wrong");
    } else {
      pushNotification({
        type: "success",
        text: "Driver deleted successfully"
      });
      (_c = options.callback) == null ? void 0 : _c.call(options);
    }
    loading.value = false;
  }
  return {
    selectedDriver,
    dataForm,
    onSubmit,
    deleteDriver,
    loading
  };
}

export { useDriver as u };
//# sourceMappingURL=useDriver-57dd9605.mjs.map
