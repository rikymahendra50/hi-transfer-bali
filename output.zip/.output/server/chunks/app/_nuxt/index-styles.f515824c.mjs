const HomeBanner_vue_vue_type_style_index_0_scoped_e04897ab_lang = ".fade-enter-active[data-v-e04897ab]{transition:all .3s ease-out}.fade-leave-active[data-v-e04897ab]{transition:all .8s cubic-bezier(1,.5,.8,1)}.fade-enter-from[data-v-e04897ab],.fade-leave-to[data-v-e04897ab]{opacity:0;transform:translateX(20px)}";

const indexStyles_f515824c = [HomeBanner_vue_vue_type_style_index_0_scoped_e04897ab_lang];

export { indexStyles_f515824c as default };
//# sourceMappingURL=index-styles.f515824c.mjs.map
