import { o as defineNuxtRouteMiddleware, r as useCookie, p as executeAsync, q as navigateTo } from '../server.mjs';
import 'vue';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'vue/server-renderer';

const guest = /* @__PURE__ */ defineNuxtRouteMiddleware(async (to, from) => {
  var _a;
  let __temp, __restore;
  const credential = useCookie("auth-token", {
    expires: new Date(Date.now() + 12096e5),
    // 2 weeks from now
    sameSite: "lax",
    path: "/",
    watch: true
  });
  if ((_a = credential.value) == null ? void 0 : _a.token) {
    return [__temp, __restore] = executeAsync(() => navigateTo("/")), __temp = await __temp, __restore(), __temp;
  }
});

export { guest as default };
//# sourceMappingURL=guest-653805c5.mjs.map
