import { Swiper, SwiperSlide } from 'swiper/vue';
import { useSSRContext, defineComponent, computed, mergeProps, unref, ref, withAsyncContext, watch, withCtx, createVNode, toDisplayString, openBlock, createBlock, createCommentVNode, Fragment, renderList, withDirectives, vModelCheckbox, isRef, createTextVNode } from 'vue';
import { Autoplay } from 'swiper/modules';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderList, ssrLooseContain, ssrRenderAttr } from 'vue/server-renderer';
import { _ as __nuxt_component_0$2 } from './Container-f78810bd.mjs';
import __nuxt_component_0$1 from './Icon-0f6314e3.mjs';
import { _ as _sfc_main$4 } from './CtaSection-c459c0c9.mjs';
import { _ as __nuxt_component_3 } from './Modal-967d83e0.mjs';
import { Form } from 'vee-validate';
import { _ as _sfc_main$5 } from './MGroup-e711cd83.mjs';
import { _ as _sfc_main$6 } from './MTextField-bd75102a.mjs';
import { _ as _sfc_main$7 } from './Btn-577fa59f.mjs';
import { l as _export_sfc, f as useI18n, h as useRequestHelper, e as useRequestOptions, b as useRouter, d as useRoute, g as useAsyncData, a as useHead } from '../server.mjs';
import { u as useSchema } from './useSchema-7a41625c.mjs';
import { u as useTourForm } from './useTourStore-3373162f.mjs';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import './index-a61f78d7.mjs';
import './index-596a8548.mjs';
import './TransitionX-601819e8.mjs';
import 'clsx';
import 'zod';
import '@vee-validate/zod';
import './nofication-1c3cca5e.mjs';

const _sfc_main$3 = {
  __name: "Swiper",
  __ssrInlineRender: true,
  props: { data: { type: Array } },
  setup(__props) {
    const props = __props;
    const slidesPerView1024 = computed(() => {
      var _a, _b, _c, _d, _e;
      if (((_a = props.data) == null ? void 0 : _a.length) <= 1) {
        return 1;
      } else if (((_b = props.data) == null ? void 0 : _b.length) <= 2 && ((_c = props.data) == null ? void 0 : _c.length) >= 1) {
        return 2;
      } else if (((_d = props.data) == null ? void 0 : _d.length) <= 3 && ((_e = props.data) == null ? void 0 : _e.length) >= 2) {
        return 3;
      } else {
        return 3;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Swiper = Swiper;
      const _component_SwiperSlide = SwiperSlide;
      _push(ssrRenderComponent(_component_Swiper, mergeProps({
        modules: ["SwiperAutoplay" in _ctx ? _ctx.SwiperAutoplay : unref(Autoplay)],
        "slides-per-view": 1,
        loop: true,
        effect: "creative",
        "space-between": "1",
        autoplay: {
          delay: 8e3,
          disableOnInteraction: true
        },
        breakpoints: {
          "640": {
            slidesPerView: 2,
            spaceBetween: 20
          },
          "1024": {
            slidesPerView: unref(slidesPerView1024),
            spaceBetween: 30
          }
        }
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(__props.data, (slide) => {
              _push2(ssrRenderComponent(_component_SwiperSlide, { key: slide }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="h-[350px] border"${_scopeId2}><img${ssrRenderAttr("src", slide.image)} alt="slide" class="w-full h-full object-cover"${_scopeId2}></div>`);
                  } else {
                    return [
                      createVNode("div", { class: "h-[350px] border" }, [
                        createVNode("img", {
                          src: slide.image,
                          alt: "slide",
                          class: "w-full h-full object-cover"
                        }, null, 8, ["src"])
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(__props.data, (slide) => {
                return openBlock(), createBlock(_component_SwiperSlide, { key: slide }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "h-[350px] border" }, [
                      createVNode("img", {
                        src: slide.image,
                        alt: "slide",
                        class: "w-full h-full object-cover"
                      }, null, 8, ["src"])
                    ])
                  ]),
                  _: 2
                }, 1024);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/Swiper.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$3;
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "NumberUpDown",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      type: [Number, String]
    },
    minValue: {
      type: [Number, String]
    },
    maxValue: {
      type: [Number, String]
    },
    showTooltip: {
      type: Boolean,
      default: false
    }
  },
  emits: ["update:modelValue", "increment", "decrement"],
  setup(__props, { emit }) {
    const props = __props;
    const input = computed({
      get() {
        var _a;
        return (_a = props.modelValue) != null ? _a : 0;
      },
      set(value) {
        emit("update:modelValue", value);
      }
    });
    const disabledDecrement = computed(() => {
      if (props.minValue) {
        return input.value < props.minValue;
      }
      return input.value <= 0;
    });
    const disabledIncrement = computed(() => {
      if (props.maxValue) {
        return input.value >= parseInt(props.maxValue);
      }
      return false;
    });
    const dataTip = computed(() => {
      const array = [];
      if (props.minValue) {
        array.push(`Minimal order: ${props.minValue}`);
      }
      if (props.maxValue) {
        array.push(`Maximal order: ${props.maxValue}`);
      }
      if (array.length === 0) {
        return "no min and max order";
      }
      return array.join(" and ");
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["inline-flex space-x-1 items-center", { tooltip: __props.showTooltip }],
        "data-tip": unref(dataTip)
      }, _attrs))}><button${ssrRenderAttrs(mergeProps({
        disabled: unref(disabledDecrement),
        class: "btn btn-sm btn-primary h-8 w-8 !p-0",
        type: "button"
      }, _ctx.$attrs))}>`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "i-heroicons-minus",
        class: "h-4 w-4"
      }, null, _parent));
      _push(`</button><div class="px-3">${ssrInterpolate(unref(input))}</div><button${ssrRenderAttrs(mergeProps({
        type: "button",
        class: "btn btn-sm btn-primary h-8 w-8 !p-0",
        disabled: unref(disabledIncrement)
      }, _ctx.$attrs))}>`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "i-heroicons-plus",
        class: "h-4 w-4"
      }, null, _parent));
      _push(`</button></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/NumberUpDown.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "Tour2",
  __ssrInlineRender: true,
  props: {
    modelValue: { type: Boolean, default: false },
    dataLocation: {
      type: Array
    }
  },
  emits: ["update:modelValue", "functiSave"],
  setup(__props, { emit }) {
    const { locale, t: $t } = useI18n();
    useRequestHelper();
    useRequestOptions();
    const { tourSearchSchema, tourSearchSchema2 } = useSchema();
    useRouter();
    const selectedLocationName = ref();
    const formData = ref({
      location_id: void 0,
      activity_date: void 0
      // tourist_numbers: undefined,
    });
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedTourData,
      clearSavedTourData
    } = useTourForm({
      callback: () => {
        alert("Form has been submitted!");
      }
    });
    function onSubmit() {
      dataForm.value.location_id = formData.value.location_id;
      dataForm.value.location_name = selectedLocationName.value;
      dataForm.value.activity_date = formData.value.activity_date;
      saveFormData();
      location.reload();
      emit("update:modelValue", false);
    }
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIFormMGroup = _sfc_main$5;
      const _component_UIFormMTextField = _sfc_main$6;
      const _component_UIBtn = _sfc_main$7;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        onSubmit,
        "validation-schema": unref(tourSearchSchema2),
        class: "space-y-4 w-full"
      }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid md:grid-cols-1 w-full gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "activity_date",
              label: unref($t)("pilih-tanggal")
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "activity_date",
                    type: "date",
                    min: unref(today),
                    modelValue: unref(formData).activity_date,
                    "onUpdate:modelValue": ($event) => unref(formData).activity_date = $event,
                    placeholder: "ex:2024-01-01"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "activity_date",
                      type: "date",
                      min: unref(today),
                      modelValue: unref(formData).activity_date,
                      "onUpdate:modelValue": ($event) => unref(formData).activity_date = $event,
                      placeholder: "ex:2024-01-01"
                    }, null, 8, ["min", "modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<div class="flex justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              variant: "primary",
              type: "submit"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref($t)("select-date"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref($t)("select-date")), 1)
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid md:grid-cols-1 w-full gap-4" }, [
                createVNode(_component_UIFormMGroup, {
                  name: "activity_date",
                  label: unref($t)("pilih-tanggal")
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      name: "activity_date",
                      type: "date",
                      min: unref(today),
                      modelValue: unref(formData).activity_date,
                      "onUpdate:modelValue": ($event) => unref(formData).activity_date = $event,
                      placeholder: "ex:2024-01-01"
                    }, null, 8, ["min", "modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }, 8, ["label"]),
                createVNode("div", { class: "flex justify-end" }, [
                  createVNode(_component_UIBtn, {
                    variant: "primary",
                    type: "submit"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref($t)("select-date")), 1)
                    ]),
                    _: 1
                  })
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Share/Filter/Tour2.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main$1;
const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b;
    let __temp, __restore;
    const { locale, t: $t } = useI18n();
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    const route = useRoute();
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedTourData,
      clearSavedTourData
    } = useTourForm({
      callback: () => {
        console.log("Form has been submitted!");
      }
    });
    const slug = computed(() => route.params.slug);
    const apiData = ref(null);
    const variants = ref([]);
    const totalPrice = ref(0);
    const showModal = ref(false);
    const totalPriceUSD = ref(0);
    const result = computed(() => {
      var _a2, _b2, _c;
      return ((_c = (_b2 = (_a2 = apiData.value) == null ? void 0 : _a2.data) == null ? void 0 : _b2.locations) == null ? void 0 : _c.map((item) => item.name).join(" - ")) || "";
    });
    const { data, error } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "tours",
      () => $fetch(`/tours/${slug.value}?lang=${locale.value}`, {
        headers: {
          Accept: "application/json"
        },
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    apiData.value = data.value;
    const initializeVariants = () => {
      var _a2, _b2, _c, _d, _e, _f, _g, _h;
      if ((_b2 = (_a2 = apiData.value) == null ? void 0 : _a2.data) == null ? void 0 : _b2.variants) {
        variants.value = apiData.value.data.variants.map((variant, index) => ({
          ...variant,
          quantity: 0,
          isChecked: false,
          totalItemPrice: 0,
          totalItemPriceUSD: 0
        }));
      }
      totalPrice.value = ((_e = (_d = (_c = apiData.value) == null ? void 0 : _c.data) == null ? void 0 : _d.variants[0]) == null ? void 0 : _e.price) || 0;
      totalPriceUSD.value = ((_h = (_g = (_f = apiData.value) == null ? void 0 : _f.data) == null ? void 0 : _g.variants[0]) == null ? void 0 : _h.usd_price) || 0;
    };
    initializeVariants();
    const updateTotalPrice = () => {
      totalPrice.value = variants.value.reduce((total, variant) => {
        variant.totalItemPrice = variant.price * variant.quantity;
        return variant.isChecked ? total + variant.totalItemPrice : total;
      }, 0);
    };
    const updateTotalPriceUSD = () => {
      totalPriceUSD.value = variants.value.reduce((total, variant) => {
        variant.totalItemPriceUSD = variant.usd_price * variant.quantity;
        return variant.isChecked ? total + variant.totalItemPriceUSD : total;
      }, 0);
    };
    const handleVariantChange = (index) => {
      const variant = variants.value[index];
      if (variant.isChecked && variant.quantity === 0) {
        variant.quantity = 1;
      } else if (!variant.isChecked) {
        variant.quantity = 0;
      }
      updateTotalPrice();
      updateTotalPriceUSD();
    };
    const handleQuantityChange = (index, newQuantity) => {
      const variant = variants.value[index];
      if (newQuantity > variant.max_person) {
        newQuantity = variant.max_person;
      }
      variant.quantity = newQuantity;
      if (newQuantity > 0 && !variant.isChecked) {
        variant.isChecked = true;
      } else if (newQuantity === 0) {
        variant.isChecked = false;
      }
      updateTotalPrice();
      updateTotalPriceUSD();
    };
    const getMaxValueForVariant = (index) => {
      return variants.value[index].max_person;
    };
    const continueOnsubmit = () => {
      dataForm.value.price = totalPrice.value;
      dataForm.value.usd_price = totalPriceUSD.value;
      dataForm.value.variants = variants.value.filter(
        (variant) => variant.quantity > 0
      );
      saveFormData();
      router.push({ path: "/tours/booking" });
    };
    watch(
      variants,
      () => {
        updateTotalPrice();
        updateTotalPriceUSD();
      },
      { deep: true }
    );
    const isButtonDisabled = computed(() => {
      return variants.value.every((variant) => variant.quantity === 0);
    });
    function modalWhenNotSelectDate() {
      showModal.value = !showModal.value;
    }
    const isLocationIdorActivity = computed(() => {
      return dataForm.value.activity_date === null;
    });
    useHead({
      title: computed(() => {
        var _a2, _b2;
        return (_b2 = (_a2 = apiData.value) == null ? void 0 : _a2.data) == null ? void 0 : _b2.name;
      }),
      meta: [
        {
          name: "description",
          content: (_b = (_a = apiData.value) == null ? void 0 : _a.data) == null ? void 0 : _b.meta
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a2;
      const _component_TourSwiper = __nuxt_component_0;
      const _component_UIContainer = __nuxt_component_0$2;
      const _component_Icon = __nuxt_component_0$1;
      const _component_NumberUpDown = _sfc_main$2;
      const _component_ShareCtaSection = _sfc_main$4;
      const _component_modal = __nuxt_component_3;
      const _component_ShareFilterTour2 = __nuxt_component_6;
      _push(`<!--[--><div data-v-cf6c79fd><div class="h-44 sm:h-28" data-v-cf6c79fd></div>`);
      _push(ssrRenderComponent(_component_TourSwiper, {
        data: (_a2 = unref(apiData).data) == null ? void 0 : _a2.images
      }, null, _parent));
      _push(`<div class="h-5" data-v-cf6c79fd></div>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a3, _b2, _c, _d, _e, _f;
          if (_push2) {
            _push2(`<div class="grid sm:grid-cols-2 lg:space-y-0 lg:space-x-4 w-full my-2 lg:my-4" data-v-cf6c79fd${_scopeId}><div class="flex flex-col space-y-2 gap-2" data-v-cf6c79fd${_scopeId}><h1 class="text-xl lg:text-[32px] lg:leading-[40px] font-semibold" data-v-cf6c79fd${_scopeId}>${ssrInterpolate((_a3 = unref(apiData).data) == null ? void 0 : _a3.name)}</h1><div class="inline-flex space-x-2" data-v-cf6c79fd${_scopeId}><div data-v-cf6c79fd${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Icon, {
              name: "ph:map-pin-line-fill",
              class: "w-5 h-5 text-[#00A59A]"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="text-zinc-400" data-v-cf6c79fd${_scopeId}>${ssrInterpolate(unref(result))}</div></div></div><div class="flex justify-end w-full pt-5" data-v-cf6c79fd${_scopeId}><div class="flex items-center justify-end" data-v-cf6c79fd${_scopeId}>`);
            if (unref(isLocationIdorActivity)) {
              _push2(`<button class="btn btn-primary" type="button"${ssrIncludeBooleanAttr(unref(isLocationIdorActivity)) ? " disabled" : ""} data-v-cf6c79fd${_scopeId}>${ssrInterpolate(unref($t)("lanjutkan"))}</button>`);
            } else {
              _push2(`<button class="btn btn-primary" type="button"${ssrIncludeBooleanAttr(unref(isButtonDisabled)) ? " disabled" : ""} data-v-cf6c79fd${_scopeId}>${ssrInterpolate(unref($t)("lanjutkan"))}</button>`);
            }
            _push2(`</div></div></div><div class="h-5" data-v-cf6c79fd${_scopeId}></div><div class="grid grid-cols-1 md:grid-cols-[150px_1fr] gap-4 mb-4 sm:mb-6 md:mb-8 lg:mb-10" data-v-cf6c79fd${_scopeId}><div class="text-2xl font-semibold pt-5 md:pt-10" data-v-cf6c79fd${_scopeId}>${ssrInterpolate(unref($t)("variant"))}</div><div class="flex flex-col gap-3 relative" data-v-cf6c79fd${_scopeId}>`);
            if (unref(isLocationIdorActivity)) {
              _push2(`<div class="absolute w-full h-full bg-gray-500 bg-opacity-20 rounded-lg" data-v-cf6c79fd${_scopeId}></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<!--[-->`);
            ssrRenderList(unref(variants), (item, index) => {
              _push2(`<div class="form-control" data-v-cf6c79fd${_scopeId}><div class="flex flex-row space-x-4" data-v-cf6c79fd${_scopeId}><div class="flex p-2 gap-2 sm:p-4 sm:gap-3 w-full" data-v-cf6c79fd${_scopeId}><div class="form-control" data-v-cf6c79fd${_scopeId}><label class="cursor-pointer label" data-v-cf6c79fd${_scopeId}><input type="checkbox"${ssrIncludeBooleanAttr(Array.isArray(item.isChecked) ? ssrLooseContain(item.isChecked, null) : item.isChecked) ? " checked" : ""} class="checkbox checkbox-primary" data-v-cf6c79fd${_scopeId}></label></div><div class="flex flex-col w-full gap-2 md:gap-3" data-v-cf6c79fd${_scopeId}><p class="text-black text-sm lg:text-base font-semibold pt-1" data-v-cf6c79fd${_scopeId}>${ssrInterpolate(item.name)}</p><p class="text-black text-sm lg:text-base font-medium pt-1" data-v-cf6c79fd${_scopeId}>${ssrInterpolate(item.description)}</p><div class="flex items-center justify-between gap-4 mt-2" data-v-cf6c79fd${_scopeId}>`);
              _push2(ssrRenderComponent(_component_NumberUpDown, {
                modelValue: item.quantity,
                "onUpdate:modelValue": [
                  ($event) => item.quantity = $event,
                  (newValue) => handleQuantityChange(index, newValue)
                ],
                minValue: 0,
                maxValue: getMaxValueForVariant(index)
              }, null, _parent2, _scopeId));
              _push2(`<div class="text-sm sm:text-base md:text-lg font-semibold" data-v-cf6c79fd${_scopeId}>${ssrInterpolate(unref(locale) === "en" ? ("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(
                item.totalItemPriceUSD.toString(),
                "USD"
              ) : ("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(
                item.totalItemPrice.toString(),
                "IDR"
              ))}</div></div></div></div></div></div>`);
            });
            _push2(`<!--]--></div></div><div class="grid grid-cols-1 md:grid-cols-[150px_1fr] gap-4 mb-4 sm:mb-6 md:mb-8 lg:mb-10" data-v-cf6c79fd${_scopeId}><div class="text-2xl font-semibold pt-5 md:pt-10" data-v-cf6c79fd${_scopeId}>${ssrInterpolate(unref($t)("ringkasan"))}</div><div class="rounded-[6px] shadow-sm flex flex-col" data-v-cf6c79fd${_scopeId}><div class="adjustdefault" data-v-cf6c79fd${_scopeId}>${(_c = (_b2 = unref(apiData)) == null ? void 0 : _b2.data) == null ? void 0 : _c.description}</div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid sm:grid-cols-2 lg:space-y-0 lg:space-x-4 w-full my-2 lg:my-4" }, [
                createVNode("div", { class: "flex flex-col space-y-2 gap-2" }, [
                  createVNode("h1", { class: "text-xl lg:text-[32px] lg:leading-[40px] font-semibold" }, toDisplayString((_d = unref(apiData).data) == null ? void 0 : _d.name), 1),
                  createVNode("div", { class: "inline-flex space-x-2" }, [
                    createVNode("div", null, [
                      createVNode(_component_Icon, {
                        name: "ph:map-pin-line-fill",
                        class: "w-5 h-5 text-[#00A59A]"
                      })
                    ]),
                    createVNode("div", { class: "text-zinc-400" }, toDisplayString(unref(result)), 1)
                  ])
                ]),
                createVNode("div", { class: "flex justify-end w-full pt-5" }, [
                  createVNode("div", { class: "flex items-center justify-end" }, [
                    unref(isLocationIdorActivity) ? (openBlock(), createBlock("button", {
                      key: 0,
                      class: "btn btn-primary",
                      type: "button",
                      disabled: unref(isLocationIdorActivity),
                      onClick: ($event) => continueOnsubmit()
                    }, toDisplayString(unref($t)("lanjutkan")), 9, ["disabled", "onClick"])) : (openBlock(), createBlock("button", {
                      key: 1,
                      class: "btn btn-primary",
                      type: "button",
                      disabled: unref(isButtonDisabled),
                      onClick: ($event) => continueOnsubmit()
                    }, toDisplayString(unref($t)("lanjutkan")), 9, ["disabled", "onClick"]))
                  ])
                ])
              ]),
              createVNode("div", { class: "h-5" }),
              createVNode("div", { class: "grid grid-cols-1 md:grid-cols-[150px_1fr] gap-4 mb-4 sm:mb-6 md:mb-8 lg:mb-10" }, [
                createVNode("div", { class: "text-2xl font-semibold pt-5 md:pt-10" }, toDisplayString(unref($t)("variant")), 1),
                createVNode("div", { class: "flex flex-col gap-3 relative" }, [
                  unref(isLocationIdorActivity) ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "absolute w-full h-full bg-gray-500 bg-opacity-20 rounded-lg",
                    onClick: modalWhenNotSelectDate
                  })) : createCommentVNode("", true),
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(variants), (item, index) => {
                    return openBlock(), createBlock("div", {
                      key: item.id,
                      class: "form-control"
                    }, [
                      createVNode("div", { class: "flex flex-row space-x-4" }, [
                        createVNode("div", { class: "flex p-2 gap-2 sm:p-4 sm:gap-3 w-full" }, [
                          createVNode("div", { class: "form-control" }, [
                            createVNode("label", { class: "cursor-pointer label" }, [
                              withDirectives(createVNode("input", {
                                type: "checkbox",
                                "onUpdate:modelValue": ($event) => item.isChecked = $event,
                                class: "checkbox checkbox-primary",
                                onChange: ($event) => handleVariantChange(index)
                              }, null, 40, ["onUpdate:modelValue", "onChange"]), [
                                [vModelCheckbox, item.isChecked]
                              ])
                            ])
                          ]),
                          createVNode("div", { class: "flex flex-col w-full gap-2 md:gap-3" }, [
                            createVNode("p", { class: "text-black text-sm lg:text-base font-semibold pt-1" }, toDisplayString(item.name), 1),
                            createVNode("p", { class: "text-black text-sm lg:text-base font-medium pt-1" }, toDisplayString(item.description), 1),
                            createVNode("div", { class: "flex items-center justify-between gap-4 mt-2" }, [
                              createVNode(_component_NumberUpDown, {
                                modelValue: item.quantity,
                                "onUpdate:modelValue": [
                                  ($event) => item.quantity = $event,
                                  (newValue) => handleQuantityChange(index, newValue)
                                ],
                                minValue: 0,
                                maxValue: getMaxValueForVariant(index)
                              }, null, 8, ["modelValue", "onUpdate:modelValue", "maxValue"]),
                              createVNode("div", { class: "text-sm sm:text-base md:text-lg font-semibold" }, toDisplayString(unref(locale) === "en" ? ("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(
                                item.totalItemPriceUSD.toString(),
                                "USD"
                              ) : ("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(
                                item.totalItemPrice.toString(),
                                "IDR"
                              )), 1)
                            ])
                          ])
                        ])
                      ])
                    ]);
                  }), 128))
                ])
              ]),
              createVNode("div", { class: "grid grid-cols-1 md:grid-cols-[150px_1fr] gap-4 mb-4 sm:mb-6 md:mb-8 lg:mb-10" }, [
                createVNode("div", { class: "text-2xl font-semibold pt-5 md:pt-10" }, toDisplayString(unref($t)("ringkasan")), 1),
                createVNode("div", { class: "rounded-[6px] shadow-sm flex flex-col" }, [
                  createVNode("div", {
                    innerHTML: (_f = (_e = unref(apiData)) == null ? void 0 : _e.data) == null ? void 0 : _f.description,
                    class: "adjustdefault"
                  }, null, 8, ["innerHTML"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_ShareCtaSection, { link: "/" }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_modal, {
        modelValue: unref(showModal),
        "onUpdate:modelValue": ($event) => isRef(showModal) ? showModal.value = $event : null,
        class: "relative w-[90%] sm:w-[60%] lg:w-[70%]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a3, _b2, _c, _d;
          if (_push2) {
            _push2(`<div class="flex justify-center items-center flex-col p-2 sm:p-5 lg:p-10 overflow-auto" data-v-cf6c79fd${_scopeId}>`);
            _push2(ssrRenderComponent(_component_ShareFilterTour2, {
              modelValue: unref(showModal),
              "onUpdate:modelValue": ($event) => isRef(showModal) ? showModal.value = $event : null,
              dataLocation: (_b2 = (_a3 = unref(apiData)) == null ? void 0 : _a3.data) == null ? void 0 : _b2.locations
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex justify-center items-center flex-col p-2 sm:p-5 lg:p-10 overflow-auto" }, [
                createVNode(_component_ShareFilterTour2, {
                  modelValue: unref(showModal),
                  "onUpdate:modelValue": ($event) => isRef(showModal) ? showModal.value = $event : null,
                  dataLocation: (_d = (_c = unref(apiData)) == null ? void 0 : _c.data) == null ? void 0 : _d.locations
                }, null, 8, ["modelValue", "onUpdate:modelValue", "dataLocation"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tours/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _slug_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-cf6c79fd"]]);

export { _slug_ as default };
//# sourceMappingURL=_slug_-7c5c3df9.mjs.map
