import { ref } from 'vue';
import { m as defineStore } from '../server.mjs';

const useNotification = defineStore("Notification", () => {
  const messages = ref([]);
  function pushNotification(notification) {
    messages.value.push({
      id: (/* @__PURE__ */ new Date()).getTime(),
      ...notification,
      timer: 60
    });
  }
  function clearNotification() {
    messages.value = [];
  }
  return {
    messages,
    pushNotification,
    clearNotification
  };
});

export { useNotification as u };
//# sourceMappingURL=nofication-1c3cca5e.mjs.map
