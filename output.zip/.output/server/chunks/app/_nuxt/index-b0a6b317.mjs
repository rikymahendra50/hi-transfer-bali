import __nuxt_component_0$3 from './Icon-0f6314e3.mjs';
import { useSSRContext, defineComponent, withCtx, createVNode, mergeProps, unref, ref, computed, watch, nextTick, toRef, inject, isRef, withAsyncContext, resolveComponent, openBlock, createBlock, toDisplayString, createTextVNode, createCommentVNode, Fragment, renderList, withModifiers } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderTeleport, ssrRenderClass, ssrRenderSlot, ssrGetDynamicModelProps, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseEqual, ssrRenderList } from 'vue/server-renderer';
import clsx from 'clsx';
import { useField, Form, Field, ErrorMessage } from 'vee-validate';
import { _ as _sfc_main$d } from './MGroup-e711cd83.mjs';
import { f as useI18n, a as useHead, d as useRoute, b as useRouter, h as useRequestHelper, e as useRequestOptions, g as useAsyncData, l as _export_sfc, k as useNuxtApp } from '../server.mjs';
import { o as onClickOutside, u as useStepper, d as useBreakpoints, e as breakpointsTailwind } from './index-a61f78d7.mjs';
import { _ as _sfc_main$e } from './MTextField-bd75102a.mjs';
import { _ as _sfc_main$f } from './MSelect-8e6f95b5.mjs';
import { _ as _sfc_main$g } from './Btn-577fa59f.mjs';
import { u as useNotification } from './nofication-1c3cca5e.mjs';
import { u as useSchema } from './useSchema-0246d9f0.mjs';
import { u as useTourForm$1 } from './useCarStore-4fa50219.mjs';
import { u as useTourForm } from './useTourStore-4a6f0bac.mjs';
import { _ as __nuxt_component_0$2 } from './Container-f78810bd.mjs';
import { _ as __nuxt_component_4 } from './Card-80efc1d3.mjs';
import { _ as _sfc_main$c } from './CtaSection-c459c0c9.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './TransitionX-601819e8.mjs';
import './index-596a8548.mjs';
import 'zod';
import '@vee-validate/zod';
import './FormatMoneyDash-4b79c187.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main$b = /* @__PURE__ */ defineComponent({
  __name: "TabLink",
  __ssrInlineRender: true,
  props: {
    label: {},
    icon: {},
    isActive: { type: Boolean, default: false }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_0$3;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: unref(clsx)(
          "inline-flex space-x-2 items-center text-zinc-400 hover:border-b-2 py-2 hover:bg-green-100 transition-colors duration-300 px-2 hover:text-primary hover:border-primary hover:bg-opacity-30 cursor-pointer",
          {
            "border-b-2 border-primary bg-opacity-30 !text-primary bg-green-100": props.isActive
          }
        )
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_Icon, {
        name: props.icon,
        class: "h-5 w-5"
      }, null, _parent));
      _push(`<div class="text-sm md:text-lg">${ssrInterpolate(props.label)}</div></div>`);
    };
  }
});
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Share/Menu/TabLink.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const _sfc_main$a = {
  __name: "Map",
  __ssrInlineRender: true,
  props: {
    latitude: {
      type: [String, Number]
    },
    longitude: {
      type: [String, Number]
    },
    locationAddress: {
      type: [String, Number]
    },
    locationName: {
      type: String
    },
    dataJikaSudahada3: {
      type: [Array, Object]
    }
  },
  emits: [
    "update:longitude",
    "update:latitude",
    "update:locationAddress",
    "update:locationName",
    "hideModal"
  ],
  setup(__props, { emit }) {
    var _a2, _b2, _c2, _d2, _e2, _f2, _g2, _h2;
    var _a, _b, _c, _d, _e, _f, _g, _h;
    const props = __props;
    const { $toast } = useNuxtApp();
    const center = ref({
      lat: (_a2 = (_a = props.dataJikaSudahada3) == null ? void 0 : _a.latitude) != null ? _a2 : -8.417347915171359,
      lng: (_b2 = (_b = props.dataJikaSudahada3) == null ? void 0 : _b.longitude) != null ? _b2 : 115.19596919507471
    });
    const currentMarkerPosition = ref({
      lat: (_c2 = (_c = props.dataJikaSudahada3) == null ? void 0 : _c.latitude) != null ? _c2 : -8.417347915171359,
      lng: (_d2 = (_d = props.dataJikaSudahada3) == null ? void 0 : _d.longitude) != null ? _d2 : 115.19596919507471
    });
    const latitudeFix = ref(
      (_e2 = (_e = props.dataJikaSudahada3) == null ? void 0 : _e.latitude) != null ? _e2 : -8.417347915171359
    );
    const longitudeFix = ref(
      (_f2 = (_f = props.dataJikaSudahada3) == null ? void 0 : _f.longitude) != null ? _f2 : 115.19596919507471
    );
    const locationAddress = ref((_g2 = (_g = props.dataJikaSudahada3) == null ? void 0 : _g.locationAddress) != null ? _g2 : "");
    const locationName = ref((_h2 = (_h = props.dataJikaSudahada3) == null ? void 0 : _h.locationName) != null ? _h2 : "");
    const baliBounds = {
      minLat: -9,
      // Menambah area ke selatan
      maxLat: -8,
      // Memperbaiki area utara
      minLng: 114,
      // Menambah area ke barat
      maxLng: 115.7
      // Memperbaiki area timur
    };
    async function fetchAddress(latitude, longitude) {
      const geocoder = new google.maps.Geocoder();
      const latLng = {
        lat: parseFloat(latitude.value),
        lng: parseFloat(longitude.value)
      };
      geocoder.geocode({ location: latLng }, (results, status) => {
        if (status === "OK" && results.length > 0) {
          locationAddress.value = results[0].formatted_address;
          locationName.value = getDescriptiveLocationName(
            results[0].address_components
          );
        } else {
          alert("Geocode was not successful: " + status);
        }
      });
    }
    function handleMapClick(event) {
      const latitude = event.latLng.lat();
      const longitude = event.latLng.lng();
      if (isWithinBaliBounds(latitude, longitude)) {
        currentMarkerPosition.value = { lat: latitude, lng: longitude };
        center.value = { lat: latitude, lng: longitude };
        latitudeFix.value = latitude;
        longitudeFix.value = longitude;
      } else {
        $toast.error($t("lokasi-harus-dibali"));
      }
    }
    function setPlace(ctx) {
      var _a22, _b22, _c22, _d22;
      const latitude = (_b22 = (_a22 = ctx.geometry) == null ? void 0 : _a22.location) == null ? void 0 : _b22.lat();
      const longitude = (_d22 = (_c22 = ctx.geometry) == null ? void 0 : _c22.location) == null ? void 0 : _d22.lng();
      if (isWithinBaliBounds(latitude, longitude)) {
        currentMarkerPosition.value = { lat: latitude, lng: longitude };
        center.value = { lat: latitude, lng: longitude };
        latitudeFix.value = latitude;
        longitudeFix.value = longitude;
      } else {
        $toast.error($t("lokasi-harus-dibali"));
      }
    }
    function isWithinBaliBounds(lat, lng) {
      return lat >= baliBounds.minLat && lat <= baliBounds.maxLat && lng >= baliBounds.minLng && lng <= baliBounds.maxLng;
    }
    function getDescriptiveLocationName(addressComponents) {
      const types = [
        "establishment",
        "point_of_interest",
        // "locality",
        // "administrative_area_level_1",
        "country",
        // "administrative_area_level_2",
        // "administrative_area_level_3",
        // "administrative_area_level_4",
        // "administrative_area_level_5",
        // "administrative_area_level_6",
        // "administrative_area_level_7",
        "archipelago",
        // "colloquial_area",
        "continent",
        "food",
        "floor",
        "general_contractor",
        "geocode",
        "health",
        // "intersection",
        "landmark",
        "natural_feature",
        "neighborhood",
        "place_of_worship",
        "political"
        // "plus_code",
        // "postal_code",
        // "postal_code_prefix",
        // "postal_code_suffix",
        // "postal_town",
        // "premise",
        // "room",
        // "route",
        // "street_address",
        // "street_number",
        // "sublocality",
        // "sublocality_level_1",
        // "sublocality_level_2",
        // "sublocality_level_3",
        // "sublocality_level_4",
        // "sublocality_level_5",
        // "subpremise",
        // "town_square",
      ];
      for (const component of addressComponents) {
        if (types.some((type) => component.types.includes(type))) {
          console.log(component);
          return component.long_name;
        }
      }
      return addressComponents[0].long_name;
    }
    watch(
      () => latitudeFix.value,
      () => {
        fetchAddress(latitudeFix, longitudeFix);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_GMapAutocomplete = resolveComponent("GMapAutocomplete");
      const _component_GMapMap = resolveComponent("GMapMap");
      const _component_GMapMarker = resolveComponent("GMapMarker");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "rounded-lg overflow-hidden relative" }, _attrs))} data-v-55b653ea><div class="my-2 bg-yellow-600 w-fit px-2 py-1 rounded-lg text-gray-100 text-sm md:text-base" data-v-55b653ea><p data-v-55b653ea>${ssrInterpolate(_ctx.$t("pastikan-lokasi"))}</p></div><div class="relative z-[10000] grid md:flex gap-3 items-center" data-v-55b653ea><button class="btn border-primary border bg-white text-primary md:mb-3" data-v-55b653ea>${ssrInterpolate(_ctx.$t("dapatkan-lokasi-anda"))}</button>`);
      _push(ssrRenderComponent(_component_GMapAutocomplete, {
        class: "input input-bordered flex-grow mb-3",
        placeholder: "Search Location",
        onPlace_changed: setPlace,
        "select-first-on-enter": true
      }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_GMapMap, {
        center: center.value,
        zoom: 14,
        "map-type-id": "terrain",
        style: { "width": "100%", "height": "270px" },
        options: {
          disableDefaultUi: false,
          draggableCursor: "pointer"
        },
        onClick: handleMapClick
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_GMapMarker, {
              key: "current",
              position: currentMarkerPosition.value,
              icon: {
                url: "/marker-red.svg",
                scaledSize: { width: 50, height: 50 }
              },
              clickable: true
            }, null, _parent2, _scopeId));
          } else {
            return [
              (openBlock(), createBlock(_component_GMapMarker, {
                key: "current",
                position: currentMarkerPosition.value,
                icon: {
                  url: "/marker-red.svg",
                  scaledSize: { width: 50, height: 50 }
                },
                clickable: true
              }, null, 8, ["position", "icon"]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="flex justify-between mt-3 items-center gap-3" data-v-55b653ea><div class="grid gap-1" data-v-55b653ea><p class="font-semibold lg:text-[20px]" data-v-55b653ea>${ssrInterpolate(_ctx.$t("location"))} :</p><p class="text-sm" data-v-55b653ea>${ssrInterpolate(locationName.value)}</p><p class="text-sm" data-v-55b653ea>${ssrInterpolate(locationAddress.value)}</p></div><button type="submit" class="bg-primary text-sm text-white normal-case !font-medium hover:bg-primary whitespace-nowrap md:col-span-2 btn" data-v-55b653ea>${ssrInterpolate(_ctx.$t("pilih-lokasi-ini"))}</button></div></div>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Map.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const __nuxt_component_1$1 = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["__scopeId", "data-v-55b653ea"]]);
const _sfc_main$9 = /* @__PURE__ */ Object.assign({
  inheritAttrs: false
}, {
  __name: "ModalMap",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      type: Boolean,
      default: false
    },
    clickOutside: {
      type: Boolean,
      default: false
    },
    latitude: {
      type: [String, Number]
    },
    longitude: {
      type: [String, Number]
    },
    locationAddress: {
      type: [String, Number]
    },
    locationName: {
      type: String
    },
    dataJikaSudahada2: {
      type: [Array, Object]
    }
  },
  emits: [
    "update:modelValue",
    "update:longitude",
    "update:latitude",
    "update:locationAddress",
    "update:locationName"
  ],
  setup(__props, { expose: __expose, emit }) {
    const props = __props;
    const modal = ref(null);
    const showModal = computed({
      get() {
        return props.modelValue;
      },
      set(value) {
        emit("update:modelValue", value);
      }
    });
    function hideModal() {
      showModal.value = false;
    }
    watch(showModal, (newValue) => {
      if (newValue) {
        nextTick(() => {
          onClickOutside(modal, () => {
            if (props.clickOutside) {
              hideModal();
            }
          });
        });
      }
    });
    __expose({
      hideModal
    });
    const formData = ref({
      latitude: void 0,
      longitude: void 0,
      locationAddress: void 0,
      locationName: void 0
    });
    watch(
      () => formData.value.latitude,
      (newValue, oldValue) => {
        emit("update:latitude", newValue);
      }
    );
    watch(
      () => formData.value.longitude,
      (newValue, oldValue) => {
        emit("update:longitude", newValue);
      }
    );
    watch(
      () => formData.value.locationAddress,
      (newValue, oldValue) => {
        emit("update:locationAddress", newValue);
      }
    );
    watch(
      () => formData.value.locationName,
      (newValue, oldValue) => {
        emit("update:locationName", newValue);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_0$3;
      const _component_Map = __nuxt_component_1$1;
      ssrRenderTeleport(_push, (_push2) => {
        if (unref(showModal)) {
          _push2(`<div class="modal-background" data-v-14bbed61></div>`);
        } else {
          _push2(`<!---->`);
        }
        if (unref(showModal)) {
          _push2(`<dialog class="${ssrRenderClass([{
            "modal-open": unref(showModal)
          }, "modal z-[99] !bg-transparent"])}" data-v-14bbed61><div${ssrRenderAttrs(mergeProps({ class: "modal-content rounded-[10px] !bg-white py-3 w-[90%] px-3 md:w-[60%] overflow-auto h-[90%] md:h-fit" }, _ctx.$attrs, {
            ref_key: "modal",
            ref: modal
          }))} data-v-14bbed61>`);
          if (unref(showModal)) {
            _push2(`<!--[--><div class="flex items-end justify-between pb-4 px-2" data-v-14bbed61><h3 class="font-semibold text-lg" data-v-14bbed61>${ssrInterpolate(_ctx.$t("dijemput-dimana"))}</h3><div class="" data-v-14bbed61><div class="px-1 flex items-center rounded-md cursor-pointer" data-v-14bbed61>`);
            _push2(ssrRenderComponent(_component_Icon, {
              name: "ion:close",
              class: "w-5 h-5"
            }, null, _parent));
            _push2(`</div></div></div>`);
            _push2(ssrRenderComponent(_component_Map, {
              latitude: unref(formData).latitude,
              "onUpdate:latitude": ($event) => unref(formData).latitude = $event,
              longitude: unref(formData).longitude,
              "onUpdate:longitude": ($event) => unref(formData).longitude = $event,
              locationAddress: unref(formData).locationAddress,
              "onUpdate:locationAddress": ($event) => unref(formData).locationAddress = $event,
              locationName: unref(formData).locationName,
              "onUpdate:locationName": ($event) => unref(formData).locationName = $event,
              onHideModal: hideModal,
              dataJikaSudahada3: props.dataJikaSudahada2
            }, null, _parent));
            _push2(`<!--]-->`);
          } else {
            _push2(`<!---->`);
          }
          _push2(`</div></dialog>`);
        } else {
          _push2(`<!---->`);
        }
      }, "body", false, _parent);
    };
  }
});
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ModalMap.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["__scopeId", "data-v-14bbed61"]]);
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "TextFieldWModal",
  __ssrInlineRender: true,
  props: {
    type: { default: "text" },
    modelValue: {},
    name: {},
    class: {},
    disabled: { type: Boolean, default: false },
    ariaLabel: {},
    placeholder: {},
    readonly: { type: Boolean },
    dataJikaSudahada: {}
  },
  emits: [
    "update:longitude",
    "update:latitude",
    "update:locationAddress",
    "update:locationName"
  ],
  setup(__props, { emit }) {
    const props = __props;
    const name = toRef(props, "name");
    const { value, errorMessage } = useField(name, void 0, {
      syncVModel: true
    });
    const { setError } = inject("group-form");
    watch(errorMessage, (value2) => {
      if (value2) {
        setError(true);
      } else {
        setError(false);
      }
    });
    ref();
    const showModal = ref(false);
    const formData = ref({
      latitude: void 0,
      longitude: void 0,
      locationAddress: void 0,
      locationName: void 0
    });
    watch(
      () => formData.value.latitude,
      (newValue, oldValue) => {
        emit("update:latitude", newValue);
      }
    );
    watch(
      () => formData.value.longitude,
      (newValue, oldValue) => {
        emit("update:longitude", newValue);
      }
    );
    watch(
      () => formData.value.locationAddress,
      (newValue, oldValue) => {
        emit("update:locationAddress", newValue);
      }
    );
    watch(
      () => formData.value.locationName,
      (newValue, oldValue) => {
        emit("update:locationName", newValue);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ModalMap = __nuxt_component_0$1;
      let _temp0;
      _push(`<!--[--><label class="${ssrRenderClass(
        unref(clsx)(
          "flex items-center  rounded-lg focus-within:outline-none w-full h-9 overflow-hidden",
          {
            "gap-2": !!_ctx.$slots.leftSection || !!_ctx.$slots.rightSection,
            "pl-0": !_ctx.$slots.leftSection,
            "pr-0": !_ctx.$slots.rightSection
          }
        )
      )}">`);
      if (_ctx.$slots.leftSection) {
        ssrRenderSlot(_ctx.$slots, "leftSection", {}, null, _push, _parent);
      } else {
        _push(`<!---->`);
      }
      _push(`<input${ssrRenderAttrs((_temp0 = mergeProps({
        name: unref(name),
        id: unref(name),
        type: _ctx.type,
        readonly: "",
        disabled: _ctx.disabled,
        "aria-label": _ctx.ariaLabel,
        placeholder: _ctx.placeholder,
        class: unref(clsx)(
          "w-full h-full !outline-none focus:!border-none disabled:bg-gray-50 cursor-pointer",
          {
            "px-1": !_ctx.$slots.leftSection || !_ctx.$slots.rightSection
          }
        )
      }, _ctx.$attrs), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, unref(value)))))}>`);
      if (_ctx.$slots.rightSection) {
        ssrRenderSlot(_ctx.$slots, "rightSection", {}, null, _push, _parent);
      } else {
        _push(`<!---->`);
      }
      _push(`</label>`);
      _push(ssrRenderComponent(_component_ModalMap, {
        modelValue: unref(showModal),
        "onUpdate:modelValue": ($event) => isRef(showModal) ? showModal.value = $event : null,
        latitude: unref(formData).latitude,
        "onUpdate:latitude": ($event) => unref(formData).latitude = $event,
        longitude: unref(formData).longitude,
        "onUpdate:longitude": ($event) => unref(formData).longitude = $event,
        locationAddress: unref(formData).locationAddress,
        "onUpdate:locationAddress": ($event) => unref(formData).locationAddress = $event,
        locationName: unref(formData).locationName,
        "onUpdate:locationName": ($event) => unref(formData).locationName = $event,
        dataJikaSudahada2: props.dataJikaSudahada
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/TextFieldWModal.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "Toggle",
  __ssrInlineRender: true,
  props: {
    name: {},
    label: {},
    modelValue: {},
    disabled: { type: Boolean, default: false },
    trueValue: { default: 1 },
    falseValue: { default: 0 },
    ariaLabel: { default: "toggle" },
    variant: {},
    size: {},
    class: {},
    readonly: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const name = toRef(props, "name");
    const variants = [
      "toggle-primary",
      "toggle-secondary",
      "toggle-accent",
      "toggle-info",
      "toggle-success",
      "toggle-warning",
      "toggle-error"
    ];
    const sizes = [
      "toggle-xs",
      "toggle-sm",
      "toggle-md",
      "toggle-lg"
    ];
    const {
      value,
      errorMessage
    } = useField(name, void 0, {
      syncVModel: true
    });
    const toggleClass = computed(() => {
      return clsx(
        "toggle",
        variants[variants.indexOf(`toggle-${props.variant}`)],
        sizes[sizes.indexOf(`toggle-${props.size}`)],
        props.class
      );
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "form-control w-full" }, _attrs))}><label class="label !justify-start cursor-pointer inline-flex gap-4"><input type="checkbox" class="${ssrRenderClass(unref(toggleClass))}"${ssrRenderAttr("name", props.name)}${ssrIncludeBooleanAttr(props.disabled) ? " disabled" : ""}${ssrIncludeBooleanAttr(ssrLooseEqual(unref(value), props.trueValue)) ? " checked" : ""}${ssrRenderAttr("aria-label", _ctx.ariaLabel)}${ssrIncludeBooleanAttr(props.readonly) ? " readonly" : ""}>`);
      if (props.label || _ctx.$slots.default) {
        _push(`<span class="label-text">`);
        ssrRenderSlot(_ctx.$slots, "default", {}, () => {
          _push(`${ssrInterpolate(props.label)}`);
        }, _push, _parent);
        _push(`</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</label></div>`);
    };
  }
});
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/Toggle.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const _sfc_main$6 = {
  __name: "Vehicle",
  __ssrInlineRender: true,
  setup(__props) {
    useRequestOptions();
    const { loading, message, alertType, setErrorMessage, transformErrors } = useRequestHelper();
    useNotification();
    const { carSearchSchema, carSearchSchemaIfPickUpTrue } = useSchema();
    const { locale, t: $t2 } = useI18n();
    const breakpoints = useBreakpoints(breakpointsTailwind);
    const isMobile = breakpoints.smaller("lg");
    useRouter();
    const { $toast } = useNuxtApp();
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedCarData,
      clearSavedCarData
    } = useTourForm$1({
      callback: () => {
        console.log("Form has been submitted!");
      }
    });
    const formDataJemput = ref({
      latitude: void 0,
      longitude: void 0,
      locationAddress: void 0,
      locationName: void 0
    });
    const formDataTujuan = ref({
      latitude: void 0,
      longitude: void 0,
      locationAddress: void 0,
      locationName: void 0
    });
    const distance = ref();
    const distanceRound = ref();
    const dateReturnDisabled = computed(() => {
      if (dataForm.value.round_trip == 1) {
        dataForm.value.return_date = void 0;
        return false;
      } else if (dataForm.value.round_trip == 0) {
        return true;
      }
    });
    const carSearchSchemaShouldUse = computed(() => {
      if (dateReturnDisabled.value) {
        return carSearchSchema;
      } else {
        return carSearchSchemaIfPickUpTrue;
      }
    });
    watch(
      () => dataForm.value.pickup_date,
      (newPickupDate) => {
        if (newPickupDate && dataForm.value.return_date < newPickupDate) {
          dataForm.value.return_date = "";
        }
      }
    );
    watch(
      () => formDataJemput.value.longitude,
      (newValue, oldValue) => {
        formDataJemput.value.longitude = newValue;
        calculateDistanceMatrix();
      }
    );
    watch(
      () => formDataJemput.value.latitude,
      (newValue, oldValue) => {
        formDataJemput.value.latitude = newValue;
        calculateDistanceMatrix();
      }
    );
    watch(
      () => formDataTujuan.value.longitude,
      (newValue, oldValue) => {
        formDataTujuan.value.longitude = newValue;
        calculateDistanceMatrix();
      }
    );
    watch(
      () => formDataTujuan.value.latitude,
      (newValue, oldValue) => {
        formDataTujuan.value.latitude = newValue;
        calculateDistanceMatrix();
      }
    );
    watch(
      () => dataForm.value.round_trip,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          calculateDistanceMatrix();
        }
      }
    );
    const maxReturnDate = ref("");
    watch(
      () => dataForm.value.pickup_date,
      (newPickupDate) => {
        if (newPickupDate) {
          const pickupDate = new Date(newPickupDate);
          const returnDate = new Date(pickupDate);
          returnDate.setDate(pickupDate.getDate() + 7);
          maxReturnDate.value = returnDate.toISOString().split("T")[0];
        } else {
          maxReturnDate.value = "";
        }
      }
    );
    async function calculateDistanceMatrix() {
      if (formDataJemput.value.latitude && formDataTujuan.value.latitude) {
        const lat1 = parseFloat(formDataJemput.value.latitude);
        const lng1 = parseFloat(formDataJemput.value.longitude);
        const lat2 = parseFloat(formDataTujuan.value.latitude);
        const lng2 = parseFloat(formDataTujuan.value.longitude);
        const origin = { lat: lat1, lng: lng1 };
        const destination = { lat: lat2, lng: lng2 };
        const service = new window.google.maps.DistanceMatrixService();
        await service.getDistanceMatrix(
          {
            origins: [origin],
            destinations: [destination],
            travelMode: "DRIVING"
          },
          (response, status) => {
            var _a, _b, _c;
            if (status === "OK") {
              const result = response.rows[0].elements[0];
              distance.value = (_a = result == null ? void 0 : result.distance) == null ? void 0 : _a.value;
              distanceRound.value = (_b = result == null ? void 0 : result.distance) == null ? void 0 : _b.text;
              if (((_c = result == null ? void 0 : result.distance) == null ? void 0 : _c.value) > 1e3) {
                dataForm.value.distance = parseInt(distance.value / 1e3);
                dataForm.value.quantity = parseInt(distance.value / 1e3);
                dataForm.value.distance_text = distanceRound.value;
                if (dataForm.value.round_trip == 1) {
                  const test = parseInt(distance.value / 1e3);
                  dataForm.value.distance = test.toFixed(1) * 2;
                  dataForm.value.quantity = test.toFixed(1) * 2;
                }
              } else {
                $toast.error($t2("the-distance-cannot"));
                dataForm.value.distance = "";
                dataForm.value.quantity = "";
                dataForm.value.distance_text = "";
                formDataJemput.value = {};
                formDataTujuan.value = {};
              }
            }
          }
        );
      }
    }
    function onSubmit() {
      if (formDataJemput.value.latitude == formDataTujuan.value.latitude) {
        $toast.error($t2("lokasi-tidak-boleh-sama"));
      } else {
        dataForm.value.location_pickup_address = formDataJemput.value.locationAddress;
        dataForm.value.location_pickup_name = formDataJemput.value.locationName;
        dataForm.value.location_pickup_latitude = formDataJemput.value.latitude;
        dataForm.value.location_pickup_longitude = formDataJemput.value.longitude;
        dataForm.value.location_return_address = formDataTujuan.value.locationAddress;
        dataForm.value.location_return_name = formDataTujuan.value.locationName;
        dataForm.value.location_return_latitude = formDataTujuan.value.latitude;
        dataForm.value.location_return_longitude = formDataTujuan.value.longitude;
        saveFormData();
        window.location.href = "/vehicles";
      }
    }
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIFormMGroup = _sfc_main$d;
      const _component_UIFormTextFieldWModal = _sfc_main$8;
      const _component_Icon = __nuxt_component_0$3;
      const _component_UIFormToggle = _sfc_main$7;
      const _component_UIFormMTextField = _sfc_main$e;
      const _component_UIFormMSelect = _sfc_main$f;
      const _component_UIBtn = _sfc_main$g;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-1" }, _attrs))}><div class="flex justify-center items-center">`);
      if (unref(dataForm).quantity) {
        _push(`<div class="bg-primary flex justify-center rounded-full w-fit items-center px-2"><div class="p-1 text-sm text-white"><span>${ssrInterpolate(unref(dataForm).quantity)} Km</span></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit,
        "validation-schema": unref(carSearchSchemaShouldUse)
      }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 lg:grid-cols-[1fr_50px_1fr] gap-4 items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: unref($t2)("jemput-dimana"),
              name: "pickup_address"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormTextFieldWModal, {
                    modelValue: unref(formDataJemput).locationAddress,
                    "onUpdate:modelValue": ($event) => unref(formDataJemput).locationAddress = $event,
                    latitude: unref(formDataJemput).latitude,
                    "onUpdate:latitude": ($event) => unref(formDataJemput).latitude = $event,
                    longitude: unref(formDataJemput).longitude,
                    "onUpdate:longitude": ($event) => unref(formDataJemput).longitude = $event,
                    locationAddress: unref(formDataJemput).locationAddress,
                    "onUpdate:locationAddress": ($event) => unref(formDataJemput).locationAddress = $event,
                    locationName: unref(formDataJemput).locationName,
                    "onUpdate:locationName": ($event) => unref(formDataJemput).locationName = $event,
                    dataJikaSudahada: unref(formDataJemput),
                    name: "pickup_address",
                    placeholder: "ex:Jalan Pahlawan No. 1"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormTextFieldWModal, {
                      modelValue: unref(formDataJemput).locationAddress,
                      "onUpdate:modelValue": ($event) => unref(formDataJemput).locationAddress = $event,
                      latitude: unref(formDataJemput).latitude,
                      "onUpdate:latitude": ($event) => unref(formDataJemput).latitude = $event,
                      longitude: unref(formDataJemput).longitude,
                      "onUpdate:longitude": ($event) => unref(formDataJemput).longitude = $event,
                      locationAddress: unref(formDataJemput).locationAddress,
                      "onUpdate:locationAddress": ($event) => unref(formDataJemput).locationAddress = $event,
                      locationName: unref(formDataJemput).locationName,
                      "onUpdate:locationName": ($event) => unref(formDataJemput).locationName = $event,
                      dataJikaSudahada: unref(formDataJemput),
                      name: "pickup_address",
                      placeholder: "ex:Jalan Pahlawan No. 1"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "latitude", "onUpdate:latitude", "longitude", "onUpdate:longitude", "locationAddress", "onUpdate:locationAddress", "locationName", "onUpdate:locationName", "dataJikaSudahada"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<div class="flex flex-col gap-1 items-center"${_scopeId}><div class="flex justify-center items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Icon, {
              name: unref(isMobile) ? "i-heroicons-arrows-up-down" : "i-heroicons-arrows-right-left",
              class: "w-6 h-6"
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: unref($t2)("mau-kemana"),
              name: "return_address"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormTextFieldWModal, {
                    modelValue: unref(formDataTujuan).locationAddress,
                    "onUpdate:modelValue": ($event) => unref(formDataTujuan).locationAddress = $event,
                    latitude: unref(formDataTujuan).latitude,
                    "onUpdate:latitude": ($event) => unref(formDataTujuan).latitude = $event,
                    longitude: unref(formDataTujuan).longitude,
                    "onUpdate:longitude": ($event) => unref(formDataTujuan).longitude = $event,
                    locationAddress: unref(formDataTujuan).locationAddress,
                    "onUpdate:locationAddress": ($event) => unref(formDataTujuan).locationAddress = $event,
                    locationName: unref(formDataTujuan).locationName,
                    "onUpdate:locationName": ($event) => unref(formDataTujuan).locationName = $event,
                    dataJikaSudahada: unref(formDataTujuan),
                    name: "return_address",
                    placeholder: "ex:Jalan Pahlawan No. 1"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormTextFieldWModal, {
                      modelValue: unref(formDataTujuan).locationAddress,
                      "onUpdate:modelValue": ($event) => unref(formDataTujuan).locationAddress = $event,
                      latitude: unref(formDataTujuan).latitude,
                      "onUpdate:latitude": ($event) => unref(formDataTujuan).latitude = $event,
                      longitude: unref(formDataTujuan).longitude,
                      "onUpdate:longitude": ($event) => unref(formDataTujuan).longitude = $event,
                      locationAddress: unref(formDataTujuan).locationAddress,
                      "onUpdate:locationAddress": ($event) => unref(formDataTujuan).locationAddress = $event,
                      locationName: unref(formDataTujuan).locationName,
                      "onUpdate:locationName": ($event) => unref(formDataTujuan).locationName = $event,
                      dataJikaSudahada: unref(formDataTujuan),
                      name: "return_address",
                      placeholder: "ex:Jalan Pahlawan No. 1"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "latitude", "onUpdate:latitude", "longitude", "onUpdate:longitude", "locationAddress", "onUpdate:locationAddress", "locationName", "onUpdate:locationName", "dataJikaSudahada"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-wrap gap-6 mt-5 md:mt-7 items-center justify-evenly"${_scopeId}><div class="" class="${ssrRenderClass([{
              "lg:w-[20%]": unref(dateReturnDisabled),
              "lg:w-fit": !unref(dateReturnDisabled)
            }, ""])}"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormToggle, {
              name: "round_trip",
              label: "Pulang - Pergi",
              modelValue: unref(dataForm).round_trip,
              "onUpdate:modelValue": ($event) => unref(dataForm).round_trip = $event,
              "true-value": "1",
              "false-value": "0",
              variant: "primary"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="${ssrRenderClass([{
              "lg:w-[30%]": unref(dateReturnDisabled),
              "lg:w-fit": !unref(dateReturnDisabled)
            }, "w-full"])}"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "pickup_date",
              label: unref($t2)("jemput-tanggal")
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "pickup_date",
                    min: unref(today),
                    modelValue: unref(dataForm).pickup_date,
                    "onUpdate:modelValue": ($event) => unref(dataForm).pickup_date = $event,
                    type: "date",
                    placeholder: "ex:2024-01-01"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "pickup_date",
                      min: unref(today),
                      modelValue: unref(dataForm).pickup_date,
                      "onUpdate:modelValue": ($event) => unref(dataForm).pickup_date = $event,
                      type: "date",
                      placeholder: "ex:2024-01-01"
                    }, null, 8, ["min", "modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div>`);
            if (!unref(dateReturnDisabled)) {
              _push2(`<div class="${ssrRenderClass([{
                "lg:w-[30%]": unref(dateReturnDisabled),
                "lg:w-fit": !unref(dateReturnDisabled)
              }, "relative w-full"])}"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_UIFormMGroup, {
                name: "return_date",
                label: unref($t2)("pulang-balik")
              }, {
                default: withCtx((_, _push3, _parent3, _scopeId2) => {
                  var _a, _b;
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_UIFormMTextField, {
                      name: "return_date",
                      modelValue: unref(dataForm).return_date,
                      "onUpdate:modelValue": ($event) => unref(dataForm).return_date = $event,
                      type: "date",
                      min: (_a = unref(dataForm).pickup_date) != null ? _a : unref(today),
                      max: unref(maxReturnDate),
                      placeholder: "ex:2024-01-02"
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_component_UIFormMTextField, {
                        name: "return_date",
                        modelValue: unref(dataForm).return_date,
                        "onUpdate:modelValue": ($event) => unref(dataForm).return_date = $event,
                        type: "date",
                        min: (_b = unref(dataForm).pickup_date) != null ? _b : unref(today),
                        max: unref(maxReturnDate),
                        placeholder: "ex:2024-01-02"
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "min", "max"])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="${ssrRenderClass([{
              "lg:w-[30%]": unref(dateReturnDisabled),
              "lg:w-fit": !unref(dateReturnDisabled)
            }, "w-full"])}"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "passengers",
              label: unref($t2)("jumlah-penumpang")
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMSelect, {
                    name: "passengers",
                    modelValue: unref(dataForm).passengers,
                    "onUpdate:modelValue": ($event) => unref(dataForm).passengers = $event
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<option value="1"${_scopeId3}>1 ${ssrInterpolate(unref($t2)("penumpang"))}</option><option value="2"${_scopeId3}>2 ${ssrInterpolate(unref($t2)("penumpang"))}</option><option value="3"${_scopeId3}>3 ${ssrInterpolate(unref($t2)("penumpang"))}</option><option value="4"${_scopeId3}>4 ${ssrInterpolate(unref($t2)("penumpang"))}</option><option value="5"${_scopeId3}>5 ${ssrInterpolate(unref($t2)("penumpang"))}</option><option value="6"${_scopeId3}>6 ${ssrInterpolate(unref($t2)("penumpang"))}</option>`);
                      } else {
                        return [
                          createVNode("option", { value: "1" }, "1 " + toDisplayString(unref($t2)("penumpang")), 1),
                          createVNode("option", { value: "2" }, "2 " + toDisplayString(unref($t2)("penumpang")), 1),
                          createVNode("option", { value: "3" }, "3 " + toDisplayString(unref($t2)("penumpang")), 1),
                          createVNode("option", { value: "4" }, "4 " + toDisplayString(unref($t2)("penumpang")), 1),
                          createVNode("option", { value: "5" }, "5 " + toDisplayString(unref($t2)("penumpang")), 1),
                          createVNode("option", { value: "6" }, "6 " + toDisplayString(unref($t2)("penumpang")), 1)
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMSelect, {
                      name: "passengers",
                      modelValue: unref(dataForm).passengers,
                      "onUpdate:modelValue": ($event) => unref(dataForm).passengers = $event
                    }, {
                      default: withCtx(() => [
                        createVNode("option", { value: "1" }, "1 " + toDisplayString(unref($t2)("penumpang")), 1),
                        createVNode("option", { value: "2" }, "2 " + toDisplayString(unref($t2)("penumpang")), 1),
                        createVNode("option", { value: "3" }, "3 " + toDisplayString(unref($t2)("penumpang")), 1),
                        createVNode("option", { value: "4" }, "4 " + toDisplayString(unref($t2)("penumpang")), 1),
                        createVNode("option", { value: "5" }, "5 " + toDisplayString(unref($t2)("penumpang")), 1),
                        createVNode("option", { value: "6" }, "6 " + toDisplayString(unref($t2)("penumpang")), 1)
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div><div class="w-full md:w-fit"${_scopeId}><div class="flex justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              variant: "primary",
              type: "submit",
              disabled: unref(loading)
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref($t2)("cari-mobil"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref($t2)("cari-mobil")), 1)
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-[1fr_50px_1fr] gap-4 items-center" }, [
                createVNode(_component_UIFormMGroup, {
                  label: unref($t2)("jemput-dimana"),
                  name: "pickup_address"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormTextFieldWModal, {
                      modelValue: unref(formDataJemput).locationAddress,
                      "onUpdate:modelValue": ($event) => unref(formDataJemput).locationAddress = $event,
                      latitude: unref(formDataJemput).latitude,
                      "onUpdate:latitude": ($event) => unref(formDataJemput).latitude = $event,
                      longitude: unref(formDataJemput).longitude,
                      "onUpdate:longitude": ($event) => unref(formDataJemput).longitude = $event,
                      locationAddress: unref(formDataJemput).locationAddress,
                      "onUpdate:locationAddress": ($event) => unref(formDataJemput).locationAddress = $event,
                      locationName: unref(formDataJemput).locationName,
                      "onUpdate:locationName": ($event) => unref(formDataJemput).locationName = $event,
                      dataJikaSudahada: unref(formDataJemput),
                      name: "pickup_address",
                      placeholder: "ex:Jalan Pahlawan No. 1"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "latitude", "onUpdate:latitude", "longitude", "onUpdate:longitude", "locationAddress", "onUpdate:locationAddress", "locationName", "onUpdate:locationName", "dataJikaSudahada"])
                  ]),
                  _: 1
                }, 8, ["label"]),
                createVNode("div", { class: "flex flex-col gap-1 items-center" }, [
                  createVNode("div", { class: "flex justify-center items-center" }, [
                    createVNode(_component_Icon, {
                      name: unref(isMobile) ? "i-heroicons-arrows-up-down" : "i-heroicons-arrows-right-left",
                      class: "w-6 h-6"
                    }, null, 8, ["name"])
                  ])
                ]),
                createVNode(_component_UIFormMGroup, {
                  label: unref($t2)("mau-kemana"),
                  name: "return_address"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormTextFieldWModal, {
                      modelValue: unref(formDataTujuan).locationAddress,
                      "onUpdate:modelValue": ($event) => unref(formDataTujuan).locationAddress = $event,
                      latitude: unref(formDataTujuan).latitude,
                      "onUpdate:latitude": ($event) => unref(formDataTujuan).latitude = $event,
                      longitude: unref(formDataTujuan).longitude,
                      "onUpdate:longitude": ($event) => unref(formDataTujuan).longitude = $event,
                      locationAddress: unref(formDataTujuan).locationAddress,
                      "onUpdate:locationAddress": ($event) => unref(formDataTujuan).locationAddress = $event,
                      locationName: unref(formDataTujuan).locationName,
                      "onUpdate:locationName": ($event) => unref(formDataTujuan).locationName = $event,
                      dataJikaSudahada: unref(formDataTujuan),
                      name: "return_address",
                      placeholder: "ex:Jalan Pahlawan No. 1"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "latitude", "onUpdate:latitude", "longitude", "onUpdate:longitude", "locationAddress", "onUpdate:locationAddress", "locationName", "onUpdate:locationName", "dataJikaSudahada"])
                  ]),
                  _: 1
                }, 8, ["label"])
              ]),
              createVNode("div", { class: "flex flex-wrap gap-6 mt-5 md:mt-7 items-center justify-evenly" }, [
                createVNode("div", {
                  class: ["", {
                    "lg:w-[20%]": unref(dateReturnDisabled),
                    "lg:w-fit": !unref(dateReturnDisabled)
                  }]
                }, [
                  createVNode(_component_UIFormToggle, {
                    name: "round_trip",
                    label: "Pulang - Pergi",
                    modelValue: unref(dataForm).round_trip,
                    "onUpdate:modelValue": ($event) => unref(dataForm).round_trip = $event,
                    "true-value": "1",
                    "false-value": "0",
                    variant: "primary"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ], 2),
                createVNode("div", {
                  class: ["w-full", {
                    "lg:w-[30%]": unref(dateReturnDisabled),
                    "lg:w-fit": !unref(dateReturnDisabled)
                  }]
                }, [
                  createVNode(_component_UIFormMGroup, {
                    name: "pickup_date",
                    label: unref($t2)("jemput-tanggal")
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_UIFormMTextField, {
                        name: "pickup_date",
                        min: unref(today),
                        modelValue: unref(dataForm).pickup_date,
                        "onUpdate:modelValue": ($event) => unref(dataForm).pickup_date = $event,
                        type: "date",
                        placeholder: "ex:2024-01-01"
                      }, null, 8, ["min", "modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  }, 8, ["label"])
                ], 2),
                !unref(dateReturnDisabled) ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: ["relative w-full", {
                    "lg:w-[30%]": unref(dateReturnDisabled),
                    "lg:w-fit": !unref(dateReturnDisabled)
                  }]
                }, [
                  createVNode(_component_UIFormMGroup, {
                    name: "return_date",
                    label: unref($t2)("pulang-balik")
                  }, {
                    default: withCtx(() => {
                      var _a;
                      return [
                        createVNode(_component_UIFormMTextField, {
                          name: "return_date",
                          modelValue: unref(dataForm).return_date,
                          "onUpdate:modelValue": ($event) => unref(dataForm).return_date = $event,
                          type: "date",
                          min: (_a = unref(dataForm).pickup_date) != null ? _a : unref(today),
                          max: unref(maxReturnDate),
                          placeholder: "ex:2024-01-02"
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "min", "max"])
                      ];
                    }),
                    _: 1
                  }, 8, ["label"])
                ], 2)) : createCommentVNode("", true),
                createVNode("div", {
                  class: ["w-full", {
                    "lg:w-[30%]": unref(dateReturnDisabled),
                    "lg:w-fit": !unref(dateReturnDisabled)
                  }]
                }, [
                  createVNode(_component_UIFormMGroup, {
                    name: "passengers",
                    label: unref($t2)("jumlah-penumpang")
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_UIFormMSelect, {
                        name: "passengers",
                        modelValue: unref(dataForm).passengers,
                        "onUpdate:modelValue": ($event) => unref(dataForm).passengers = $event
                      }, {
                        default: withCtx(() => [
                          createVNode("option", { value: "1" }, "1 " + toDisplayString(unref($t2)("penumpang")), 1),
                          createVNode("option", { value: "2" }, "2 " + toDisplayString(unref($t2)("penumpang")), 1),
                          createVNode("option", { value: "3" }, "3 " + toDisplayString(unref($t2)("penumpang")), 1),
                          createVNode("option", { value: "4" }, "4 " + toDisplayString(unref($t2)("penumpang")), 1),
                          createVNode("option", { value: "5" }, "5 " + toDisplayString(unref($t2)("penumpang")), 1),
                          createVNode("option", { value: "6" }, "6 " + toDisplayString(unref($t2)("penumpang")), 1)
                        ]),
                        _: 1
                      }, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  }, 8, ["label"])
                ], 2),
                createVNode("div", { class: "w-full md:w-fit" }, [
                  createVNode("div", { class: "flex justify-end" }, [
                    createVNode(_component_UIBtn, {
                      variant: "primary",
                      type: "submit",
                      disabled: unref(loading)
                    }, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(unref($t2)("cari-mobil")), 1)
                      ]),
                      _: 1
                    }, 8, ["disabled"])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Share/Filter/Vehicle.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$6;
const _sfc_main$5 = {
  __name: "Tour",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { locale, t: $t2 } = useI18n();
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const { tourSearchSchema } = useSchema();
    useRouter();
    const selectedLocationName = ref();
    const formData = ref({
      location_id: void 0,
      activity_date: void 0
      // tourist_numbers: undefined,
    });
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedTourData,
      clearSavedTourData
    } = useTourForm({
      callback: () => {
        console.log("Form has been submitted!");
      }
    });
    const {
      data: locations,
      refresh,
      pending
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      `locations`,
      () => $fetch(`/locations`, {
        method: "GET",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    function selectLocation(location) {
      formData.value.location_id = location.id;
      selectedLocationName.value = location.name;
    }
    function onSubmit() {
      dataForm.value.location_id = formData.value.location_id;
      dataForm.value.location_name = selectedLocationName.value;
      dataForm.value.activity_date = formData.value.activity_date;
      let filters = [];
      if (dataForm.value.location_id) {
        filters.push(`location=${dataForm.value.location_id}`);
      }
      const queryString = filters.join("&");
      const url = `/tours?${queryString ? `&${queryString}` : ""}`;
      saveFormData();
      window.location.href = url;
    }
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIFormMGroup = _sfc_main$d;
      const _component_VDropdown = resolveComponent("VDropdown");
      const _component_Icon = __nuxt_component_0$3;
      const _component_VeeField = Field;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_UIFormMTextField = _sfc_main$e;
      const _component_UIBtn = _sfc_main$g;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        onSubmit,
        "validation-schema": unref(tourSearchSchema),
        class: "space-y-4"
      }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid lg:grid-cols-12 gap-4"${_scopeId}><div class="lg:col-span-5"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "tour_id",
              label: unref($t2)("pilih-destinasi")
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_VDropdown, {
                    modelValue: unref(formData).location_id,
                    "onUpdate:modelValue": ($event) => unref(formData).location_id = $event,
                    placements: "start",
                    distance: "-10",
                    skidding: "1",
                    "arrow-padding": "1"
                  }, {
                    popper: withCtx(({ hide }, _push4, _parent4, _scopeId3) => {
                      var _a, _b;
                      if (_push4) {
                        _push4(`<div class="w-full p-4 space-y-4 max-w-5xl"${_scopeId3}><div class="space-y-4 overflow-y-auto h-full lg:max-h-[200px]"${_scopeId3}><!--[-->`);
                        ssrRenderList((_a = unref(locations)) == null ? void 0 : _a.data, (location) => {
                          _push4(`<div class="grid grid-cols-[150px_1fr] gap-4 hover:bg-primary/10 transition-all duration-300 p-4 rounded-md cursor-pointer"${_scopeId3}><div${_scopeId3}>${ssrInterpolate(location.name)}</div></div>`);
                        });
                        _push4(`<!--]--></div></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "w-full p-4 space-y-4 max-w-5xl" }, [
                            createVNode("div", { class: "space-y-4 overflow-y-auto h-full lg:max-h-[200px]" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList((_b = unref(locations)) == null ? void 0 : _b.data, (location) => {
                                return openBlock(), createBlock("div", {
                                  key: location.id,
                                  class: "grid grid-cols-[150px_1fr] gap-4 hover:bg-primary/10 transition-all duration-300 p-4 rounded-md cursor-pointer",
                                  onClick: withModifiers(($event) => {
                                    selectLocation(location);
                                    hide();
                                  }, ["prevent"])
                                }, [
                                  createVNode("div", null, toDisplayString(location.name), 1)
                                ], 8, ["onClick"]);
                              }), 128))
                            ])
                          ])
                        ];
                      }
                    }),
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      var _a, _b;
                      if (_push4) {
                        _push4(`<button type="button" class="text-xs h-9 w-full flex justify-between items-center"${_scopeId3}><div${_scopeId3}>${ssrInterpolate((_a = unref(selectedLocationName)) != null ? _a : unref($t2)("pilih-destinasi"))}</div><div${_scopeId3}>`);
                        _push4(ssrRenderComponent(_component_Icon, { name: "i-heroicons-chevron-down" }, null, _parent4, _scopeId3));
                        _push4(`</div></button>`);
                      } else {
                        return [
                          createVNode("button", {
                            type: "button",
                            class: "text-xs h-9 w-full flex justify-between items-center"
                          }, [
                            createVNode("div", null, toDisplayString((_b = unref(selectedLocationName)) != null ? _b : unref($t2)("pilih-destinasi")), 1),
                            createVNode("div", null, [
                              createVNode(_component_Icon, { name: "i-heroicons-chevron-down" })
                            ])
                          ])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_VDropdown, {
                      modelValue: unref(formData).location_id,
                      "onUpdate:modelValue": ($event) => unref(formData).location_id = $event,
                      placements: "start",
                      distance: "-10",
                      skidding: "1",
                      "arrow-padding": "1"
                    }, {
                      popper: withCtx(({ hide }) => {
                        var _a;
                        return [
                          createVNode("div", { class: "w-full p-4 space-y-4 max-w-5xl" }, [
                            createVNode("div", { class: "space-y-4 overflow-y-auto h-full lg:max-h-[200px]" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList((_a = unref(locations)) == null ? void 0 : _a.data, (location) => {
                                return openBlock(), createBlock("div", {
                                  key: location.id,
                                  class: "grid grid-cols-[150px_1fr] gap-4 hover:bg-primary/10 transition-all duration-300 p-4 rounded-md cursor-pointer",
                                  onClick: withModifiers(($event) => {
                                    selectLocation(location);
                                    hide();
                                  }, ["prevent"])
                                }, [
                                  createVNode("div", null, toDisplayString(location.name), 1)
                                ], 8, ["onClick"]);
                              }), 128))
                            ])
                          ])
                        ];
                      }),
                      default: withCtx(() => {
                        var _a;
                        return [
                          createVNode("button", {
                            type: "button",
                            class: "text-xs h-9 w-full flex justify-between items-center"
                          }, [
                            createVNode("div", null, toDisplayString((_a = unref(selectedLocationName)) != null ? _a : unref($t2)("pilih-destinasi")), 1),
                            createVNode("div", null, [
                              createVNode(_component_Icon, { name: "i-heroicons-chevron-down" })
                            ])
                          ])
                        ];
                      }),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeField, {
              type: "text",
              name: "location",
              class: "hidden",
              id: "location",
              modelValue: unref(formData).location_id,
              "onUpdate:modelValue": ($event) => unref(formData).location_id = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "location",
              class: "form-error-message"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="lg:col-span-5"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "activity_date",
              label: unref($t2)("pilih-tanggal")
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "activity_date",
                    type: "date",
                    min: unref(today),
                    modelValue: unref(formData).activity_date,
                    "onUpdate:modelValue": ($event) => unref(formData).activity_date = $event,
                    placeholder: "ex:2024-01-01"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "activity_date",
                      type: "date",
                      min: unref(today),
                      modelValue: unref(formData).activity_date,
                      "onUpdate:modelValue": ($event) => unref(formData).activity_date = $event,
                      placeholder: "ex:2024-01-01"
                    }, null, 8, ["min", "modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div><div class="lg:col-span-2 flex items-center justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              variant: "primary",
              type: "submit"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref($t2)("cari-tur"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref($t2)("cari-tur")), 1)
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid lg:grid-cols-12 gap-4" }, [
                createVNode("div", { class: "lg:col-span-5" }, [
                  createVNode(_component_UIFormMGroup, {
                    name: "tour_id",
                    label: unref($t2)("pilih-destinasi")
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_VDropdown, {
                        modelValue: unref(formData).location_id,
                        "onUpdate:modelValue": ($event) => unref(formData).location_id = $event,
                        placements: "start",
                        distance: "-10",
                        skidding: "1",
                        "arrow-padding": "1"
                      }, {
                        popper: withCtx(({ hide }) => {
                          var _a;
                          return [
                            createVNode("div", { class: "w-full p-4 space-y-4 max-w-5xl" }, [
                              createVNode("div", { class: "space-y-4 overflow-y-auto h-full lg:max-h-[200px]" }, [
                                (openBlock(true), createBlock(Fragment, null, renderList((_a = unref(locations)) == null ? void 0 : _a.data, (location) => {
                                  return openBlock(), createBlock("div", {
                                    key: location.id,
                                    class: "grid grid-cols-[150px_1fr] gap-4 hover:bg-primary/10 transition-all duration-300 p-4 rounded-md cursor-pointer",
                                    onClick: withModifiers(($event) => {
                                      selectLocation(location);
                                      hide();
                                    }, ["prevent"])
                                  }, [
                                    createVNode("div", null, toDisplayString(location.name), 1)
                                  ], 8, ["onClick"]);
                                }), 128))
                              ])
                            ])
                          ];
                        }),
                        default: withCtx(() => {
                          var _a;
                          return [
                            createVNode("button", {
                              type: "button",
                              class: "text-xs h-9 w-full flex justify-between items-center"
                            }, [
                              createVNode("div", null, toDisplayString((_a = unref(selectedLocationName)) != null ? _a : unref($t2)("pilih-destinasi")), 1),
                              createVNode("div", null, [
                                createVNode(_component_Icon, { name: "i-heroicons-chevron-down" })
                              ])
                            ])
                          ];
                        }),
                        _: 1
                      }, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  }, 8, ["label"]),
                  createVNode(_component_VeeField, {
                    type: "text",
                    name: "location",
                    class: "hidden",
                    id: "location",
                    modelValue: unref(formData).location_id,
                    "onUpdate:modelValue": ($event) => unref(formData).location_id = $event
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode(_component_VeeErrorMessage, {
                    name: "location",
                    class: "form-error-message"
                  })
                ]),
                createVNode("div", { class: "lg:col-span-5" }, [
                  createVNode(_component_UIFormMGroup, {
                    name: "activity_date",
                    label: unref($t2)("pilih-tanggal")
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_UIFormMTextField, {
                        name: "activity_date",
                        type: "date",
                        min: unref(today),
                        modelValue: unref(formData).activity_date,
                        "onUpdate:modelValue": ($event) => unref(formData).activity_date = $event,
                        placeholder: "ex:2024-01-01"
                      }, null, 8, ["min", "modelValue", "onUpdate:modelValue"])
                    ]),
                    _: 1
                  }, 8, ["label"])
                ]),
                createVNode("div", { class: "lg:col-span-2 flex items-center justify-end" }, [
                  createVNode(_component_UIBtn, {
                    variant: "primary",
                    type: "submit"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref($t2)("cari-tur")), 1)
                    ]),
                    _: 1
                  })
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Share/Filter/Tour.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$5;
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "HomeBanner",
  __ssrInlineRender: true,
  setup(__props) {
    const { locale, t: $t2 } = useI18n();
    useRoute();
    useRouter();
    const { current, goTo, isCurrent } = useStepper(["transport", "paket-tour"]);
    const slides = [
      {
        title: $t2("perjalanan-aman"),
        description: $t2("armada-kendaraan-modern"),
        image: "/hi-travel-hero.jpeg",
        key: "transport"
      },
      {
        title: $t2("jelajahi-keajaiban"),
        description: $t2("dari-pantai-hingga-gunung"),
        image: "/second-thumbnail-hero-hi-travel.jpeg",
        key: "paket-tour"
      }
    ];
    const currentSlide = computed(() => {
      return slides.find((slide) => slide.key === current.value);
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d;
      const _component_ShareMenuTabLink = _sfc_main$b;
      const _component_ShareFilterVehicle = __nuxt_component_1;
      const _component_ShareFilterTour = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 relative" }, _attrs))} data-v-95e7767e><div class="relative rounded-xl overflow-hidden" data-v-95e7767e><div class="absolute h-full w-full bg-gradient-to-t from-[#121212]/20 to-[#121212]/50 text-center space-y-6" data-v-95e7767e><div class="h-20" data-v-95e7767e></div><h1 class="text-3xl lg:text-5xl text-white font-bold max-w-4xl mx-auto" data-v-95e7767e>${ssrInterpolate((_a = unref(currentSlide)) == null ? void 0 : _a.title)}</h1><p class="text-white text-base lg:text-xl max-w-2xl mx-auto" data-v-95e7767e>${ssrInterpolate((_b = unref(currentSlide)) == null ? void 0 : _b.description)}</p></div>`);
      if ((_c = unref(currentSlide)) == null ? void 0 : _c.image) {
        _push(`<img${ssrRenderAttr("src", (_d = unref(currentSlide)) == null ? void 0 : _d.image)} class="w-full h-[370px] lg:h-[500px] object-cover" alt="hero" data-v-95e7767e>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="lg:absolute z-10 w-full inset-x-0 bottom-0 lg:-bottom-4" data-v-95e7767e><div data-v-95e7767e><div class="max-w-5xl bg-white mx-auto lg:mt-auto bottom-0 p-3 md:p-4 lg:p-2 shadow rounded-lg mt-[-30px] z-40 relative" data-v-95e7767e><div class="inline-flex" data-v-95e7767e>`);
      _push(ssrRenderComponent(_component_ShareMenuTabLink, {
        label: "Transport",
        icon: "bi:car-front-fill",
        "is-active": unref(isCurrent)("transport"),
        onClick: ($event) => unref(goTo)("transport")
      }, null, _parent));
      _push(ssrRenderComponent(_component_ShareMenuTabLink, {
        label: unref($t2)("paket-tour"),
        icon: "mingcute:umbrella-2-line",
        "is-active": unref(isCurrent)("paket-tour"),
        onClick: ($event) => unref(goTo)("paket-tour")
      }, null, _parent));
      _push(`</div><div class="p-4 mt-2" data-v-95e7767e>`);
      if (unref(isCurrent)("transport")) {
        _push(`<div data-v-95e7767e>`);
        _push(ssrRenderComponent(_component_ShareFilterVehicle, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isCurrent)("paket-tour")) {
        _push(`<div data-v-95e7767e>`);
        _push(ssrRenderComponent(_component_ShareFilterTour, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div></div>`);
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Hero/HomeBanner.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-95e7767e"]]);
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "HighLight",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "popularTours",
      () => $fetch(`/popular-tours`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_TourCard = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-6 py-6" }, _attrs))}><h3 class="text-[32px] leading-[40px] font-semibold text-primary-dark">${ssrInterpolate(_ctx.$t("paket-tour"))}</h3><div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"><!--[-->`);
      ssrRenderList((_a = unref(data)) == null ? void 0 : _a.data, (item) => {
        var _a2;
        _push(ssrRenderComponent(_component_TourCard, {
          id: item.id,
          key: item.id,
          name: item.name,
          description: item.locations,
          image: (_a2 = item.thumbnail_image) == null ? void 0 : _a2.image,
          price: item.price,
          slug: `/tours/` + item.slug
        }, null, _parent));
      });
      _push(`<!--]--></div></div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/HighLight.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Card",
  __ssrInlineRender: true,
  props: {
    step: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-4 border rounded-xl pt-4 px-4 flex flex-col" }, _attrs))}><h4 class="text-primary-dark text-2xl font-bold">${ssrInterpolate(props.step.title)}</h4><div class="text-zinc-400">${ssrInterpolate(props.step.decription)}</div><div class="h-full flex items-end"><img${ssrRenderAttr("src", props.step.image)}${ssrRenderAttr("alt", props.step.title)} class="w-full h-[350px] object-cover"></div></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/StepToJoin/Card.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const { locale, t: $t2 } = useI18n();
    const steps = ref([
      {
        title: "1." + $t2("pesan-di-hitravel-list.list-1.title"),
        decription: $t2("pesan-di-hitravel-list.list-1.desk"),
        image: "/hi-travel-feat-1.png"
      },
      {
        title: "2." + $t2("pesan-di-hitravel-list.list-2.title"),
        decription: $t2("pesan-di-hitravel-list.list-2.desk"),
        image: "/hi-travel-feat-2.png"
      },
      {
        title: "3." + $t2("pesan-di-hitravel-list.list-3.title"),
        decription: $t2("pesan-di-hitravel-list.list-3.desk"),
        image: "/hi-travel-feat-3.png"
      }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_StepToJoinCard = _sfc_main$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-6 py-6" }, _attrs))}><h3 class="text-[32px] leading-[40px] font-semibold text-primary-dark">${ssrInterpolate(unref($t2)("pesan-di-hitravel"))}</h3><div class="grid grid-cols-1 lg:grid-cols-3 gap-6"><!--[-->`);
      ssrRenderList(unref(steps), (step, index) => {
        _push(ssrRenderComponent(_component_StepToJoinCard, {
          key: index,
          step
        }, null, _parent));
      });
      _push(`<!--]--></div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/StepToJoin/index.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useI18n();
    useTourForm({
      callback: () => {
        console.log("Form has been submitted!");
      }
    });
    useTourForm$1({
      callback: () => {
        console.log("Form has been submitted!");
      }
    });
    useHead({
      title: "Home",
      meta: [
        {
          name: "description",
          content: "Safe and Comfortable Transfer in Bali. A fleet of modern vehicles and experienced drivers are ready to take you wherever you want."
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeroHomeBanner = __nuxt_component_0;
      const _component_UIContainer = __nuxt_component_0$2;
      const _component_TourHighLight = _sfc_main$3;
      const _component_StepToJoin = _sfc_main$1;
      const _component_ShareCtaSection = _sfc_main$c;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="h-44 lg:h-32" id="learnmore"></div>`);
      _push(ssrRenderComponent(_component_HeroHomeBanner, null, null, _parent));
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_TourHighLight, null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_TourHighLight)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_StepToJoin, null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_StepToJoin)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_ShareCtaSection, null, null, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-b0a6b317.mjs.map
