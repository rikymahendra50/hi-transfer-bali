import { Form, ErrorMessage, useField } from 'vee-validate';
import { _ as _sfc_main$4 } from './Alert-f7c32dd8.mjs';
import __nuxt_component_1$1 from './Icon-ab561e52.mjs';
import { useSSRContext, defineComponent, unref, withCtx, isRef, createVNode, ref, computed, mergeProps, toRef, readonly } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrIncludeBooleanAttr, ssrRenderAttr, ssrRenderClass, ssrRenderSlot, ssrGetDynamicModelProps } from 'vue/server-renderer';
import { b as useFileDialog } from './index-dea25161.mjs';
import { _ as _sfc_main$5 } from './MGroup-56a6a0a6.mjs';
import { _ as _sfc_main$6 } from './MTextField-bd75102a.mjs';
import { u as useSchema } from './useSchema-04511848.mjs';
import { u as useAuth, e as useRequestOptions, h as useRequestHelper, f as useI18n, i as useFetch } from '../server.mjs';
import { u as useNotification } from './nofication-1c3cca5e.mjs';
import { _ as _sfc_main$7 } from './Group-4dcbb69b.mjs';
import { _ as __nuxt_component_0 } from './TransitionX-601819e8.mjs';
import clsx from 'clsx';
import { u as usePasswordHelper } from './usePasswordHelper-d8a46f8b.mjs';

const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "Avatar",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      type: [File, String]
    },
    profileImage: {
      type: String
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit }) {
    const props = __props;
    const image = ref(null);
    const { files, open, reset, onChange } = useFileDialog({
      accept: "image/*",
      // Set to accept only image files
      multiple: false
    });
    onChange((files2) => {
      if (!files2) {
        return;
      }
      emit("update:modelValue", files2[0]);
      image.value = files2[0];
      reset();
    });
    const imageUrlReview = computed(() => {
      if (image.value) {
        return URL.createObjectURL(image.value);
      }
      return !!props.profileImage ? props.profileImage : "https://fakeimg.pl/400x400?text=profile";
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-20 group" }, _attrs))}><div class="avatar" role="button">`);
      if (unref(imageUrlReview)) {
        _push(`<div class="w-20 h-20 rounded-full overflow-hidden group-hover:ring-1 ring-gray-500/80 ring-offset-1 transition-all duration-300"><img${ssrRenderAttr("src", unref(imageUrlReview))} alt="profile" class="w-full h-full"></div>`);
      } else {
        _push(`<div class="w-20 h-20 bg-gray-200 rounded-full overflow-hidden flex items-center justify-center">`);
        _push(ssrRenderComponent(_component_Icon, { name: "i-heroicons-user" }, null, _parent));
        _push(`</div>`);
      }
      _push(`</div><div class="hidden group-hover:block text-center transition-all duration-300 delay-100 text-sm text-gray-500/80"> Update Image </div></div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/Avatar.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
function useProfile(usedBy, callback) {
  const { $user, $fetchAuthProfile } = useAuth();
  const { requestOptions } = useRequestOptions();
  const { pushNotification } = useNotification();
  const { loading, message, alertType, setErrorMessage, transformErrors } = useRequestHelper();
  const { t: $t, locale } = useI18n();
  const dataForm = ref({
    email: "",
    first_name: "",
    last_name: "",
    phone: "",
    image: void 0,
    is_profile_picture_deleted: 0
  });
  const updateURL = computed(() => {
    if (usedBy == "user") {
      return "/users/profile?lang=" + locale.value;
    }
    return "/admins/profile?lang=" + locale.value;
  });
  const currentUserProfile = computed(() => {
    var _a2;
    var _a;
    return (_a2 = (_a = $user.value) == null ? void 0 : _a.image) != null ? _a2 : "";
  });
  async function updateProfile(values, ctx) {
    var _a, _b;
    const formData = new FormData();
    const object = { ...dataForm.value };
    for (const item in object) {
      const objectItem = object[item];
      formData.append(item, objectItem);
    }
    if (!dataForm.value.image) {
      formData.delete("image");
    }
    loading.value = true;
    const { data, error } = await useFetch(
      `${updateURL.value}&_method=PUT`,
      {
        headers: {
          Accept: "application/json"
        },
        method: "POST",
        body: formData,
        ...requestOptions
      },
      "$aeNfF1ntZC"
    );
    if (error.value) {
      setErrorMessage((_a = error.value.data) == null ? void 0 : _a.message);
      ctx.setErrors(transformErrors((_b = error.value) == null ? void 0 : _b.data));
      pushNotification({
        type: "error",
        text: error.value.data.message,
        title: "error"
      });
    } else {
      alert("Success update profil");
      pushNotification({
        type: "success",
        text: "Success update profil",
        title: "Success"
      });
      await $fetchAuthProfile();
    }
    loading.value = false;
  }
  return {
    dataForm,
    updateProfile,
    message,
    alertType,
    loading,
    currentUserProfile
  };
}
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Profile",
  __ssrInlineRender: true,
  props: {
    usedBy: {
      type: String,
      default: "user"
    }
  },
  emits: ["reload"],
  setup(__props, { emit }) {
    const props = __props;
    const { updateProfileSchema } = useSchema();
    const {
      loading,
      message,
      alertType,
      dataForm,
      updateProfile,
      currentUserProfile
    } = useProfile(props.usedBy);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_Alert = _sfc_main$4;
      const _component_UIFormAvatar = _sfc_main$3;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_UIFormMGroup = _sfc_main$5;
      const _component_UIFormMTextField = _sfc_main$6;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit: unref(updateProfile),
        "validation-schema": unref(updateProfileSchema)
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Alert, {
              modelValue: unref(message),
              "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
              type: unref(alertType)
            }, null, _parent2, _scopeId));
            _push2(`<div class="flex flex-row items-center space-x-2"${_scopeId}><div class="flex-shrink-0"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormAvatar, {
              modelValue: unref(dataForm).image,
              "onUpdate:modelValue": ($event) => unref(dataForm).image = $event,
              "profile-image": unref(currentUserProfile)
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "profile_picture",
              class: "form-error-message"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="text-sm text-[#506176]"${_scopeId}> Recommended dimensions: 200x200px. Max. file size: 1 MB </div></div>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Nama Pertama",
              name: "first_name"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: unref(dataForm).first_name,
                    "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
                    name: "first_name",
                    class: "input-bordered",
                    placeholder: "ex:jhon"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref(dataForm).first_name,
                      "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
                      name: "first_name",
                      class: "input-bordered",
                      placeholder: "ex:jhon"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Nama terakhir",
              name: "last_name"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    modelValue: unref(dataForm).last_name,
                    "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
                    name: "last_name",
                    class: "input-bordered",
                    placeholder: "ex:doe"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref(dataForm).last_name,
                      "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
                      name: "last_name",
                      class: "input-bordered",
                      placeholder: "ex:doe"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: "Email",
              name: "email"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "email",
                    modelValue: unref(dataForm).email,
                    "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                    class: "input-bordered",
                    placeholder: "ex:myemail@gmail.com"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "email",
                      modelValue: unref(dataForm).email,
                      "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                      class: "input-bordered",
                      placeholder: "ex:myemail@gmail.com"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="h-1"${_scopeId}></div><div${_scopeId}><button class="btn btn-primary btn-block" type="submit"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""}${ssrRenderAttr("loading", unref(loading))}${_scopeId}> Update Profile </button></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 gap-4" }, [
                createVNode(_component_Alert, {
                  modelValue: unref(message),
                  "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
                  type: unref(alertType)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "type"]),
                createVNode("div", { class: "flex flex-row items-center space-x-2" }, [
                  createVNode("div", { class: "flex-shrink-0" }, [
                    createVNode(_component_UIFormAvatar, {
                      modelValue: unref(dataForm).image,
                      "onUpdate:modelValue": ($event) => unref(dataForm).image = $event,
                      "profile-image": unref(currentUserProfile)
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "profile-image"]),
                    createVNode(_component_VeeErrorMessage, {
                      name: "profile_picture",
                      class: "form-error-message"
                    })
                  ]),
                  createVNode("div", { class: "text-sm text-[#506176]" }, " Recommended dimensions: 200x200px. Max. file size: 1 MB ")
                ]),
                createVNode(_component_UIFormMGroup, {
                  label: "Nama Pertama",
                  name: "first_name"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref(dataForm).first_name,
                      "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
                      name: "first_name",
                      class: "input-bordered",
                      placeholder: "ex:jhon"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  label: "Nama terakhir",
                  name: "last_name"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      modelValue: unref(dataForm).last_name,
                      "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
                      name: "last_name",
                      class: "input-bordered",
                      placeholder: "ex:doe"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormMGroup, {
                  label: "Email",
                  name: "email"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      name: "email",
                      modelValue: unref(dataForm).email,
                      "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                      class: "input-bordered",
                      placeholder: "ex:myemail@gmail.com"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode("div", { class: "h-1" }),
                createVNode("div", null, [
                  createVNode("button", {
                    class: "btn btn-primary btn-block",
                    type: "submit",
                    disabled: unref(loading),
                    loading: unref(loading)
                  }, " Update Profile ", 8, ["disabled", "loading"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/Profile.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "TextCostume",
  __ssrInlineRender: true,
  props: {
    type: { default: "text" },
    modelValue: {},
    name: {},
    class: {},
    disabled: { type: Boolean, default: false },
    ariaLabel: {},
    placeholder: {},
    variant: {},
    size: {},
    ghost: { type: Boolean },
    bordered: { type: Boolean, default: true },
    readonly: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const name = toRef(props, "name");
    const { value, errorMessage, handleBlur, handleChange, meta } = useField(
      name,
      void 0,
      {
        syncVModel: true
      }
    );
    const variant = [
      "input-neutral",
      "input-primary",
      "input-secondary",
      "input-accent",
      "input-info",
      "input-success",
      "input-warning",
      "input-error"
    ];
    const size = ["input-xs", "input-sm", "input-md", "input-lg"];
    const className = computed(() => {
      const arr = [];
      const inputClass = [];
      if (props.bordered && !props.ghost) {
        inputClass.push("input-bordered");
      }
      if (props.variant) {
        inputClass.push(variant[variant.indexOf(`input-${props.variant}`)]);
      }
      if (props.size) {
        inputClass.push(size[size.indexOf(`input-${props.size}`)]);
      }
      if (props.ghost) {
        inputClass.push("input-ghost");
      }
      if (!!errorMessage.value) {
        arr.push("input-error");
      }
      return clsx(arr.join(" "), inputClass.join(" "), props.class);
    });
    ref();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TransitionX = __nuxt_component_0;
      const _component_VeeErrorMessage = ErrorMessage;
      let _temp0;
      _push(`<!--[--><label class="${ssrRenderClass(
        unref(clsx)("flex items-center input  overflow-hidden", unref(className), {
          "gap-2": !!_ctx.$slots.leftSection || !!_ctx.$slots.rightSection,
          "pl-0": !_ctx.$slots.leftSection,
          "pr-0": !_ctx.$slots.rightSection
        })
      )}">`);
      if (_ctx.$slots.leftSection) {
        ssrRenderSlot(_ctx.$slots, "leftSection", {}, null, _push, _parent);
      } else {
        _push(`<!---->`);
      }
      _push(`<input${ssrRenderAttrs((_temp0 = mergeProps({
        name: unref(name),
        id: unref(name),
        type: _ctx.type,
        readonly: "readonly" in _ctx ? _ctx.readonly : unref(readonly),
        disabled: _ctx.disabled,
        "aria-label": _ctx.ariaLabel,
        placeholder: _ctx.placeholder,
        class: unref(clsx)("w-full h-full", {
          "px-4": !_ctx.$slots.leftSection || !_ctx.$slots.rightSection
        })
      }, _ctx.$attrs), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, unref(value)))))}>`);
      if (_ctx.$slots.rightSection) {
        ssrRenderSlot(_ctx.$slots, "rightSection", {}, null, _push, _parent);
      } else {
        _push(`<!---->`);
      }
      _push(`</label>`);
      _push(ssrRenderComponent(_component_TransitionX, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: unref(name),
              class: "form-error-message"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_VeeErrorMessage, {
                name: unref(name),
                class: "form-error-message"
              }, null, 8, ["name"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/TextCostume.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
function usePasswordChange(userBy) {
  const { loading, message, alertType, setErrorMessage, transformErrors } = useRequestHelper();
  const { requestOptions } = useRequestOptions();
  const { pushNotification } = useNotification();
  const { $user } = useAuth();
  const { t: $t, locale } = useI18n();
  const dataForm = ref({
    old_password: "",
    password: "",
    confirm_password: ""
  });
  const updateURL = computed(() => {
    if (userBy == "user") {
      return `/users/${$user.value.uuid}/change-password`;
    }
    return "/admins/change-password?lang=" + locale.value;
  });
  function resetForm() {
    dataForm.value = {
      old_password: "",
      password: "",
      confirm_password: ""
    };
  }
  const isPasswordSetted = computed(() => {
    var _a;
    return (_a = $user.value) == null ? void 0 : _a.is_password_setted;
  });
  async function updatePassword(values, ctx) {
    var _a2;
    var _a, _b, _c, _d, _e;
    loading.value = true;
    const object = {
      old_password: dataForm.value.old_password,
      password: dataForm.value.password,
      confirm_password: dataForm.value.confirm_password
    };
    if (isPasswordSetted.value) {
      object.old_password = dataForm.value.old_password;
    }
    const { data, error } = await useFetch(
      updateURL.value,
      {
        method: "POST",
        body: { ...object },
        ...requestOptions
      },
      "$yL3PXkrPlh"
    );
    if (error.value) {
      setErrorMessage((_b = (_a = error.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message);
      ctx.setErrors(transformErrors((_c = error.value) == null ? void 0 : _c.data));
    } else {
      pushNotification({
        type: "success",
        text: (_a2 = (_e = (_d = data.value) == null ? void 0 : _d.data) == null ? void 0 : _e.message) != null ? _a2 : $t("password_has_been_change_txt")
      });
      ctx.resetForm();
      resetForm();
    }
    loading.value = false;
  }
  return {
    dataForm,
    updatePassword,
    message,
    alertType,
    loading,
    isPasswordSetted
  };
}
const _sfc_main = {
  __name: "ChangePassword",
  __ssrInlineRender: true,
  props: {
    usedBy: {
      type: String,
      default: "user"
    }
  },
  setup(__props) {
    const props = __props;
    const {
      loading,
      message,
      alertType,
      updatePassword,
      dataForm,
      isPasswordSetted
    } = usePasswordChange(props.usedBy);
    const { updatePasswordSchema, unSetPasswordSchema } = useSchema();
    const { inputType, toggleInputType } = usePasswordHelper();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_Alert = _sfc_main$4;
      const _component_UIFormGroup = _sfc_main$7;
      const _component_UIFormTextCostume = _sfc_main$1;
      const _component_Icon = __nuxt_component_1$1;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit: unref(updatePassword),
        "validation-schema": unref(isPasswordSetted) ? unref(updatePasswordSchema) : unref(unSetPasswordSchema)
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Alert, {
              modelValue: unref(message),
              "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
              type: unref(alertType)
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="space-y-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormGroup, {
              label: "Old password",
              name: "old_password"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormTextCostume, {
                    name: "old_password",
                    modelValue: unref(dataForm).old_password,
                    "onUpdate:modelValue": ($event) => unref(dataForm).old_password = $event,
                    type: unref(inputType),
                    class: "input-bordered",
                    placeholder: "********"
                  }, {
                    leftSection: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Icon, {
                            name: "i-heroicons-lock-closed",
                            class: "w-5 h-5 text-gray-400"
                          })
                        ];
                      }
                    }),
                    rightSection: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          onClick: unref(toggleInputType),
                          class: "w-5 h-5 cursor-pointer text-gray-400"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Icon, {
                            name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                            onClick: unref(toggleInputType),
                            class: "w-5 h-5 cursor-pointer text-gray-400"
                          }, null, 8, ["name", "onClick"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormTextCostume, {
                      name: "old_password",
                      modelValue: unref(dataForm).old_password,
                      "onUpdate:modelValue": ($event) => unref(dataForm).old_password = $event,
                      type: unref(inputType),
                      class: "input-bordered",
                      placeholder: "********"
                    }, {
                      leftSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        })
                      ]),
                      rightSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          onClick: unref(toggleInputType),
                          class: "w-5 h-5 cursor-pointer text-gray-400"
                        }, null, 8, ["name", "onClick"])
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue", "type"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormGroup, {
              label: "Password",
              name: "password"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormTextCostume, {
                    name: "password",
                    modelValue: unref(dataForm).password,
                    "onUpdate:modelValue": ($event) => unref(dataForm).password = $event,
                    type: unref(inputType),
                    class: "input-bordered",
                    placeholder: "********"
                  }, {
                    leftSection: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Icon, {
                            name: "i-heroicons-lock-closed",
                            class: "w-5 h-5 text-gray-400"
                          })
                        ];
                      }
                    }),
                    rightSection: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          onClick: unref(toggleInputType),
                          class: "w-5 h-5 cursor-pointer text-gray-400"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Icon, {
                            name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                            onClick: unref(toggleInputType),
                            class: "w-5 h-5 cursor-pointer text-gray-400"
                          }, null, 8, ["name", "onClick"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormTextCostume, {
                      name: "password",
                      modelValue: unref(dataForm).password,
                      "onUpdate:modelValue": ($event) => unref(dataForm).password = $event,
                      type: unref(inputType),
                      class: "input-bordered",
                      placeholder: "********"
                    }, {
                      leftSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        })
                      ]),
                      rightSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          onClick: unref(toggleInputType),
                          class: "w-5 h-5 cursor-pointer text-gray-400"
                        }, null, 8, ["name", "onClick"])
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue", "type"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormGroup, {
              label: "Konfirm Password",
              name: "confirm_password"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormTextCostume, {
                    name: "confirm_password",
                    modelValue: unref(dataForm).confirm_password,
                    "onUpdate:modelValue": ($event) => unref(dataForm).confirm_password = $event,
                    type: unref(inputType),
                    class: "input-bordered",
                    placeholder: "********"
                  }, {
                    leftSection: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Icon, {
                            name: "i-heroicons-lock-closed",
                            class: "w-5 h-5 text-gray-400"
                          })
                        ];
                      }
                    }),
                    rightSection: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          onClick: unref(toggleInputType),
                          class: "w-5 h-5 cursor-pointer text-gray-400"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_Icon, {
                            name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                            onClick: unref(toggleInputType),
                            class: "w-5 h-5 cursor-pointer text-gray-400"
                          }, null, 8, ["name", "onClick"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormTextCostume, {
                      name: "confirm_password",
                      modelValue: unref(dataForm).confirm_password,
                      "onUpdate:modelValue": ($event) => unref(dataForm).confirm_password = $event,
                      type: unref(inputType),
                      class: "input-bordered",
                      placeholder: "********"
                    }, {
                      leftSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        })
                      ]),
                      rightSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          onClick: unref(toggleInputType),
                          class: "w-5 h-5 cursor-pointer text-gray-400"
                        }, null, 8, ["name", "onClick"])
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue", "type"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}><button type="submit"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""}${ssrRenderAttr("loading", unref(loading))} class="btn btn-primary btn-block"${_scopeId}> Update password </button></div></div>`);
          } else {
            return [
              createVNode("div", { class: "py-2" }, [
                createVNode(_component_Alert, {
                  modelValue: unref(message),
                  "onUpdate:modelValue": ($event) => isRef(message) ? message.value = $event : null,
                  type: unref(alertType)
                }, null, 8, ["modelValue", "onUpdate:modelValue", "type"])
              ]),
              createVNode("div", { class: "space-y-4" }, [
                createVNode(_component_UIFormGroup, {
                  label: "Old password",
                  name: "old_password"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormTextCostume, {
                      name: "old_password",
                      modelValue: unref(dataForm).old_password,
                      "onUpdate:modelValue": ($event) => unref(dataForm).old_password = $event,
                      type: unref(inputType),
                      class: "input-bordered",
                      placeholder: "********"
                    }, {
                      leftSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        })
                      ]),
                      rightSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          onClick: unref(toggleInputType),
                          class: "w-5 h-5 cursor-pointer text-gray-400"
                        }, null, 8, ["name", "onClick"])
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue", "type"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormGroup, {
                  label: "Password",
                  name: "password"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormTextCostume, {
                      name: "password",
                      modelValue: unref(dataForm).password,
                      "onUpdate:modelValue": ($event) => unref(dataForm).password = $event,
                      type: unref(inputType),
                      class: "input-bordered",
                      placeholder: "********"
                    }, {
                      leftSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        })
                      ]),
                      rightSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          onClick: unref(toggleInputType),
                          class: "w-5 h-5 cursor-pointer text-gray-400"
                        }, null, 8, ["name", "onClick"])
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue", "type"])
                  ]),
                  _: 1
                }),
                createVNode(_component_UIFormGroup, {
                  label: "Konfirm Password",
                  name: "confirm_password"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormTextCostume, {
                      name: "confirm_password",
                      modelValue: unref(dataForm).confirm_password,
                      "onUpdate:modelValue": ($event) => unref(dataForm).confirm_password = $event,
                      type: unref(inputType),
                      class: "input-bordered",
                      placeholder: "********"
                    }, {
                      leftSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: "i-heroicons-lock-closed",
                          class: "w-5 h-5 text-gray-400"
                        })
                      ]),
                      rightSection: withCtx(() => [
                        createVNode(_component_Icon, {
                          name: unref(inputType) === "password" ? "i-heroicons-eye" : "i-heroicons-eye-slash",
                          onClick: unref(toggleInputType),
                          class: "w-5 h-5 cursor-pointer text-gray-400"
                        }, null, 8, ["name", "onClick"])
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue", "type"])
                  ]),
                  _: 1
                }),
                createVNode("div", null, [
                  createVNode("button", {
                    type: "submit",
                    disabled: unref(loading),
                    loading: unref(loading),
                    class: "btn btn-primary btn-block"
                  }, " Update password ", 8, ["disabled", "loading"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/ChangePassword.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main;

export { _sfc_main$2 as _, __nuxt_component_1 as a };
//# sourceMappingURL=ChangePassword-4e6c8a19.mjs.map
