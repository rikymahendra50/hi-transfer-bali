import { useField, ErrorMessage } from 'vee-validate';
import { defineComponent, toRef, computed, mergeProps, unref, useSSRContext, ref } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderClass, ssrInterpolate, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import __nuxt_component_1 from './Icon-ab561e52.mjs';
import { o as onClickOutside } from './index-dea25161.mjs';

const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "InputNumber",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      type: [String, Number],
      default: ""
    },
    name: {
      type: String,
      required: true
    },
    classCustom: {
      type: String,
      default: ""
    },
    label: {
      type: String,
      default: ""
    },
    step1: {
      type: String,
      default: "1"
    },
    min: {
      type: [Number, String],
      default: "1"
    },
    max: {
      type: [Number, String]
    },
    autocomplete: {
      type: String,
      default: "on"
    }
  },
  setup(__props) {
    const props = __props;
    const name = toRef(props, "name");
    const {
      value: inputValue,
      errorMessage,
      handleBlur,
      handleChange,
      meta
    } = useField(name, void 0, {
      syncVModel: true
    });
    const className = computed(() => {
      const arr = ["input input-bordered"];
      if (meta.touched && meta.valid) {
        arr.push("input-success");
      }
      if (!!errorMessage.value) {
        arr.push("input-error");
      }
      return arr.join(" ");
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeErrorMessage = ErrorMessage;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col gap-1" }, _attrs))}><label${ssrRenderAttr("for", name.value)} class="${ssrRenderClass([__props.classCustom, "mt-3 text-[14px] font-medium w-fit"])}">${ssrInterpolate(__props.label)} <span class="text-[#F97066]">*</span>`);
      _push(ssrRenderComponent(_component_VeeErrorMessage, {
        name: name.value,
        class: "form-error-message text-[#F97066] text-sm pt-1"
      }, null, _parent));
      _push(`</label><div class="relative flex flex-col"><input${ssrRenderAttrs(mergeProps({
        id: name.value,
        name: name.value,
        type: "number"
      }, _ctx.$attrs, {
        class: className.value,
        step: __props.step1 || "1",
        max: __props.max,
        value: unref(inputValue),
        autocomplete: __props.autocomplete
      }))}></div></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/InputNumber.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ Object.assign({
  inheritAttrs: false
}, {
  __name: "DropdownOnlyTwo",
  __ssrInlineRender: true,
  props: {
    type: {
      default: "text"
    },
    modelValue: {
      type: [String, Number]
    },
    name: {
      type: String,
      required: true
    },
    classCustom: {
      type: String
    },
    label: {
      type: String
    },
    step1: {
      type: String
    },
    min: {
      type: [Number, String]
    },
    max: {
      type: [Number, String]
    },
    autocomplete: {
      type: String,
      default: "on"
    },
    dataDropdown: {
      type: Array
    }
  },
  emits: ["update:modelValue", "getId"],
  setup(__props, { emit }) {
    const props = __props;
    const dropdown = ref(null);
    onClickOutside(dropdown, () => {
      isDropdownOpen.value = false;
    });
    const name = toRef(props, "name");
    const {
      value: inputValue,
      errorMessage,
      handleBlur,
      handleChange,
      meta
    } = useField(name, void 0, {
      syncVModel: true
    });
    const className = computed(() => {
      const arr = ["input input-bordered cursor-pointer"];
      if (!meta.touched) {
        return arr;
      }
      if (meta.touched && meta.valid) {
        arr.push("input-success");
      }
      if (!!errorMessage.value) {
        arr.push("input-error");
      }
      return arr.join(" ");
    });
    const isDropdownOpen = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_Icon = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col gap-1" }, _attrs))}><label${ssrRenderAttr("for", unref(name))} class="${ssrRenderClass([__props.classCustom, "mt-3 text-[14px] font-bold"])}">${ssrInterpolate(__props.label)} `);
      _push(ssrRenderComponent(_component_VeeErrorMessage, {
        name: unref(name),
        class: "form-error-message text-[#F97066] text-sm pt-1 ml-1"
      }, null, _parent));
      _push(`</label><div class="flex flex-col">`);
      if (!isDropdownOpen.value) {
        _push(`<div class="flex flex-col justify-center relative"><input${ssrRenderAttrs(mergeProps({
          id: unref(name),
          name: unref(name),
          type: __props.type,
          class: unref(className)
        }, _ctx.$attrs, {
          autocomplete: __props.autocomplete,
          readonly: "",
          value: unref(inputValue)
        }))}><div class="absolute top-2 right-4">`);
        _push(ssrRenderComponent(_component_Icon, {
          name: "gridicons:dropdown",
          class: "text-black w-5 h-5"
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<div class="flex flex-col justify-center relative"><input${ssrRenderAttrs(mergeProps({
          id: unref(name),
          name: unref(name),
          type: __props.type,
          class: unref(className)
        }, _ctx.$attrs, {
          autocomplete: __props.autocomplete,
          readonly: "",
          value: unref(inputValue)
        }))}><div class="absolute top-2 right-4">`);
        _push(ssrRenderComponent(_component_Icon, {
          name: "gridicons:dropdown",
          class: "text-black w-5 h-5"
        }, null, _parent));
        _push(`</div></div>`);
      }
      if (isDropdownOpen.value) {
        _push(`<div class="relative z-20"><div class="absolute mt-2 w-48 bg-white border border-gray-300 rounded shadow-lg"><ul><!--[-->`);
        ssrRenderList(__props.dataDropdown, (item) => {
          _push(`<li class="px-4 py-2 hover:bg-gray-100 cursor-pointer">${ssrInterpolate(item.name)}</li>`);
        });
        _push(`<!--]--></ul></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/DropdownOnlyTwo.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main$1;
const _sfc_main = /* @__PURE__ */ Object.assign({
  inheritAttrs: false
}, {
  __name: "DropdownsTest",
  __ssrInlineRender: true,
  props: {
    type: {
      default: "text"
    },
    modelValue: {
      type: [String, Number, Array]
    },
    name: {
      type: String,
      required: true
    },
    classCustom: {
      type: String
    },
    label: {
      type: String
    },
    autocomplete: {
      type: String,
      default: "on"
    },
    dataDropdown: {
      type: Array
    },
    dataSelected: {
      type: Array
    }
  },
  emits: ["update:modelValue", "getId"],
  setup(__props, { emit }) {
    const props = __props;
    const dropdown = ref(null);
    const isDropdownOpen = ref(false);
    const selectedOptions = ref([]);
    onClickOutside(dropdown, () => {
      isDropdownOpen.value = false;
    });
    const name = toRef(props, "name");
    const {
      value: inputValue,
      errorMessage,
      handleBlur,
      handleChange,
      meta
    } = useField(name, void 0, {
      syncVModel: true
    });
    const className = computed(() => {
      const arr = ["input input-bordered cursor-pointer"];
      if (!meta.touched)
        return arr;
      if (meta.valid)
        arr.push("input-success");
      if (errorMessage.value)
        arr.push("input-error");
      return arr.join(" ");
    });
    function isSelected(option) {
      return selectedOptions.value.some((selected) => selected.id === option.id);
    }
    function removeOption(item) {
      const index = selectedOptions.value.findIndex(
        (selected) => selected.id === item.id
      );
      if (index !== -1) {
        selectedOptions.value.splice(index, 1);
      }
      emit(
        "getId",
        selectedOptions.value.map((option) => option.id)
      );
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_Icon = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col gap-1" }, _attrs))}><label${ssrRenderAttr("for", unref(name))} class="${ssrRenderClass([__props.classCustom, "mt-3 text-[14px] font-medium w-fit"])}">${ssrInterpolate(__props.label)} <span class="text-[#F97066]">*</span>`);
      _push(ssrRenderComponent(_component_VeeErrorMessage, {
        name: unref(name),
        class: "form-error-message text-[#F97066] text-sm pt-1 ml-1"
      }, null, _parent));
      _push(`</label><div class="flex flex-col"><div class="flex flex-col justify-center relative"><input${ssrRenderAttrs(mergeProps({
        id: unref(name),
        name: unref(name),
        type: __props.type,
        class: unref(className)
      }, _ctx.$attrs, {
        autocomplete: __props.autocomplete,
        readonly: ""
      }))}><div class="absolute top-2 right-4">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "gridicons:dropdown",
        class: "text-black w-5 h-5"
      }, null, _parent));
      _push(`</div></div>`);
      if (unref(isDropdownOpen)) {
        _push(`<div class="relative z-20"><div class="absolute mt-2 min-w-48 bg-white border border-gray-300 rounded shadow-lg max-h-[130px] overflow-auto"><ul><!--[-->`);
        ssrRenderList(__props.dataDropdown, (item) => {
          var _a;
          _push(`<li class="${ssrRenderClass([
            "px-3 py-2 hover:bg-gray-100 cursor-pointer",
            isSelected(item) ? "bg-gray-100" : ""
          ])}">${ssrInterpolate((_a = item.description) != null ? _a : item.name)} `);
          if (isSelected(item)) {
            _push(`<span class="text-sm text-primary"> \xA0\xA0(Dipilih)</span>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</li>`);
        });
        _push(`<!--]--></ul></div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(selectedOptions).length) {
        _push(`<div class="mt-2"><!--[-->`);
        ssrRenderList(unref(selectedOptions), (option, index) => {
          var _a;
          _push(`<div class="inline-block bg-gray-100 border border-gray-300 rounded px-2 py-2 mr-2 mb-2 text-sm">${ssrInterpolate((_a = option.description) != null ? _a : option.name)} `);
          _push(ssrRenderComponent(_component_Icon, {
            name: "mingcute:close-fill",
            class: "text-red-500 ml-1 cursor-pointer",
            onClick: ($event) => removeOption(option)
          }, null, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/DropdownsTest.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_7 = _sfc_main;

export { _sfc_main$2 as _, __nuxt_component_6 as a, __nuxt_component_7 as b };
//# sourceMappingURL=DropdownsTest-e2f0d57d.mjs.map
