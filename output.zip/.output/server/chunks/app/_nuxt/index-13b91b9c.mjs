import { _ as __nuxt_component_0 } from './TitleAdmin-130db81a.mjs';
import { _ as __nuxt_component_1 } from './ButtonAddAdmin-3ce2c9a4.mjs';
import __nuxt_component_1$1 from './Icon-f8c4e628.mjs';
import { h as useRequestHelper, e as useRequestOptions, b as useRouter, d as useRoute, a as useHead, g as useAsyncData, j as __nuxt_component_0$1 } from '../server.mjs';
import { _ as __nuxt_component_2 } from './PaginationAdmin-f2cea012.mjs';
import { _ as __nuxt_component_3 } from './Modal-8edbde02.mjs';
import { defineComponent, ref, withAsyncContext, watch, resolveComponent, withCtx, createVNode, unref, createTextVNode, isRef, withModifiers, useSSRContext } from 'vue';
import { o as withQuery } from '../../nitro/node-server.mjs';
import { u as useTourPackage } from './useTourPackage-653e033f.mjs';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { u as useTimeoutFn } from './index-596a8548.mjs';
import './config-9e484511.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './index-dea25161.mjs';
import './nofication-1c3cca5e.mjs';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    useRoute();
    useHead({
      title: "Tour Package"
    });
    const page = ref(1);
    const showModalDelete = ref(false);
    const currentId = ref(void 0);
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "tours",
      () => $fetch(`/admins/tours?page=${page.value}`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    const { selectedTourPackage, deleteTourPackage, loading } = useTourPackage({
      callback: refresh
    });
    watch(page, (newValue, oldValue) => {
      if (newValue !== oldValue) {
        start();
      }
    });
    const { start, stop } = useTimeoutFn(() => {
      replaceWindow();
    }, 1e3);
    function replaceWindow() {
      router.replace(
        withQuery("/admin/tour-package", {
          page: page.value
        })
      );
      refresh();
    }
    function showModalDeleteFunc(hide, id) {
      showModalDelete.value = !showModalDelete.value;
      hide();
      if (showModalDelete.value) {
        currentId.value = id;
      } else {
        currentId.value = void 0;
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
      const _component_TitleAdmin = __nuxt_component_0;
      const _component_ButtonAddAdmin = __nuxt_component_1;
      const _component_VDropdown = resolveComponent("VDropdown");
      const _component_Icon = __nuxt_component_1$1;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_PaginationAdmin = __nuxt_component_2;
      const _component_modal = __nuxt_component_3;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_TitleAdmin, {
        title: "Kelola Produk: Paket Tur",
        subTitle: "Kelola paket tur Anda disini"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_ButtonAddAdmin, {
              link: "/admin/tour-package/add",
              name: "Tambah paket baru"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_ButtonAddAdmin, {
                link: "/admin/tour-package/add",
                name: "Tambah paket baru"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<table class="table"><thead><tr><th><div class="text-[#989393]">Nama Tur</div></th><th><div>Harga</div></th><th><div>Status tur</div></th></tr></thead><tbody><!--[-->`);
      ssrRenderList((_a = unref(data)) == null ? void 0 : _a.data, (item) => {
        _push(`<tr><td class="text-sm font-normal"><div class="font-medium text-[14px] text-black">${ssrInterpolate(item == null ? void 0 : item.name)}</div></td><td class="text-sm font-normal text-[#989393]">${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(item == null ? void 0 : item.price))}</td><td class="text-sm font-normal text-[#989393]">${ssrInterpolate((item == null ? void 0 : item.is_active) === 1 ? "Tersedia" : "Tidak tersedia")}</td><td><div class="flex items-center">`);
        _push(ssrRenderComponent(_component_VDropdown, null, {
          popper: withCtx(({ hide }, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="bg-white flex flex-col shadow"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_NuxtLink, {
                to: `/admin/tour-package/${item.slug}/images`,
                class: "hover:bg-orange-400 hover:text-white py-3 px-5 text-sm"
              }, {
                default: withCtx((_, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Upload Gambar `);
                  } else {
                    return [
                      createTextVNode(" Upload Gambar ")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_NuxtLink, {
                to: `/admin/tour-package/${item.slug}/edit`,
                class: "hover:bg-orange-400 hover:text-white py-3 px-5 text-sm"
              }, {
                default: withCtx((_, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` Edit `);
                  } else {
                    return [
                      createTextVNode(" Edit ")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`<div class="flex items-start justify-start w-full hover:bg-red-600 hover:text-white text-sm py-3 px-5"${_scopeId}><button type="button" class="hover:bg-red-600 hover:text-white"${_scopeId}> Delete </button></div></div>`);
            } else {
              return [
                createVNode("div", { class: "bg-white flex flex-col shadow" }, [
                  createVNode(_component_NuxtLink, {
                    to: `/admin/tour-package/${item.slug}/images`,
                    class: "hover:bg-orange-400 hover:text-white py-3 px-5 text-sm"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Upload Gambar ")
                    ]),
                    _: 2
                  }, 1032, ["to"]),
                  createVNode(_component_NuxtLink, {
                    to: `/admin/tour-package/${item.slug}/edit`,
                    class: "hover:bg-orange-400 hover:text-white py-3 px-5 text-sm"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Edit ")
                    ]),
                    _: 2
                  }, 1032, ["to"]),
                  createVNode("div", {
                    class: "flex items-start justify-start w-full hover:bg-red-600 hover:text-white text-sm py-3 px-5",
                    onClick: ($event) => showModalDeleteFunc(hide, item.slug)
                  }, [
                    createVNode("button", {
                      type: "button",
                      class: "hover:bg-red-600 hover:text-white"
                    }, " Delete ")
                  ], 8, ["onClick"])
                ])
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex items-center justify-center"${_scopeId}><button class="flex items-center justify-center cursor-pointer"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, {
                name: "pepicons-pencil:dots-y",
                class: "text-[#717171]"
              }, null, _parent2, _scopeId));
              _push2(`</button></div>`);
            } else {
              return [
                createVNode("div", { class: "flex items-center justify-center" }, [
                  createVNode("button", { class: "flex items-center justify-center cursor-pointer" }, [
                    createVNode(_component_Icon, {
                      name: "pepicons-pencil:dots-y",
                      class: "text-[#717171]"
                    })
                  ])
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></td></tr>`);
      });
      _push(`<!--]--></tbody></table><div class="flex flex-col md:flex-row items-center justify-between gap-3 w-full py-3 px-3"><div class="flex items-center gap-3"><div class="py-2 px-3 rounded-[8px]"><p class="font-medium text-[12px] md:text-sm text-[#121212]">${ssrInterpolate((_c = (_b = unref(data)) == null ? void 0 : _b.meta) == null ? void 0 : _c.from)} - ${ssrInterpolate((_e = (_d = unref(data)) == null ? void 0 : _d.meta) == null ? void 0 : _e.to)} of ${ssrInterpolate((_g = (_f = unref(data)) == null ? void 0 : _f.meta) == null ? void 0 : _g.total)} item </p></div></div><div class="font-medium text-[14px] text-[#344054] flex items-center gap-3">`);
      _push(ssrRenderComponent(_component_PaginationAdmin, {
        modelValue: unref(page),
        "onUpdate:modelValue": ($event) => isRef(page) ? page.value = $event : null,
        total: (_i = (_h = unref(data)) == null ? void 0 : _h.meta) == null ? void 0 : _i.total,
        includeFirstLast: false,
        "per-page": (_k = (_j = unref(data)) == null ? void 0 : _j.meta) == null ? void 0 : _k.per_page,
        class: "flex justify-center"
      }, null, _parent));
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_modal, {
        modelValue: unref(showModalDelete),
        "onUpdate:modelValue": ($event) => isRef(showModalDelete) ? showModalDelete.value = $event : null,
        class: "relative w-[90%] sm:w-[60%] lg:w-[40%]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex justify-center items-center flex-col p-2 sm:p-5 lg:p-10 overflow-auto"${_scopeId}><div class="flex flex-col items-center gap-3 lg:gap-5 text-center transition h-full"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Icon, {
              name: "ph:trash-duotone",
              style: { "color": "#ff0000" },
              class: "w-12 h-12 md:w-20 md:h-20"
            }, null, _parent2, _scopeId));
            _push2(`<p${_scopeId}>Apakah anda yakin untuk menghapus tour package ini ?</p></div><div class="grid grid-cols-1 lg:grid-cols-2 w-full gap-y-4 md:gap-x-6 mt-5"${_scopeId}><div class="btn bg-transparent border shadow"${_scopeId}><span${_scopeId}>Batal</span></div><div class="btn bg-red-600 text-white shadow"${_scopeId}><span${_scopeId}>Hapus</span></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex justify-center items-center flex-col p-2 sm:p-5 lg:p-10 overflow-auto" }, [
                createVNode("div", { class: "flex flex-col items-center gap-3 lg:gap-5 text-center transition h-full" }, [
                  createVNode(_component_Icon, {
                    name: "ph:trash-duotone",
                    style: { "color": "#ff0000" },
                    class: "w-12 h-12 md:w-20 md:h-20"
                  }),
                  createVNode("p", null, "Apakah anda yakin untuk menghapus tour package ini ?")
                ]),
                createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-2 w-full gap-y-4 md:gap-x-6 mt-5" }, [
                  createVNode("div", {
                    class: "btn bg-transparent border shadow",
                    onClick: ($event) => showModalDelete.value = false
                  }, [
                    createVNode("span", null, "Batal")
                  ], 8, ["onClick"]),
                  createVNode("div", {
                    onClick: withModifiers(($event) => (unref(deleteTourPackage)(unref(currentId)), showModalDelete.value = false), ["prevent"]),
                    class: "btn bg-red-600 text-white shadow"
                  }, [
                    createVNode("span", null, "Hapus")
                  ], 8, ["onClick"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/tour-package/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-13b91b9c.mjs.map
