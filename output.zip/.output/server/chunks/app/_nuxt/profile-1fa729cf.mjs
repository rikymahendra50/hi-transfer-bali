import { _ as _sfc_main$2, a as __nuxt_component_1 } from './ChangePassword-df496b51.mjs';
import { m as useAuth, f as useHead } from '../server.mjs';
import { unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import 'vee-validate';
import './Alert-ad006b11.mjs';
import './TransitionTopToBottom-3d1af8ef.mjs';
import './Icon-9a1ee2a3.mjs';
import './config-71e93c9c.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './index-df4194e4.mjs';
import './MGroup-560eed6a.mjs';
import 'clsx';
import './MTextField-bd75102a.mjs';
import './useSchema-f211c259.mjs';
import 'zod';
import '@vee-validate/zod';
import './nofication-176ebe9f.mjs';
import './Group-4dcbb69b.mjs';
import './usePasswordHelper-d8a46f8b.mjs';

const _sfc_main = {
  __name: "profile",
  __ssrInlineRender: true,
  setup(__props) {
    const { $fetchAuthProfile } = useAuth();
    useHead({
      title: "User"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIFormProfile = _sfc_main$2;
      const _component_UIFormChangePassword = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="h-28"></div><div class="flex justify-center"><div class="max-w-xl space-y-8 p-4">`);
      _push(ssrRenderComponent(_component_UIFormProfile, {
        onReload: ($event) => unref($fetchAuthProfile)(),
        "used-by": "user"
      }, null, _parent));
      _push(ssrRenderComponent(_component_UIFormChangePassword, { "used-by": "user" }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/profile.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=profile-1fa729cf.mjs.map
