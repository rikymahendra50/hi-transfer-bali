import { _ as __nuxt_component_0 } from './TitleAdminBack-edb4ce21.mjs';
import { f as useI18n, a as useHead, h as useRequestHelper, e as useRequestOptions, b as useRouter, d as useRoute, g as useAsyncData } from '../server.mjs';
import { ref, computed, withAsyncContext, unref, withCtx, createVNode, toDisplayString, useSSRContext } from 'vue';
import { u as useFormatDate } from './useFormatDate-4be124f7.mjs';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import { ssrRenderComponent, ssrRenderStyle, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import './Icon-0f6314e3.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useI18n();
    useHead({
      title: "Order detail"
    });
    ref({
      sort: ""
    });
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    useRouter();
    const route = useRoute();
    ref(1);
    ref(false);
    ref(void 0);
    const slug = computed(() => route.params.slug);
    const { formatDate } = useFormatDate();
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "ordersDetail",
      () => $fetch(`/admins/car-orders/${slug.value}`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b2, _c2, _d2, _e2;
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R, _S, _T, _U, _V, _W, _X, _Y, _Z, __, _$, _aa, _ba, _ca, _da, _ea, _fa, _ga, _ha, _ia, _ja, _ka, _la, _ma, _na, _oa, _pa, _qa, _ra;
      const _component_TitleAdminBack = __nuxt_component_0;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_TitleAdminBack, {
        title: "Ringkasan Pesanan",
        subTitle: `Informasi lengkap untuk pesanan #${(_a2 = (_b = (_a = unref(data)) == null ? void 0 : _a.data) == null ? void 0 : _b.uuid) != null ? _a2 : ""}`,
        link: "/admin/orders/order-cars"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a22, _b22, _c22, _d22, _e22, _f2, _g2, _h2, _i2, _j2, _k2, _l2, _m2, _n2, _o2, _p2, _q2, _r2, _s2, _t2, _u2, _v2, _w2, _x2;
          if (_push2) {
            _push2(`<div${_scopeId}><div class="border-2 shadow-xs p-3 rounded-xl" style="${ssrRenderStyle({
              backgroundColor: ((_b22 = (_a22 = unref(data)) == null ? void 0 : _a22.data) == null ? void 0 : _b22.status) === "waiting_for_payment" ? "#f2ec72" : ((_d22 = (_c22 = unref(data)) == null ? void 0 : _c22.data) == null ? void 0 : _d22.status) === "canceled" ? "#f2727b" : ((_f2 = (_e22 = unref(data)) == null ? void 0 : _e22.data) == null ? void 0 : _f2.status) === "paid" ? "#f2ec72" : ((_h2 = (_g2 = unref(data)) == null ? void 0 : _g2.data) == null ? void 0 : _h2.status) === "failed" ? "#f2727b" : ((_j2 = (_i2 = unref(data)) == null ? void 0 : _i2.data) == null ? void 0 : _j2.status) === "refunding" ? "#f2727b" : "transparent"
            })}"${_scopeId}>${ssrInterpolate((_l2 = (_k2 = unref(data)) == null ? void 0 : _k2.data) == null ? void 0 : _l2.status)}</div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", {
                  class: "border-2 shadow-xs p-3 rounded-xl",
                  style: {
                    backgroundColor: ((_n2 = (_m2 = unref(data)) == null ? void 0 : _m2.data) == null ? void 0 : _n2.status) === "waiting_for_payment" ? "#f2ec72" : ((_p2 = (_o2 = unref(data)) == null ? void 0 : _o2.data) == null ? void 0 : _p2.status) === "canceled" ? "#f2727b" : ((_r2 = (_q2 = unref(data)) == null ? void 0 : _q2.data) == null ? void 0 : _r2.status) === "paid" ? "#f2ec72" : ((_t2 = (_s2 = unref(data)) == null ? void 0 : _s2.data) == null ? void 0 : _t2.status) === "failed" ? "#f2727b" : ((_v2 = (_u2 = unref(data)) == null ? void 0 : _u2.data) == null ? void 0 : _v2.status) === "refunding" ? "#f2727b" : "transparent"
                  }
                }, toDisplayString((_x2 = (_w2 = unref(data)) == null ? void 0 : _w2.data) == null ? void 0 : _x2.status), 5)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="px-5 py-4 flex flex-col gap-3 border-b"><div class="text-gray-500 uppercase text-[12px] font-semibold"> Informasi Pelanggan </div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Nama pelanggan:</p><p>${ssrInterpolate(((_e = (_d = (_c = unref(data)) == null ? void 0 : _c.data) == null ? void 0 : _d.user) == null ? void 0 : _e.first_name) + " " + ((_h = (_g = (_f = unref(data)) == null ? void 0 : _f.data) == null ? void 0 : _g.user) == null ? void 0 : _h.last_name))}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Email:</p><p>${ssrInterpolate((_k = (_j = (_i = unref(data)) == null ? void 0 : _i.data) == null ? void 0 : _j.user) == null ? void 0 : _k.email)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold text-sm">Nomor Telepon:</p><p>${ssrInterpolate((_n = (_m = (_l = unref(data)) == null ? void 0 : _l.data) == null ? void 0 : _m.user) == null ? void 0 : _n.phone)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold text-sm">Flight Number</p><p class="font-semibold text-sm">${ssrInterpolate((_b2 = (_p = (_o = unref(data)) == null ? void 0 : _o.data) == null ? void 0 : _p.flight_number) != null ? _b2 : "-")}</p></div></div><div class="px-5 py-6 flex flex-col gap-3 border-b"><div class="text-gray-500 uppercase text-[12px] font-semibold"> Informasi Pemesanan </div><div class="grid md:grid-cols-2 gap-5"><div class="flex flex-col gap-2"><p class="font-semibold text-sm">Penjemputan</p><p class="text-sm">${ssrInterpolate((_s = (_r = (_q = unref(data)) == null ? void 0 : _q.data) == null ? void 0 : _r.details[0]) == null ? void 0 : _s.pickup_name)}</p><div class="text-sm opacity-50"><a class="hover:text-primary font-medium"${ssrRenderAttr("href", `https://maps.google.com/?q=${(_v = (_u = (_t = unref(data)) == null ? void 0 : _t.data) == null ? void 0 : _u.details[0]) == null ? void 0 : _v.pickup_latitude},${(_y = (_x = (_w = unref(data)) == null ? void 0 : _w.data) == null ? void 0 : _x.details[0]) == null ? void 0 : _y.pickup_longitude}`)} target="_blank">${ssrInterpolate((_B = (_A = (_z = unref(data)) == null ? void 0 : _z.data) == null ? void 0 : _A.details[0]) == null ? void 0 : _B.pickup_address)}</a></div><div class="text-sm">${ssrInterpolate((_c2 = unref(formatDate)((_E = (_D = (_C = unref(data)) == null ? void 0 : _C.data) == null ? void 0 : _D.details[0]) == null ? void 0 : _E.activity_date)) != null ? _c2 : "")}</div></div><div class="flex flex-col gap-2"><p class="font-semibold text-sm">Pengantaran</p><p class="text-sm">${ssrInterpolate((_H = (_G = (_F = unref(data)) == null ? void 0 : _F.data) == null ? void 0 : _G.details[0]) == null ? void 0 : _H.destination_name)}</p><div class="text-sm opacity-50"><a target="_blank" class="hover:text-primary font-medium"${ssrRenderAttr("href", `https://maps.google.com/?q=${(_K = (_J = (_I = unref(data)) == null ? void 0 : _I.data) == null ? void 0 : _J.details[0]) == null ? void 0 : _K.destination_latitude},${(_N = (_M = (_L = unref(data)) == null ? void 0 : _L.data) == null ? void 0 : _M.details[0]) == null ? void 0 : _N.destination_longitude}`)}>${ssrInterpolate((_Q = (_P = (_O = unref(data)) == null ? void 0 : _O.data) == null ? void 0 : _P.details[0]) == null ? void 0 : _Q.destination_address)}</a></div><div class="text-sm"><div class="text-sm">${ssrInterpolate(((_T = (_S = (_R = unref(data)) == null ? void 0 : _R.data) == null ? void 0 : _S.details[1]) == null ? void 0 : _T.activity_date) ? unref(formatDate)((_W = (_V = (_U = unref(data)) == null ? void 0 : _U.data) == null ? void 0 : _V.details[1]) == null ? void 0 : _W.activity_date) : unref(formatDate)((_Z = (_Y = (_X = unref(data)) == null ? void 0 : _X.data) == null ? void 0 : _Y.details[0]) == null ? void 0 : _Z.activity_date))}</div></div></div></div>`);
      if ((_$ = (__ = unref(data)) == null ? void 0 : __.data) == null ? void 0 : _$.details) {
        _push(`<div>`);
        if (((_ca = (_ba = (_aa = unref(data)) == null ? void 0 : _aa.data) == null ? void 0 : _ba.details) == null ? void 0 : _ca.length) > 1) {
          _push(`<div class="bg-primary py-2 px-4 rounded-xl text-white w-fit"><p>Bolak balik</p></div>`);
        } else if (((_fa = (_ea = (_da = unref(data)) == null ? void 0 : _da.data) == null ? void 0 : _ea.details) == null ? void 0 : _fa.length) == 1) {
          _push(`<div class="bg-primary py-2 px-4 rounded-xl text-white w-fit"><p>Satu arah</p></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="px-5 py-4 flex flex-col gap-3"><div class="text-gray-500 uppercase text-[12px] font-semibold"> Informasi Pembayaran </div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Metode Pembayaran</p><p>${ssrInterpolate((_d2 = (_ia = (_ha = (_ga = unref(data)) == null ? void 0 : _ga.data) == null ? void 0 : _ha.payment) == null ? void 0 : _ia.payment_method) != null ? _d2 : "-")}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Channel Pembayaran</p><p>${ssrInterpolate((_e2 = (_la = (_ka = (_ja = unref(data)) == null ? void 0 : _ja.data) == null ? void 0 : _ka.payment) == null ? void 0 : _la.payment_channel) != null ? _e2 : "-")}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Status Pembayaran</p><p>${ssrInterpolate((_oa = (_na = (_ma = unref(data)) == null ? void 0 : _ma.data) == null ? void 0 : _na.payment) == null ? void 0 : _oa.status)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Total Harga</p><p>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(
        (_ra = (_qa = (_pa = unref(data)) == null ? void 0 : _pa.data) == null ? void 0 : _qa.payment) == null ? void 0 : _ra.total_purchased.toString(),
        "IDR"
      ))}</p></div></div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/orders/order-detail-car/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-1913d2a6.mjs.map
