import { useSSRContext, computed, unref } from 'vue';
import { ssrRenderAttrs, ssrIncludeBooleanAttr, ssrInterpolate, ssrRenderList, ssrRenderClass, ssrRenderAttr } from 'vue/server-renderer';

const _sfc_main = {
  __name: "PaginationAdmin",
  __ssrInlineRender: true,
  props: {
    first: {
      type: String,
      default: "First"
    },
    last: {
      type: String,
      default: "Last"
    },
    next: {
      type: String,
      default: "Selanjutnya"
    },
    prev: {
      type: String,
      default: "Sebelumnya"
    },
    maxVisibleButtons: {
      type: Number,
      required: false,
      default: 3
    },
    total: {
      type: Number,
      required: true
    },
    perPage: {
      type: Number,
      required: true
    },
    modelValue: {
      type: [Number, String],
      required: true
    },
    includeFirstLast: {
      type: Boolean,
      default: () => true
    },
    includeNextPrev: {
      type: Boolean,
      default: () => true
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit }) {
    const props = __props;
    const startPage = computed(() => {
      if (props.modelValue === 1) {
        return 1;
      }
      if (props.modelValue === totalPages.value) {
        return totalPages.value - props.maxVisibleButtons + 1;
      }
      return Number(props.modelValue) - 1;
    });
    const endPage = computed(() => {
      return Math.min(
        startPage.value + props.maxVisibleButtons - 1,
        totalPages.value
      );
    });
    const pages = computed(() => {
      const range = [];
      const internalPage = startPage.value <= 1 ? 1 : startPage.value;
      for (let i = internalPage; i <= endPage.value; i += 1) {
        range.push({
          name: i,
          isDisabled: i === props.modelValue
        });
      }
      return range;
    });
    const totalPages = computed(() => {
      if (props.total <= props.perPage) {
        return 1;
      }
      return Math.ceil(props.total / props.perPage);
    });
    const isInFirstPage = computed(() => {
      return props.modelValue === 1;
    });
    const isInLastPage = computed(() => {
      return props.modelValue === totalPages.value;
    });
    function isPageActive(page) {
      return props.modelValue === page;
    }
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="inline-flex gap-2">`);
      if (__props.includeFirstLast) {
        _push(`<button type="button"${ssrIncludeBooleanAttr(unref(isInFirstPage)) ? " disabled" : ""} aria-label="Go to first page" class="btn btn-sm h-3 sm:h-10 bg-primary text-white">${ssrInterpolate(props.first)}</button>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.includeNextPrev) {
        _push(`<button type="button"${ssrIncludeBooleanAttr(unref(isInFirstPage)) ? " disabled" : ""} aria-label="Go to previous page" class="border shadow-sm border-[#D0D5DD] py-2 px-3 rounded-[8px]">${ssrInterpolate(props.prev)}</button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--[-->`);
      ssrRenderList(unref(pages), (page) => {
        _push(`<button type="button"${ssrIncludeBooleanAttr(page.isDisabled) ? " disabled" : ""} class="${ssrRenderClass([{ active: isPageActive(page.name) }, "btn btn-sm h-3 sm:h-10 bg-primary text-white"])}"${ssrRenderAttr("aria-label", `Go to page number ${page.name}`)}>${ssrInterpolate(page.name)}</button>`);
      });
      _push(`<!--]-->`);
      if (__props.includeNextPrev) {
        _push(`<button type="button"${ssrIncludeBooleanAttr(unref(isInLastPage)) ? " disabled" : ""} aria-label="Go to next page" class="border shadow-sm border-[#D0D5DD] py-2 px-3 rounded-[8px]">${ssrInterpolate(props.next)}</button>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.includeFirstLast) {
        _push(`<button type="button"${ssrIncludeBooleanAttr(unref(isInLastPage)) ? " disabled" : ""} aria-label="Go to last page" class="btn btn-sm h-3 sm:h-10 bg-primary text-white">${ssrInterpolate(props.last)}</button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/PaginationAdmin.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main;

export { __nuxt_component_2 as _ };
//# sourceMappingURL=PaginationAdmin-f2cea012.mjs.map
