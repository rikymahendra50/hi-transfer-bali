import __nuxt_component_1 from './Icon-7218f0f6.mjs';
import { defineComponent, mergeProps, useSSRContext } from 'vue';
import { a as useRouter } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "SelectedCard",
  __ssrInlineRender: true,
  setup(__props) {
    useRouter();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "border rounded-xl p-4 hover:border-primary hover:shadow shadow-primary" }, _attrs))}><div class="grid grid-cols-[100px_1fr] lg:grid-cols-[150px_1fr] gap-4"><div class="border rounded-xl overflow-hidden"><img src="https://placehold.co/150" alt="vehicle" class="w-full h-full xl:h-[150px] object-cover"></div><div class="grid grid-cols-1"><div class="space-y-2"><h4 class="text-lg lg:text-2xl font-semibold">Standar (Hatchback)</h4><div class="grid grid-cols-1 md:grid-cols-2 gap-1 lg:p-4"><div class="inline-flex space-x-1">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "i-heroicons-users",
        class: "w-5 h-5 text-primary"
      }, null, _parent));
      _push(`<div class="text-zinc-400 text-sm whitespace-nowrap"> Hingga 4 Penumpang </div></div><div class="inline-flex space-x-1">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "i-heroicons-briefcase",
        class: "w-5 h-5 text-primary"
      }, null, _parent));
      _push(`<div class="text-zinc-400 text-sm whitespace-nowrap"> Muat 4 Koper </div></div><div class="inline-flex space-x-1">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "mingcute:steering-wheel-fill",
        class: "w-5 h-5 text-primary"
      }, null, _parent));
      _push(`<div class="text-zinc-400 text-sm whitespace-nowrap"> Termasuk Sopir </div></div><div class="inline-flex space-x-1">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "i-heroicons-check-circle",
        class: "w-5 h-5 text-primary"
      }, null, _parent));
      _push(`<div class="text-zinc-400 text-sm whitespace-nowrap"> Gratis Tol &amp; Parkir </div></div></div></div></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vehicle/SelectedCard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=SelectedCard-bf5abcb8.mjs.map
