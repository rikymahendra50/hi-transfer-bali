import __nuxt_component_0 from './Icon-0f6314e3.mjs';
import { e as useRequestOptions, u as useAuth, g as useAsyncData, s as storeToRefs, _ as __nuxt_component_0$1 } from '../server.mjs';
import { useSSRContext, defineComponent, ref, watch, withAsyncContext, resolveComponent, unref, withCtx, createVNode, toDisplayString, withModifiers, computed, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderSlot, ssrRenderTeleport } from 'vue/server-renderer';
import { u as useNotification } from './nofication-1c3cca5e.mjs';
import { _ as _imports_0 } from './hi-transfer-logo-97c0b5ac.mjs';
import { d as useBreakpoints, e as breakpointsTailwind, o as onClickOutside } from './index-a61f78d7.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import './index-596a8548.mjs';

const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "NotificationItem",
  __ssrInlineRender: true,
  props: {
    notification: {},
    timer: {}
  },
  emits: ["close", "update:timer"],
  setup(__props, { emit }) {
    const props = __props;
    const interfallMaxClose = computed({
      get() {
        return props.timer;
      },
      set(value) {
        emit("update:timer", value);
      }
    });
    const alertClass = computed(() => {
      switch (props.notification.type) {
        case "success":
          return "alert-success";
        case "error":
          return "alert-error";
        case "warning":
          return "alert-warning";
        case "info":
          return "alert-info";
      }
    });
    function countdown() {
      const interval = setInterval(() => {
        if (interfallMaxClose.value === 0) {
          close();
          clearInterval(interval);
        } else {
          interfallMaxClose.value--;
        }
      }, 100);
    }
    function close() {
      emit("close");
    }
    watch(
      () => props.notification.id,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          countdown();
        }
      },
      { immediate: false }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["alert flex flex-col", unref(alertClass)]
      }, _attrs))}><div class="flex flex-row flex-grow mx-auto min-w-[200px] space-x-2"><div class="w-full flex flex-col flex-grow">`);
      if (props.notification.title) {
        _push(`<strong class="tracking-wide">${ssrInterpolate(props.notification.title)}</strong>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<span class="max-w-[300px] whitespace-pre-wrap leading-4 tracking-normal text-left">${ssrInterpolate(props.notification.text)}</span></div><div class="w-6 h-6 p-0.5 flex items-center justify-center hover:bg-white rounded-full transition-all duration-300" role="button">`);
      _push(ssrRenderComponent(_component_Icon, { name: "i-heroicons-x-circle" }, null, _parent));
      _push(`</div></div><progress class="progress bg-white !h-0.5 transition duration-500 ease-out"${ssrRenderAttr("value", unref(interfallMaxClose))} min="0" max="60"></progress></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/NotificationItem.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Notification",
  __ssrInlineRender: true,
  setup(__props) {
    const store = useNotification();
    const { messages } = storeToRefs(store);
    function closeByID(id) {
      messages.value = [...messages.value.filter((message) => message.id !== id)];
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UINotificationItem = _sfc_main$2;
      ssrRenderTeleport(_push, (_push2) => {
        if (unref(messages).length) {
          _push2(`<div class="toast toast-top toast-end !z-[9999] p-2"><!--[-->`);
          ssrRenderList(unref(messages), (notification, index) => {
            _push2(ssrRenderComponent(_component_UINotificationItem, {
              key: index,
              notification,
              timer: notification.timer,
              "onUpdate:timer": ($event) => notification.timer = $event,
              onClose: ($event) => closeByID(notification.id)
            }, null, _parent));
          });
          _push2(`<!--]--></div>`);
        } else {
          _push2(`<!---->`);
        }
      }, "body", false, _parent);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Notification.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "admin",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { requestOptions } = useRequestOptions();
    const linksAllowed = ref([
      {
        to: "/admin/orders",
        label: "Orders",
        icon: "bx:list-ol"
      },
      {
        to: "/admin/admin-list",
        label: "Admins",
        icon: "dashicons:admin-users"
      }
    ]);
    const linksProducts = ref([
      {
        to: "/admin/transport",
        label: "Transport",
        icon: "bitcoin-icons:car-filled"
      },
      {
        to: "/admin/tour-package",
        label: "Paket Tur",
        icon: "icon-park-outline:beach-umbrella"
      }
    ]);
    const linksDestinations = ref([
      {
        to: "/admin/destinations",
        label: "Daftar Destinasi",
        icon: "mdi:map-marker-radius"
      }
    ]);
    const linksOthers = ref([
      {
        to: "/admin/users",
        label: "Pengguna",
        icon: "flowbite:users-group-solid"
      },
      {
        to: "/admin/driver",
        label: "Driver",
        icon: "mingcute:steering-wheel-fill"
      },
      {
        to: "/admin/facility-car",
        label: "Facility Car",
        icon: "ion:diamond-outline"
      }
    ]);
    const breakpoints = useBreakpoints(breakpointsTailwind);
    const { $logout, $user } = useAuth();
    const drawer = ref(null);
    const tableOrLaptop = breakpoints.greater("lg");
    const aside = ref();
    onClickOutside(aside, () => {
      if (!tableOrLaptop.value && drawer.value)
        drawer.value = false;
    });
    watch(
      () => tableOrLaptop.value,
      (value) => {
        if (value && !drawer.value) {
          drawer.value = tableOrLaptop.value;
        }
      }
    );
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "adminsProfile",
      () => $fetch(`/admins/profile`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_VDropdown = resolveComponent("VDropdown");
      const _component_UINotification = _sfc_main$1;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class=""><div class="px-6 h-24 border-b flex flex-row items-center gap-4">`);
      if (!unref(drawer)) {
        _push(`<button class="block lg:hidden" type="button">`);
        _push(ssrRenderComponent(_component_Icon, {
          name: "i-heroicons-bars-3",
          class: "w-6 h-6 opacity-50"
        }, null, _parent));
        _push(`</button>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(drawer)) {
        _push(`<button class="block lg:hidden" type="button">`);
        _push(ssrRenderComponent(_component_Icon, {
          name: "pajamas:close-xs",
          class: "w-6 h-6 opacity-50"
        }, null, _parent));
        _push(`</button>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "link link-primary link-hover p-1 underline-offset-8 decoration-4 rounded",
        "active-class": "font-medium",
        to: "/admin/orders"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="logo" class="h-[60px] w-[60px]"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                alt: "logo",
                class: "h-[60px] w-[60px]"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="relative lg:static lg:grid lg:grid-cols-[300px_1fr]">`);
      if (unref(drawer)) {
        _push(`<aside class="absolute lg:static z-50 lg:z-0 min-h-screen w-[300px] border-r bg-white"><div class="flex flex-col h-full"><div class="p-4 flex-grow flex-shrink h-full space-y-8"><ul class="space-y-2 lg:space-y-3.5"><!--[-->`);
        ssrRenderList(unref(linksAllowed), (item) => {
          _push(`<li>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: item.to,
            class: "inline-flex ring-1 ring-zinc-300 ring-offset-1 items-center space-x-2.5 hover:bg-primary hover:ring-primary text-zinc-400 hover:text-white transition-all duration-500 p-3 rounded-lg group w-full hover:scale-x-95 text-sm",
            "active-class": "bg-primary !text-white !ring-primary"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(_component_Icon, {
                  name: item.icon,
                  class: "h-5 w-5 opacity-80"
                }, null, _parent2, _scopeId));
                _push2(`<span class="text-sm"${_scopeId}>${ssrInterpolate(item.label)}</span>`);
              } else {
                return [
                  createVNode(_component_Icon, {
                    name: item.icon,
                    class: "h-5 w-5 opacity-80"
                  }, null, 8, ["name"]),
                  createVNode("span", { class: "text-sm" }, toDisplayString(item.label), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--></ul><div class="space-y-2"><h4 class="font-semibold text-zinc-400">PRODUCTS</h4><ul class="space-y-2 lg:space-y-3.5"><!--[-->`);
        ssrRenderList(unref(linksProducts), (item) => {
          _push(`<li>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: item.to,
            class: "inline-flex ring-1 ring-zinc-300 ring-offset-1 items-center space-x-2.5 hover:bg-primary hover:ring-primary text-zinc-400 hover:text-white transition-all duration-500 p-3 rounded-lg group w-full hover:scale-x-95 text-sm",
            "active-class": "bg-primary !text-white !ring-primary"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(_component_Icon, {
                  name: item.icon,
                  class: "h-5 w-5 opacity-80"
                }, null, _parent2, _scopeId));
                _push2(`<span class="text-sm"${_scopeId}>${ssrInterpolate(item.label)}</span>`);
              } else {
                return [
                  createVNode(_component_Icon, {
                    name: item.icon,
                    class: "h-5 w-5 opacity-80"
                  }, null, 8, ["name"]),
                  createVNode("span", { class: "text-sm" }, toDisplayString(item.label), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--></ul></div><div class="space-y-2"><h4 class="font-semibold text-zinc-400">Lokasi</h4><ul class="space-y-2 lg:space-y-3.5"><!--[-->`);
        ssrRenderList(unref(linksDestinations), (item) => {
          _push(`<li>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: item.to,
            class: "inline-flex ring-1 ring-zinc-300 ring-offset-1 items-center space-x-2.5 hover:bg-primary hover:ring-primary text-zinc-400 hover:text-white transition-all duration-500 p-3 rounded-lg group w-full hover:scale-x-95 text-sm",
            "active-class": "bg-primary !text-white !ring-primary"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(_component_Icon, {
                  name: item.icon,
                  class: "h-5 w-5 opacity-80"
                }, null, _parent2, _scopeId));
                _push2(`<span class="text-sm"${_scopeId}>${ssrInterpolate(item.label)}</span>`);
              } else {
                return [
                  createVNode(_component_Icon, {
                    name: item.icon,
                    class: "h-5 w-5 opacity-80"
                  }, null, 8, ["name"]),
                  createVNode("span", { class: "text-sm" }, toDisplayString(item.label), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--></ul></div><div class="space-y-2"><h4 class="font-semibold text-zinc-400">OTHERS</h4><ul class="space-y-2 lg:space-y-3.5"><!--[-->`);
        ssrRenderList(unref(linksOthers), (item) => {
          _push(`<li>`);
          _push(ssrRenderComponent(_component_NuxtLink, {
            to: item.to,
            class: "inline-flex ring-1 ring-zinc-300 ring-offset-1 items-center space-x-2.5 hover:bg-primary hover:ring-primary text-zinc-400 hover:text-white transition-all duration-500 p-3 rounded-lg group w-full hover:scale-x-95 text-sm",
            "active-class": "bg-primary !text-white !ring-primary"
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(_component_Icon, {
                  name: item.icon,
                  class: "h-5 w-5 opacity-80"
                }, null, _parent2, _scopeId));
                _push2(`<span class="text-sm"${_scopeId}>${ssrInterpolate(item.label)}</span>`);
              } else {
                return [
                  createVNode(_component_Icon, {
                    name: item.icon,
                    class: "h-5 w-5 opacity-80"
                  }, null, 8, ["name"]),
                  createVNode("span", { class: "text-sm" }, toDisplayString(item.label), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</li>`);
        });
        _push(`<!--]--></ul></div></div><div class="mb-16 px-4 mt-10">`);
        _push(ssrRenderComponent(_component_VDropdown, null, {
          popper: withCtx(({ hide }, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="bg-white flex flex-col shadow w-fit"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_NuxtLink, {
                to: `/admin/profile`,
                onClick: hide,
                class: "border-t hover:bg-primary hover:text-white py-2 px-3 flex items-center gap-2"
              }, {
                default: withCtx((_, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_Icon, {
                      name: "iconamoon:profile-circle-thin",
                      class: "w-6 h-6"
                    }, null, _parent3, _scopeId2));
                    _push3(`<div${_scopeId2}>Profil saya</div>`);
                  } else {
                    return [
                      createVNode(_component_Icon, {
                        name: "iconamoon:profile-circle-thin",
                        class: "w-6 h-6"
                      }),
                      createVNode("div", null, "Profil saya")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`<div class="border-t cursor-pointer"${_scopeId}><button type="button" class="flex flex-row space-x-2 items-center text-red-500 font-medium py-2 px-3 w-full hover:bg-red-500 hover:text-white"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, {
                name: "ic:baseline-logout",
                class: "w-6 h-6"
              }, null, _parent2, _scopeId));
              _push2(`<span${_scopeId}>Logout</span></button></div></div>`);
            } else {
              return [
                createVNode("div", { class: "bg-white flex flex-col shadow w-fit" }, [
                  createVNode(_component_NuxtLink, {
                    to: `/admin/profile`,
                    onClick: withModifiers(hide, ["prevent"]),
                    class: "border-t hover:bg-primary hover:text-white py-2 px-3 flex items-center gap-2"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_Icon, {
                        name: "iconamoon:profile-circle-thin",
                        class: "w-6 h-6"
                      }),
                      createVNode("div", null, "Profil saya")
                    ]),
                    _: 2
                  }, 1032, ["onClick"]),
                  createVNode("div", { class: "border-t cursor-pointer" }, [
                    createVNode("button", {
                      type: "button",
                      onClick: unref($logout),
                      class: "flex flex-row space-x-2 items-center text-red-500 font-medium py-2 px-3 w-full hover:bg-red-500 hover:text-white"
                    }, [
                      createVNode(_component_Icon, {
                        name: "ic:baseline-logout",
                        class: "w-6 h-6"
                      }),
                      createVNode("span", null, "Logout")
                    ], 8, ["onClick"])
                  ])
                ])
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p;
            if (_push2) {
              _push2(`<div class="flex items-center gap-2 border py-3 rounded-[8px] px-4 shadow-sm cursor-pointer"${_scopeId}><img${ssrRenderAttr(
                "src",
                ((_b = (_a = unref(data)) == null ? void 0 : _a.data) == null ? void 0 : _b.profile_picture) == "" ? "https://placehold.co/40" : (_d = (_c = unref(data)) == null ? void 0 : _c.data) == null ? void 0 : _d.profile_picture
              )} alt="profile" class="w-6 h-6 rounded-full"${_scopeId}><p class="font-normal"${_scopeId}>${ssrInterpolate((_f = (_e = unref(data)) == null ? void 0 : _e.data) == null ? void 0 : _f.first_name)} ${ssrInterpolate((_h = (_g = unref(data)) == null ? void 0 : _g.data) == null ? void 0 : _h.last_name)}</p></div>`);
            } else {
              return [
                createVNode("div", { class: "flex items-center gap-2 border py-3 rounded-[8px] px-4 shadow-sm cursor-pointer" }, [
                  createVNode("img", {
                    src: ((_j = (_i = unref(data)) == null ? void 0 : _i.data) == null ? void 0 : _j.profile_picture) == "" ? "https://placehold.co/40" : (_l = (_k = unref(data)) == null ? void 0 : _k.data) == null ? void 0 : _l.profile_picture,
                    alt: "profile",
                    class: "w-6 h-6 rounded-full"
                  }, null, 8, ["src"]),
                  createVNode("p", { class: "font-normal" }, toDisplayString((_n = (_m = unref(data)) == null ? void 0 : _m.data) == null ? void 0 : _n.first_name) + " " + toDisplayString((_p = (_o = unref(data)) == null ? void 0 : _o.data) == null ? void 0 : _p.last_name), 1)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div></aside>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="w-full absolute lg:static min-h-svh overflow-y-auto space-y-6 lg"><main>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</main>`);
      _push(ssrRenderComponent(_component_UINotification, null, null, _parent));
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/admin.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=admin-d23e15c6.mjs.map
