import __nuxt_component_1$2 from './Icon-f8c4e628.mjs';
import { useSSRContext, defineComponent, withCtx, createVNode, mergeProps, unref, ref, computed, watch, nextTick, toRef, inject, isRef, withAsyncContext, resolveComponent, openBlock, createBlock, toDisplayString, createTextVNode, Fragment, renderList, withModifiers } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderTeleport, ssrRenderClass, ssrRenderSlot, ssrGetDynamicModelProps, ssrRenderAttr, ssrIncludeBooleanAttr, ssrLooseEqual, ssrRenderList } from 'vue/server-renderer';
import clsx from 'clsx';
import { useField, Form, Field, ErrorMessage } from 'vee-validate';
import { _ as _sfc_main$d } from './MGroup-c9c56f96.mjs';
import { f as useI18n, a as useHead, d as useRoute, b as useRouter, h as useRequestHelper, e as useRequestOptions, g as useAsyncData, _ as _export_sfc } from '../server.mjs';
import { o as onClickOutside, u as useStepper, d as useBreakpoints, e as breakpointsTailwind } from './index-dea25161.mjs';
import { _ as _sfc_main$e } from './MTextField-bd75102a.mjs';
import { _ as _sfc_main$f } from './MSelect-8e6f95b5.mjs';
import { _ as _sfc_main$g } from './Btn-577fa59f.mjs';
import { u as useNotification } from './nofication-1c3cca5e.mjs';
import { u as useSchema } from './useSchema-2d00eed1.mjs';
import { u as useTourForm$1 } from './useCarStore-c3348ce9.mjs';
import { u as useTourForm } from './useTourStore-056c1748.mjs';
import { _ as __nuxt_component_0$2 } from './Container-45516e4d.mjs';
import { _ as __nuxt_component_4 } from './Card-9f2531a7.mjs';
import { _ as _sfc_main$c } from './CtaSection-8aad2cc4.mjs';
import './config-9e484511.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './TransitionX-055dd228.mjs';
import './index-596a8548.mjs';
import 'zod';
import '@vee-validate/zod';
import './FormatMoneyDash-4b79c187.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main$b = /* @__PURE__ */ defineComponent({
  __name: "TabLink",
  __ssrInlineRender: true,
  props: {
    label: {},
    icon: {},
    isActive: { type: Boolean, default: false }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_1$2;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: unref(clsx)(
          "inline-flex space-x-2 items-center text-zinc-400 hover:border-b-2 py-2 hover:bg-green-100 transition-colors duration-300 px-2 hover:text-primary hover:border-primary cursor-pointer",
          {
            "border-b-2 border-primary !text-primary bg-green-100": props.isActive
          }
        )
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_Icon, {
        name: props.icon,
        class: "h-5 w-5"
      }, null, _parent));
      _push(`<div class="">${ssrInterpolate(props.label)}</div></div>`);
    };
  }
});
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Share/Menu/TabLink.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const _sfc_main$a = {
  __name: "Map",
  __ssrInlineRender: true,
  props: {
    latitude: {
      type: [String, Number]
    },
    longitude: {
      type: [String, Number]
    },
    locationAddress: {
      type: [String, Number]
    },
    locationName: {
      type: String
    }
  },
  emits: [
    "update:longitude",
    "update:latitude",
    "update:locationAddress",
    "update:locationName",
    "hideModal"
  ],
  setup(__props, { emit }) {
    const center = ref({ lat: -8.417347915171359, lng: 115.19596919507471 });
    const currentMarkerPosition = ref({
      lat: -8.417347915171359,
      lng: 115.19596919507471
    });
    const latitudeFix = ref(-8.417347915171359);
    const longitudeFix = ref(115.19596919507471);
    const locationAddress = ref();
    const locationName = ref();
    async function fetchAddress(latitude, longitude) {
      const geocoder = new google.maps.Geocoder();
      const latLng = {
        lat: parseFloat(latitude.value),
        lng: parseFloat(longitude.value)
      };
      geocoder.geocode({ location: latLng }, (results, status) => {
        if (status === "OK" && results[0]) {
          locationAddress.value = results[0].formatted_address;
          locationName.value = results[0].address_components[0].long_name;
        } else {
          alert("Geocode was not successful: " + status);
        }
      });
    }
    function handleMapClick(event) {
      const latitude = event.latLng.lat();
      const longitude = event.latLng.lng();
      currentMarkerPosition.value = { lat: latitude, lng: longitude };
      center.value = { lat: latitude, lng: longitude };
      latitudeFix.value = latitude;
      longitudeFix.value = longitude;
    }
    function setPlace(ctx) {
      var _a, _b, _c, _d;
      const latitude = (_b = (_a = ctx.geometry) == null ? void 0 : _a.location) == null ? void 0 : _b.lat();
      const longitude = (_d = (_c = ctx.geometry) == null ? void 0 : _c.location) == null ? void 0 : _d.lng();
      currentMarkerPosition.value = { lat: latitude, lng: longitude };
      center.value = { lat: latitude, lng: longitude };
      latitudeFix.value = latitude;
      longitudeFix.value = longitude;
    }
    watch(
      () => latitudeFix.value,
      () => {
        fetchAddress(latitudeFix, longitudeFix);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_GMapAutocomplete = resolveComponent("GMapAutocomplete");
      const _component_GMapMap = resolveComponent("GMapMap");
      const _component_GMapMarker = resolveComponent("GMapMarker");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "rounded-lg overflow-hidden relative p-3" }, _attrs))} data-v-729aa682><div class="relative z-[10000] grid md:flex gap-3 items-center" data-v-729aa682><button class="btn border-primary border bg-white text-primary md:mb-3" data-v-729aa682>${ssrInterpolate(_ctx.$t("dapatkan-lokasi-anda"))}</button>`);
      _push(ssrRenderComponent(_component_GMapAutocomplete, {
        class: "input input-bordered flex-grow mb-3",
        placeholder: "Search Location",
        onPlace_changed: setPlace,
        "select-first-on-enter": true
      }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_GMapMap, {
        center: center.value,
        zoom: 10,
        "map-type-id": "terrain",
        style: { "width": "100%", "height": "250px" },
        options: {
          disableDefaultUi: true,
          draggableCursor: "pointer"
        },
        onClick: handleMapClick
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_GMapMarker, {
              key: "current",
              position: currentMarkerPosition.value,
              icon: {
                url: "/marker-red.svg",
                scaledSize: { width: 50, height: 50 }
              },
              clickable: true
            }, null, _parent2, _scopeId));
          } else {
            return [
              (openBlock(), createBlock(_component_GMapMarker, {
                key: "current",
                position: currentMarkerPosition.value,
                icon: {
                  url: "/marker-red.svg",
                  scaledSize: { width: 50, height: 50 }
                },
                clickable: true
              }, null, 8, ["position", "icon"]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="flex justify-between mt-3 items-center gap-3" data-v-729aa682><div class="grid gap-1" data-v-729aa682><p class="font-semibold lg:text-[20px]" data-v-729aa682>${ssrInterpolate(_ctx.$t("location"))} :</p><p class="text-sm" data-v-729aa682>${ssrInterpolate(locationName.value)}</p><p class="text-sm" data-v-729aa682>${ssrInterpolate(locationAddress.value)}</p></div><button type="submit" class="bg-primary text-sm text-white normal-case !font-medium hover:bg-primary whitespace-nowrap md:col-span-2 btn" data-v-729aa682>${ssrInterpolate(_ctx.$t("pilih-lokasi-ini"))}</button></div></div>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Map.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const __nuxt_component_1$1 = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["__scopeId", "data-v-729aa682"]]);
const _sfc_main$9 = /* @__PURE__ */ Object.assign({
  inheritAttrs: false
}, {
  __name: "ModalMap",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      type: Boolean,
      default: false
    },
    clickOutside: {
      type: Boolean,
      default: false
    },
    latitude: {
      type: [String, Number]
    },
    longitude: {
      type: [String, Number]
    },
    locationAddress: {
      type: [String, Number]
    },
    locationName: {
      type: String
    }
  },
  emits: [
    "update:modelValue",
    "update:longitude",
    "update:latitude",
    "update:locationAddress",
    "update:locationName"
  ],
  setup(__props, { expose: __expose, emit }) {
    const props = __props;
    const modal = ref(null);
    const showModal = computed({
      get() {
        return props.modelValue;
      },
      set(value) {
        emit("update:modelValue", value);
      }
    });
    function hideModal() {
      showModal.value = false;
    }
    watch(showModal, (newValue) => {
      if (newValue) {
        nextTick(() => {
          onClickOutside(modal, () => {
            if (props.clickOutside) {
              hideModal();
            }
          });
        });
      }
    });
    __expose({
      hideModal
    });
    const formData = ref({
      latitude: void 0,
      longitude: void 0,
      locationAddress: void 0,
      locationName: void 0
    });
    watch(
      () => formData.value.latitude,
      (newValue, oldValue) => {
        emit("update:latitude", newValue);
      }
    );
    watch(
      () => formData.value.longitude,
      (newValue, oldValue) => {
        emit("update:longitude", newValue);
      }
    );
    watch(
      () => formData.value.locationAddress,
      (newValue, oldValue) => {
        emit("update:locationAddress", newValue);
      }
    );
    watch(
      () => formData.value.locationName,
      (newValue, oldValue) => {
        emit("update:locationName", newValue);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_1$2;
      const _component_Map = __nuxt_component_1$1;
      ssrRenderTeleport(_push, (_push2) => {
        if (unref(showModal)) {
          _push2(`<div class="modal-background" data-v-f231b5c7></div>`);
        } else {
          _push2(`<!---->`);
        }
        if (unref(showModal)) {
          _push2(`<dialog class="${ssrRenderClass([{
            "modal-open": unref(showModal)
          }, "modal z-[99] !bg-transparent"])}" data-v-f231b5c7><div${ssrRenderAttrs(mergeProps({ class: "modal-content rounded-[10px] !bg-white py-3 w-[90%] px-3 md:w-[60%] overflow-auto h-[90%] md:h-fit" }, _ctx.$attrs, {
            ref_key: "modal",
            ref: modal
          }))} data-v-f231b5c7>`);
          if (unref(showModal)) {
            _push2(`<!--[--><div class="flex items-end justify-between pb-4 px-2" data-v-f231b5c7><h3 class="font-semibold text-lg" data-v-f231b5c7>${ssrInterpolate(_ctx.$t("dijemput-dimana"))}</h3><div class="" data-v-f231b5c7><div class="px-1 flex items-center rounded-md cursor-pointer" data-v-f231b5c7>`);
            _push2(ssrRenderComponent(_component_Icon, {
              name: "ion:close",
              class: "w-5 h-5"
            }, null, _parent));
            _push2(`</div></div></div>`);
            _push2(ssrRenderComponent(_component_Map, {
              latitude: unref(formData).latitude,
              "onUpdate:latitude": ($event) => unref(formData).latitude = $event,
              longitude: unref(formData).longitude,
              "onUpdate:longitude": ($event) => unref(formData).longitude = $event,
              locationAddress: unref(formData).locationAddress,
              "onUpdate:locationAddress": ($event) => unref(formData).locationAddress = $event,
              locationName: unref(formData).locationName,
              "onUpdate:locationName": ($event) => unref(formData).locationName = $event,
              onHideModal: hideModal
            }, null, _parent));
            _push2(`<!--]-->`);
          } else {
            _push2(`<!---->`);
          }
          _push2(`</div></dialog>`);
        } else {
          _push2(`<!---->`);
        }
      }, "body", false, _parent);
    };
  }
});
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ModalMap.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["__scopeId", "data-v-f231b5c7"]]);
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "TextFieldWModal",
  __ssrInlineRender: true,
  props: {
    type: { default: "text" },
    modelValue: {},
    name: {},
    class: {},
    disabled: { type: Boolean, default: false },
    ariaLabel: {},
    placeholder: {},
    readonly: { type: Boolean }
  },
  emits: [
    "update:longitude",
    "update:latitude",
    "update:locationAddress",
    "update:locationName"
  ],
  setup(__props, { emit }) {
    const props = __props;
    const name = toRef(props, "name");
    const { value, errorMessage } = useField(name, void 0, {
      syncVModel: true
    });
    const { setError } = inject("group-form");
    watch(errorMessage, (value2) => {
      if (value2) {
        setError(true);
      } else {
        setError(false);
      }
    });
    ref();
    const showModal = ref(false);
    const formData = ref({
      latitude: void 0,
      longitude: void 0,
      locationAddress: void 0,
      locationName: void 0
    });
    watch(
      () => formData.value.latitude,
      (newValue, oldValue) => {
        emit("update:latitude", newValue);
      }
    );
    watch(
      () => formData.value.longitude,
      (newValue, oldValue) => {
        emit("update:longitude", newValue);
      }
    );
    watch(
      () => formData.value.locationAddress,
      (newValue, oldValue) => {
        emit("update:locationAddress", newValue);
      }
    );
    watch(
      () => formData.value.locationName,
      (newValue, oldValue) => {
        emit("update:locationName", newValue);
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ModalMap = __nuxt_component_0$1;
      let _temp0;
      _push(`<!--[--><label class="${ssrRenderClass(
        unref(clsx)(
          "flex items-center  rounded-lg focus-within:outline-none w-full h-9 overflow-hidden",
          {
            "gap-2": !!_ctx.$slots.leftSection || !!_ctx.$slots.rightSection,
            "pl-0": !_ctx.$slots.leftSection,
            "pr-0": !_ctx.$slots.rightSection
          }
        )
      )}">`);
      if (_ctx.$slots.leftSection) {
        ssrRenderSlot(_ctx.$slots, "leftSection", {}, null, _push, _parent);
      } else {
        _push(`<!---->`);
      }
      _push(`<input${ssrRenderAttrs((_temp0 = mergeProps({
        name: unref(name),
        id: unref(name),
        type: _ctx.type,
        readonly: "",
        disabled: _ctx.disabled,
        "aria-label": _ctx.ariaLabel,
        placeholder: _ctx.placeholder,
        class: unref(clsx)(
          "w-full h-full !outline-none focus:!border-none disabled:bg-gray-50 cursor-pointer",
          {
            "px-1": !_ctx.$slots.leftSection || !_ctx.$slots.rightSection
          }
        )
      }, _ctx.$attrs), mergeProps(_temp0, ssrGetDynamicModelProps(_temp0, unref(value)))))}>`);
      if (_ctx.$slots.rightSection) {
        ssrRenderSlot(_ctx.$slots, "rightSection", {}, null, _push, _parent);
      } else {
        _push(`<!---->`);
      }
      _push(`</label>`);
      _push(ssrRenderComponent(_component_ModalMap, {
        modelValue: unref(showModal),
        "onUpdate:modelValue": ($event) => isRef(showModal) ? showModal.value = $event : null,
        latitude: unref(formData).latitude,
        "onUpdate:latitude": ($event) => unref(formData).latitude = $event,
        longitude: unref(formData).longitude,
        "onUpdate:longitude": ($event) => unref(formData).longitude = $event,
        locationAddress: unref(formData).locationAddress,
        "onUpdate:locationAddress": ($event) => unref(formData).locationAddress = $event,
        locationName: unref(formData).locationName,
        "onUpdate:locationName": ($event) => unref(formData).locationName = $event
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/TextFieldWModal.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "Toggle",
  __ssrInlineRender: true,
  props: {
    name: {},
    label: {},
    modelValue: {},
    disabled: { type: Boolean, default: false },
    trueValue: { default: 1 },
    falseValue: { default: 0 },
    ariaLabel: { default: "toggle" },
    variant: {},
    size: {},
    class: {},
    readonly: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const name = toRef(props, "name");
    const variants = [
      "toggle-primary",
      "toggle-secondary",
      "toggle-accent",
      "toggle-info",
      "toggle-success",
      "toggle-warning",
      "toggle-error"
    ];
    const sizes = [
      "toggle-xs",
      "toggle-sm",
      "toggle-md",
      "toggle-lg"
    ];
    const {
      value,
      errorMessage
    } = useField(name, void 0, {
      syncVModel: true
    });
    const toggleClass = computed(() => {
      return clsx(
        "toggle",
        variants[variants.indexOf(`toggle-${props.variant}`)],
        sizes[sizes.indexOf(`toggle-${props.size}`)],
        props.class
      );
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "form-control w-full" }, _attrs))}><label class="label !justify-start cursor-pointer inline-flex gap-4"><input type="checkbox" class="${ssrRenderClass(unref(toggleClass))}"${ssrRenderAttr("name", props.name)}${ssrIncludeBooleanAttr(props.disabled) ? " disabled" : ""}${ssrIncludeBooleanAttr(ssrLooseEqual(unref(value), props.trueValue)) ? " checked" : ""}${ssrRenderAttr("aria-label", _ctx.ariaLabel)}${ssrIncludeBooleanAttr(props.readonly) ? " readonly" : ""}>`);
      if (props.label || _ctx.$slots.default) {
        _push(`<span class="label-text">`);
        ssrRenderSlot(_ctx.$slots, "default", {}, () => {
          _push(`${ssrInterpolate(props.label)}`);
        }, _push, _parent);
        _push(`</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</label></div>`);
    };
  }
});
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/Toggle.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const _sfc_main$6 = {
  __name: "Vehicle",
  __ssrInlineRender: true,
  setup(__props) {
    useRequestOptions();
    const { loading, message, alertType, setErrorMessage, transformErrors } = useRequestHelper();
    useNotification();
    const { carSearchSchema } = useSchema();
    const { locale, t: $t } = useI18n();
    const breakpoints = useBreakpoints(breakpointsTailwind);
    const isMobile = breakpoints.smaller("lg");
    const router = useRouter();
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedCarData,
      clearSavedCarData
    } = useTourForm$1({
      callback: () => {
        alert("Form has been submitted!");
      }
    });
    const formDataJemput = ref({
      latitude: void 0,
      longitude: void 0,
      locationAddress: void 0,
      locationName: void 0
    });
    const formDataTujuan = ref({
      latitude: void 0,
      longitude: void 0,
      locationAddress: void 0,
      locationName: void 0
    });
    const distance = ref();
    const distanceRound = ref();
    watch(
      () => dataForm.value.pickup_date,
      (newPickupDate) => {
        if (newPickupDate && dataForm.value.return_date < newPickupDate) {
          dataForm.value.return_date = "";
        }
      }
    );
    watch(
      () => formDataJemput.value.longitude,
      (newValue, oldValue) => {
        formDataJemput.value.longitude = newValue;
        calculateDistanceMatrix();
      }
    );
    watch(
      () => formDataJemput.value.latitude,
      (newValue, oldValue) => {
        formDataJemput.value.latitude = newValue;
        calculateDistanceMatrix();
      }
    );
    watch(
      () => formDataTujuan.value.longitude,
      (newValue, oldValue) => {
        formDataTujuan.value.longitude = newValue;
        calculateDistanceMatrix();
      }
    );
    watch(
      () => formDataTujuan.value.latitude,
      (newValue, oldValue) => {
        formDataTujuan.value.latitude = newValue;
        calculateDistanceMatrix();
      }
    );
    const maxReturnDate = ref("");
    watch(
      () => dataForm.value.pickup_date,
      (newPickupDate) => {
        if (newPickupDate) {
          const pickupDate = new Date(newPickupDate);
          const returnDate = new Date(pickupDate);
          returnDate.setDate(pickupDate.getDate() + 7);
          maxReturnDate.value = returnDate.toISOString().split("T")[0];
        } else {
          maxReturnDate.value = "";
        }
      }
    );
    async function calculateDistanceMatrix() {
      if (formDataJemput.value.latitude && formDataTujuan.value.latitude) {
        const lat1 = parseFloat(formDataJemput.value.latitude);
        const lng1 = parseFloat(formDataJemput.value.longitude);
        const lat2 = parseFloat(formDataTujuan.value.latitude);
        const lng2 = parseFloat(formDataTujuan.value.longitude);
        const origin = { lat: lat1, lng: lng1 };
        const destination = { lat: lat2, lng: lng2 };
        const service = new window.google.maps.DistanceMatrixService();
        await service.getDistanceMatrix(
          {
            origins: [origin],
            destinations: [destination],
            travelMode: "DRIVING"
          },
          (response, status) => {
            var _a, _b;
            if (status === "OK") {
              const result = response.rows[0].elements[0];
              distance.value = (_a = result == null ? void 0 : result.distance) == null ? void 0 : _a.value;
              distanceRound.value = (_b = result == null ? void 0 : result.distance) == null ? void 0 : _b.text;
            }
          }
        );
      }
    }
    function onSubmit() {
      let filters = [];
      if (dataForm.value.passengers) {
        filters.push(`passengers=${dataForm.value.passengers}`);
      }
      if (dataForm.value.distance) {
        filters.push(`distance=${dataForm.value.distance}`);
      }
      const queryString = filters.join("&");
      const url = `/vehicles?${queryString ? `&${queryString}` : ""}`;
      dataForm.value.location_pickup_address = formDataJemput.value.locationAddress;
      dataForm.value.location_pickup_name = formDataJemput.value.locationName;
      dataForm.value.location_pickup_latitude = formDataJemput.value.latitude;
      dataForm.value.location_pickup_longitude = formDataJemput.value.longitude;
      dataForm.value.location_return_address = formDataTujuan.value.locationAddress;
      dataForm.value.location_return_name = formDataTujuan.value.locationName;
      dataForm.value.location_return_latitude = formDataTujuan.value.latitude;
      dataForm.value.location_return_longitude = formDataTujuan.value.longitude;
      dataForm.value.distance = distance.value;
      saveFormData();
      router.replace(url);
    }
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIFormMGroup = _sfc_main$d;
      const _component_UIFormTextFieldWModal = _sfc_main$8;
      const _component_Icon = __nuxt_component_1$2;
      const _component_UIFormToggle = _sfc_main$7;
      const _component_UIFormMTextField = _sfc_main$e;
      const _component_UIFormMSelect = _sfc_main$f;
      const _component_UIBtn = _sfc_main$g;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-1" }, _attrs))}><div class="flex justify-center items-center">`);
      if (unref(dataForm).distance) {
        _push(`<div class="bg-primary flex justify-center rounded-full w-fit items-center px-2"><div class="p-1 text-sm text-white"><span>${ssrInterpolate(unref(dataForm).distance)}</span></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit,
        "validation-schema": unref(carSearchSchema)
      }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 lg:grid-cols-[1fr_50px_1fr] gap-4 items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: unref($t)("jemput-dimana"),
              name: "pickup_address"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormTextFieldWModal, {
                    modelValue: unref(formDataJemput).locationAddress,
                    "onUpdate:modelValue": ($event) => unref(formDataJemput).locationAddress = $event,
                    latitude: unref(formDataJemput).latitude,
                    "onUpdate:latitude": ($event) => unref(formDataJemput).latitude = $event,
                    longitude: unref(formDataJemput).longitude,
                    "onUpdate:longitude": ($event) => unref(formDataJemput).longitude = $event,
                    locationAddress: unref(formDataJemput).locationAddress,
                    "onUpdate:locationAddress": ($event) => unref(formDataJemput).locationAddress = $event,
                    locationName: unref(formDataJemput).locationName,
                    "onUpdate:locationName": ($event) => unref(formDataJemput).locationName = $event,
                    name: "pickup_address",
                    placeholder: "ex:Jalan Pahlawan No. 1"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormTextFieldWModal, {
                      modelValue: unref(formDataJemput).locationAddress,
                      "onUpdate:modelValue": ($event) => unref(formDataJemput).locationAddress = $event,
                      latitude: unref(formDataJemput).latitude,
                      "onUpdate:latitude": ($event) => unref(formDataJemput).latitude = $event,
                      longitude: unref(formDataJemput).longitude,
                      "onUpdate:longitude": ($event) => unref(formDataJemput).longitude = $event,
                      locationAddress: unref(formDataJemput).locationAddress,
                      "onUpdate:locationAddress": ($event) => unref(formDataJemput).locationAddress = $event,
                      locationName: unref(formDataJemput).locationName,
                      "onUpdate:locationName": ($event) => unref(formDataJemput).locationName = $event,
                      name: "pickup_address",
                      placeholder: "ex:Jalan Pahlawan No. 1"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "latitude", "onUpdate:latitude", "longitude", "onUpdate:longitude", "locationAddress", "onUpdate:locationAddress", "locationName", "onUpdate:locationName"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<div class="flex flex-col gap-1 items-center"${_scopeId}><div class="flex justify-center items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Icon, {
              name: unref(isMobile) ? "i-heroicons-arrows-up-down" : "i-heroicons-arrows-right-left",
              class: "w-6 h-6"
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              label: unref($t)("mau-kemana"),
              name: "return_address"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormTextFieldWModal, {
                    modelValue: unref(formDataTujuan).locationAddress,
                    "onUpdate:modelValue": ($event) => unref(formDataTujuan).locationAddress = $event,
                    latitude: unref(formDataTujuan).latitude,
                    "onUpdate:latitude": ($event) => unref(formDataTujuan).latitude = $event,
                    longitude: unref(formDataTujuan).longitude,
                    "onUpdate:longitude": ($event) => unref(formDataTujuan).longitude = $event,
                    locationAddress: unref(formDataTujuan).locationAddress,
                    "onUpdate:locationAddress": ($event) => unref(formDataTujuan).locationAddress = $event,
                    locationName: unref(formDataTujuan).locationName,
                    "onUpdate:locationName": ($event) => unref(formDataTujuan).locationName = $event,
                    name: "return_address",
                    placeholder: "ex:Jalan Pahlawan No. 1"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormTextFieldWModal, {
                      modelValue: unref(formDataTujuan).locationAddress,
                      "onUpdate:modelValue": ($event) => unref(formDataTujuan).locationAddress = $event,
                      latitude: unref(formDataTujuan).latitude,
                      "onUpdate:latitude": ($event) => unref(formDataTujuan).latitude = $event,
                      longitude: unref(formDataTujuan).longitude,
                      "onUpdate:longitude": ($event) => unref(formDataTujuan).longitude = $event,
                      locationAddress: unref(formDataTujuan).locationAddress,
                      "onUpdate:locationAddress": ($event) => unref(formDataTujuan).locationAddress = $event,
                      locationName: unref(formDataTujuan).locationName,
                      "onUpdate:locationName": ($event) => unref(formDataTujuan).locationName = $event,
                      name: "return_address",
                      placeholder: "ex:Jalan Pahlawan No. 1"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "latitude", "onUpdate:latitude", "longitude", "onUpdate:longitude", "locationAddress", "onUpdate:locationAddress", "locationName", "onUpdate:locationName"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div><div class="grid grid-cols-1 lg:grid-cols-5 gap-4 mt-6"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormToggle, {
              name: "round_trip",
              label: "Pulang - Pergi",
              modelValue: unref(dataForm).round_trip,
              "onUpdate:modelValue": ($event) => unref(dataForm).round_trip = $event,
              "true-value": "1",
              "false-value": "0",
              variant: "primary"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "pickup_date",
              label: unref($t)("jemput-tanggal")
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "pickup_date",
                    min: unref(today),
                    modelValue: unref(dataForm).pickup_date,
                    "onUpdate:modelValue": ($event) => unref(dataForm).pickup_date = $event,
                    type: "date",
                    placeholder: "ex:2024-01-01"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "pickup_date",
                      min: unref(today),
                      modelValue: unref(dataForm).pickup_date,
                      "onUpdate:modelValue": ($event) => unref(dataForm).pickup_date = $event,
                      type: "date",
                      placeholder: "ex:2024-01-01"
                    }, null, 8, ["min", "modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "return_date",
              label: unref($t)("pulang-balik")
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                var _a, _b;
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "return_date",
                    modelValue: unref(dataForm).return_date,
                    "onUpdate:modelValue": ($event) => unref(dataForm).return_date = $event,
                    type: "date",
                    min: (_a = unref(dataForm).pickup_date) != null ? _a : unref(today),
                    max: unref(maxReturnDate),
                    placeholder: "ex:2024-01-02"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "return_date",
                      modelValue: unref(dataForm).return_date,
                      "onUpdate:modelValue": ($event) => unref(dataForm).return_date = $event,
                      type: "date",
                      min: (_b = unref(dataForm).pickup_date) != null ? _b : unref(today),
                      max: unref(maxReturnDate),
                      placeholder: "ex:2024-01-02"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "min", "max"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "passengers",
              label: unref($t)("jumlah-penumpang")
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMSelect, {
                    name: "passengers",
                    modelValue: unref(dataForm).passengers,
                    "onUpdate:modelValue": ($event) => unref(dataForm).passengers = $event
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<option value="1"${_scopeId3}>1 ${ssrInterpolate(unref($t)("penumpang"))}</option><option value="2"${_scopeId3}>2 ${ssrInterpolate(unref($t)("penumpang"))}</option><option value="3"${_scopeId3}>3 ${ssrInterpolate(unref($t)("penumpang"))}</option><option value="4"${_scopeId3}>4 ${ssrInterpolate(unref($t)("penumpang"))}</option><option value="5"${_scopeId3}>5 ${ssrInterpolate(unref($t)("penumpang"))}</option><option value="6"${_scopeId3}>6 ${ssrInterpolate(unref($t)("penumpang"))}</option>`);
                      } else {
                        return [
                          createVNode("option", { value: "1" }, "1 " + toDisplayString(unref($t)("penumpang")), 1),
                          createVNode("option", { value: "2" }, "2 " + toDisplayString(unref($t)("penumpang")), 1),
                          createVNode("option", { value: "3" }, "3 " + toDisplayString(unref($t)("penumpang")), 1),
                          createVNode("option", { value: "4" }, "4 " + toDisplayString(unref($t)("penumpang")), 1),
                          createVNode("option", { value: "5" }, "5 " + toDisplayString(unref($t)("penumpang")), 1),
                          createVNode("option", { value: "6" }, "6 " + toDisplayString(unref($t)("penumpang")), 1)
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMSelect, {
                      name: "passengers",
                      modelValue: unref(dataForm).passengers,
                      "onUpdate:modelValue": ($event) => unref(dataForm).passengers = $event
                    }, {
                      default: withCtx(() => [
                        createVNode("option", { value: "1" }, "1 " + toDisplayString(unref($t)("penumpang")), 1),
                        createVNode("option", { value: "2" }, "2 " + toDisplayString(unref($t)("penumpang")), 1),
                        createVNode("option", { value: "3" }, "3 " + toDisplayString(unref($t)("penumpang")), 1),
                        createVNode("option", { value: "4" }, "4 " + toDisplayString(unref($t)("penumpang")), 1),
                        createVNode("option", { value: "5" }, "5 " + toDisplayString(unref($t)("penumpang")), 1),
                        createVNode("option", { value: "6" }, "6 " + toDisplayString(unref($t)("penumpang")), 1)
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              variant: "primary",
              type: "submit",
              disabled: unref(loading)
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref($t)("cari-mobil"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref($t)("cari-mobil")), 1)
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-[1fr_50px_1fr] gap-4 items-center" }, [
                createVNode(_component_UIFormMGroup, {
                  label: unref($t)("jemput-dimana"),
                  name: "pickup_address"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormTextFieldWModal, {
                      modelValue: unref(formDataJemput).locationAddress,
                      "onUpdate:modelValue": ($event) => unref(formDataJemput).locationAddress = $event,
                      latitude: unref(formDataJemput).latitude,
                      "onUpdate:latitude": ($event) => unref(formDataJemput).latitude = $event,
                      longitude: unref(formDataJemput).longitude,
                      "onUpdate:longitude": ($event) => unref(formDataJemput).longitude = $event,
                      locationAddress: unref(formDataJemput).locationAddress,
                      "onUpdate:locationAddress": ($event) => unref(formDataJemput).locationAddress = $event,
                      locationName: unref(formDataJemput).locationName,
                      "onUpdate:locationName": ($event) => unref(formDataJemput).locationName = $event,
                      name: "pickup_address",
                      placeholder: "ex:Jalan Pahlawan No. 1"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "latitude", "onUpdate:latitude", "longitude", "onUpdate:longitude", "locationAddress", "onUpdate:locationAddress", "locationName", "onUpdate:locationName"])
                  ]),
                  _: 1
                }, 8, ["label"]),
                createVNode("div", { class: "flex flex-col gap-1 items-center" }, [
                  createVNode("div", { class: "flex justify-center items-center" }, [
                    createVNode(_component_Icon, {
                      name: unref(isMobile) ? "i-heroicons-arrows-up-down" : "i-heroicons-arrows-right-left",
                      class: "w-6 h-6"
                    }, null, 8, ["name"])
                  ])
                ]),
                createVNode(_component_UIFormMGroup, {
                  label: unref($t)("mau-kemana"),
                  name: "return_address"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormTextFieldWModal, {
                      modelValue: unref(formDataTujuan).locationAddress,
                      "onUpdate:modelValue": ($event) => unref(formDataTujuan).locationAddress = $event,
                      latitude: unref(formDataTujuan).latitude,
                      "onUpdate:latitude": ($event) => unref(formDataTujuan).latitude = $event,
                      longitude: unref(formDataTujuan).longitude,
                      "onUpdate:longitude": ($event) => unref(formDataTujuan).longitude = $event,
                      locationAddress: unref(formDataTujuan).locationAddress,
                      "onUpdate:locationAddress": ($event) => unref(formDataTujuan).locationAddress = $event,
                      locationName: unref(formDataTujuan).locationName,
                      "onUpdate:locationName": ($event) => unref(formDataTujuan).locationName = $event,
                      name: "return_address",
                      placeholder: "ex:Jalan Pahlawan No. 1"
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "latitude", "onUpdate:latitude", "longitude", "onUpdate:longitude", "locationAddress", "onUpdate:locationAddress", "locationName", "onUpdate:locationName"])
                  ]),
                  _: 1
                }, 8, ["label"])
              ]),
              createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-5 gap-4 mt-6" }, [
                createVNode(_component_UIFormToggle, {
                  name: "round_trip",
                  label: "Pulang - Pergi",
                  modelValue: unref(dataForm).round_trip,
                  "onUpdate:modelValue": ($event) => unref(dataForm).round_trip = $event,
                  "true-value": "1",
                  "false-value": "0",
                  variant: "primary"
                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode(_component_UIFormMGroup, {
                  name: "pickup_date",
                  label: unref($t)("jemput-tanggal")
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      name: "pickup_date",
                      min: unref(today),
                      modelValue: unref(dataForm).pickup_date,
                      "onUpdate:modelValue": ($event) => unref(dataForm).pickup_date = $event,
                      type: "date",
                      placeholder: "ex:2024-01-01"
                    }, null, 8, ["min", "modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }, 8, ["label"]),
                createVNode(_component_UIFormMGroup, {
                  name: "return_date",
                  label: unref($t)("pulang-balik")
                }, {
                  default: withCtx(() => {
                    var _a;
                    return [
                      createVNode(_component_UIFormMTextField, {
                        name: "return_date",
                        modelValue: unref(dataForm).return_date,
                        "onUpdate:modelValue": ($event) => unref(dataForm).return_date = $event,
                        type: "date",
                        min: (_a = unref(dataForm).pickup_date) != null ? _a : unref(today),
                        max: unref(maxReturnDate),
                        placeholder: "ex:2024-01-02"
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "min", "max"])
                    ];
                  }),
                  _: 1
                }, 8, ["label"]),
                createVNode(_component_UIFormMGroup, {
                  name: "passengers",
                  label: unref($t)("jumlah-penumpang")
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMSelect, {
                      name: "passengers",
                      modelValue: unref(dataForm).passengers,
                      "onUpdate:modelValue": ($event) => unref(dataForm).passengers = $event
                    }, {
                      default: withCtx(() => [
                        createVNode("option", { value: "1" }, "1 " + toDisplayString(unref($t)("penumpang")), 1),
                        createVNode("option", { value: "2" }, "2 " + toDisplayString(unref($t)("penumpang")), 1),
                        createVNode("option", { value: "3" }, "3 " + toDisplayString(unref($t)("penumpang")), 1),
                        createVNode("option", { value: "4" }, "4 " + toDisplayString(unref($t)("penumpang")), 1),
                        createVNode("option", { value: "5" }, "5 " + toDisplayString(unref($t)("penumpang")), 1),
                        createVNode("option", { value: "6" }, "6 " + toDisplayString(unref($t)("penumpang")), 1)
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }, 8, ["label"]),
                createVNode("div", null, [
                  createVNode(_component_UIBtn, {
                    variant: "primary",
                    type: "submit",
                    disabled: unref(loading)
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref($t)("cari-mobil")), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Share/Filter/Vehicle.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$6;
const _sfc_main$5 = {
  __name: "Tour",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { locale, t: $t } = useI18n();
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const { tourSearchSchema } = useSchema();
    const router = useRouter();
    const selectedLocationName = ref();
    const formData = ref({
      location_id: void 0,
      activity_date: void 0,
      tourist_numbers: void 0
    });
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedTourData,
      clearSavedTourData
    } = useTourForm({
      callback: () => {
        alert("Form has been submitted!");
      }
    });
    const {
      data: locations,
      refresh,
      pending
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      `locations`,
      () => $fetch(`/locations`, {
        method: "GET",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    function selectLocation(location) {
      formData.value.location_id = location.id;
      selectedLocationName.value = location.name;
    }
    function onSubmit() {
      dataForm.value.location_id = formData.value.location_id;
      dataForm.value.location_name = selectedLocationName.value;
      dataForm.value.activity_date = formData.value.activity_date;
      dataForm.value.tourist_numbers = formData.value.tourist_numbers;
      let filters = [];
      if (dataForm.value.location_id) {
        filters.push(`location=${dataForm.value.location_id}`);
      }
      if (dataForm.value.tourist_numbers) {
        filters.push(`tourist_numbers=${dataForm.value.tourist_numbers}`);
      }
      const queryString = filters.join("&");
      const url = `/tours?${queryString ? `&${queryString}` : ""}`;
      console.log(
        "ini setelah filters tour harusnya menyimpan location_id, location_name, activity_date dan tourist number",
        dataForm.value
      );
      console.log(dataForm.value.tourist_numbers);
      saveFormData();
      router.replace(url);
    }
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_UIFormMGroup = _sfc_main$d;
      const _component_VDropdown = resolveComponent("VDropdown");
      const _component_Icon = __nuxt_component_1$2;
      const _component_VeeField = Field;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_UIFormMTextField = _sfc_main$e;
      const _component_UIBtn = _sfc_main$g;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        onSubmit,
        "validation-schema": unref(tourSearchSchema),
        class: "space-y-4"
      }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "tour_id",
              label: unref($t)("pilih-destinasi")
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_VDropdown, {
                    modelValue: unref(formData).location_id,
                    "onUpdate:modelValue": ($event) => unref(formData).location_id = $event,
                    placements: "start",
                    distance: "-10",
                    skidding: "1",
                    "arrow-padding": "1"
                  }, {
                    popper: withCtx(({ hide }, _push4, _parent4, _scopeId3) => {
                      var _a, _b;
                      if (_push4) {
                        _push4(`<div class="w-full p-4 space-y-4 max-w-5xl"${_scopeId3}><div class="space-y-4 overflow-y-auto h-full lg:max-h-[200px]"${_scopeId3}><!--[-->`);
                        ssrRenderList((_a = unref(locations)) == null ? void 0 : _a.data, (location) => {
                          _push4(`<div class="grid grid-cols-[150px_1fr] gap-4 hover:bg-primary/10 transition-all duration-300 p-4 rounded-md cursor-pointer"${_scopeId3}><div${_scopeId3}>${ssrInterpolate(location.name)}</div></div>`);
                        });
                        _push4(`<!--]--></div></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "w-full p-4 space-y-4 max-w-5xl" }, [
                            createVNode("div", { class: "space-y-4 overflow-y-auto h-full lg:max-h-[200px]" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList((_b = unref(locations)) == null ? void 0 : _b.data, (location) => {
                                return openBlock(), createBlock("div", {
                                  key: location.id,
                                  class: "grid grid-cols-[150px_1fr] gap-4 hover:bg-primary/10 transition-all duration-300 p-4 rounded-md cursor-pointer",
                                  onClick: withModifiers(($event) => {
                                    selectLocation(location);
                                    hide();
                                  }, ["prevent"])
                                }, [
                                  createVNode("div", null, toDisplayString(location.name), 1)
                                ], 8, ["onClick"]);
                              }), 128))
                            ])
                          ])
                        ];
                      }
                    }),
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      var _a, _b;
                      if (_push4) {
                        _push4(`<button type="button" class="text-xs h-9 w-full flex justify-between items-center"${_scopeId3}><div${_scopeId3}>${ssrInterpolate((_a = unref(selectedLocationName)) != null ? _a : unref($t)("pilih-destinasi"))}</div><div${_scopeId3}>`);
                        _push4(ssrRenderComponent(_component_Icon, { name: "i-heroicons-chevron-down" }, null, _parent4, _scopeId3));
                        _push4(`</div></button>`);
                      } else {
                        return [
                          createVNode("button", {
                            type: "button",
                            class: "text-xs h-9 w-full flex justify-between items-center"
                          }, [
                            createVNode("div", null, toDisplayString((_b = unref(selectedLocationName)) != null ? _b : unref($t)("pilih-destinasi")), 1),
                            createVNode("div", null, [
                              createVNode(_component_Icon, { name: "i-heroicons-chevron-down" })
                            ])
                          ])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_VDropdown, {
                      modelValue: unref(formData).location_id,
                      "onUpdate:modelValue": ($event) => unref(formData).location_id = $event,
                      placements: "start",
                      distance: "-10",
                      skidding: "1",
                      "arrow-padding": "1"
                    }, {
                      popper: withCtx(({ hide }) => {
                        var _a;
                        return [
                          createVNode("div", { class: "w-full p-4 space-y-4 max-w-5xl" }, [
                            createVNode("div", { class: "space-y-4 overflow-y-auto h-full lg:max-h-[200px]" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList((_a = unref(locations)) == null ? void 0 : _a.data, (location) => {
                                return openBlock(), createBlock("div", {
                                  key: location.id,
                                  class: "grid grid-cols-[150px_1fr] gap-4 hover:bg-primary/10 transition-all duration-300 p-4 rounded-md cursor-pointer",
                                  onClick: withModifiers(($event) => {
                                    selectLocation(location);
                                    hide();
                                  }, ["prevent"])
                                }, [
                                  createVNode("div", null, toDisplayString(location.name), 1)
                                ], 8, ["onClick"]);
                              }), 128))
                            ])
                          ])
                        ];
                      }),
                      default: withCtx(() => {
                        var _a;
                        return [
                          createVNode("button", {
                            type: "button",
                            class: "text-xs h-9 w-full flex justify-between items-center"
                          }, [
                            createVNode("div", null, toDisplayString((_a = unref(selectedLocationName)) != null ? _a : unref($t)("pilih-destinasi")), 1),
                            createVNode("div", null, [
                              createVNode(_component_Icon, { name: "i-heroicons-chevron-down" })
                            ])
                          ])
                        ];
                      }),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeField, {
              type: "text",
              name: "location",
              class: "hidden",
              id: "location",
              modelValue: unref(formData).location_id,
              "onUpdate:modelValue": ($event) => unref(formData).location_id = $event
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "location",
              class: "form-error-message"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="grid grid-cols-1 lg:grid-cols-[1fr_1fr_110px] gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "activity_date",
              label: unref($t)("pilih-tanggal")
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "activity_date",
                    type: "date",
                    min: unref(today),
                    modelValue: unref(formData).activity_date,
                    "onUpdate:modelValue": ($event) => unref(formData).activity_date = $event,
                    placeholder: "ex:2024-01-01"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "activity_date",
                      type: "date",
                      min: unref(today),
                      modelValue: unref(formData).activity_date,
                      "onUpdate:modelValue": ($event) => unref(formData).activity_date = $event,
                      placeholder: "ex:2024-01-01"
                    }, null, 8, ["min", "modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "total_passengers",
              label: unref($t)("beberapa-orang")
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMTextField, {
                    name: "total_passengers",
                    modelValue: unref(formData).tourist_numbers,
                    "onUpdate:modelValue": ($event) => unref(formData).tourist_numbers = $event,
                    placeholder: "ex:1"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMTextField, {
                      name: "total_passengers",
                      modelValue: unref(formData).tourist_numbers,
                      "onUpdate:modelValue": ($event) => unref(formData).tourist_numbers = $event,
                      placeholder: "ex:1"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              variant: "primary",
              type: "submit"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref($t)("cari-tur"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref($t)("cari-tur")), 1)
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode(_component_UIFormMGroup, {
                  name: "tour_id",
                  label: unref($t)("pilih-destinasi")
                }, {
                  default: withCtx(() => [
                    createVNode(_component_VDropdown, {
                      modelValue: unref(formData).location_id,
                      "onUpdate:modelValue": ($event) => unref(formData).location_id = $event,
                      placements: "start",
                      distance: "-10",
                      skidding: "1",
                      "arrow-padding": "1"
                    }, {
                      popper: withCtx(({ hide }) => {
                        var _a;
                        return [
                          createVNode("div", { class: "w-full p-4 space-y-4 max-w-5xl" }, [
                            createVNode("div", { class: "space-y-4 overflow-y-auto h-full lg:max-h-[200px]" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList((_a = unref(locations)) == null ? void 0 : _a.data, (location) => {
                                return openBlock(), createBlock("div", {
                                  key: location.id,
                                  class: "grid grid-cols-[150px_1fr] gap-4 hover:bg-primary/10 transition-all duration-300 p-4 rounded-md cursor-pointer",
                                  onClick: withModifiers(($event) => {
                                    selectLocation(location);
                                    hide();
                                  }, ["prevent"])
                                }, [
                                  createVNode("div", null, toDisplayString(location.name), 1)
                                ], 8, ["onClick"]);
                              }), 128))
                            ])
                          ])
                        ];
                      }),
                      default: withCtx(() => {
                        var _a;
                        return [
                          createVNode("button", {
                            type: "button",
                            class: "text-xs h-9 w-full flex justify-between items-center"
                          }, [
                            createVNode("div", null, toDisplayString((_a = unref(selectedLocationName)) != null ? _a : unref($t)("pilih-destinasi")), 1),
                            createVNode("div", null, [
                              createVNode(_component_Icon, { name: "i-heroicons-chevron-down" })
                            ])
                          ])
                        ];
                      }),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }, 8, ["label"]),
                createVNode(_component_VeeField, {
                  type: "text",
                  name: "location",
                  class: "hidden",
                  id: "location",
                  modelValue: unref(formData).location_id,
                  "onUpdate:modelValue": ($event) => unref(formData).location_id = $event
                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "location",
                  class: "form-error-message"
                })
              ]),
              createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-[1fr_1fr_110px] gap-4" }, [
                createVNode(_component_UIFormMGroup, {
                  name: "activity_date",
                  label: unref($t)("pilih-tanggal")
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      name: "activity_date",
                      type: "date",
                      min: unref(today),
                      modelValue: unref(formData).activity_date,
                      "onUpdate:modelValue": ($event) => unref(formData).activity_date = $event,
                      placeholder: "ex:2024-01-01"
                    }, null, 8, ["min", "modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }, 8, ["label"]),
                createVNode(_component_UIFormMGroup, {
                  name: "total_passengers",
                  label: unref($t)("beberapa-orang")
                }, {
                  default: withCtx(() => [
                    createVNode(_component_UIFormMTextField, {
                      name: "total_passengers",
                      modelValue: unref(formData).tourist_numbers,
                      "onUpdate:modelValue": ($event) => unref(formData).tourist_numbers = $event,
                      placeholder: "ex:1"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }, 8, ["label"]),
                createVNode("div", null, [
                  createVNode(_component_UIBtn, {
                    variant: "primary",
                    type: "submit"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref($t)("cari-tur")), 1)
                    ]),
                    _: 1
                  })
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Share/Filter/Tour.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$5;
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "HomeBanner",
  __ssrInlineRender: true,
  setup(__props) {
    const { locale, t: $t } = useI18n();
    useRoute();
    const router = useRouter();
    const { current, goTo, isCurrent } = useStepper(["transport", "paket-tour"]);
    const slides = [
      {
        title: $t("perjalanan-aman"),
        description: $t("armada-kendaraan-modern"),
        image: "/hi-travel-hero.jpeg",
        key: "transport"
      },
      {
        title: $t("jelajahi-keajaiban"),
        description: $t("dari-pantai-hingga-gunung"),
        image: "/second-thumbnail-hero-hi-travel.jpeg",
        key: "paket-tour"
      }
    ];
    const currentSlide = computed(() => {
      return slides.find((slide) => slide.key === current.value);
    });
    function replaceWindow() {
      if (isCurrent("transport")) {
        router.replace("/?transport");
      } else {
        router.replace("/?tour");
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d;
      const _component_ShareMenuTabLink = _sfc_main$b;
      const _component_ShareFilterVehicle = __nuxt_component_1;
      const _component_ShareFilterTour = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-4 relative" }, _attrs))} data-v-007a135b><div class="relative rounded-xl overflow-hidden" data-v-007a135b><div class="absolute h-full w-full bg-gradient-to-t from-[#121212]/20 to-[#121212]/50 text-center space-y-6" data-v-007a135b><div class="h-20" data-v-007a135b></div><h1 class="text-3xl lg:text-5xl text-white font-bold max-w-4xl mx-auto" data-v-007a135b>${ssrInterpolate((_a = unref(currentSlide)) == null ? void 0 : _a.title)}</h1><p class="text-white text-base lg:text-xl max-w-2xl mx-auto" data-v-007a135b>${ssrInterpolate((_b = unref(currentSlide)) == null ? void 0 : _b.description)}</p></div>`);
      if ((_c = unref(currentSlide)) == null ? void 0 : _c.image) {
        _push(`<img${ssrRenderAttr("src", (_d = unref(currentSlide)) == null ? void 0 : _d.image)} class="w-full h-[500px] object-cover" alt="hero" data-v-007a135b>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="lg:absolute z-10 w-full inset-x-0 bottom-0 lg:-bottom-4" data-v-007a135b><div data-v-007a135b><div class="max-w-5xl bg-white mx-auto mt-auto bottom-0 p-6 lg:p-2 shadow rounded-lg" data-v-007a135b><div class="inline-flex" data-v-007a135b>`);
      _push(ssrRenderComponent(_component_ShareMenuTabLink, {
        label: "Transport",
        icon: "bi:car-front-fill",
        "is-active": unref(isCurrent)("transport"),
        onClick: ($event) => (unref(goTo)("transport"), replaceWindow())
      }, null, _parent));
      _push(ssrRenderComponent(_component_ShareMenuTabLink, {
        label: unref($t)("paket-tour"),
        icon: "mingcute:umbrella-2-line",
        "is-active": unref(isCurrent)("paket-tour"),
        onClick: ($event) => (unref(goTo)("paket-tour"), replaceWindow())
      }, null, _parent));
      _push(`</div><div class="p-4 mt-2" data-v-007a135b>`);
      if (unref(isCurrent)("transport")) {
        _push(`<div data-v-007a135b>`);
        _push(ssrRenderComponent(_component_ShareFilterVehicle, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isCurrent)("paket-tour")) {
        _push(`<div data-v-007a135b>`);
        _push(ssrRenderComponent(_component_ShareFilterTour, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></div></div>`);
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Hero/HomeBanner.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-007a135b"]]);
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "HighLight",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "popularTours",
      () => $fetch(`/popular-tours`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_TourCard = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-6 py-6" }, _attrs))}><h3 class="text-[32px] leading-[40px] font-semibold text-primary-dark">${ssrInterpolate(_ctx.$t("paket-tour"))}</h3><div class="grid grid-cols-1 lg:grid-cols-4 gap-6"><!--[-->`);
      ssrRenderList((_a = unref(data)) == null ? void 0 : _a.data, (item) => {
        var _a2;
        _push(ssrRenderComponent(_component_TourCard, {
          id: item.id,
          key: item.id,
          name: item.name,
          description: item.locations,
          image: (_a2 = item.thumbnail_image) == null ? void 0 : _a2.image,
          price: item.price,
          slug: `/tours/` + item.slug
        }, null, _parent));
      });
      _push(`<!--]--></div></div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/HighLight.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Card",
  __ssrInlineRender: true,
  props: {
    step: {}
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-4 border rounded-xl p-4" }, _attrs))}><h4 class="text-primary-dark text-2xl font-bold">${ssrInterpolate(props.step.title)}</h4><div class="text-zinc-400">${ssrInterpolate(props.step.decription)}</div><img${ssrRenderAttr("src", props.step.image)}${ssrRenderAttr("alt", props.step.title)} class="w-full h-[350px] object-cover"></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/StepToJoin/Card.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const { locale, t: $t } = useI18n();
    const steps = ref([
      {
        title: "1." + $t("pesan-di-hitravel-list.list-1.title"),
        decription: $t("pesan-di-hitravel-list.list-1.desk"),
        image: "/hi-travel-feat-1.png"
      },
      {
        title: "2." + $t("pesan-di-hitravel-list.list-2.title"),
        decription: $t("pesan-di-hitravel-list.list-2.desk"),
        image: "/hi-travel-feat-2.png"
      },
      {
        title: "3." + $t("pesan-di-hitravel-list.list-3.title"),
        decription: $t("pesan-di-hitravel-list.list-3.desk"),
        image: "/hi-travel-feat-3.png"
      }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_StepToJoinCard = _sfc_main$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-6 py-6" }, _attrs))}><h3 class="text-[32px] leading-[40px] font-semibold text-primary-dark">${ssrInterpolate(unref($t)("pesan-di-hitravel"))}</h3><div class="grid grid-cols-1 lg:grid-cols-3 gap-6"><!--[-->`);
      ssrRenderList(unref(steps), (step, index) => {
        _push(ssrRenderComponent(_component_StepToJoinCard, {
          key: index,
          step
        }, null, _parent));
      });
      _push(`<!--]--></div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/StepToJoin/index.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useI18n();
    useTourForm({
      callback: () => {
        alert("Form has been submitted!");
      }
    });
    useTourForm$1({
      callback: () => {
        alert("Form has been submitted!");
      }
    });
    useHead({
      title: "Home",
      meta: [
        {
          name: "description",
          content: "Safe and Comfortable Transfer in Bali. A fleet of modern vehicles and experienced drivers are ready to take you wherever you want."
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeroHomeBanner = __nuxt_component_0;
      const _component_UIContainer = __nuxt_component_0$2;
      const _component_TourHighLight = _sfc_main$3;
      const _component_StepToJoin = _sfc_main$1;
      const _component_ShareCtaSection = _sfc_main$c;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="h-32" id="learnmore"></div>`);
      _push(ssrRenderComponent(_component_HeroHomeBanner, null, null, _parent));
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_TourHighLight, null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_TourHighLight)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_StepToJoin, null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_StepToJoin)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_ShareCtaSection, null, null, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-1f9d5c17.mjs.map
