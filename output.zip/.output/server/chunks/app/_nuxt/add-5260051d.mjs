import { _ as __nuxt_component_0 } from './TitleBack-580f5db2.mjs';
import { _ as __nuxt_component_1 } from './TourPackage-fa527a68.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { f as useHead } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './Icon-9a1ee2a3.mjs';
import './config-71e93c9c.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'vee-validate';
import './TextFieldWLabel-0de16bf1.mjs';
import './DropdownsTest-2042eaff.mjs';
import './index-df4194e4.mjs';
import './TabItem-142d001b.mjs';
import './client-only-53a57ea8.mjs';
import 'clsx';
import './Group-4dcbb69b.mjs';
import './useTourPackage-18c36174.mjs';
import './nofication-176ebe9f.mjs';
import '@tiptap/vue-3';
import '@tiptap/starter-kit';
import '@tiptap/extension-link';
import '@tiptap/extension-text-align';
import '@tiptap/extension-placeholder';
import '@tiptap/extension-table';
import '@tiptap/extension-table-cell';
import '@tiptap/extension-table-header';
import '@tiptap/extension-table-row';
import 'tiptap-extension-resize-image';
import './useSchema-f211c259.mjs';
import 'zod';
import '@vee-validate/zod';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "add",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Add Paket tur"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TitleBack = __nuxt_component_0;
      const _component_UIFormTourPackage = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "px-5 py-6 md:px-10 md:py-10" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_TitleBack, {
        title: "Tambah paket tur baru",
        link: "/admin/tour-package"
      }, null, _parent));
      _push(ssrRenderComponent(_component_UIFormTourPackage, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/tour-package/add.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=add-5260051d.mjs.map
