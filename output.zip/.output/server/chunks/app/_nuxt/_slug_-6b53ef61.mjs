import { Swiper, SwiperSlide } from 'swiper/vue';
import { Autoplay } from 'swiper/modules';
import { useSSRContext, withCtx, createVNode, createTextVNode, mergeProps, unref, openBlock, createBlock, Fragment, renderList } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import { e as _export_sfc } from '../server.mjs';
import { _ as __nuxt_component_0$1 } from './Container-c0bcb3c6.mjs';
import __nuxt_component_1 from './Icon-7218f0f6.mjs';
import { _ as __nuxt_component_3 } from './CtaSection-9975e633.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-aab100d3.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main$1 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  const _component_Swiper = Swiper;
  const _component_SwiperSlide = SwiperSlide;
  _push(ssrRenderComponent(_component_Swiper, mergeProps({
    modules: ["SwiperAutoplay" in _ctx ? _ctx.SwiperAutoplay : unref(Autoplay)],
    "slides-per-view": 1,
    loop: true,
    effect: "creative",
    "space-between": "1",
    autoplay: {
      delay: 8e3,
      disableOnInteraction: true
    },
    breakpoints: {
      "640": {
        slidesPerView: 2,
        spaceBetween: 20
      },
      "1024": {
        slidesPerView: 4,
        spaceBetween: 40
      }
    }
  }, _attrs), {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<!--[-->`);
        ssrRenderList(10, (slide) => {
          _push2(ssrRenderComponent(_component_SwiperSlide, { key: slide }, {
            default: withCtx((_2, _push3, _parent3, _scopeId2) => {
              if (_push3) {
                _push3(`<div class="h-[350px] border"${_scopeId2}><img src="https://placehold.co/150" alt="slide" class="w-full h-full object-cover"${_scopeId2}></div>`);
              } else {
                return [
                  createVNode("div", { class: "h-[350px] border" }, [
                    createVNode("img", {
                      src: "https://placehold.co/150",
                      alt: "slide",
                      class: "w-full h-full object-cover"
                    })
                  ])
                ];
              }
            }),
            _: 2
          }, _parent2, _scopeId));
        });
        _push2(`<!--]-->`);
      } else {
        return [
          (openBlock(), createBlock(Fragment, null, renderList(10, (slide) => {
            return createVNode(_component_SwiperSlide, { key: slide }, {
              default: withCtx(() => [
                createVNode("div", { class: "h-[350px] border" }, [
                  createVNode("img", {
                    src: "https://placehold.co/150",
                    alt: "slide",
                    class: "w-full h-full object-cover"
                  })
                ])
              ]),
              _: 2
            }, 1024);
          }), 64))
        ];
      }
    }),
    _: 1
  }, _parent));
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/Swiper.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_TourSwiper = __nuxt_component_0;
  const _component_UIContainer = __nuxt_component_0$1;
  const _component_Icon = __nuxt_component_1;
  const _component_ShareCtaSection = __nuxt_component_3;
  _push(`<div${ssrRenderAttrs(_attrs)}><div class="h-28"></div>`);
  _push(ssrRenderComponent(_component_TourSwiper, null, null, _parent));
  _push(`<div class="h-5"></div>`);
  _push(ssrRenderComponent(_component_UIContainer, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full"${_scopeId}><div class="flex flex-col space-y-2"${_scopeId}><h1 class="text-xl lg:text-[32px] lg:leading-[40px] font-semibold"${_scopeId}>West Nusa Penida Tour</h1><div class="inline-flex space-x-2"${_scopeId}><div${_scopeId}>`);
        _push2(ssrRenderComponent(_component_Icon, {
          name: "ph:map-pin-line-fill",
          class: "w-5 h-5 text-[#00A59A]"
        }, null, _parent2, _scopeId));
        _push2(`</div><div class="text-zinc-400"${_scopeId}> Kelingking Cliff - Angel&#39;s Billabong - Broken Beach - Crystal Bay Beach </div></div><div${_scopeId}><div class="text-zinc-400 text-xs"${_scopeId}>Harga Mulai Dari</div><h4 class="text-xl font-semibold text-primary"${_scopeId}>Rp. 1.000.000/Orang</h4></div></div><div class="flex justify-end w-full"${_scopeId}><div${_scopeId}><button class="btn btn-primary"${_scopeId}>Booking Sekarang `);
        _push2(ssrRenderComponent(_component_Icon, {
          name: "i-heroicons-arrow-right",
          class: "w-5 h-5 -rotate-45"
        }, null, _parent2, _scopeId));
        _push2(`</button></div></div></div><div class="h-5"${_scopeId}></div><div class="grid grid-cols-1 md:grid-cols-[150px_1fr] gap-4"${_scopeId}><div class="text-2xl font-semibold"${_scopeId}>Ringkasan</div><div${_scopeId}> Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam commodi nihil provident? Blanditiis ab corporis cum fugit repudiandae reiciendis quam accusantium. Officia quam facilis ducimus veniam ut autem dolores fuga! </div></div>`);
      } else {
        return [
          createVNode("div", { class: "flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full" }, [
            createVNode("div", { class: "flex flex-col space-y-2" }, [
              createVNode("h1", { class: "text-xl lg:text-[32px] lg:leading-[40px] font-semibold" }, "West Nusa Penida Tour"),
              createVNode("div", { class: "inline-flex space-x-2" }, [
                createVNode("div", null, [
                  createVNode(_component_Icon, {
                    name: "ph:map-pin-line-fill",
                    class: "w-5 h-5 text-[#00A59A]"
                  })
                ]),
                createVNode("div", { class: "text-zinc-400" }, " Kelingking Cliff - Angel's Billabong - Broken Beach - Crystal Bay Beach ")
              ]),
              createVNode("div", null, [
                createVNode("div", { class: "text-zinc-400 text-xs" }, "Harga Mulai Dari"),
                createVNode("h4", { class: "text-xl font-semibold text-primary" }, "Rp. 1.000.000/Orang")
              ])
            ]),
            createVNode("div", { class: "flex justify-end w-full" }, [
              createVNode("div", null, [
                createVNode("button", { class: "btn btn-primary" }, [
                  createTextVNode("Booking Sekarang "),
                  createVNode(_component_Icon, {
                    name: "i-heroicons-arrow-right",
                    class: "w-5 h-5 -rotate-45"
                  })
                ])
              ])
            ])
          ]),
          createVNode("div", { class: "h-5" }),
          createVNode("div", { class: "grid grid-cols-1 md:grid-cols-[150px_1fr] gap-4" }, [
            createVNode("div", { class: "text-2xl font-semibold" }, "Ringkasan"),
            createVNode("div", null, " Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam commodi nihil provident? Blanditiis ab corporis cum fugit repudiandae reiciendis quam accusantium. Officia quam facilis ducimus veniam ut autem dolores fuga! ")
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_ShareCtaSection, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tours/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _slug_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { _slug_ as default };
//# sourceMappingURL=_slug_-6b53ef61.mjs.map
