const Map_vue_vue_type_style_index_0_scoped_46d8ebc7_lang = ".input[data-v-46d8ebc7]{--tw-bg-opacity:1;background-color:#fff;background-color:rgb(255 255 255/var(--tw-bg-opacity));z-index:10}";

const ModalMap_vue_vue_type_style_index_0_scoped_8e23213d_lang = ".modal-background[data-v-8e23213d]{background-color:hsla(0,0%,100%,.2)}.modal[data-v-8e23213d],.modal-background[data-v-8e23213d]{height:100%;left:0;position:fixed;top:0;width:100%}.modal[data-v-8e23213d]{align-items:center;display:flex;justify-content:center}.modal-open[data-v-8e23213d]{overflow:hidden}.modal-content[data-v-8e23213d]{background-color:#fff;box-shadow:0 4px 6px rgba(0,0,0,.1)}";

const HomeBanner_vue_vue_type_style_index_0_scoped_007a135b_lang = ".fade-enter-active[data-v-007a135b]{transition:all .3s ease-out}.fade-leave-active[data-v-007a135b]{transition:all .8s cubic-bezier(1,.5,.8,1)}.fade-enter-from[data-v-007a135b],.fade-leave-to[data-v-007a135b]{opacity:0;transform:translateX(20px)}";

const FloatingWa_vue_vue_type_style_index_0_scoped_b7612713_lang = ".float[data-v-b7612713]{background-color:#25d366;border-radius:50px;bottom:25px;box-shadow:2px 2px 3px #999;color:#fff;font-size:30px;height:60px;left:25px;position:fixed;text-align:center;width:60px;z-index:100}.my-float[data-v-b7612713]{margin-top:16px}";

const indexStyles_5c8398ea = [Map_vue_vue_type_style_index_0_scoped_46d8ebc7_lang, ModalMap_vue_vue_type_style_index_0_scoped_8e23213d_lang, HomeBanner_vue_vue_type_style_index_0_scoped_007a135b_lang, FloatingWa_vue_vue_type_style_index_0_scoped_b7612713_lang];

export { indexStyles_5c8398ea as default };
//# sourceMappingURL=index-styles.5c8398ea.mjs.map
