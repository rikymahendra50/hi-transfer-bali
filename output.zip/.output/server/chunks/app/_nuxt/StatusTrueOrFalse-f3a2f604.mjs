import __nuxt_component_0 from './Icon-0f6314e3.mjs';
import { useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "StatusTrueOrFalse",
  __ssrInlineRender: true,
  props: {
    trueString: {
      type: String
    },
    falseString: {
      type: String
    },
    trueNumber: {
      type: [Number, Boolean]
    },
    falseNumber: {
      type: [Number, Boolean]
    },
    data: {
      type: [Number, String, Boolean]
    }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["px-3 py-1 w-fit rounded-xl", {
          "bg-[#ECFDF3] text-[#037847]": __props.data === props.trueNumber,
          "bg-[#EF4444] bg-opacity-[12%] text-error": __props.data === props.falseNumber
        }]
      }, _attrs))}>`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "icon-park-outline:dot",
        class: {
          "text-[#22C55E]": __props.data === props.trueNumber,
          "text-[#EF4444]": __props.data === props.falseNumber
        }
      }, null, _parent));
      _push(` ${ssrInterpolate(__props.data === props.trueNumber ? props.trueString : props.falseString)}</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/StatusTrueOrFalse.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main;

export { __nuxt_component_2 as _ };
//# sourceMappingURL=StatusTrueOrFalse-f3a2f604.mjs.map
