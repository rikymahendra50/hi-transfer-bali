import { _ as __nuxt_component_0 } from './Container-f78810bd.mjs';
import { d as useRoute, e as useRequestOptions, u as useAuth, h as useRequestHelper, g as useAsyncData, a as useHead, i as useFetch, _ as __nuxt_component_0$1, k as useNuxtApp } from '../server.mjs';
import __nuxt_component_0$2 from './Icon-0f6314e3.mjs';
import { _ as __nuxt_component_3 } from './Modal-967d83e0.mjs';
import { _ as __nuxt_component_4 } from './Verified-7114dbcb.mjs';
import { computed, ref, withAsyncContext, withCtx, createVNode, unref, toDisplayString, createTextVNode, openBlock, createBlock, Fragment, renderList, createCommentVNode, isRef, useSSRContext } from 'vue';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-3cecc2b8.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './index-a61f78d7.mjs';
import './index-596a8548.mjs';
import 'vee-validate';
import './Alert-4fa497cc.mjs';
import './TransitionTopToBottom-a8e40871.mjs';
import './InputOTP-bbb2b053.mjs';
import './useSchema-0246d9f0.mjs';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const route = useRoute();
    const slug = computed(() => {
      var _a;
      return (_a = route == null ? void 0 : route.params) == null ? void 0 : _a.slug;
    });
    const { requestOptions } = useRequestOptions();
    const { $user } = useAuth();
    ref(1);
    const showModalRefund = ref(false);
    const { $toast } = useNuxtApp();
    ref(void 0);
    const { loading, message, alertType, setErrorMessage, transformErrors } = useRequestHelper();
    const {
      data: tourOrderDetail,
      error: errorOrderTour,
      refresh: refreshOrderTour
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "toursOrderDetail",
      () => {
        var _a;
        return $fetch(`/users/${(_a = $user.value) == null ? void 0 : _a.uuid}/tour-orders/${slug.value}`, {
          headers: {
            Accept: "application/json"
          },
          method: "get",
          ...requestOptions
        });
      }
    )), __temp = await __temp, __restore(), __temp);
    async function showModalRefundFunc(id) {
      var _a2, _b2, _c2;
      var _a, _b, _c, _d, _e, _f, _g, _h;
      showModalRefund.value = !showModalRefund.value;
      console.log("ini user uuid", $user.value.uuid);
      console.log("ini tour detail", (_a = tourOrderDetail.value.data) == null ? void 0 : _a.uuid);
      const { data, error } = await useFetch(
        `/users/${$user.value.uuid}/tour-orders/${(_b = tourOrderDetail.value.data) == null ? void 0 : _b.uuid}/refund-request`,
        {
          method: "post",
          ...requestOptions
        },
        "$5yzj0GjwU4"
      );
      if (error.value) {
        setErrorMessage((_a2 = (_d = (_c = error.value) == null ? void 0 : _c.data) == null ? void 0 : _d.message) != null ? _a2 : "Something went wrong");
        $toast.error((_b2 = (_f = (_e = error.value) == null ? void 0 : _e.data) == null ? void 0 : _f.message) != null ? _b2 : "Something went wrong.");
      } else {
        $toast.success(
          (_c2 = (_h = (_g = data.value) == null ? void 0 : _g.data) == null ? void 0 : _h.message) != null ? _c2 : "Cancel tour order successfully"
        );
      }
      loading.value = false;
    }
    async function cancelOrder() {
      var _a2, _b2, _c2;
      var _a, _b, _c, _d, _e, _f, _g;
      loading.value = true;
      const { data, error } = await useFetch(
        `/users/${$user.value.uuid}/tour-orders/${(_a = tourOrderDetail.value.data) == null ? void 0 : _a.uuid}/cancel`,
        {
          method: "post",
          ...requestOptions
        },
        "$BLvWzAnRF7"
      );
      if (error.value) {
        setErrorMessage((_a2 = (_c = (_b = error.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message) != null ? _a2 : "Something went wrong");
        $toast.error((_b2 = (_e = (_d = error.value) == null ? void 0 : _d.data) == null ? void 0 : _e.message) != null ? _b2 : "Something went wrong.");
      } else {
        $toast.success(
          (_c2 = (_g = (_f = data.value) == null ? void 0 : _f.data) == null ? void 0 : _g.message) != null ? _c2 : "Cancel tour order successfully"
        );
      }
      loading.value = false;
      refreshOrderTour();
      window.location.reload();
    }
    function getSuskes(data) {
      showModalRefund.value = data;
    }
    useHead({ title: "Order detail tour" });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_0$2;
      const _component_modal = __nuxt_component_3;
      const _component_Verified = __nuxt_component_4;
      _push(`<!--[--><div class="h-28"></div><div class="w-full border-b">`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R, _S, _T, _U, _V, _W, _X, _Y, _Z, __, _$, _aa, _ba, _ca, _da, _ea, _fa, _ga, _ha, _ia, _ja, _ka, _la, _ma, _na;
          if (_push2) {
            _push2(`<div class="flex items-center gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, { to: "/user" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_Icon, {
                    name: "formkit:arrowleft",
                    class: "text-black w-7 h-7"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_Icon, {
                      name: "formkit:arrowleft",
                      class: "text-black w-7 h-7"
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="flex flex-col gap-1"${_scopeId}><p class="text-black text-[18px] font-medium"${_scopeId}>${ssrInterpolate(_ctx.$t("ringkasan-pesanan"))}</p><span${_scopeId}>${ssrInterpolate(_ctx.$t("informasi-lengkap-pesanan"))} #${ssrInterpolate((_b = (_a = unref(tourOrderDetail)) == null ? void 0 : _a.data) == null ? void 0 : _b.uuid)}</span></div></div><div class="py-10"${_scopeId}><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("informasi-pelanggan"))}</div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("nama-pelanggan"))}:</p><p${_scopeId}>${ssrInterpolate((_e = (_d = (_c = unref(tourOrderDetail)) == null ? void 0 : _c.data) == null ? void 0 : _d.user) == null ? void 0 : _e.first_name)}\xA0${ssrInterpolate((_h = (_g = (_f = unref(tourOrderDetail)) == null ? void 0 : _f.data) == null ? void 0 : _g.user) == null ? void 0 : _h.last_name)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Email:</p><p${_scopeId}>${ssrInterpolate((_k = (_j = (_i = unref(tourOrderDetail)) == null ? void 0 : _i.data) == null ? void 0 : _j.user) == null ? void 0 : _k.email)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("nomor-telepon"))}:</p><p${_scopeId}>${ssrInterpolate((_n = (_m = (_l = unref(tourOrderDetail)) == null ? void 0 : _l.data) == null ? void 0 : _m.user) == null ? void 0 : _n.phone)}</p></div></div><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("informasi-pemesanan"))}</div><div class="grid gap-3 md:grid-cols-2"${_scopeId}><div class="flex flex-col gap-1 text-sm"${_scopeId}><p class="text-[#121212] font-semibold"${_scopeId}>Activity Date</p> ${ssrInterpolate((_p = (_o = unref(tourOrderDetail)) == null ? void 0 : _o.data) == null ? void 0 : _p.activity_date)}</div></div><div class="flex flex-col gap-1 text-sm"${_scopeId}><p class="text-[#121212] font-semibold"${_scopeId}>Details :</p><div class=""${_scopeId}><!--[-->`);
            ssrRenderList((_r = (_q = unref(tourOrderDetail)) == null ? void 0 : _q.data) == null ? void 0 : _r.details, (item) => {
              _push2(`<div class="py-4 flex flex-col gap-3 border-b mb-4"${_scopeId}><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Name :</p><p${_scopeId}>${ssrInterpolate(item.name)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Quantity :</p><p${_scopeId}>${ssrInterpolate(item.quantity)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Location Name :</p><p${_scopeId}>${ssrInterpolate(item.location_name)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Price :</p><p${_scopeId}>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(item.price))}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Total Price :</p><p${_scopeId}>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(item.total_price))}</p></div></div>`);
            });
            _push2(`<!--]--></div></div></div><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("payment-information"))}</div>`);
            if ((_t = (_s = unref(tourOrderDetail)) == null ? void 0 : _s.data) == null ? void 0 : _t.refund_status) {
              _push2(`<div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Refund status</p><p${_scopeId}>${ssrInterpolate((_v = (_u = unref(tourOrderDetail)) == null ? void 0 : _u.data) == null ? void 0 : _v.refund_status)}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("payment-status"))}</p><p${_scopeId}>${ssrInterpolate((_x = (_w = unref(tourOrderDetail)) == null ? void 0 : _w.data) == null ? void 0 : _x.payment_status)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("total-price"))}</p><p${_scopeId}>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))((_z = (_y = unref(tourOrderDetail)) == null ? void 0 : _y.data) == null ? void 0 : _z.total_purchased))}</p></div></div></div><div class="flex items-center justify-end gap-2"${_scopeId}>`);
            if (((_B = (_A = unref(tourOrderDetail)) == null ? void 0 : _A.data) == null ? void 0 : _B.payment_status) === "paid") {
              _push2(`<button type="button"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""} class="border-2 shadow-sm rounded-lg py-2 px-4 btn bg-white"${_scopeId}><p${_scopeId}>${ssrInterpolate(_ctx.$t("pengembalian-pembayaran"))}</p></button>`);
            } else if (((_D = (_C = unref(tourOrderDetail)) == null ? void 0 : _C.data) == null ? void 0 : _D.status) === "waiting_for_payment" && ((_F = (_E = unref(tourOrderDetail)) == null ? void 0 : _E.data) == null ? void 0 : _F.status) !== "cancel") {
              _push2(`<button type="button"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""} class="border-2 shadow-sm rounded-lg py-2 px-4 btn bg-white"${_scopeId}><p${_scopeId}>Cancel Order</p></button>`);
            } else if (((_H = (_G = unref(tourOrderDetail)) == null ? void 0 : _G.data) == null ? void 0 : _H.status) == "completed") {
              _push2(`<div${_scopeId}> Completed </div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex items-center gap-4" }, [
                createVNode(_component_NuxtLink, { to: "/user" }, {
                  default: withCtx(() => [
                    createVNode(_component_Icon, {
                      name: "formkit:arrowleft",
                      class: "text-black w-7 h-7"
                    })
                  ]),
                  _: 1
                }),
                createVNode("div", { class: "flex flex-col gap-1" }, [
                  createVNode("p", { class: "text-black text-[18px] font-medium" }, toDisplayString(_ctx.$t("ringkasan-pesanan")), 1),
                  createVNode("span", null, toDisplayString(_ctx.$t("informasi-lengkap-pesanan")) + " #" + toDisplayString((_J = (_I = unref(tourOrderDetail)) == null ? void 0 : _I.data) == null ? void 0 : _J.uuid), 1)
                ])
              ]),
              createVNode("div", { class: "py-10" }, [
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(_ctx.$t("informasi-pelanggan")), 1),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, toDisplayString(_ctx.$t("nama-pelanggan")) + ":", 1),
                    createVNode("p", null, toDisplayString((_M = (_L = (_K = unref(tourOrderDetail)) == null ? void 0 : _K.data) == null ? void 0 : _L.user) == null ? void 0 : _M.first_name) + "\xA0" + toDisplayString((_P = (_O = (_N = unref(tourOrderDetail)) == null ? void 0 : _N.data) == null ? void 0 : _O.user) == null ? void 0 : _P.last_name), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, "Email:"),
                    createVNode("p", null, toDisplayString((_S = (_R = (_Q = unref(tourOrderDetail)) == null ? void 0 : _Q.data) == null ? void 0 : _R.user) == null ? void 0 : _S.email), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(_ctx.$t("nomor-telepon")) + ":", 1),
                    createVNode("p", null, toDisplayString((_V = (_U = (_T = unref(tourOrderDetail)) == null ? void 0 : _T.data) == null ? void 0 : _U.user) == null ? void 0 : _V.phone), 1)
                  ])
                ]),
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(_ctx.$t("informasi-pemesanan")), 1),
                  createVNode("div", { class: "grid gap-3 md:grid-cols-2" }, [
                    createVNode("div", { class: "flex flex-col gap-1 text-sm" }, [
                      createVNode("p", { class: "text-[#121212] font-semibold" }, "Activity Date"),
                      createTextVNode(" " + toDisplayString((_X = (_W = unref(tourOrderDetail)) == null ? void 0 : _W.data) == null ? void 0 : _X.activity_date), 1)
                    ])
                  ]),
                  createVNode("div", { class: "flex flex-col gap-1 text-sm" }, [
                    createVNode("p", { class: "text-[#121212] font-semibold" }, "Details :"),
                    createVNode("div", { class: "" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList((_Z = (_Y = unref(tourOrderDetail)) == null ? void 0 : _Y.data) == null ? void 0 : _Z.details, (item) => {
                        return openBlock(), createBlock("div", { class: "py-4 flex flex-col gap-3 border-b mb-4" }, [
                          createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                            createVNode("p", { class: "font-semibold" }, "Name :"),
                            createVNode("p", null, toDisplayString(item.name), 1)
                          ]),
                          createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                            createVNode("p", { class: "font-semibold" }, "Quantity :"),
                            createVNode("p", null, toDisplayString(item.quantity), 1)
                          ]),
                          createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                            createVNode("p", { class: "font-semibold" }, "Location Name :"),
                            createVNode("p", null, toDisplayString(item.location_name), 1)
                          ]),
                          createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                            createVNode("p", { class: "font-semibold" }, "Price :"),
                            createVNode("p", null, toDisplayString(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(item.price)), 1)
                          ]),
                          createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                            createVNode("p", { class: "font-semibold" }, "Total Price :"),
                            createVNode("p", null, toDisplayString(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(item.total_price)), 1)
                          ])
                        ]);
                      }), 256))
                    ])
                  ])
                ]),
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(_ctx.$t("payment-information")), 1),
                  ((_$ = (__ = unref(tourOrderDetail)) == null ? void 0 : __.data) == null ? void 0 : _$.refund_status) ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm"
                  }, [
                    createVNode("p", { class: "font-semibold" }, "Refund status"),
                    createVNode("p", null, toDisplayString((_ba = (_aa = unref(tourOrderDetail)) == null ? void 0 : _aa.data) == null ? void 0 : _ba.refund_status), 1)
                  ])) : createCommentVNode("", true),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(_ctx.$t("payment-status")), 1),
                    createVNode("p", null, toDisplayString((_da = (_ca = unref(tourOrderDetail)) == null ? void 0 : _ca.data) == null ? void 0 : _da.payment_status), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(_ctx.$t("total-price")), 1),
                    createVNode("p", null, toDisplayString(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))((_fa = (_ea = unref(tourOrderDetail)) == null ? void 0 : _ea.data) == null ? void 0 : _fa.total_purchased)), 1)
                  ])
                ])
              ]),
              createVNode("div", { class: "flex items-center justify-end gap-2" }, [
                ((_ha = (_ga = unref(tourOrderDetail)) == null ? void 0 : _ga.data) == null ? void 0 : _ha.payment_status) === "paid" ? (openBlock(), createBlock("button", {
                  key: 0,
                  type: "button",
                  onClick: ($event) => showModalRefundFunc(),
                  disabled: unref(loading),
                  class: "border-2 shadow-sm rounded-lg py-2 px-4 btn bg-white"
                }, [
                  createVNode("p", null, toDisplayString(_ctx.$t("pengembalian-pembayaran")), 1)
                ], 8, ["onClick", "disabled"])) : ((_ja = (_ia = unref(tourOrderDetail)) == null ? void 0 : _ia.data) == null ? void 0 : _ja.status) === "waiting_for_payment" && ((_la = (_ka = unref(tourOrderDetail)) == null ? void 0 : _ka.data) == null ? void 0 : _la.status) !== "cancel" ? (openBlock(), createBlock("button", {
                  key: 1,
                  type: "button",
                  onClick: ($event) => cancelOrder(),
                  disabled: unref(loading),
                  class: "border-2 shadow-sm rounded-lg py-2 px-4 btn bg-white"
                }, [
                  createVNode("p", null, "Cancel Order")
                ], 8, ["onClick", "disabled"])) : ((_na = (_ma = unref(tourOrderDetail)) == null ? void 0 : _ma.data) == null ? void 0 : _na.status) == "completed" ? (openBlock(), createBlock("div", { key: 2 }, " Completed ")) : createCommentVNode("", true)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_modal, {
        modelValue: unref(showModalRefund),
        "onUpdate:modelValue": ($event) => isRef(showModalRefund) ? showModalRefund.value = $event : null,
        class: "relative w-[90%] sm:w-[60%] lg:w-[40%]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div class="flex justify-center items-center flex-col px-2 sm:px-4 lg:px-5 overflow-auto"${_scopeId}><div class="flex flex-col gap-3 lg:gap-5 transition h-full"${_scopeId}><p class="font-semibold text-xl"${_scopeId}>${ssrInterpolate(_ctx.$t("pengembalian-pembayaran"))}</p><p class="text-[12px] border-b border-gray-500 pb-3"${_scopeId}>${ssrInterpolate(_ctx.$t("silakan-periksa-kotak-masuk"))}</p></div><div class="w-full"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Verified, {
              uuidData: (_a = unref(tourOrderDetail).data) == null ? void 0 : _a.uuid,
              onSukses: getSuskes,
              carOrTour: "tour-orders"
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex justify-center items-center flex-col px-2 sm:px-4 lg:px-5 overflow-auto" }, [
                createVNode("div", { class: "flex flex-col gap-3 lg:gap-5 transition h-full" }, [
                  createVNode("p", { class: "font-semibold text-xl" }, toDisplayString(_ctx.$t("pengembalian-pembayaran")), 1),
                  createVNode("p", { class: "text-[12px] border-b border-gray-500 pb-3" }, toDisplayString(_ctx.$t("silakan-periksa-kotak-masuk")), 1)
                ]),
                createVNode("div", { class: "w-full" }, [
                  createVNode(_component_Verified, {
                    uuidData: (_b = unref(tourOrderDetail).data) == null ? void 0 : _b.uuid,
                    onSukses: getSuskes,
                    carOrTour: "tour-orders"
                  }, null, 8, ["uuidData"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/order/order-summary/tour/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-0ac4382b.mjs.map
