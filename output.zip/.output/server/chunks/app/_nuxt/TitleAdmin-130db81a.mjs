import { useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';

const _sfc_main = {
  __name: "TitleAdmin",
  __ssrInlineRender: true,
  props: {
    title: { type: String },
    subTitle: {
      type: String
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col md:flex-row gap-4 md:gap-0 md:justify-between px-5 border-b items-end md:items-center py-6 md:py-4" }, _attrs))}><div class="flex flex-col gap-1"><p class="text-[#121212] text-[18px] font-semibold text-lg md:text-xl">${ssrInterpolate(__props.title)}</p><p class="text-[14px] text-gray-500">${ssrInterpolate(__props.subTitle)}</p></div><div class="">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TitleAdmin.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=TitleAdmin-130db81a.mjs.map
