import { h as useRequestHelper, e as useRequestOptions, b as useRouter } from '../server.mjs';
import { ref } from 'vue';
import { u as useNotification } from './nofication-1c3cca5e.mjs';

function useTourForm(options = {}) {
  const { loading, message, alertType, setErrorMessage, transformErrors } = useRequestHelper();
  const { requestOptions } = useRequestOptions();
  useRouter();
  useNotification();
  const dataForm = ref({
    location_pickup_name: void 0,
    location_pickup_address: void 0,
    location_return_name: void 0,
    location_return_address: void 0,
    location_return_latitude: void 0,
    location_return_longitude: void 0,
    location_pickup_latitude: void 0,
    location_pickup_longitude: void 0,
    pickup_date: void 0,
    return_date: void 0,
    round_trip: 0,
    passengers: 1,
    distance: void 0,
    distance_text: void 0,
    car_id: void 0,
    name_car: void 0,
    image: void 0,
    price: void 0,
    max_person: void 0,
    facilities: [],
    user_uuid: void 0,
    name: void 0,
    email: void 0,
    phone: void 0
  });
  function saveFormData() {
    sessionStorage.setItem("carFormData", JSON.stringify(dataForm.value));
  }
  function showSavedCarData() {
    const savedData = sessionStorage.getItem("carFormData");
    if (savedData) {
      dataForm.value = JSON.parse(savedData);
    }
  }
  function clearSavedCarData() {
    sessionStorage.removeItem("carFormData");
    console.log("Car form data dihapus dari sessionStorage");
  }
  const submitFormOrder = async (ctx) => {
    const formData = new FormData();
    loading.value = true;
    formData.append("pic_name", dataForm.value.name || "");
    formData.append("pic_email", dataForm.value.email || "");
    formData.append("pic_phone_number", dataForm.value.phone || "");
    formData.append("products[0][id]", dataForm.value.car_id || "");
    formData.append("products[0][quantity]", dataForm.value.distance || "");
    formData.append(
      "products[0][pickup_latitude]",
      dataForm.value.location_pickup_latitude || ""
    );
    formData.append(
      "products[0][pickup_longitude]",
      dataForm.value.location_pickup_longitude || ""
    );
    formData.append(
      "products[0][pickup_name]",
      dataForm.value.location_pickup_name || ""
    );
    formData.append(
      "products[0][pickup_address]",
      dataForm.value.location_pickup_address || ""
    );
    formData.append(
      "products[0][destination_latitude]",
      dataForm.value.location_return_latitude || ""
    );
    formData.append(
      "products[0][destination_longitude]",
      dataForm.value.location_return_longitude || ""
    );
    formData.append(
      "products[0][destination_name]",
      dataForm.value.location_return_name || ""
    );
    formData.append(
      "products[0][destination_address]",
      dataForm.value.location_return_address || ""
    );
    formData.append(
      "products[0][activity_date]",
      dataForm.value.pickup_date || ""
    );
    await $fetch(
      `/users/${dataForm.value.user_uuid}/car-orders`,
      {
        headers: {
          Accept: "application/json"
        },
        method: "POST",
        body: formData,
        ...requestOptions
      }
    ).catch((error) => {
      alert(error);
    }).then((data) => {
      var _a, _b;
      if (data) {
        console.log(data);
        window.location.replace((_a = data.data) == null ? void 0 : _a.payment_url);
        (_b = options.callback) == null ? void 0 : _b.call(options);
      }
    });
    loading.value = false;
  };
  return {
    submitFormOrder,
    clearSavedCarData,
    saveFormData,
    dataForm,
    showSavedCarData
    // saveFormDataProfile,
    // showSavedCarDataProfile,
  };
}

export { useTourForm as u };
//# sourceMappingURL=useCarStore-c3348ce9.mjs.map
