import { _ as __nuxt_component_0 } from './Container-afb1bf23.mjs';
import { d as useRoute, a as useRequestOptions, m as useAuth, g as useAsyncData, f as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_1 from './Icon-9a1ee2a3.mjs';
import { _ as __nuxt_component_3 } from './Modal-be43a7fe.mjs';
import { _ as __nuxt_component_4 } from './Verified-ef3c6fe5.mjs';
import { computed, ref, withAsyncContext, withCtx, createVNode, unref, toDisplayString, createTextVNode, openBlock, createBlock, Fragment, renderList, createCommentVNode, isRef, useSSRContext } from 'vue';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-71e93c9c.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './index-dea25161.mjs';
import './index-596a8548.mjs';
import 'vee-validate';
import './Alert-ad006b11.mjs';
import './TransitionTopToBottom-3d1af8ef.mjs';
import './InputOTP-bbb2b053.mjs';
import './useSchema-10fbf818.mjs';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const route = useRoute();
    const slug = computed(() => {
      var _a;
      return (_a = route == null ? void 0 : route.params) == null ? void 0 : _a.slug;
    });
    const { requestOptions } = useRequestOptions();
    const { $user } = useAuth();
    ref(1);
    const showModalRefund = ref(false);
    ref(void 0);
    const {
      data: tourOrderDetail,
      error: errorOrderTour,
      refresh: refreshOrderTour
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "toursOrderDetail",
      () => {
        var _a;
        return $fetch(`/users/${(_a = $user.value) == null ? void 0 : _a.uuid}/tour-orders/${slug.value}`, {
          headers: {
            Accept: "application/json"
          },
          method: "get",
          ...requestOptions
        });
      }
    )), __temp = await __temp, __restore(), __temp);
    console.log(tourOrderDetail.value);
    function showModalRefundFunc(id) {
      showModalRefund.value = !showModalRefund.value;
    }
    useHead({ title: "Order Summary" });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_1;
      const _component_modal = __nuxt_component_3;
      const _component_Verified = __nuxt_component_4;
      _push(`<!--[--><div class="h-28"></div><div class="w-full border-b">`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R, _S, _T, _U, _V, _W, _X, _Y, _Z, __, _$, _aa, _ba;
          if (_push2) {
            _push2(`<div class="flex items-center gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, { to: "/user" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_Icon, {
                    name: "formkit:arrowleft",
                    class: "text-black w-7 h-7"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_Icon, {
                      name: "formkit:arrowleft",
                      class: "text-black w-7 h-7"
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="flex flex-col gap-1"${_scopeId}><p class="text-black text-[18px] font-medium"${_scopeId}>${ssrInterpolate(_ctx.$t("ringkasan-pesanan"))}</p><span${_scopeId}>${ssrInterpolate(_ctx.$t("informasi-lengkap-pesanan"))} #${ssrInterpolate((_b = (_a = unref(tourOrderDetail)) == null ? void 0 : _a.data) == null ? void 0 : _b.uuid)}</span></div></div><div class="py-10"${_scopeId}><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("informasi-pelanggan"))}</div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("nama-pelanggan"))}:</p><p${_scopeId}>${ssrInterpolate((_e = (_d = (_c = unref(tourOrderDetail)) == null ? void 0 : _c.data) == null ? void 0 : _d.user) == null ? void 0 : _e.first_name)}\xA0${ssrInterpolate((_h = (_g = (_f = unref(tourOrderDetail)) == null ? void 0 : _f.data) == null ? void 0 : _g.user) == null ? void 0 : _h.last_name)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Email:</p><p${_scopeId}>${ssrInterpolate((_k = (_j = (_i = unref(tourOrderDetail)) == null ? void 0 : _i.data) == null ? void 0 : _j.user) == null ? void 0 : _k.email)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("nomor-telepon"))}:</p><p${_scopeId}>${ssrInterpolate((_n = (_m = (_l = unref(tourOrderDetail)) == null ? void 0 : _l.data) == null ? void 0 : _m.user) == null ? void 0 : _n.phone)}</p></div></div><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("informasi-pemesanan"))}</div><div class="grid gap-3 md:grid-cols-2"${_scopeId}><div class="flex flex-col gap-1 text-sm"${_scopeId}><p class="text-[#121212] font-semibold"${_scopeId}>Activity Date</p> ${ssrInterpolate((_p = (_o = unref(tourOrderDetail)) == null ? void 0 : _o.data) == null ? void 0 : _p.activity_date)}</div></div><div class="flex flex-col gap-1 text-sm"${_scopeId}><p class="text-[#121212] font-semibold"${_scopeId}>Details :</p><div class=""${_scopeId}><!--[-->`);
            ssrRenderList((_r = (_q = unref(tourOrderDetail)) == null ? void 0 : _q.data) == null ? void 0 : _r.details, (item) => {
              _push2(`<div class="py-4 flex flex-col gap-3 border-b mb-4"${_scopeId}><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Name :</p><p${_scopeId}>${ssrInterpolate(item.name)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Quantity :</p><p${_scopeId}>${ssrInterpolate(item.quantity)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Location Name :</p><p${_scopeId}>${ssrInterpolate(item.location_name)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Price :</p><p${_scopeId}>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(item.price))}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Total Price :</p><p${_scopeId}>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(item.total_price))}</p></div></div>`);
            });
            _push2(`<!--]--></div></div></div><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("payment-information"))}</div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Promo</p><p${_scopeId}>${ssrInterpolate((_t = (_s = unref(tourOrderDetail)) == null ? void 0 : _s.data) == null ? void 0 : _t.promo_amount)}</p></div>`);
            if ((_v = (_u = unref(tourOrderDetail)) == null ? void 0 : _u.data) == null ? void 0 : _v.refund_status) {
              _push2(`<div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Refund status</p><p${_scopeId}>${ssrInterpolate((_x = (_w = unref(tourOrderDetail)) == null ? void 0 : _w.data) == null ? void 0 : _x.refund_status)}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("payment-status"))}</p><p${_scopeId}>${ssrInterpolate((_z = (_y = unref(tourOrderDetail)) == null ? void 0 : _y.data) == null ? void 0 : _z.payment_status)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(_ctx.$t("total-price"))}</p><p${_scopeId}>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))((_B = (_A = unref(tourOrderDetail)) == null ? void 0 : _A.data) == null ? void 0 : _B.total_purchased))}</p></div></div></div><div class="flex items-center justify-end"${_scopeId}><button type="button" class="border-2 shadow-sm rounded-lg py-2 px-4"${_scopeId}><p${_scopeId}>Payment refund</p></button></div>`);
          } else {
            return [
              createVNode("div", { class: "flex items-center gap-4" }, [
                createVNode(_component_NuxtLink, { to: "/user" }, {
                  default: withCtx(() => [
                    createVNode(_component_Icon, {
                      name: "formkit:arrowleft",
                      class: "text-black w-7 h-7"
                    })
                  ]),
                  _: 1
                }),
                createVNode("div", { class: "flex flex-col gap-1" }, [
                  createVNode("p", { class: "text-black text-[18px] font-medium" }, toDisplayString(_ctx.$t("ringkasan-pesanan")), 1),
                  createVNode("span", null, toDisplayString(_ctx.$t("informasi-lengkap-pesanan")) + " #" + toDisplayString((_D = (_C = unref(tourOrderDetail)) == null ? void 0 : _C.data) == null ? void 0 : _D.uuid), 1)
                ])
              ]),
              createVNode("div", { class: "py-10" }, [
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(_ctx.$t("informasi-pelanggan")), 1),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, toDisplayString(_ctx.$t("nama-pelanggan")) + ":", 1),
                    createVNode("p", null, toDisplayString((_G = (_F = (_E = unref(tourOrderDetail)) == null ? void 0 : _E.data) == null ? void 0 : _F.user) == null ? void 0 : _G.first_name) + "\xA0" + toDisplayString((_J = (_I = (_H = unref(tourOrderDetail)) == null ? void 0 : _H.data) == null ? void 0 : _I.user) == null ? void 0 : _J.last_name), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, "Email:"),
                    createVNode("p", null, toDisplayString((_M = (_L = (_K = unref(tourOrderDetail)) == null ? void 0 : _K.data) == null ? void 0 : _L.user) == null ? void 0 : _M.email), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(_ctx.$t("nomor-telepon")) + ":", 1),
                    createVNode("p", null, toDisplayString((_P = (_O = (_N = unref(tourOrderDetail)) == null ? void 0 : _N.data) == null ? void 0 : _O.user) == null ? void 0 : _P.phone), 1)
                  ])
                ]),
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(_ctx.$t("informasi-pemesanan")), 1),
                  createVNode("div", { class: "grid gap-3 md:grid-cols-2" }, [
                    createVNode("div", { class: "flex flex-col gap-1 text-sm" }, [
                      createVNode("p", { class: "text-[#121212] font-semibold" }, "Activity Date"),
                      createTextVNode(" " + toDisplayString((_R = (_Q = unref(tourOrderDetail)) == null ? void 0 : _Q.data) == null ? void 0 : _R.activity_date), 1)
                    ])
                  ]),
                  createVNode("div", { class: "flex flex-col gap-1 text-sm" }, [
                    createVNode("p", { class: "text-[#121212] font-semibold" }, "Details :"),
                    createVNode("div", { class: "" }, [
                      (openBlock(true), createBlock(Fragment, null, renderList((_T = (_S = unref(tourOrderDetail)) == null ? void 0 : _S.data) == null ? void 0 : _T.details, (item) => {
                        return openBlock(), createBlock("div", { class: "py-4 flex flex-col gap-3 border-b mb-4" }, [
                          createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                            createVNode("p", { class: "font-semibold" }, "Name :"),
                            createVNode("p", null, toDisplayString(item.name), 1)
                          ]),
                          createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                            createVNode("p", { class: "font-semibold" }, "Quantity :"),
                            createVNode("p", null, toDisplayString(item.quantity), 1)
                          ]),
                          createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                            createVNode("p", { class: "font-semibold" }, "Location Name :"),
                            createVNode("p", null, toDisplayString(item.location_name), 1)
                          ]),
                          createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                            createVNode("p", { class: "font-semibold" }, "Price :"),
                            createVNode("p", null, toDisplayString(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(item.price)), 1)
                          ]),
                          createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                            createVNode("p", { class: "font-semibold" }, "Total Price :"),
                            createVNode("p", null, toDisplayString(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))(item.total_price)), 1)
                          ])
                        ]);
                      }), 256))
                    ])
                  ])
                ]),
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(_ctx.$t("payment-information")), 1),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, "Promo"),
                    createVNode("p", null, toDisplayString((_V = (_U = unref(tourOrderDetail)) == null ? void 0 : _U.data) == null ? void 0 : _V.promo_amount), 1)
                  ]),
                  ((_X = (_W = unref(tourOrderDetail)) == null ? void 0 : _W.data) == null ? void 0 : _X.refund_status) ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm"
                  }, [
                    createVNode("p", { class: "font-semibold" }, "Refund status"),
                    createVNode("p", null, toDisplayString((_Z = (_Y = unref(tourOrderDetail)) == null ? void 0 : _Y.data) == null ? void 0 : _Z.refund_status), 1)
                  ])) : createCommentVNode("", true),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(_ctx.$t("payment-status")), 1),
                    createVNode("p", null, toDisplayString((_$ = (__ = unref(tourOrderDetail)) == null ? void 0 : __.data) == null ? void 0 : _$.payment_status), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(_ctx.$t("total-price")), 1),
                    createVNode("p", null, toDisplayString(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))((_ba = (_aa = unref(tourOrderDetail)) == null ? void 0 : _aa.data) == null ? void 0 : _ba.total_purchased)), 1)
                  ])
                ])
              ]),
              createVNode("div", { class: "flex items-center justify-end" }, [
                createVNode("button", {
                  type: "button",
                  onClick: ($event) => showModalRefundFunc(),
                  class: "border-2 shadow-sm rounded-lg py-2 px-4"
                }, [
                  createVNode("p", null, "Payment refund")
                ], 8, ["onClick"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_modal, {
        modelValue: unref(showModalRefund),
        "onUpdate:modelValue": ($event) => isRef(showModalRefund) ? showModalRefund.value = $event : null,
        class: "relative w-[90%] sm:w-[60%] lg:w-[40%]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex justify-center items-center flex-col px-2 sm:px-4 lg:px-5 overflow-auto"${_scopeId}><div class="flex flex-col gap-3 lg:gap-5 transition h-full"${_scopeId}><p class="font-semibold text-xl"${_scopeId}>Pengembalian Pembayaran</p><p class="text-[12px] border-b border-gray-500 pb-3"${_scopeId}> Silakan periksa kotak masuk email Anda untuk mendapatkan PIN verifikasi untuk proses pengembalian dana, lalu ketik di kolom di bawah ini. </p></div><div class="w-full"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Verified, null, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex justify-center items-center flex-col px-2 sm:px-4 lg:px-5 overflow-auto" }, [
                createVNode("div", { class: "flex flex-col gap-3 lg:gap-5 transition h-full" }, [
                  createVNode("p", { class: "font-semibold text-xl" }, "Pengembalian Pembayaran"),
                  createVNode("p", { class: "text-[12px] border-b border-gray-500 pb-3" }, " Silakan periksa kotak masuk email Anda untuk mendapatkan PIN verifikasi untuk proses pengembalian dana, lalu ketik di kolom di bawah ini. ")
                ]),
                createVNode("div", { class: "w-full" }, [
                  createVNode(_component_Verified)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/order/order-summary/tour/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-2654f533.mjs.map
