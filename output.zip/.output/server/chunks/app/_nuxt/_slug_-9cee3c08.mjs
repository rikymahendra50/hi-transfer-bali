import { _ as __nuxt_component_0 } from './Container-f78810bd.mjs';
import { d as useRoute, e as useRequestOptions, u as useAuth, f as useI18n, h as useRequestHelper, g as useAsyncData, a as useHead, i as useFetch, _ as __nuxt_component_0$1, k as useNuxtApp } from '../server.mjs';
import __nuxt_component_0$2 from './Icon-0f6314e3.mjs';
import { _ as __nuxt_component_3 } from './Modal-967d83e0.mjs';
import { _ as __nuxt_component_4 } from './Verified-96ada82c.mjs';
import { computed, ref, withAsyncContext, withCtx, createVNode, unref, toDisplayString, openBlock, createBlock, createCommentVNode, isRef, useSSRContext } from 'vue';
import { u as useNotification } from './nofication-1c3cca5e.mjs';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-3cecc2b8.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './index-a61f78d7.mjs';
import './index-596a8548.mjs';
import 'vee-validate';
import './Alert-4fa497cc.mjs';
import './TransitionTopToBottom-a8e40871.mjs';
import './InputOTP-4b85403c.mjs';
import './useSchema-0246d9f0.mjs';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const route = useRoute();
    const slug = computed(() => {
      var _a;
      return (_a = route == null ? void 0 : route.params) == null ? void 0 : _a.slug;
    });
    const { requestOptions } = useRequestOptions();
    const { $user } = useAuth();
    ref(1);
    const { locale, t: $t } = useI18n();
    const showModalRefund = ref(false);
    ref(void 0);
    const { $toast } = useNuxtApp();
    const { loading, message, alertType, setErrorMessage, transformErrors } = useRequestHelper();
    useNotification();
    const {
      data: carsOrderDetail,
      error: errorCars,
      refresh: refreshCar
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "carsOrderDetail",
      () => {
        var _a;
        return $fetch(`/users/${(_a = $user.value) == null ? void 0 : _a.uuid}/car-orders/${slug.value}`, {
          headers: {
            Accept: "application/json"
          },
          method: "get",
          ...requestOptions
        });
      }
    )), __temp = await __temp, __restore(), __temp);
    async function showModalRefundFunc(id) {
      var _a2, _b2, _c2;
      var _a, _b, _c, _d, _e, _f, _g;
      loading.value = true;
      showModalRefund.value = !showModalRefund.value;
      const { data, error } = await useFetch(
        `/users/${$user.value.uuid}/car-orders/${(_a = carsOrderDetail.value.data) == null ? void 0 : _a.uuid}/refund-request`,
        {
          method: "post",
          ...requestOptions
        },
        "$Ss6W4zujzk"
      );
      if (error.value) {
        setErrorMessage((_a2 = (_c = (_b = error.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message) != null ? _a2 : "Something went wrong");
        $toast.error((_b2 = (_e = (_d = error.value) == null ? void 0 : _d.data) == null ? void 0 : _e.message) != null ? _b2 : "Something went wrong. ");
      } else {
        $toast.success(
          (_c2 = (_g = (_f = data.value) == null ? void 0 : _f.data) == null ? void 0 : _g.message) != null ? _c2 : "Sending request refund sucsess"
        );
      }
      loading.value = false;
    }
    function getSuskes(data) {
      showModalRefund.value = data;
      refresh();
    }
    function formatDate(dateString) {
      const date = new Date(dateString);
      return date.toLocaleDateString("en-GB", {
        day: "numeric",
        month: "long",
        year: "numeric"
      });
    }
    useHead({ title: "Order detail car" });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_0$2;
      const _component_modal = __nuxt_component_3;
      const _component_Verified = __nuxt_component_4;
      _push(`<!--[--><div class="h-44 sm:h-28"></div><div class="w-full border-b">`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2;
          var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R, _S, _T, _U, _V, _W, _X, _Y, _Z, __, _$, _aa, _ba, _ca, _da, _ea, _fa, _ga, _ha, _ia, _ja, _ka, _la, _ma, _na, _oa, _pa, _qa, _ra, _sa, _ta, _ua, _va, _wa, _xa, _ya, _za, _Aa, _Ba, _Ca, _Da, _Ea, _Fa, _Ga, _Ha, _Ia, _Ja, _Ka, _La, _Ma, _Na, _Oa, _Pa, _Qa, _Ra, _Sa, _Ta;
          if (_push2) {
            _push2(`<div class="flex items-center gap-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, { to: "/user" }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_Icon, {
                    name: "formkit:arrowleft",
                    class: "text-black w-7 h-7"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_Icon, {
                      name: "formkit:arrowleft",
                      class: "text-black w-7 h-7"
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div class="flex flex-col gap-1"${_scopeId}><p class="text-black text-[18px] font-medium"${_scopeId}>${ssrInterpolate(unref($t)("ringkasan-pesanan"))}</p><span class="text-sm"${_scopeId}>${ssrInterpolate(unref($t)("informasi-lengkap-pesanan"))} #${ssrInterpolate((_b = (_a = unref(carsOrderDetail)) == null ? void 0 : _a.data) == null ? void 0 : _b.uuid)}</span></div></div><div class="py-10"${_scopeId}><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(unref($t)("informasi-pelanggan"))}</div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>${ssrInterpolate(unref($t)("nama-pelanggan"))}:</p><p${_scopeId}>${ssrInterpolate((_e = (_d = (_c = unref(carsOrderDetail)) == null ? void 0 : _c.data) == null ? void 0 : _d.user) == null ? void 0 : _e.first_name)}\xA0${ssrInterpolate((_h = (_g = (_f = unref(carsOrderDetail)) == null ? void 0 : _f.data) == null ? void 0 : _g.user) == null ? void 0 : _h.last_name)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Email:</p><p${_scopeId}>${ssrInterpolate((_k = (_j = (_i = unref(carsOrderDetail)) == null ? void 0 : _i.data) == null ? void 0 : _j.user) == null ? void 0 : _k.email)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(unref($t)("nomor-telepon"))}:</p><p${_scopeId}>${ssrInterpolate((_n = (_m = (_l = unref(carsOrderDetail)) == null ? void 0 : _l.data) == null ? void 0 : _m.user) == null ? void 0 : _n.phone)}</p></div></div><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(unref($t)("informasi-pemesanan"))}</div><div class="grid gap-3 md:grid-cols-2"${_scopeId}><div class="flex flex-col gap-1 text-sm"${_scopeId}><p class="text-[#121212] font-semibold"${_scopeId}>${ssrInterpolate(unref($t)("penjeputan"))}</p><p class="font-normal"${_scopeId}>${ssrInterpolate((_p = (_o = unref(carsOrderDetail)) == null ? void 0 : _o.data) == null ? void 0 : _p.details[0].pickup_name)}</p><p class="font-normal text-[#16161697]"${_scopeId}>${ssrInterpolate((_r = (_q = unref(carsOrderDetail)) == null ? void 0 : _q.data) == null ? void 0 : _r.details[0].pickup_address)}</p><p class="font-normal text-[#16161697]"${_scopeId}>${ssrInterpolate((_a2 = formatDate(
              (_u = (_t = (_s = unref(carsOrderDetail)) == null ? void 0 : _s.data) == null ? void 0 : _t.details[0]) == null ? void 0 : _u.activity_date
            )) != null ? _a2 : "")}</p></div><div class="flex flex-col gap-1 text-sm"${_scopeId}><p class="text-[#121212] font-semibold"${_scopeId}>${ssrInterpolate(unref($t)("pengantaran"))}</p><p class="font-normal"${_scopeId}>${ssrInterpolate((_w = (_v = unref(carsOrderDetail)) == null ? void 0 : _v.data) == null ? void 0 : _w.details[0].destination_name)}</p><p class="font-normal text-[#16161697]"${_scopeId}>${ssrInterpolate((_y = (_x = unref(carsOrderDetail)) == null ? void 0 : _x.data) == null ? void 0 : _y.details[0].destination_address)}</p><p class="font-normal text-[#16161697]"${_scopeId}>${ssrInterpolate((_b2 = formatDate(
              (_B = (_A = (_z = unref(carsOrderDetail)) == null ? void 0 : _z.data) == null ? void 0 : _A.details[1]) == null ? void 0 : _B.activity_date
            )) != null ? _b2 : "")}</p></div></div>`);
            if ((_D = (_C = unref(carsOrderDetail)) == null ? void 0 : _C.data) == null ? void 0 : _D.details) {
              _push2(`<div${_scopeId}>`);
              if (((_F = (_E = unref(carsOrderDetail)) == null ? void 0 : _E.data) == null ? void 0 : _F.details.length) > 1) {
                _push2(`<div class="bg-primary py-2 px-4 rounded-xl text-white w-fit"${_scopeId}><p${_scopeId}>Round trip</p></div>`);
              } else if (((_H = (_G = unref(carsOrderDetail)) == null ? void 0 : _G.data) == null ? void 0 : _H.details.length) == 1) {
                _push2(`<div class="bg-primary py-2 px-4 rounded-xl text-white w-fit"${_scopeId}><p${_scopeId}>One way</p></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="px-5 py-4 flex flex-col gap-3 border-b"${_scopeId}><div class="text-gray-500 uppercase text-sm"${_scopeId}>${ssrInterpolate(unref($t)("payment-information"))}</div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>${ssrInterpolate(unref($t)("payment-method"))}</p><p${_scopeId}>${ssrInterpolate((_J = (_I = unref(carsOrderDetail)) == null ? void 0 : _I.data) == null ? void 0 : _J.payment_method)}</p></div>`);
            if ((_L = (_K = unref(carsOrderDetail)) == null ? void 0 : _K.data) == null ? void 0 : _L.refund_status) {
              _push2(`<div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold"${_scopeId}>Refund status</p><p${_scopeId}>${ssrInterpolate((_N = (_M = unref(carsOrderDetail)) == null ? void 0 : _M.data) == null ? void 0 : _N.refund_status)}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(unref($t)("payment-status"))}</p><p${_scopeId}>${ssrInterpolate((_P = (_O = unref(carsOrderDetail)) == null ? void 0 : _O.data) == null ? void 0 : _P.payment_status)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"${_scopeId}><p class="font-semibold text-sm"${_scopeId}>${ssrInterpolate(unref($t)("total-price"))}</p><p${_scopeId}>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))((_R = (_Q = unref(carsOrderDetail)) == null ? void 0 : _Q.data) == null ? void 0 : _R.total_purchased))}</p></div></div></div><div class="flex items-center justify-end gap-2"${_scopeId}>`);
            if (((_T = (_S = unref(carsOrderDetail)) == null ? void 0 : _S.data) == null ? void 0 : _T.payment_status) === "paid") {
              _push2(`<button type="button" class="border-2 shadow-sm rounded-lg py-2 px-4 btn bg-white"${_scopeId}><p${_scopeId}>Cancel</p></button>`);
            } else {
              _push2(`<!---->`);
            }
            if (((_V = (_U = unref(carsOrderDetail)) == null ? void 0 : _U.data) == null ? void 0 : _V.payment_status) === "pending") {
              _push2(`<a${ssrRenderAttr("href", (_X = (_W = unref(carsOrderDetail)) == null ? void 0 : _W.data) == null ? void 0 : _X.payment_url)} target="_blank" class="border-2 shadow-sm rounded-lg py-2 px-4 btn bg-white"${_scopeId}><p${_scopeId}>Payment url</p></a>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex items-center gap-4" }, [
                createVNode(_component_NuxtLink, { to: "/user" }, {
                  default: withCtx(() => [
                    createVNode(_component_Icon, {
                      name: "formkit:arrowleft",
                      class: "text-black w-7 h-7"
                    })
                  ]),
                  _: 1
                }),
                createVNode("div", { class: "flex flex-col gap-1" }, [
                  createVNode("p", { class: "text-black text-[18px] font-medium" }, toDisplayString(unref($t)("ringkasan-pesanan")), 1),
                  createVNode("span", { class: "text-sm" }, toDisplayString(unref($t)("informasi-lengkap-pesanan")) + " #" + toDisplayString((_Z = (_Y = unref(carsOrderDetail)) == null ? void 0 : _Y.data) == null ? void 0 : _Z.uuid), 1)
                ])
              ]),
              createVNode("div", { class: "py-10" }, [
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(unref($t)("informasi-pelanggan")), 1),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, toDisplayString(unref($t)("nama-pelanggan")) + ":", 1),
                    createVNode("p", null, toDisplayString((_aa = (_$ = (__ = unref(carsOrderDetail)) == null ? void 0 : __.data) == null ? void 0 : _$.user) == null ? void 0 : _aa.first_name) + "\xA0" + toDisplayString((_da = (_ca = (_ba = unref(carsOrderDetail)) == null ? void 0 : _ba.data) == null ? void 0 : _ca.user) == null ? void 0 : _da.last_name), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, "Email:"),
                    createVNode("p", null, toDisplayString((_ga = (_fa = (_ea = unref(carsOrderDetail)) == null ? void 0 : _ea.data) == null ? void 0 : _fa.user) == null ? void 0 : _ga.email), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(unref($t)("nomor-telepon")) + ":", 1),
                    createVNode("p", null, toDisplayString((_ja = (_ia = (_ha = unref(carsOrderDetail)) == null ? void 0 : _ha.data) == null ? void 0 : _ia.user) == null ? void 0 : _ja.phone), 1)
                  ])
                ]),
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(unref($t)("informasi-pemesanan")), 1),
                  createVNode("div", { class: "grid gap-3 md:grid-cols-2" }, [
                    createVNode("div", { class: "flex flex-col gap-1 text-sm" }, [
                      createVNode("p", { class: "text-[#121212] font-semibold" }, toDisplayString(unref($t)("penjeputan")), 1),
                      createVNode("p", { class: "font-normal" }, toDisplayString((_la = (_ka = unref(carsOrderDetail)) == null ? void 0 : _ka.data) == null ? void 0 : _la.details[0].pickup_name), 1),
                      createVNode("p", { class: "font-normal text-[#16161697]" }, toDisplayString((_na = (_ma = unref(carsOrderDetail)) == null ? void 0 : _ma.data) == null ? void 0 : _na.details[0].pickup_address), 1),
                      createVNode("p", { class: "font-normal text-[#16161697]" }, toDisplayString((_c2 = formatDate(
                        (_qa = (_pa = (_oa = unref(carsOrderDetail)) == null ? void 0 : _oa.data) == null ? void 0 : _pa.details[0]) == null ? void 0 : _qa.activity_date
                      )) != null ? _c2 : ""), 1)
                    ]),
                    createVNode("div", { class: "flex flex-col gap-1 text-sm" }, [
                      createVNode("p", { class: "text-[#121212] font-semibold" }, toDisplayString(unref($t)("pengantaran")), 1),
                      createVNode("p", { class: "font-normal" }, toDisplayString((_sa = (_ra = unref(carsOrderDetail)) == null ? void 0 : _ra.data) == null ? void 0 : _sa.details[0].destination_name), 1),
                      createVNode("p", { class: "font-normal text-[#16161697]" }, toDisplayString((_ua = (_ta = unref(carsOrderDetail)) == null ? void 0 : _ta.data) == null ? void 0 : _ua.details[0].destination_address), 1),
                      createVNode("p", { class: "font-normal text-[#16161697]" }, toDisplayString((_d2 = formatDate(
                        (_xa = (_wa = (_va = unref(carsOrderDetail)) == null ? void 0 : _va.data) == null ? void 0 : _wa.details[1]) == null ? void 0 : _xa.activity_date
                      )) != null ? _d2 : ""), 1)
                    ])
                  ]),
                  ((_za = (_ya = unref(carsOrderDetail)) == null ? void 0 : _ya.data) == null ? void 0 : _za.details) ? (openBlock(), createBlock("div", { key: 0 }, [
                    ((_Ba = (_Aa = unref(carsOrderDetail)) == null ? void 0 : _Aa.data) == null ? void 0 : _Ba.details.length) > 1 ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "bg-primary py-2 px-4 rounded-xl text-white w-fit"
                    }, [
                      createVNode("p", null, "Round trip")
                    ])) : ((_Da = (_Ca = unref(carsOrderDetail)) == null ? void 0 : _Ca.data) == null ? void 0 : _Da.details.length) == 1 ? (openBlock(), createBlock("div", {
                      key: 1,
                      class: "bg-primary py-2 px-4 rounded-xl text-white w-fit"
                    }, [
                      createVNode("p", null, "One way")
                    ])) : createCommentVNode("", true)
                  ])) : createCommentVNode("", true)
                ]),
                createVNode("div", { class: "px-5 py-4 flex flex-col gap-3 border-b" }, [
                  createVNode("div", { class: "text-gray-500 uppercase text-sm" }, toDisplayString(unref($t)("payment-information")), 1),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold" }, toDisplayString(unref($t)("payment-method")), 1),
                    createVNode("p", null, toDisplayString((_Fa = (_Ea = unref(carsOrderDetail)) == null ? void 0 : _Ea.data) == null ? void 0 : _Fa.payment_method), 1)
                  ]),
                  ((_Ha = (_Ga = unref(carsOrderDetail)) == null ? void 0 : _Ga.data) == null ? void 0 : _Ha.refund_status) ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm"
                  }, [
                    createVNode("p", { class: "font-semibold" }, "Refund status"),
                    createVNode("p", null, toDisplayString((_Ja = (_Ia = unref(carsOrderDetail)) == null ? void 0 : _Ia.data) == null ? void 0 : _Ja.refund_status), 1)
                  ])) : createCommentVNode("", true),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(unref($t)("payment-status")), 1),
                    createVNode("p", null, toDisplayString((_La = (_Ka = unref(carsOrderDetail)) == null ? void 0 : _Ka.data) == null ? void 0 : _La.payment_status), 1)
                  ]),
                  createVNode("div", { class: "grid grid-cols-2 w-full md:w-[40%] items-center text-sm" }, [
                    createVNode("p", { class: "font-semibold text-sm" }, toDisplayString(unref($t)("total-price")), 1),
                    createVNode("p", null, toDisplayString(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))((_Na = (_Ma = unref(carsOrderDetail)) == null ? void 0 : _Ma.data) == null ? void 0 : _Na.total_purchased)), 1)
                  ])
                ])
              ]),
              createVNode("div", { class: "flex items-center justify-end gap-2" }, [
                ((_Pa = (_Oa = unref(carsOrderDetail)) == null ? void 0 : _Oa.data) == null ? void 0 : _Pa.payment_status) === "paid" ? (openBlock(), createBlock("button", {
                  key: 0,
                  type: "button",
                  onClick: ($event) => showModalRefundFunc(),
                  class: "border-2 shadow-sm rounded-lg py-2 px-4 btn bg-white"
                }, [
                  createVNode("p", null, "Cancel")
                ], 8, ["onClick"])) : createCommentVNode("", true),
                ((_Ra = (_Qa = unref(carsOrderDetail)) == null ? void 0 : _Qa.data) == null ? void 0 : _Ra.payment_status) === "pending" ? (openBlock(), createBlock("a", {
                  key: 1,
                  href: (_Ta = (_Sa = unref(carsOrderDetail)) == null ? void 0 : _Sa.data) == null ? void 0 : _Ta.payment_url,
                  target: "_blank",
                  class: "border-2 shadow-sm rounded-lg py-2 px-4 btn bg-white"
                }, [
                  createVNode("p", null, "Payment url")
                ], 8, ["href"])) : createCommentVNode("", true)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_modal, {
        modelValue: unref(showModalRefund),
        "onUpdate:modelValue": ($event) => isRef(showModalRefund) ? showModalRefund.value = $event : null,
        class: "relative w-[90%] sm:w-[60%] lg:w-[40%]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b;
          if (_push2) {
            _push2(`<div class="flex justify-center items-center flex-col px-2 sm:px-4 lg:px-5 overflow-auto"${_scopeId}><div class="flex flex-col gap-3 lg:gap-5 transition h-full"${_scopeId}><p class="font-semibold text-xl"${_scopeId}>${ssrInterpolate(unref($t)("pengembalian-pembayaran"))}</p><p class="text-[12px] border-b border-gray-500 pb-3"${_scopeId}>${ssrInterpolate(unref($t)("silakan-periksa-kotak-masuk"))}</p></div><div class="w-full"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Verified, {
              uuidData: (_a = unref(carsOrderDetail).data) == null ? void 0 : _a.uuid,
              onSukses: getSuskes,
              carOrTour: "car-orders"
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex justify-center items-center flex-col px-2 sm:px-4 lg:px-5 overflow-auto" }, [
                createVNode("div", { class: "flex flex-col gap-3 lg:gap-5 transition h-full" }, [
                  createVNode("p", { class: "font-semibold text-xl" }, toDisplayString(unref($t)("pengembalian-pembayaran")), 1),
                  createVNode("p", { class: "text-[12px] border-b border-gray-500 pb-3" }, toDisplayString(unref($t)("silakan-periksa-kotak-masuk")), 1)
                ]),
                createVNode("div", { class: "w-full" }, [
                  createVNode(_component_Verified, {
                    uuidData: (_b = unref(carsOrderDetail).data) == null ? void 0 : _b.uuid,
                    onSukses: getSuskes,
                    carOrTour: "car-orders"
                  }, null, 8, ["uuidData"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/user/order/order-summary/car/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-9cee3c08.mjs.map
