import { _ as __nuxt_component_0 } from './TransitionTopToBottom-a8e40871.mjs';
import __nuxt_component_1 from './Icon-ab561e52.mjs';
import { defineComponent, ref, computed, watch, withCtx, unref, openBlock, createBlock, createVNode, toDisplayString, createCommentVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderClass, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Alert",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      type: String
    },
    type: {
      type: String,
      validate(value) {
        return ["success", "error"].includes(value);
      }
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit }) {
    const props = __props;
    const showAlert = ref(false);
    const message = computed({
      get() {
        return props.modelValue;
      },
      set(value) {
        emit("update:modelValue", value);
      }
    });
    const alertType = computed(() => {
      if (props.type === "success") {
        return "alert-success";
      }
      return "alert-error";
    });
    watch(message, (value) => {
      if (value && !showAlert.value) {
        showAlert.value = true;
        setTimeout(closeAlert, 5e3);
      }
    });
    function closeAlert() {
      message.value = "";
      showAlert.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TransitionTopToBottom = __nuxt_component_0;
      const _component_Icon = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_TransitionTopToBottom, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (unref(showAlert)) {
              _push2(`<div class="${ssrRenderClass([[unref(alertType)], "alert w-full flex"])}"${_scopeId}><div class="w-full flex flex-col flex-grow flex-shrink"${_scopeId}><span class="max-w-[300px] whitespace-pre-wrap leading-4 tracking-normal text-left"${_scopeId}>${ssrInterpolate(unref(message))}</span></div><div class="flex-none"${_scopeId}><div class="w-6 h-6 p-0.5 flex items-center justify-center hover:bg-white rounded-full transition-all duration-300" role="button"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, { name: "i-heroicons-x-circle" }, null, _parent2, _scopeId));
              _push2(`</div></div></div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              unref(showAlert) ? (openBlock(), createBlock("div", {
                key: 0,
                class: ["alert w-full flex", [unref(alertType)]]
              }, [
                createVNode("div", { class: "w-full flex flex-col flex-grow flex-shrink" }, [
                  createVNode("span", { class: "max-w-[300px] whitespace-pre-wrap leading-4 tracking-normal text-left" }, toDisplayString(unref(message)), 1)
                ]),
                createVNode("div", { class: "flex-none" }, [
                  createVNode("div", {
                    class: "w-6 h-6 p-0.5 flex items-center justify-center hover:bg-white rounded-full transition-all duration-300",
                    onClick: closeAlert,
                    role: "button"
                  }, [
                    createVNode(_component_Icon, { name: "i-heroicons-x-circle" })
                  ])
                ])
              ], 2)) : createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Alert.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=Alert-f7c32dd8.mjs.map
