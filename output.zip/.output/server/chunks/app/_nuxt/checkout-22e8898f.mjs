import { _ as __nuxt_component_0 } from './Container-f78810bd.mjs';
import { _ as _sfc_main$4 } from './SelectedCard-f7c91828.mjs';
import { useSSRContext, ref, withCtx, unref, createVNode, toDisplayString, defineComponent, mergeProps } from 'vue';
import { ssrRenderComponent, ssrInterpolate, ssrIncludeBooleanAttr, ssrRenderAttrs, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import { u as useTourForm } from './useTourStore-4a6f0bac.mjs';
import { a as useHead } from '../server.mjs';
import './nofication-1c3cca5e.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "ParticipantCard",
  __ssrInlineRender: true,
  props: { dataParticipant: { type: Array } },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="grid grid-cols-1 divide-y border rounded-xl"><!--[-->`);
      ssrRenderList(__props.dataParticipant, (item) => {
        _push(`<div class="p-4"><div class="flex flex-col lg:flex-row lg:justify-between item-center"><div class="text-lg font-semibold flex items-center">${ssrInterpolate(item.name)}</div><div class="flex flex-row justify-between space-x-4"><div class="flex flex-col space-y-1"><div class="text-xs text-zinc-400">Kebangsaan</div><div>${ssrInterpolate(item.nationality)}</div></div></div></div></div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/ParticipantCard.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "OrdererCard",
  __ssrInlineRender: true,
  props: {
    name: {
      type: String
    },
    email: {
      type: String
    },
    phone: {
      type: String
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="space-y-4 p-4 border rounded-xl"><div class="flex flex-col lg:flex-row lg:justify-between item-center"><div class="text-lg font-semibold flex items-center">${ssrInterpolate(__props.name)}</div><div class="flex flex-col lg:flex-row space-y-4 lg:space-y-0 space-x-0 lg:space-x-4"><div class="flex flex-col space-y-1"><div class="text-xs text-zinc-400">Email</div><div>${ssrInterpolate(__props.email)}</div></div><div class="flex flex-col space-y-1"><div class="text-xs text-zinc-400">Nomor Telepon</div><div>${ssrInterpolate(__props.phone)}</div></div></div></div></div></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/OrdererCard.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "DetailCheckoutInformation",
  __ssrInlineRender: true,
  props: {
    name: {
      type: String
    },
    desk: {
      type: String
    },
    image: {
      type: String
    },
    dataListPrice: {
      type: Array
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "space-y-4 border rounded-xl p-4 divide-y" }, _attrs))}><div class="grid grid-cols-[100px_1fr] space-x-2"><div class="rounded-xl overflow-hidden w-[100px] h-[100px]"><img${ssrRenderAttr("src", __props.image)} alt="" class="w-full h-full object-cover"></div><div class="flex flex-col justify-between space-y-4"><div class="text-lg font-semibold">${ssrInterpolate(__props.name)}</div><div><div class="text-zinc-400 text-xs">${ssrInterpolate(_ctx.$t("destinasi"))}</div><div class="text-sm">${ssrInterpolate(__props.desk)}</div></div></div></div><div class=""><div class="font-semibold pt-2 pb-4">${ssrInterpolate(_ctx.$t("detail-harga"))}</div><!--[-->`);
      ssrRenderList(__props.dataListPrice, (item) => {
        var _a;
        _push(`<div class="flex justify-between items-center pt-3 border-t"><div class="font-semibold">${ssrInterpolate(item.name)}</div><div>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))((_a = item == null ? void 0 : item.totalItemPrice) == null ? void 0 : _a.toString()))}</div></div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Tour/DetailCheckoutInformation.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "checkout",
  __ssrInlineRender: true,
  setup(__props) {
    ref({
      sort: ""
    });
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedTourData,
      clearSavedTourData,
      loading
    } = useTourForm({
      callback: () => {
        console.log("Form has been submitted!");
      }
    });
    function onSubmit() {
      console.log("ini adalah dataForm final", dataForm.value);
      saveFormData();
      submitForm();
    }
    useHead({
      title: "Checkout"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_TourSelectedCard = _sfc_main$4;
      const _component_TourParticipantCard = _sfc_main$3;
      const _component_TourOrdererCard = _sfc_main$2;
      const _component_TourDetailCheckoutInformation = _sfc_main$1;
      _push(`<!--[--><div class="h-28"></div>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d;
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 divide-x-2"${_scopeId}><div class="space-y-6 py-4"${_scopeId}><h3 class="text-2xl font-semibold text-primary-dark"${_scopeId}>${ssrInterpolate(_ctx.$t("pesanan-anda"))}</h3><div class="space-y-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_TourSelectedCard, {
              image: unref(dataForm).tour_image,
              name: unref(dataForm).tour_name,
              desk: unref(dataForm).list_location_string
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="p-4"${_scopeId}><div class="flex flex-col space-y-6"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><div class="text-2xl font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("data-peserta"))}</div></div><div class="space-y-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_TourParticipantCard, {
              dataParticipant: unref(dataForm).forms
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-between items-center"${_scopeId}><div class="text-2xl font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("data-pemesan"))}</div></div><div class="space-y-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_TourOrdererCard, {
              name: unref(dataForm).name,
              email: unref(dataForm).email,
              phone: unref(dataForm).phone
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-between items-center"${_scopeId}><div class="text-2xl font-semibold"${_scopeId}>${ssrInterpolate(_ctx.$t("detail-harga"))}</div></div><div class="space-y-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_TourDetailCheckoutInformation, {
              name: unref(dataForm).tour_name,
              desk: unref(dataForm).list_location_string,
              image: unref(dataForm).tour_image,
              dataListPrice: unref(dataForm).variants
            }, null, _parent2, _scopeId));
            _push2(`<div${_scopeId}><div class="space-y-4 p-4 border rounded-xl"${_scopeId}><div class="flex flex-col lg:flex-row lg:justify-between item-center"${_scopeId}><div${_scopeId}>${ssrInterpolate(_ctx.$t("yang-harus-kamu-bayar"))}</div><div class="text-lg font-semibold text-primary"${_scopeId}>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))((_b = (_a = unref(dataForm)) == null ? void 0 : _a.price) == null ? void 0 : _b.toString()))}</div></div></div></div></div><div class="flex items-end justify-end"${_scopeId}><button type="submit" class="btn btn-md bg-primary text-white"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""}${_scopeId}><p${_scopeId}>${ssrInterpolate(_ctx.$t("pesan-dan-bayar"))}</p></button></div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 divide-x-2" }, [
                createVNode("div", { class: "space-y-6 py-4" }, [
                  createVNode("h3", { class: "text-2xl font-semibold text-primary-dark" }, toDisplayString(_ctx.$t("pesanan-anda")), 1),
                  createVNode("div", { class: "space-y-4" }, [
                    createVNode(_component_TourSelectedCard, {
                      image: unref(dataForm).tour_image,
                      name: unref(dataForm).tour_name,
                      desk: unref(dataForm).list_location_string
                    }, null, 8, ["image", "name", "desk"])
                  ])
                ]),
                createVNode("div", { class: "p-4" }, [
                  createVNode("div", { class: "flex flex-col space-y-6" }, [
                    createVNode("div", { class: "flex justify-between items-center" }, [
                      createVNode("div", { class: "text-2xl font-semibold" }, toDisplayString(_ctx.$t("data-peserta")), 1)
                    ]),
                    createVNode("div", { class: "space-y-4" }, [
                      createVNode(_component_TourParticipantCard, {
                        dataParticipant: unref(dataForm).forms
                      }, null, 8, ["dataParticipant"])
                    ]),
                    createVNode("div", { class: "flex justify-between items-center" }, [
                      createVNode("div", { class: "text-2xl font-semibold" }, toDisplayString(_ctx.$t("data-pemesan")), 1)
                    ]),
                    createVNode("div", { class: "space-y-4" }, [
                      createVNode(_component_TourOrdererCard, {
                        name: unref(dataForm).name,
                        email: unref(dataForm).email,
                        phone: unref(dataForm).phone
                      }, null, 8, ["name", "email", "phone"])
                    ]),
                    createVNode("div", { class: "flex justify-between items-center" }, [
                      createVNode("div", { class: "text-2xl font-semibold" }, toDisplayString(_ctx.$t("detail-harga")), 1)
                    ]),
                    createVNode("div", { class: "space-y-4" }, [
                      createVNode(_component_TourDetailCheckoutInformation, {
                        name: unref(dataForm).tour_name,
                        desk: unref(dataForm).list_location_string,
                        image: unref(dataForm).tour_image,
                        dataListPrice: unref(dataForm).variants
                      }, null, 8, ["name", "desk", "image", "dataListPrice"]),
                      createVNode("div", null, [
                        createVNode("div", { class: "space-y-4 p-4 border rounded-xl" }, [
                          createVNode("div", { class: "flex flex-col lg:flex-row lg:justify-between item-center" }, [
                            createVNode("div", null, toDisplayString(_ctx.$t("yang-harus-kamu-bayar")), 1),
                            createVNode("div", { class: "text-lg font-semibold text-primary" }, toDisplayString(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))((_d = (_c = unref(dataForm)) == null ? void 0 : _c.price) == null ? void 0 : _d.toString())), 1)
                          ])
                        ])
                      ])
                    ]),
                    createVNode("div", {
                      class: "flex items-end justify-end",
                      onClick: onSubmit
                    }, [
                      createVNode("button", {
                        type: "submit",
                        class: "btn btn-md bg-primary text-white",
                        disabled: unref(loading)
                      }, [
                        createVNode("p", null, toDisplayString(_ctx.$t("pesan-dan-bayar")), 1)
                      ], 8, ["disabled"])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tours/booking/checkout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=checkout-22e8898f.mjs.map
