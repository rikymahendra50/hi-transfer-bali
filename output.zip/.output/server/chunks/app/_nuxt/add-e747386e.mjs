import { _ as __nuxt_component_0 } from './TitleBack-5f778ce2.mjs';
import { _ as __nuxt_component_1 } from './Driver-1e9d4758.mjs';
import { e as useRequestOptions, a as useHead } from '../server.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './Icon-ab561e52.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'vee-validate';
import './TextFieldWLabel-0de16bf1.mjs';
import './useSchema-27c20d48.mjs';
import 'zod';
import '@vee-validate/zod';
import './useDriver-a263cd04.mjs';
import './nofication-1c3cca5e.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "add",
  __ssrInlineRender: true,
  setup(__props) {
    useRequestOptions();
    useHead({
      title: "Add Driver"
    });
    useHead({
      title: "Add Driver"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_TitleBack = __nuxt_component_0;
      const _component_UIFormDriver = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "px-5 py-6 md:px-10 md:py-10" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_TitleBack, {
        link: "/admin/driver",
        title: "Tambah Driver Baru"
      }, null, _parent));
      _push(ssrRenderComponent(_component_UIFormDriver, { buttonTitle: "Tambah Driver" }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/driver/add.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=add-e747386e.mjs.map
