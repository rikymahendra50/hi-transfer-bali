import { _ as __nuxt_component_0 } from './Container-f78810bd.mjs';
import { _ as _sfc_main$1 } from './Btn-577fa59f.mjs';
import { _ as _sfc_main$2 } from './MGroup-56a6a0a6.mjs';
import { _ as _sfc_main$3 } from './MSelect-8e6f95b5.mjs';
import { _ as __nuxt_component_4 } from './Card-016c911f.mjs';
import { _ as __nuxt_component_7 } from './Empty-bbf16402.mjs';
import { ref, watch, withCtx, unref, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, Fragment, renderList, useSSRContext } from 'vue';
import { d as useRoute, b as useRouter, e as useRequestOptions, f as useI18n, g as useAsyncData, a as useHead } from '../server.mjs';
import { u as useTourForm } from './useTourStore-4a6f0bac.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import 'clsx';
import './TransitionX-601819e8.mjs';
import 'vee-validate';
import './FormatMoneyDash-4b79c187.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './nofication-1c3cca5e.mjs';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useRoute();
    const router = useRouter();
    const { requestOptions } = useRequestOptions();
    const { locale, t: $t } = useI18n();
    ref();
    const selectedLocation = ref();
    const dataT = ref();
    const filter = ref({ sort: "" });
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedTourData,
      clearSavedTourData
    } = useTourForm({
      callback: () => {
        console.log("Form has been submitted!");
      }
    });
    watch([() => filter.value.sort, selectedLocation], fetchData);
    async function fetchData() {
      const { data, error, refresh } = await useAsyncData(
        "tours",
        () => $fetch(
          `/tours?sort=${filter.value.sort}&lang=${locale.value}&filter[location_id]=${selectedLocation.value}`,
          {
            headers: {
              Accept: "aplication/json"
            },
            method: "get",
            ...requestOptions
          }
        )
      );
      dataT.value = data.value;
    }
    function goToHomePage() {
      clearSavedTourData();
      router.push({ path: "/?tours" });
    }
    useHead({
      title: "Tours",
      meta: [
        {
          name: "description",
          content: "Safe and Comfortable Transfer in Bali. A fleet of modern vehicles and experienced drivers are ready to take you wherever you want."
        }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_UIBtn = _sfc_main$1;
      const _component_UIFormMGroup = _sfc_main$2;
      const _component_UIFormMSelect = _sfc_main$3;
      const _component_TourCard = __nuxt_component_4;
      const _component_Empty = __nuxt_component_7;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="h-28"></div><div class="w-full border-b">`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              onClick: ($event) => goToHomePage(),
              variant: "primary",
              outlined: "",
              class: "whitespace-nowrap"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref($t)("kembali-ke-beranda"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref($t)("kembali-ke-beranda")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="w-full"${_scopeId}><div class="flex flex-col lg:flex-row space-y-1 lg:space-y-0 lg:space-x-4 text-lg lg:text-xl font-semibold"${_scopeId}><div class="text-center"${_scopeId}>${ssrInterpolate(unref(dataForm).location_name)}</div></div><div class="text-zinc-400 text-sm whitespace-nowrap text-center lg:text-left"${_scopeId}>${ssrInterpolate(unref(dataForm).activity_date)}</div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full" }, [
                createVNode("div", null, [
                  createVNode(_component_UIBtn, {
                    onClick: ($event) => goToHomePage(),
                    variant: "primary",
                    outlined: "",
                    class: "whitespace-nowrap"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref($t)("kembali-ke-beranda")), 1)
                    ]),
                    _: 1
                  }, 8, ["onClick"])
                ]),
                createVNode("div", { class: "w-full" }, [
                  createVNode("div", { class: "flex flex-col lg:flex-row space-y-1 lg:space-y-0 lg:space-x-4 text-lg lg:text-xl font-semibold" }, [
                    createVNode("div", { class: "text-center" }, toDisplayString(unref(dataForm).location_name), 1)
                  ]),
                  createVNode("div", { class: "text-zinc-400 text-sm whitespace-nowrap text-center lg:text-left" }, toDisplayString(unref(dataForm).activity_date), 1)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
          if (_push2) {
            _push2(`<div class="flex flex-col space-y-6 mt-4"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><div${_scopeId}>${ssrInterpolate(unref($t)("menampilkan-paket-tur", { number: (_b = (_a = unref(dataT)) == null ? void 0 : _a.meta) == null ? void 0 : _b.total }))}</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIFormMGroup, {
              name: "sort",
              label: unref($t)("urut-berdasarkan")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_UIFormMSelect, {
                    modelValue: unref(filter).sort,
                    "onUpdate:modelValue": ($event) => unref(filter).sort = $event,
                    name: "sort",
                    class: true
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<option value=""${_scopeId3}>${ssrInterpolate(unref($t)("semua"))}</option><option value="price"${_scopeId3}>${ssrInterpolate(unref($t)("murah-ke-mahal"))}</option><option value="-price"${_scopeId3}>${ssrInterpolate(unref($t)("mahal-ke-murah"))}</option><option value="recomended"${_scopeId3}>${ssrInterpolate(unref($t)("rekomendasi"))}</option>`);
                      } else {
                        return [
                          createVNode("option", { value: "" }, toDisplayString(unref($t)("semua")), 1),
                          createVNode("option", { value: "price" }, toDisplayString(unref($t)("murah-ke-mahal")), 1),
                          createVNode("option", { value: "-price" }, toDisplayString(unref($t)("mahal-ke-murah")), 1),
                          createVNode("option", { value: "recomended" }, toDisplayString(unref($t)("rekomendasi")), 1)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_UIFormMSelect, {
                      modelValue: unref(filter).sort,
                      "onUpdate:modelValue": ($event) => unref(filter).sort = $event,
                      name: "sort",
                      class: true
                    }, {
                      default: withCtx(() => [
                        createVNode("option", { value: "" }, toDisplayString(unref($t)("semua")), 1),
                        createVNode("option", { value: "price" }, toDisplayString(unref($t)("murah-ke-mahal")), 1),
                        createVNode("option", { value: "-price" }, toDisplayString(unref($t)("mahal-ke-murah")), 1),
                        createVNode("option", { value: "recomended" }, toDisplayString(unref($t)("rekomendasi")), 1)
                      ]),
                      _: 1
                    }, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div${_scopeId}>`);
            if (((_d = (_c = unref(dataT)) == null ? void 0 : _c.data) == null ? void 0 : _d.length) > 0) {
              _push2(`<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4"${_scopeId}><!--[-->`);
              ssrRenderList((_e = unref(dataT)) == null ? void 0 : _e.data, (item) => {
                var _a2;
                _push2(ssrRenderComponent(_component_TourCard, {
                  key: item.id,
                  id: item.id,
                  description: item.locations,
                  price: item.price,
                  name: item.name,
                  image: (_a2 = item.thumbnail_image) == null ? void 0 : _a2.image,
                  slug: "/tours/" + item.slug
                }, null, _parent2, _scopeId));
              });
              _push2(`<!--]--></div>`);
            } else {
              _push2(ssrRenderComponent(_component_Empty, {
                description: unref($t)("paket-tur-tidak-ditemukan")
              }, null, _parent2, _scopeId));
            }
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col space-y-6 mt-4" }, [
                createVNode("div", { class: "flex justify-between items-center" }, [
                  createVNode("div", null, toDisplayString(unref($t)("menampilkan-paket-tur", { number: (_g = (_f = unref(dataT)) == null ? void 0 : _f.meta) == null ? void 0 : _g.total })), 1),
                  createVNode("div", null, [
                    createVNode(_component_UIFormMGroup, {
                      name: "sort",
                      label: unref($t)("urut-berdasarkan")
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_UIFormMSelect, {
                          modelValue: unref(filter).sort,
                          "onUpdate:modelValue": ($event) => unref(filter).sort = $event,
                          name: "sort",
                          class: true
                        }, {
                          default: withCtx(() => [
                            createVNode("option", { value: "" }, toDisplayString(unref($t)("semua")), 1),
                            createVNode("option", { value: "price" }, toDisplayString(unref($t)("murah-ke-mahal")), 1),
                            createVNode("option", { value: "-price" }, toDisplayString(unref($t)("mahal-ke-murah")), 1),
                            createVNode("option", { value: "recomended" }, toDisplayString(unref($t)("rekomendasi")), 1)
                          ]),
                          _: 1
                        }, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      _: 1
                    }, 8, ["label"])
                  ])
                ]),
                createVNode("div", null, [
                  ((_i = (_h = unref(dataT)) == null ? void 0 : _h.data) == null ? void 0 : _i.length) > 0 ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4"
                  }, [
                    (openBlock(true), createBlock(Fragment, null, renderList((_j = unref(dataT)) == null ? void 0 : _j.data, (item) => {
                      var _a2;
                      return openBlock(), createBlock(_component_TourCard, {
                        key: item.id,
                        id: item.id,
                        description: item.locations,
                        price: item.price,
                        name: item.name,
                        image: (_a2 = item.thumbnail_image) == null ? void 0 : _a2.image,
                        slug: "/tours/" + item.slug
                      }, null, 8, ["id", "description", "price", "name", "image", "slug"]);
                    }), 128))
                  ])) : (openBlock(), createBlock(_component_Empty, {
                    key: 1,
                    description: unref($t)("paket-tur-tidak-ditemukan")
                  }, null, 8, ["description"]))
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="h-10"></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tours/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-bf3d31ef.mjs.map
