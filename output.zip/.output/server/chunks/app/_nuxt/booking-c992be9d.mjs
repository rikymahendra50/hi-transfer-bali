import { _ as __nuxt_component_0 } from './Container-f78810bd.mjs';
import { _ as _sfc_main$1 } from './Btn-577fa59f.mjs';
import { _ as _sfc_main$2 } from './AddressInformation-3373b627.mjs';
import { Form } from 'vee-validate';
import { a as useHead, h as useRequestHelper, e as useRequestOptions, b as useRouter, d as useRoute, f as useI18n, u as useAuth, _ as __nuxt_component_0$1 } from '../server.mjs';
import { _ as _sfc_main$3 } from './MGroup-e711cd83.mjs';
import { _ as _sfc_main$4 } from './MTextField-bd75102a.mjs';
import { _ as _sfc_main$5 } from './SelectedCard-939884a9.mjs';
import { ref, withCtx, unref, createTextVNode, toDisplayString, createVNode, openBlock, createBlock, createCommentVNode, useSSRContext } from 'vue';
import { u as useSchema } from './useSchema-7a41625c.mjs';
import { u as useTourForm } from './useCarStore-4fa50219.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import 'clsx';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './TransitionX-601819e8.mjs';
import 'zod';
import '@vee-validate/zod';
import './nofication-1c3cca5e.mjs';

const _sfc_main = {
  __name: "booking",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Booking Detail"
    });
    ref({
      sort: ""
    });
    useRequestHelper();
    useRequestOptions();
    const router = useRouter();
    useRoute();
    const { locale, t: $t } = useI18n();
    const { $isLoggedIn, $isUser, $logout } = useAuth();
    ref("");
    ref("");
    const { orderCarSchema } = useSchema();
    useHead({
      title: "Vehicle"
    });
    const {
      dataForm,
      submitForm,
      saveFormData,
      showSavedCarData,
      clearSavedCarData
    } = useTourForm({
      callback: () => {
        console.log("Form has been submitted!");
      }
    });
    ref(null);
    const dataFormT = ref({
      user_uuid: void 0,
      name: void 0,
      email: void 0,
      phone: void 0
    });
    function submitFormT() {
      dataForm.value.user_uuid = dataFormT.value.user_uuid;
      dataForm.value.name = dataFormT.value.name;
      dataForm.value.email = dataFormT.value.email;
      dataForm.value.phone = dataFormT.value.phone;
      saveFormData();
      router.push("/vehicles/checkout");
    }
    function goToHomePage() {
      clearSavedCarData();
      router.push({ path: "/?cars" });
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_UIBtn = _sfc_main$1;
      const _component_VehicleAddressInformation = _sfc_main$2;
      const _component_VeeForm = Form;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_UIFormMGroup = _sfc_main$3;
      const _component_UIFormMTextField = _sfc_main$4;
      const _component_VehicleSelectedCard = _sfc_main$5;
      _push(`<!--[--><div class="h-44 sm:h-28"></div><div class="w-full border-b">`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_UIBtn, {
              onClick: goToHomePage,
              variant: "primary",
              outlined: "",
              class: "whitespace-nowrap"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref($t)("kembali-ke-beranda"))}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref($t)("kembali-ke-beranda")), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full" }, [
                createVNode("div", null, [
                  createVNode(_component_UIBtn, {
                    onClick: goToHomePage,
                    variant: "primary",
                    outlined: "",
                    class: "whitespace-nowrap"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref($t)("kembali-ke-beranda")), 1)
                    ]),
                    _: 1
                  })
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 divide-x-2"${_scopeId}><div class="space-y-6 py-4"${_scopeId}><h3 class="text-2xl font-semibold text-primary-dark"${_scopeId}>${ssrInterpolate(unref($t)("perjalanan-anda"))}</h3>`);
            if (unref(dataForm).location_pickup_name && unref(dataForm).location_return_name) {
              _push2(`<div class="space-y-4"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_VehicleAddressInformation, {
                name: unref($t)("penjemputan"),
                locationName: unref(dataForm).location_pickup_name,
                locationAddress: unref(dataForm).location_pickup_address
              }, null, _parent2, _scopeId));
              _push2(`<div class="divider text-xs text-zinc-400"${_scopeId}>${ssrInterpolate(unref($t)("perjalananmu-sekitar"))} ${ssrInterpolate(unref(dataForm).distance)} Km </div>`);
              _push2(ssrRenderComponent(_component_VehicleAddressInformation, {
                name: unref($t)("tujuan"),
                locationName: unref(dataForm).location_return_name,
                locationAddress: unref(dataForm).location_return_address
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_VeeForm, {
              onSubmit: submitFormT,
              class: "p-4",
              "validation-schema": unref(orderCarSchema)
            }, {
              default: withCtx(({ errors }, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="flex flex-col space-y-6"${_scopeId2}><div class="flex justify-between items-center"${_scopeId2}><div class="text-2xl font-semibold"${_scopeId2}>${ssrInterpolate(unref($t)("data-pemesan"))}</div></div><div class="space-y-4 relative"${_scopeId2}>`);
                  if (!unref($isUser)) {
                    _push3(ssrRenderComponent(_component_NuxtLink, {
                      to: "/sign-in",
                      class: "absolute w-full h-full z-[200] bg-opacity-0"
                    }, null, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`<div${_scopeId2}><div class="space-y-4 p-4 border rounded-xl"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_UIFormMGroup, {
                    name: "name",
                    label: "Nama Lengkap"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormMTextField, {
                          modelValue: unref(dataFormT).name,
                          "onUpdate:modelValue": ($event) => unref(dataFormT).name = $event,
                          name: "name",
                          class: "input-bordered",
                          placeholder: "Ketik Nama Lengkap Anda"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormMTextField, {
                            modelValue: unref(dataFormT).name,
                            "onUpdate:modelValue": ($event) => unref(dataFormT).name = $event,
                            name: "name",
                            class: "input-bordered",
                            placeholder: "Ketik Nama Lengkap Anda"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_UIFormMGroup, {
                    name: "email",
                    label: "Email"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormMTextField, {
                          modelValue: unref(dataFormT).email,
                          "onUpdate:modelValue": ($event) => unref(dataFormT).email = $event,
                          name: "email",
                          class: "input-bordered",
                          placeholder: "Ketik Email Anda"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormMTextField, {
                            modelValue: unref(dataFormT).email,
                            "onUpdate:modelValue": ($event) => unref(dataFormT).email = $event,
                            name: "email",
                            class: "input-bordered",
                            placeholder: "Ketik Email Anda"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_UIFormMGroup, {
                    name: "phone",
                    label: "Nomor Telepon"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_UIFormMTextField, {
                          modelValue: unref(dataFormT).phone,
                          "onUpdate:modelValue": ($event) => unref(dataFormT).phone = $event,
                          name: "phone",
                          class: "input-bordered",
                          placeholder: "Ketik Nomor Telepon"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_UIFormMTextField, {
                            modelValue: unref(dataFormT).phone,
                            "onUpdate:modelValue": ($event) => unref(dataFormT).phone = $event,
                            name: "phone",
                            class: "input-bordered",
                            placeholder: "Ketik Nomor Telepon"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(`<div class="hidden"${_scopeId2}><button type="submit"${_scopeId2}>submit</button></div></div></div></div><div class="flex justify-between items-center"${_scopeId2}><div class="text-2xl font-semibold"${_scopeId2}>${ssrInterpolate(unref($t)("detail-mobil"))}</div></div><div class="space-y-4"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_VehicleSelectedCard, {
                    name: unref(dataForm).name_car,
                    image: unref(dataForm).image,
                    facilities: unref(dataForm).facilities
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="flex items-center justify-end"${_scopeId2}><button class="btn btn-primary" type="submit"${ssrIncludeBooleanAttr(unref($isUser) === false) ? " disabled" : ""}${_scopeId2}><p${_scopeId2}>${ssrInterpolate(unref($t)("lanjutkan"))}</p></button></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "flex flex-col space-y-6" }, [
                      createVNode("div", { class: "flex justify-between items-center" }, [
                        createVNode("div", { class: "text-2xl font-semibold" }, toDisplayString(unref($t)("data-pemesan")), 1)
                      ]),
                      createVNode("div", { class: "space-y-4 relative" }, [
                        !unref($isUser) ? (openBlock(), createBlock(_component_NuxtLink, {
                          key: 0,
                          to: "/sign-in",
                          class: "absolute w-full h-full z-[200] bg-opacity-0"
                        })) : createCommentVNode("", true),
                        createVNode("div", null, [
                          createVNode("div", { class: "space-y-4 p-4 border rounded-xl" }, [
                            createVNode(_component_UIFormMGroup, {
                              name: "name",
                              label: "Nama Lengkap"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_UIFormMTextField, {
                                  modelValue: unref(dataFormT).name,
                                  "onUpdate:modelValue": ($event) => unref(dataFormT).name = $event,
                                  name: "name",
                                  class: "input-bordered",
                                  placeholder: "Ketik Nama Lengkap Anda"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_UIFormMGroup, {
                              name: "email",
                              label: "Email"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_UIFormMTextField, {
                                  modelValue: unref(dataFormT).email,
                                  "onUpdate:modelValue": ($event) => unref(dataFormT).email = $event,
                                  name: "email",
                                  class: "input-bordered",
                                  placeholder: "Ketik Email Anda"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_UIFormMGroup, {
                              name: "phone",
                              label: "Nomor Telepon"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_UIFormMTextField, {
                                  modelValue: unref(dataFormT).phone,
                                  "onUpdate:modelValue": ($event) => unref(dataFormT).phone = $event,
                                  name: "phone",
                                  class: "input-bordered",
                                  placeholder: "Ketik Nomor Telepon"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode("div", { class: "hidden" }, [
                              createVNode("button", {
                                ref: "internalSubmit",
                                type: "submit"
                              }, "submit", 512)
                            ])
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "flex justify-between items-center" }, [
                        createVNode("div", { class: "text-2xl font-semibold" }, toDisplayString(unref($t)("detail-mobil")), 1)
                      ]),
                      createVNode("div", { class: "space-y-4" }, [
                        createVNode(_component_VehicleSelectedCard, {
                          name: unref(dataForm).name_car,
                          image: unref(dataForm).image,
                          facilities: unref(dataForm).facilities
                        }, null, 8, ["name", "image", "facilities"])
                      ]),
                      createVNode("div", { class: "flex items-center justify-end" }, [
                        createVNode("button", {
                          class: "btn btn-primary",
                          type: "submit",
                          disabled: unref($isUser) === false
                        }, [
                          createVNode("p", null, toDisplayString(unref($t)("lanjutkan")), 1)
                        ], 8, ["disabled"])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 divide-x-2" }, [
                createVNode("div", { class: "space-y-6 py-4" }, [
                  createVNode("h3", { class: "text-2xl font-semibold text-primary-dark" }, toDisplayString(unref($t)("perjalanan-anda")), 1),
                  unref(dataForm).location_pickup_name && unref(dataForm).location_return_name ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "space-y-4"
                  }, [
                    createVNode(_component_VehicleAddressInformation, {
                      name: unref($t)("penjemputan"),
                      locationName: unref(dataForm).location_pickup_name,
                      locationAddress: unref(dataForm).location_pickup_address
                    }, null, 8, ["name", "locationName", "locationAddress"]),
                    createVNode("div", { class: "divider text-xs text-zinc-400" }, toDisplayString(unref($t)("perjalananmu-sekitar")) + " " + toDisplayString(unref(dataForm).distance) + " Km ", 1),
                    createVNode(_component_VehicleAddressInformation, {
                      name: unref($t)("tujuan"),
                      locationName: unref(dataForm).location_return_name,
                      locationAddress: unref(dataForm).location_return_address
                    }, null, 8, ["name", "locationName", "locationAddress"])
                  ])) : createCommentVNode("", true)
                ]),
                createVNode(_component_VeeForm, {
                  onSubmit: submitFormT,
                  class: "p-4",
                  "validation-schema": unref(orderCarSchema)
                }, {
                  default: withCtx(({ errors }) => [
                    createVNode("div", { class: "flex flex-col space-y-6" }, [
                      createVNode("div", { class: "flex justify-between items-center" }, [
                        createVNode("div", { class: "text-2xl font-semibold" }, toDisplayString(unref($t)("data-pemesan")), 1)
                      ]),
                      createVNode("div", { class: "space-y-4 relative" }, [
                        !unref($isUser) ? (openBlock(), createBlock(_component_NuxtLink, {
                          key: 0,
                          to: "/sign-in",
                          class: "absolute w-full h-full z-[200] bg-opacity-0"
                        })) : createCommentVNode("", true),
                        createVNode("div", null, [
                          createVNode("div", { class: "space-y-4 p-4 border rounded-xl" }, [
                            createVNode(_component_UIFormMGroup, {
                              name: "name",
                              label: "Nama Lengkap"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_UIFormMTextField, {
                                  modelValue: unref(dataFormT).name,
                                  "onUpdate:modelValue": ($event) => unref(dataFormT).name = $event,
                                  name: "name",
                                  class: "input-bordered",
                                  placeholder: "Ketik Nama Lengkap Anda"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_UIFormMGroup, {
                              name: "email",
                              label: "Email"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_UIFormMTextField, {
                                  modelValue: unref(dataFormT).email,
                                  "onUpdate:modelValue": ($event) => unref(dataFormT).email = $event,
                                  name: "email",
                                  class: "input-bordered",
                                  placeholder: "Ketik Email Anda"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode(_component_UIFormMGroup, {
                              name: "phone",
                              label: "Nomor Telepon"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_UIFormMTextField, {
                                  modelValue: unref(dataFormT).phone,
                                  "onUpdate:modelValue": ($event) => unref(dataFormT).phone = $event,
                                  name: "phone",
                                  class: "input-bordered",
                                  placeholder: "Ketik Nomor Telepon"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ]),
                              _: 1
                            }),
                            createVNode("div", { class: "hidden" }, [
                              createVNode("button", {
                                ref: "internalSubmit",
                                type: "submit"
                              }, "submit", 512)
                            ])
                          ])
                        ])
                      ]),
                      createVNode("div", { class: "flex justify-between items-center" }, [
                        createVNode("div", { class: "text-2xl font-semibold" }, toDisplayString(unref($t)("detail-mobil")), 1)
                      ]),
                      createVNode("div", { class: "space-y-4" }, [
                        createVNode(_component_VehicleSelectedCard, {
                          name: unref(dataForm).name_car,
                          image: unref(dataForm).image,
                          facilities: unref(dataForm).facilities
                        }, null, 8, ["name", "image", "facilities"])
                      ]),
                      createVNode("div", { class: "flex items-center justify-end" }, [
                        createVNode("button", {
                          class: "btn btn-primary",
                          type: "submit",
                          disabled: unref($isUser) === false
                        }, [
                          createVNode("p", null, toDisplayString(unref($t)("lanjutkan")), 1)
                        ], 8, ["disabled"])
                      ])
                    ])
                  ]),
                  _: 1
                }, 8, ["validation-schema"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/vehicles/booking.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=booking-c992be9d.mjs.map
