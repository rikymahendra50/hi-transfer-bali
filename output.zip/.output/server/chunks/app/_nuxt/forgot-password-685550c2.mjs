import { _ as _sfc_main$2, a as _sfc_main$1, b as _sfc_main$3 } from './Change-5e0500a5.mjs';
import { defineComponent, computed, mergeProps, unref, useSSRContext } from 'vue';
import { b as useRouter, f as useI18n, u as useAuth, a as useHead } from '../server.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { u as useStepper } from './index-a61f78d7.mjs';
import 'vee-validate';
import './Alert-129c5078.mjs';
import './TransitionTopToBottom-a8e40871.mjs';
import './Icon-0f6314e3.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './MGroup-e711cd83.mjs';
import './TransitionX-601819e8.mjs';
import 'clsx';
import './MTextField-bd75102a.mjs';
import './Btn-577fa59f.mjs';
import './useSchema-0246d9f0.mjs';
import 'zod';
import '@vee-validate/zod';
import './Group-4dcbb69b.mjs';
import './InputOTP-bbb2b053.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './index-596a8548.mjs';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "forgot-password",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter();
    const { locale, t: $t } = useI18n();
    const stepper = useStepper({
      "forgot-password": {
        title: $t("lupa-password"),
        isValid: () => true
      },
      otp: {
        title: "Verification OTP",
        isValid: () => true
      },
      "change-password": {
        title: $t("rubah-password"),
        isValid: () => true
      }
    });
    const { $credentialForgotPassword } = useAuth();
    const titleHeader = computed(() => {
      var _a2;
      var _a, _b;
      return (_a2 = (_b = (_a = stepper.current) == null ? void 0 : _a.value) == null ? void 0 : _b.title) != null ? _a2 : $t("forgot-password");
    });
    function goToHome() {
      router.push("/");
    }
    useHead({
      title: titleHeader.value
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ForgotPassword = _sfc_main$2;
      const _component_ForgotPasswordVerifiedOTP = _sfc_main$1;
      const _component_ForgotPasswordChange = _sfc_main$3;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "hero min-h-screen" }, _attrs))}><div class="hero-content text-center"><div class="max-w-md"><h1 class="text-4xl font-bold mb-6">${ssrInterpolate(unref(stepper).current.value.title)}</h1>`);
      if (unref(stepper).isCurrent("forgot-password")) {
        _push(ssrRenderComponent(_component_ForgotPassword, {
          email: unref($credentialForgotPassword).email,
          "onUpdate:email": ($event) => unref($credentialForgotPassword).email = $event,
          onNext: () => unref(stepper).goTo("otp"),
          "used-by": "admin"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(stepper).isCurrent("otp")) {
        _push(ssrRenderComponent(_component_ForgotPasswordVerifiedOTP, {
          pin: unref($credentialForgotPassword).pin,
          "onUpdate:pin": ($event) => unref($credentialForgotPassword).pin = $event,
          email: unref($credentialForgotPassword).email,
          onNext: () => unref(stepper).goTo("change-password"),
          "used-by": "admin"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(stepper).isCurrent("change-password")) {
        _push(ssrRenderComponent(_component_ForgotPasswordChange, {
          email: unref($credentialForgotPassword).email,
          pin: unref($credentialForgotPassword).pin,
          onNext: goToHome,
          "used-by": "admin"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/forgot-password.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=forgot-password-685550c2.mjs.map
