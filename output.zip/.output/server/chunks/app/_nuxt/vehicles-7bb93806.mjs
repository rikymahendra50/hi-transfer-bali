import { _ as __nuxt_component_0 } from './Container-c0bcb3c6.mjs';
import { _ as _sfc_main$2 } from './Btn-61213793.mjs';
import __nuxt_component_1 from './Icon-7218f0f6.mjs';
import { defineComponent, computed, unref, withCtx, createTextVNode, createVNode, openBlock, createBlock, createCommentVNode, useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { u as useRoute, a as useRouter, i as __nuxt_component_4, e as _export_sfc } from '../server.mjs';
import { u as useVehicleForm } from './vehicleForm-b4695968.mjs';
import 'clsx';
import './config-aab100d3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "border rounded-xl p-4 space-y-2" }, _attrs))}><div class="text-xs text-zinc-400"> Penjemputan </div><div> Bandara Int&#39;l Gusti Ngurah Rai </div><div class="text-sm text-zinc-400"> Jln. Raya Gusti Ngurah Rai, Tuban, Kec. Kuta, Kabupaten Badung, Bali 80362 </div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Vehicle/AddressInformation.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "vehicles",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    useRouter();
    const { btnSubmitClick } = useVehicleForm();
    const isVehiclePage = computed(() => {
      return route.name === "vehicles";
    });
    const isVehicleBookingPage = computed(() => {
      return route.name === "vehicles-booking";
    });
    const isVehicleCheckoutPage = computed(() => {
      return route.name === "vehicles-checkout";
    });
    const gotoCheckout = () => {
      btnSubmitClick();
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIContainer = __nuxt_component_0;
      const _component_UIBtn = _sfc_main$2;
      const _component_Icon = __nuxt_component_1;
      const _component_VehicleAddressInformation = __nuxt_component_3;
      const _component_NuxtPage = __nuxt_component_4;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="h-28"></div>`);
      if (unref(isVehiclePage)) {
        _push(`<div class="w-full border-b">`);
        _push(ssrRenderComponent(_component_UIContainer, null, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full"${_scopeId}><div${_scopeId}>`);
              _push2(ssrRenderComponent(_component_UIBtn, {
                variant: "primary",
                outlined: "",
                class: "whitespace-nowrap"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`Kembali ke Beranda`);
                  } else {
                    return [
                      createTextVNode("Kembali ke Beranda")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`</div><div class="w-full"${_scopeId}><div class="flex flex-col lg:flex-row space-y-1 lg:space-y-0 lg:space-x-4 text-lg lg:text-xl font-semibold"${_scopeId}><div class="text-center"${_scopeId}> Bandara Int&#39;l I Gusti Ngurah Rai </div><div class="hidden lg:block text-center"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, {
                name: "i-heroicons-arrow-right",
                class: "w-4 h-4"
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="block lg:hidden text-center"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, {
                name: "i-heroicons-arrow-down",
                class: "w-4 h-4"
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="text-center"${_scopeId}> The Trans Resort Bali </div></div><div class="text-zinc-400 text-sm whitespace-nowrap text-center lg:text-left"${_scopeId}> 21 Juni 2024 | 2 Penumpang </div></div></div>`);
            } else {
              return [
                createVNode("div", { class: "flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4 w-full" }, [
                  createVNode("div", null, [
                    createVNode(_component_UIBtn, {
                      variant: "primary",
                      outlined: "",
                      class: "whitespace-nowrap"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Kembali ke Beranda")
                      ]),
                      _: 1
                    })
                  ]),
                  createVNode("div", { class: "w-full" }, [
                    createVNode("div", { class: "flex flex-col lg:flex-row space-y-1 lg:space-y-0 lg:space-x-4 text-lg lg:text-xl font-semibold" }, [
                      createVNode("div", { class: "text-center" }, " Bandara Int'l I Gusti Ngurah Rai "),
                      createVNode("div", { class: "hidden lg:block text-center" }, [
                        createVNode(_component_Icon, {
                          name: "i-heroicons-arrow-right",
                          class: "w-4 h-4"
                        })
                      ]),
                      createVNode("div", { class: "block lg:hidden text-center" }, [
                        createVNode(_component_Icon, {
                          name: "i-heroicons-arrow-down",
                          class: "w-4 h-4"
                        })
                      ]),
                      createVNode("div", { class: "text-center" }, " The Trans Resort Bali ")
                    ]),
                    createVNode("div", { class: "text-zinc-400 text-sm whitespace-nowrap text-center lg:text-left" }, " 21 Juni 2024 | 2 Penumpang ")
                  ])
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_UIContainer, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 divide-x-2"${_scopeId}><div class="space-y-6 py-4"${_scopeId}><h3 class="text-2xl font-semibold text-primary-dark"${_scopeId}> Perjalanan Anda </h3><div class="space-y-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VehicleAddressInformation, null, null, _parent2, _scopeId));
            _push2(`<div class="divider text-xs text-zinc-400"${_scopeId}>Perjalananmu sekitar 10,9km</div>`);
            _push2(ssrRenderComponent(_component_VehicleAddressInformation, null, null, _parent2, _scopeId));
            _push2(`</div></div><div class="p-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtPage, null, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 divide-x-2" }, [
                createVNode("div", { class: "space-y-6 py-4" }, [
                  createVNode("h3", { class: "text-2xl font-semibold text-primary-dark" }, " Perjalanan Anda "),
                  createVNode("div", { class: "space-y-4" }, [
                    createVNode(_component_VehicleAddressInformation),
                    createVNode("div", { class: "divider text-xs text-zinc-400" }, "Perjalananmu sekitar 10,9km"),
                    createVNode(_component_VehicleAddressInformation)
                  ])
                ]),
                createVNode("div", { class: "p-4" }, [
                  createVNode(_component_NuxtPage)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      if (unref(isVehicleBookingPage) || unref(isVehicleCheckoutPage)) {
        _push(`<div class="w-full border-b border-t">`);
        _push(ssrRenderComponent(_component_UIContainer, null, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex justify-end w-full"${_scopeId}><div${_scopeId}>`);
              if (unref(isVehicleBookingPage)) {
                _push2(ssrRenderComponent(_component_UIBtn, {
                  variant: "primary",
                  onClick: gotoCheckout,
                  class: "whitespace-nowrap"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`Lanjutkan`);
                    } else {
                      return [
                        createTextVNode("Lanjutkan")
                      ];
                    }
                  }),
                  _: 1
                }, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              if (unref(isVehicleCheckoutPage)) {
                _push2(ssrRenderComponent(_component_UIBtn, {
                  variant: "primary",
                  onClick: gotoCheckout,
                  class: "whitespace-nowrap"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`Pesan Dan Bayar`);
                    } else {
                      return [
                        createTextVNode("Pesan Dan Bayar")
                      ];
                    }
                  }),
                  _: 1
                }, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div>`);
            } else {
              return [
                createVNode("div", { class: "flex justify-end w-full" }, [
                  createVNode("div", null, [
                    unref(isVehicleBookingPage) ? (openBlock(), createBlock(_component_UIBtn, {
                      key: 0,
                      variant: "primary",
                      onClick: gotoCheckout,
                      class: "whitespace-nowrap"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Lanjutkan")
                      ]),
                      _: 1
                    })) : createCommentVNode("", true),
                    unref(isVehicleCheckoutPage) ? (openBlock(), createBlock(_component_UIBtn, {
                      key: 1,
                      variant: "primary",
                      onClick: gotoCheckout,
                      class: "whitespace-nowrap"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Pesan Dan Bayar")
                      ]),
                      _: 1
                    })) : createCommentVNode("", true)
                  ])
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/vehicles.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=vehicles-7bb93806.mjs.map
