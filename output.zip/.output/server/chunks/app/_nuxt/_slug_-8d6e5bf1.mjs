import { _ as __nuxt_component_0 } from './TitleAdminBack-74ddbbfb.mjs';
import { ref, computed, withAsyncContext, unref, withCtx, createVNode, toDisplayString, useSSRContext } from 'vue';
import { a as useHead, h as useRequestHelper, e as useRequestOptions, b as useRouter, d as useRoute, g as useAsyncData } from '../server.mjs';
import { _ as __unimport_FormatMoneyDash } from './FormatMoneyDash-4b79c187.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import './Icon-ab561e52.mjs';
import './config-3cecc2b8.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useHead({
      title: "Order detail"
    });
    ref({
      sort: ""
    });
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    useRouter();
    const route = useRoute();
    ref(1);
    ref(false);
    ref(void 0);
    const slug = computed(() => route.params.slug);
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "ordersDetail",
      () => $fetch(`/admins/car-orders/${slug.value}`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b2;
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B;
      const _component_TitleAdminBack = __nuxt_component_0;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_TitleAdminBack, {
        title: "Ringkasan Pesanan",
        subTitle: `Informasi lengkap untuk pesanan #${(_b = (_a = unref(data)) == null ? void 0 : _a.data) == null ? void 0 : _b.uuid}`,
        link: "/admin/orders"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a22, _b22, _c2, _d2;
          if (_push2) {
            _push2(`<div${_scopeId}><div class="border-2 shadow-xs p-3 rounded-xl"${_scopeId}>${ssrInterpolate((_b22 = (_a22 = unref(data)) == null ? void 0 : _a22.data) == null ? void 0 : _b22.status)}</div></div>`);
          } else {
            return [
              createVNode("div", null, [
                createVNode("div", { class: "border-2 shadow-xs p-3 rounded-xl" }, toDisplayString((_d2 = (_c2 = unref(data)) == null ? void 0 : _c2.data) == null ? void 0 : _d2.status), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="px-5 py-4 flex flex-col gap-3 border-b"><div class="text-gray-500 uppercase text-[12px] font-semibold"> Informasi Pelanggan </div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Nama pelanggan:</p><p>${ssrInterpolate(((_e = (_d = (_c = unref(data)) == null ? void 0 : _c.data) == null ? void 0 : _d.user) == null ? void 0 : _e.first_name) + " " + ((_h = (_g = (_f = unref(data)) == null ? void 0 : _f.data) == null ? void 0 : _g.user) == null ? void 0 : _h.last_name))}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Email:</p><p>${ssrInterpolate((_k = (_j = (_i = unref(data)) == null ? void 0 : _i.data) == null ? void 0 : _j.user) == null ? void 0 : _k.email)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold text-sm">Nomor Telepon:</p><p>${ssrInterpolate((_n = (_m = (_l = unref(data)) == null ? void 0 : _l.data) == null ? void 0 : _m.user) == null ? void 0 : _n.phone)}</p></div></div><div class="px-5 py-6 flex flex-col gap-3 border-b"><div class="text-gray-500 uppercase text-[12px] font-semibold"> Informasi Pemesanan </div><!--[-->`);
      ssrRenderList((_p = (_o = unref(data)) == null ? void 0 : _o.data) == null ? void 0 : _p.details, (item) => {
        _push(`<div class="grid md:grid-cols-2"><div class="flex flex-col gap-2"><p class="font-semibold text-sm">Penjemputan</p><p class="text-sm">${ssrInterpolate(item.pickup_name)}</p><div class="text-sm opacity-50"><a${ssrRenderAttr("href", `https://maps.google.com/?q=${item.pickup_address},${item.pickup_address}`)} target="_blank">${ssrInterpolate(item.pickup_address)}</a></div></div><div class="flex flex-col gap-2"><p class="font-semibold text-sm">Pengantaran</p><p class="text-sm">${ssrInterpolate(item.destination_name)}</p><div class="text-sm opacity-50"><a target="_blank"${ssrRenderAttr("href", `https://maps.google.com/?q=${item.destination_latitude},${item.destination_longitude}`)}>${ssrInterpolate(item.destination_address)}</a></div></div></div>`);
      });
      _push(`<!--]--></div><div class="px-5 py-4 flex flex-col gap-3"><div class="text-gray-500 uppercase text-[12px] font-semibold"> Payment Information </div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Payment Method</p><p>${ssrInterpolate((_a2 = (_s = (_r = (_q = unref(data)) == null ? void 0 : _q.data) == null ? void 0 : _r.payment) == null ? void 0 : _s.payment_method) != null ? _a2 : "-")}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Payment Channel</p><p>${ssrInterpolate((_b2 = (_v = (_u = (_t = unref(data)) == null ? void 0 : _t.data) == null ? void 0 : _u.payment) == null ? void 0 : _v.payment_channel) != null ? _b2 : "-")}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Payment Status</p><p>${ssrInterpolate((_y = (_x = (_w = unref(data)) == null ? void 0 : _w.data) == null ? void 0 : _x.payment) == null ? void 0 : _y.status)}</p></div><div class="grid grid-cols-2 w-full md:w-[40%] items-center text-sm"><p class="font-semibold">Total Price</p><p>${ssrInterpolate(("FormatMoneyDash" in _ctx ? _ctx.FormatMoneyDash : unref(__unimport_FormatMoneyDash))((_B = (_A = (_z = unref(data)) == null ? void 0 : _z.data) == null ? void 0 : _A.payment) == null ? void 0 : _B.total_purchased.toString()))}</p></div></div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/orders/order-detail-car/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-8d6e5bf1.mjs.map
