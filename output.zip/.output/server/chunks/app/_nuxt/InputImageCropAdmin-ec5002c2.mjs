import { _ as __nuxt_component_4 } from './client-only-53a57ea8.mjs';
import { useSSRContext, ref, computed, watch } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import { a as useWindowSize, b as useFileDialog } from './index-dea25161.mjs';

const _sfc_main = {
  __name: "InputImageCropAdmin",
  __ssrInlineRender: true,
  props: {
    loading: {
      type: Boolean,
      default: false
    },
    existingimage: {
      type: String,
      default: null
    },
    modelValue: {
      type: [File, String],
      default: null
    },
    name: {
      type: String,
      default: "Image"
    },
    label: {
      type: String,
      default: "Background Image"
    },
    classCustom: {
      type: String
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { expose: __expose, emit }) {
    const props = __props;
    const { width, height } = useWindowSize();
    const modalInput = ref(false);
    ref(false);
    const image = ref(null);
    ref(void 0);
    computed(() => {
      return image.value ? URL.createObjectURL(image.value) : null;
    });
    ref();
    const imageReview = ref();
    computed(() => {
      var _a;
      return imageReview.value ? URL.createObjectURL(imageReview.value) : (_a = props.existingimage) != null ? _a : null;
    });
    const { files, open, reset, onChange } = useFileDialog({
      accept: "image/*",
      // Set to accept only image files
      multiple: false
    });
    computed(() => {
      const isLargeScreen = width.value >= 600;
      return isLargeScreen ? {
        width: "500px",
        height: "400px",
        backgroundColor: "#f8f8f8",
        margin: "auto"
      } : {
        width: "100%",
        height: "100%",
        backgroundColor: "#f8f8f8",
        margin: "auto"
      };
    });
    onChange((files2) => {
      if (!files2) {
        return;
      }
      image.value = files2[0];
      reset();
      modalInput.value = true;
    });
    watch(
      () => modalInput.value,
      (value) => {
        if (!value) {
          image.value = null;
        }
      }
    );
    __expose({
      modalInput
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_4;
      _push(ssrRenderComponent(_component_ClientOnly, _attrs, {}, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Form/InputImageCropAdmin.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main;

export { __nuxt_component_2 as _ };
//# sourceMappingURL=InputImageCropAdmin-ec5002c2.mjs.map
