const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.742f684c.mjs').then(interopDefault),
  "pages/tours/[slug].vue": () => import('./_nuxt/_slug_-styles.75e8c907.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/index-styles.48952bec.mjs').then(interopDefault),
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": () => import('./_nuxt/Icon-styles.3c97f940.mjs').then(interopDefault),
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": () => import('./_nuxt/IconCSS-styles.9ba8332f.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
