const client_manifest = {
  "FloatingWa.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "FloatingWa.a9fd3de1.css",
    "src": "FloatingWa.css"
  },
  "Modal.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Modal.200da282.css",
    "src": "Modal.css"
  },
  "TourPackage.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "TourPackage.da417478.css",
    "src": "TourPackage.css"
  },
  "_AddressInformation.vue.874d55ed.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AddressInformation.vue.874d55ed.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Alert.vue.40f07a06.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Alert.vue.40f07a06.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_TransitionTopToBottom.c5ca4536.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Alert.vue.a8555149.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Alert.vue.a8555149.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_TransitionTopToBottom.c5ca4536.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Btn.vue.77dc26e2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Btn.vue.77dc26e2.js",
    "imports": [
      "_clsx.0839fdbe.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_ButtonAddAdmin.b7cb6b11.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddAdmin.b7cb6b11.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Card.3ced18d9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Card.3ced18d9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useTourStore.f54ee4ac.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Change.vue.5353c472.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Change.vue.5353c472.js",
    "imports": [
      "_Alert.vue.40f07a06.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.8b30751e.js",
      "_Btn.vue.77dc26e2.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.c5fb0729.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_InputOTP.vue.34ce9cc3.js",
      "_TransitionX.e95318ef.js",
      "_Group.vue.dbd5fea5.js"
    ]
  },
  "_ChangePassword.625aa80f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ChangePassword.625aa80f.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.3f648032.js",
      "_swiper-vue.f9dac270.js",
      "_Alert.vue.a8555149.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.e95318ef.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.efe63601.js",
      "_useSchema.c5fb0729.js",
      "_usePasswordHelper.66d7e1e2.js"
    ]
  },
  "_Container.b9395283.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Container.b9395283.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_CtaSection.vue.81c13cb2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CtaSection.vue.81c13cb2.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Destinations.ff6bf074.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Destinations.ff6bf074.js",
    "imports": [
      "_TextFieldWLabel.vue.bae6c828.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.c5fb0729.js",
      "_useDestinations.22810def.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Driver.1a22e4e5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Driver.1a22e4e5.js",
    "imports": [
      "_TextFieldWLabel.vue.bae6c828.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.c5fb0729.js",
      "_useDriver.70ea93ed.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_DropdownsTest.66443284.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DropdownsTest.66443284.js",
    "imports": [
      "_vee-validate.esm.c1170e9f.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.3f648032.js"
    ]
  },
  "_Empty.1d65daef.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Empty.1d65daef.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_FacilityCar.e4ba6799.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FacilityCar.e4ba6799.js",
    "imports": [
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_InputImageCropAdmin.00049c61.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.c5fb0729.js",
      "_useFacility.939840a2.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_FloatingWa.35238e63.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "FloatingWa.a9fd3de1.css"
    ],
    "file": "FloatingWa.35238e63.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_Container.b9395283.js"
    ]
  },
  "FloatingWa.a9fd3de1.css": {
    "file": "FloatingWa.a9fd3de1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_FormAdmin.vue.788d853b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FormAdmin.vue.788d853b.js",
    "imports": [
      "_Alert.vue.a8555149.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.e95318ef.js",
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.efe63601.js"
    ]
  },
  "_FormatMoneyDash.aea6127b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FormatMoneyDash.aea6127b.js"
  },
  "_Group.vue.dbd5fea5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Group.vue.dbd5fea5.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_HeadPage.vue.2fb6071b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "HeadPage.vue.2fb6071b.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_InputImageCropAdmin.00049c61.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "InputImageCropAdmin.00049c61.js",
    "imports": [
      "_Modal.66017e5d.js",
      "_vee-validate.esm.c1170e9f.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_client-only.bae35f15.js",
      "_index.3f648032.js",
      "_index.989c4c14.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_InputOTP.vue.34ce9cc3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "InputOTP.vue.34ce9cc3.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_MGroup.vue.8b30751e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MGroup.vue.8b30751e.js",
    "imports": [
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.e95318ef.js",
      "_clsx.0839fdbe.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_MSelect.vue.344734d3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MSelect.vue.344734d3.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js"
    ]
  },
  "_MTextField.vue.00f77f35.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MTextField.vue.00f77f35.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js"
    ]
  },
  "_Modal.66017e5d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Modal.200da282.css"
    ],
    "file": "Modal.66017e5d.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.f9dac270.js",
      "_index.3f648032.js",
      "_index.7d9a9c74.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "Modal.200da282.css": {
    "file": "Modal.200da282.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_PaginationAdmin.7a0a3d9d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "PaginationAdmin.7a0a3d9d.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_SelectedCard.vue.225d8c13.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "SelectedCard.vue.225d8c13.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_SelectedCard.vue.58d16422.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "SelectedCard.vue.58d16422.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_StatusTrueOrFalse.b4309c51.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "StatusTrueOrFalse.b4309c51.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Switch.vue.533843fb.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Switch.vue.533843fb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TabContent.vue.9e619e50.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TabContent.vue.9e619e50.js",
    "imports": [
      "_clsx.0839fdbe.js",
      "_swiper-vue.f9dac270.js",
      "_client-only.bae35f15.js"
    ]
  },
  "_TextFieldWLabel.vue.bae6c828.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TextFieldWLabel.vue.bae6c828.js",
    "imports": [
      "_vee-validate.esm.c1170e9f.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TitleAdmin.d9ac3a1d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleAdmin.d9ac3a1d.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TitleAdminBack.8666969b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleAdminBack.8666969b.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TitleBack.99929c86.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleBack.99929c86.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TourPackage.2ce47ff8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "TourPackage.da417478.css"
    ],
    "file": "TourPackage.2ce47ff8.js",
    "imports": [
      "_TextFieldWLabel.vue.bae6c828.js",
      "_DropdownsTest.66443284.js",
      "_vee-validate.esm.c1170e9f.js",
      "_client-only.bae35f15.js",
      "_swiper-vue.f9dac270.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useTourPackage.014652ff.js",
      "_index.3f648032.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.c5fb0729.js"
    ]
  },
  "TourPackage.da417478.css": {
    "file": "TourPackage.da417478.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TransitionTopToBottom.c5ca4536.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TransitionTopToBottom.c5ca4536.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_TransitionX.e95318ef.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TransitionX.e95318ef.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_Transport.dc579215.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Transport.dc579215.js",
    "imports": [
      "_vee-validate.esm.c1170e9f.js",
      "_InputImageCropAdmin.00049c61.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_DropdownsTest.66443284.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.c5fb0729.js",
      "_useTransport.c49d92c8.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Verified.832ecc46.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Verified.832ecc46.js",
    "imports": [
      "_Alert.vue.a8555149.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputOTP.vue.34ce9cc3.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_useSchema.c5fb0729.js"
    ]
  },
  "_client-only.bae35f15.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client-only.bae35f15.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_clsx.0839fdbe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "clsx.0839fdbe.js"
  },
  "_config.ea66e5da.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.ea66e5da.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_hi-transfer-logo.9d118dbc.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hi-transfer-logo.9d118dbc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.27906dea.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.27906dea.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_index.3f648032.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.3f648032.js",
    "imports": [
      "_index.27906dea.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_index.7d9a9c74.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.7d9a9c74.js"
  },
  "_index.989c4c14.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.989c4c14.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_nofication.efe63601.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nofication.efe63601.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_swiper-vue.f9dac270.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.d33d3671.css"
    ],
    "file": "swiper-vue.f9dac270.js"
  },
  "swiper-vue.d33d3671.css": {
    "file": "swiper-vue.d33d3671.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useCarStore.5d3ffa2e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useCarStore.5d3ffa2e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.efe63601.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useDestinations.22810def.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useDestinations.22810def.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.efe63601.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useDriver.70ea93ed.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useDriver.70ea93ed.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.efe63601.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useFacility.939840a2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useFacility.939840a2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.efe63601.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_usePasswordHelper.66d7e1e2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "usePasswordHelper.66d7e1e2.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useSchema.c5fb0729.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useSchema.c5fb0729.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useTourPackage.014652ff.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTourPackage.014652ff.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.efe63601.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useTourStore.f54ee4ac.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTourStore.f54ee4ac.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.efe63601.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useTransport.c49d92c8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTransport.c49d92c8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.efe63601.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_vee-validate.esm.c1170e9f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vee-validate.esm.c1170e9f.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "assets/fonts/ClashGrotesk-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Bold.c4ea1fe3.ttf",
    "src": "assets/fonts/ClashGrotesk-Bold.ttf"
  },
  "assets/fonts/ClashGrotesk-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Bold.b1b9970d.woff",
    "src": "assets/fonts/ClashGrotesk-Bold.woff"
  },
  "assets/fonts/ClashGrotesk-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Bold.602a56af.woff2",
    "src": "assets/fonts/ClashGrotesk-Bold.woff2"
  },
  "assets/fonts/ClashGrotesk-Extralight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Extralight.6417ca23.ttf",
    "src": "assets/fonts/ClashGrotesk-Extralight.ttf"
  },
  "assets/fonts/ClashGrotesk-Extralight.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Extralight.c9c2a3a9.woff",
    "src": "assets/fonts/ClashGrotesk-Extralight.woff"
  },
  "assets/fonts/ClashGrotesk-Extralight.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Extralight.fe206472.woff2",
    "src": "assets/fonts/ClashGrotesk-Extralight.woff2"
  },
  "assets/fonts/ClashGrotesk-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Light.8e98f3c7.ttf",
    "src": "assets/fonts/ClashGrotesk-Light.ttf"
  },
  "assets/fonts/ClashGrotesk-Light.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Light.04e1d585.woff",
    "src": "assets/fonts/ClashGrotesk-Light.woff"
  },
  "assets/fonts/ClashGrotesk-Light.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Light.f0f7605c.woff2",
    "src": "assets/fonts/ClashGrotesk-Light.woff2"
  },
  "assets/fonts/ClashGrotesk-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Medium.717fd45f.ttf",
    "src": "assets/fonts/ClashGrotesk-Medium.ttf"
  },
  "assets/fonts/ClashGrotesk-Medium.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Medium.94bcd03c.woff",
    "src": "assets/fonts/ClashGrotesk-Medium.woff"
  },
  "assets/fonts/ClashGrotesk-Medium.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Medium.5c3815cf.woff2",
    "src": "assets/fonts/ClashGrotesk-Medium.woff2"
  },
  "assets/fonts/ClashGrotesk-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Regular.5c66c57f.ttf",
    "src": "assets/fonts/ClashGrotesk-Regular.ttf"
  },
  "assets/fonts/ClashGrotesk-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Regular.1c248756.woff",
    "src": "assets/fonts/ClashGrotesk-Regular.woff"
  },
  "assets/fonts/ClashGrotesk-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Regular.03ad7ecf.woff2",
    "src": "assets/fonts/ClashGrotesk-Regular.woff2"
  },
  "assets/fonts/ClashGrotesk-Semibold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Semibold.bdc47ea3.ttf",
    "src": "assets/fonts/ClashGrotesk-Semibold.ttf"
  },
  "assets/fonts/ClashGrotesk-Semibold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Semibold.48fdb6da.woff",
    "src": "assets/fonts/ClashGrotesk-Semibold.woff"
  },
  "assets/fonts/ClashGrotesk-Semibold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Semibold.befc1942.woff2",
    "src": "assets/fonts/ClashGrotesk-Semibold.woff2"
  },
  "assets/fonts/ClashGrotesk-Variable.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Variable.5887a1df.ttf",
    "src": "assets/fonts/ClashGrotesk-Variable.ttf"
  },
  "assets/fonts/ClashGrotesk-Variable.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Variable.de7ab3f6.woff",
    "src": "assets/fonts/ClashGrotesk-Variable.woff"
  },
  "assets/fonts/ClashGrotesk-Variable.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Variable.3c56fcff.woff2",
    "src": "assets/fonts/ClashGrotesk-Variable.woff2"
  },
  "assets/fonts/GeneralSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Bold.1c435b33.ttf",
    "src": "assets/fonts/GeneralSans-Bold.ttf"
  },
  "assets/fonts/GeneralSans-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Bold.4c2b7f63.woff",
    "src": "assets/fonts/GeneralSans-Bold.woff"
  },
  "assets/fonts/GeneralSans-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Bold.a29eab9b.woff2",
    "src": "assets/fonts/GeneralSans-Bold.woff2"
  },
  "assets/fonts/GeneralSans-BoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-BoldItalic.2297ae79.ttf",
    "src": "assets/fonts/GeneralSans-BoldItalic.ttf"
  },
  "assets/fonts/GeneralSans-BoldItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-BoldItalic.0599ec69.woff",
    "src": "assets/fonts/GeneralSans-BoldItalic.woff"
  },
  "assets/fonts/GeneralSans-BoldItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-BoldItalic.97483640.woff2",
    "src": "assets/fonts/GeneralSans-BoldItalic.woff2"
  },
  "assets/fonts/GeneralSans-Extralight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Extralight.4cb07dad.ttf",
    "src": "assets/fonts/GeneralSans-Extralight.ttf"
  },
  "assets/fonts/GeneralSans-Extralight.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Extralight.6a52bdce.woff",
    "src": "assets/fonts/GeneralSans-Extralight.woff"
  },
  "assets/fonts/GeneralSans-Extralight.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Extralight.3e6ee7e5.woff2",
    "src": "assets/fonts/GeneralSans-Extralight.woff2"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-ExtralightItalic.9b80b399.ttf",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.ttf"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-ExtralightItalic.acc7311a.woff",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.woff"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-ExtralightItalic.83bbc211.woff2",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.woff2"
  },
  "assets/fonts/GeneralSans-Italic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Italic.ea19866f.ttf",
    "src": "assets/fonts/GeneralSans-Italic.ttf"
  },
  "assets/fonts/GeneralSans-Italic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Italic.f9e5a73e.woff",
    "src": "assets/fonts/GeneralSans-Italic.woff"
  },
  "assets/fonts/GeneralSans-Italic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Italic.1c91e1d3.woff2",
    "src": "assets/fonts/GeneralSans-Italic.woff2"
  },
  "assets/fonts/GeneralSans-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Light.86a255b5.ttf",
    "src": "assets/fonts/GeneralSans-Light.ttf"
  },
  "assets/fonts/GeneralSans-Light.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Light.09f0f0fe.woff",
    "src": "assets/fonts/GeneralSans-Light.woff"
  },
  "assets/fonts/GeneralSans-Light.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Light.ac0b8f29.woff2",
    "src": "assets/fonts/GeneralSans-Light.woff2"
  },
  "assets/fonts/GeneralSans-LightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-LightItalic.eb313a89.ttf",
    "src": "assets/fonts/GeneralSans-LightItalic.ttf"
  },
  "assets/fonts/GeneralSans-LightItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-LightItalic.639de7d9.woff",
    "src": "assets/fonts/GeneralSans-LightItalic.woff"
  },
  "assets/fonts/GeneralSans-LightItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-LightItalic.7787625d.woff2",
    "src": "assets/fonts/GeneralSans-LightItalic.woff2"
  },
  "assets/fonts/GeneralSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Medium.e85572fe.ttf",
    "src": "assets/fonts/GeneralSans-Medium.ttf"
  },
  "assets/fonts/GeneralSans-Medium.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Medium.f5beb161.woff",
    "src": "assets/fonts/GeneralSans-Medium.woff"
  },
  "assets/fonts/GeneralSans-Medium.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Medium.c30377df.woff2",
    "src": "assets/fonts/GeneralSans-Medium.woff2"
  },
  "assets/fonts/GeneralSans-MediumItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-MediumItalic.3b4e2f45.ttf",
    "src": "assets/fonts/GeneralSans-MediumItalic.ttf"
  },
  "assets/fonts/GeneralSans-MediumItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-MediumItalic.d02080e7.woff",
    "src": "assets/fonts/GeneralSans-MediumItalic.woff"
  },
  "assets/fonts/GeneralSans-MediumItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-MediumItalic.ffe0560d.woff2",
    "src": "assets/fonts/GeneralSans-MediumItalic.woff2"
  },
  "assets/fonts/GeneralSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Regular.0723d125.ttf",
    "src": "assets/fonts/GeneralSans-Regular.ttf"
  },
  "assets/fonts/GeneralSans-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Regular.52af118f.woff",
    "src": "assets/fonts/GeneralSans-Regular.woff"
  },
  "assets/fonts/GeneralSans-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Regular.3ec2be77.woff2",
    "src": "assets/fonts/GeneralSans-Regular.woff2"
  },
  "assets/fonts/GeneralSans-Semibold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Semibold.307d27c4.ttf",
    "src": "assets/fonts/GeneralSans-Semibold.ttf"
  },
  "assets/fonts/GeneralSans-Semibold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Semibold.eec4ab4c.woff",
    "src": "assets/fonts/GeneralSans-Semibold.woff"
  },
  "assets/fonts/GeneralSans-Semibold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Semibold.94a2a0e1.woff2",
    "src": "assets/fonts/GeneralSans-Semibold.woff2"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-SemiboldItalic.d3b62cb5.ttf",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.ttf"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-SemiboldItalic.cd1fca15.woff",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.woff"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-SemiboldItalic.98c7276f.woff2",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.woff2"
  },
  "assets/fonts/GeneralSans-Variable.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Variable.4b2539d9.ttf",
    "src": "assets/fonts/GeneralSans-Variable.ttf"
  },
  "assets/fonts/GeneralSans-Variable.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Variable.473d4f5e.woff",
    "src": "assets/fonts/GeneralSans-Variable.woff"
  },
  "assets/fonts/GeneralSans-Variable.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Variable.49d3fbd2.woff2",
    "src": "assets/fonts/GeneralSans-Variable.woff2"
  },
  "assets/fonts/GeneralSans-VariableItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-VariableItalic.4aa0c20d.ttf",
    "src": "assets/fonts/GeneralSans-VariableItalic.ttf"
  },
  "assets/fonts/GeneralSans-VariableItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-VariableItalic.c0b7f35e.woff",
    "src": "assets/fonts/GeneralSans-VariableItalic.woff"
  },
  "assets/fonts/GeneralSans-VariableItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-VariableItalic.71537245.woff2",
    "src": "assets/fonts/GeneralSans-VariableItalic.woff2"
  },
  "assets/fonts/PlusJakartaSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Bold.3e08701b.ttf",
    "src": "assets/fonts/PlusJakartaSans-Bold.ttf"
  },
  "assets/fonts/PlusJakartaSans-BoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-BoldItalic.4486ec3d.ttf",
    "src": "assets/fonts/PlusJakartaSans-BoldItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraBold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraBold.644fda57.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraBold.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraBoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraBoldItalic.d51b806e.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraBoldItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraLight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraLight.9afaedac.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraLight.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraLightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraLightItalic.b7523f1e.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraLightItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Italic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Italic.b15bc27e.ttf",
    "src": "assets/fonts/PlusJakartaSans-Italic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Light.26e26359.ttf",
    "src": "assets/fonts/PlusJakartaSans-Light.ttf"
  },
  "assets/fonts/PlusJakartaSans-LightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-LightItalic.22823a55.ttf",
    "src": "assets/fonts/PlusJakartaSans-LightItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Medium.d6854d4b.ttf",
    "src": "assets/fonts/PlusJakartaSans-Medium.ttf"
  },
  "assets/fonts/PlusJakartaSans-MediumItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-MediumItalic.67cb7ae5.ttf",
    "src": "assets/fonts/PlusJakartaSans-MediumItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Regular.f7e7cebd.ttf",
    "src": "assets/fonts/PlusJakartaSans-Regular.ttf"
  },
  "assets/fonts/PlusJakartaSans-SemiBold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-SemiBold.d32adf41.ttf",
    "src": "assets/fonts/PlusJakartaSans-SemiBold.ttf"
  },
  "assets/fonts/PlusJakartaSans-SemiBoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-SemiBoldItalic.48a17bbd.ttf",
    "src": "assets/fonts/PlusJakartaSans-SemiBoldItalic.ttf"
  },
  "layouts/admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.50423ad6.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_nofication.efe63601.js",
      "_hi-transfer-logo.9d118dbc.js",
      "_index.3f648032.js",
      "_config.ea66e5da.js",
      "_index.27906dea.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/admin.vue"
  },
  "layouts/auth.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth.555c041c.js",
    "imports": [
      "_Switch.vue.533843fb.js",
      "_client-only.bae35f15.js",
      "_hi-transfer-logo.9d118dbc.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/auth.vue"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.9d3a9b4c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Switch.vue.533843fb.js",
      "_FloatingWa.35238e63.js",
      "_client-only.bae35f15.js",
      "_hi-transfer-logo.9d118dbc.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_Container.b9395283.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "layouts/empty.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "empty.87a152f5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/empty.vue"
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "user.703cc789.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Switch.vue.533843fb.js",
      "_FloatingWa.35238e63.js",
      "_client-only.bae35f15.js",
      "_hi-transfer-logo.9d118dbc.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_Container.b9395283.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "middleware/admin.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.ccd4a817.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/admin.ts"
  },
  "middleware/auth.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth.ea7ed4a1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/auth.ts"
  },
  "middleware/guest.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "guest.29138d0b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/guest.ts"
  },
  "middleware/user.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "user.2274b895.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/user.ts"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Icon.6f5d80f8.css",
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.css"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Icon.792f666c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_config.ea66e5da.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.vue"
  },
  "Icon.6f5d80f8.css": {
    "file": "Icon.6f5d80f8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "IconCSS.fe0874d9.css",
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.css"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "IconCSS.bd79aeb8.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_config.ea66e5da.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.vue"
  },
  "IconCSS.fe0874d9.css": {
    "file": "IconCSS.fe0874d9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.2cc35f7b.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.2cc35f7b.css"
    ],
    "dynamicImports": [
      "middleware/admin.ts",
      "middleware/auth.ts",
      "middleware/guest.ts",
      "middleware/user.ts",
      "layouts/admin.vue",
      "layouts/auth.vue",
      "layouts/default.vue",
      "layouts/empty.vue",
      "layouts/user.vue"
    ],
    "file": "entry.9bb197db.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.2cc35f7b.css": {
    "file": "entry.2cc35f7b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/admin-list/[uuid]/edit.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "edit.059c0ff1.js",
    "imports": [
      "_TitleBack.99929c86.js",
      "_FormAdmin.vue.788d853b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_Alert.vue.a8555149.js",
      "_TransitionTopToBottom.c5ca4536.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.e95318ef.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/[uuid]/edit.vue"
  },
  "pages/admin/admin-list/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.96fa17f8.js",
    "imports": [
      "_TitleBack.99929c86.js",
      "_FormAdmin.vue.788d853b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_Alert.vue.a8555149.js",
      "_TransitionTopToBottom.c5ca4536.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.e95318ef.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/add.vue"
  },
  "pages/admin/admin-list/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.cab162dd.js",
    "imports": [
      "_ButtonAddAdmin.b7cb6b11.js",
      "_TitleAdmin.d9ac3a1d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_swiper-vue.f9dac270.js",
      "_config.ea66e5da.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/index.vue"
  },
  "pages/admin/destinations/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.5e4032a2.js",
    "imports": [
      "_TitleBack.99929c86.js",
      "_Destinations.ff6bf074.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.c5fb0729.js",
      "_useDestinations.22810def.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/add.vue"
  },
  "pages/admin/destinations/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.71e90749.js",
    "imports": [
      "_TitleBack.99929c86.js",
      "_Destinations.ff6bf074.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.c5fb0729.js",
      "_useDestinations.22810def.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/edit/[slug].vue"
  },
  "pages/admin/destinations/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.82a6be99.js",
    "imports": [
      "_ButtonAddAdmin.b7cb6b11.js",
      "_TitleAdmin.d9ac3a1d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.66017e5d.js",
      "_swiper-vue.f9dac270.js",
      "_useDestinations.22810def.js",
      "_config.ea66e5da.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/index.vue"
  },
  "pages/admin/driver/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.516a3821.js",
    "imports": [
      "_TitleBack.99929c86.js",
      "_Driver.1a22e4e5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.c5fb0729.js",
      "_useDriver.70ea93ed.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/add.vue"
  },
  "pages/admin/driver/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.ba81b4fe.js",
    "imports": [
      "_TitleBack.99929c86.js",
      "_Driver.1a22e4e5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.c5fb0729.js",
      "_useDriver.70ea93ed.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/edit/[slug].vue"
  },
  "pages/admin/driver/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.99ed8968.js",
    "imports": [
      "_ButtonAddAdmin.b7cb6b11.js",
      "_TitleAdmin.d9ac3a1d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.66017e5d.js",
      "_swiper-vue.f9dac270.js",
      "_useDriver.70ea93ed.js",
      "_config.ea66e5da.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/index.vue"
  },
  "pages/admin/email-verification/[token].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_token_.de759254.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/email-verification/[token].vue"
  },
  "pages/admin/facility-car/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.5160ecb8.js",
    "imports": [
      "_TitleBack.99929c86.js",
      "_FacilityCar.e4ba6799.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_clsx.0839fdbe.js",
      "_client-only.bae35f15.js",
      "_InputImageCropAdmin.00049c61.js",
      "_Modal.66017e5d.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_index.989c4c14.js",
      "_useSchema.c5fb0729.js",
      "_useFacility.939840a2.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/add.vue"
  },
  "pages/admin/facility-car/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.2df6e2ab.js",
    "imports": [
      "_TitleBack.99929c86.js",
      "_FacilityCar.e4ba6799.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_clsx.0839fdbe.js",
      "_client-only.bae35f15.js",
      "_InputImageCropAdmin.00049c61.js",
      "_Modal.66017e5d.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_index.989c4c14.js",
      "_useSchema.c5fb0729.js",
      "_useFacility.939840a2.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/edit/[slug].vue"
  },
  "pages/admin/facility-car/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.56096a2a.js",
    "imports": [
      "_ButtonAddAdmin.b7cb6b11.js",
      "_TitleAdmin.d9ac3a1d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.66017e5d.js",
      "_swiper-vue.f9dac270.js",
      "_useFacility.939840a2.js",
      "_config.ea66e5da.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/index.vue"
  },
  "pages/admin/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.f393da1b.js",
    "imports": [
      "_Change.vue.5353c472.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.3f648032.js",
      "_swiper-vue.f9dac270.js",
      "_Alert.vue.40f07a06.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_TransitionTopToBottom.c5ca4536.js",
      "_MTextField.vue.00f77f35.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MGroup.vue.8b30751e.js",
      "_TransitionX.e95318ef.js",
      "_Btn.vue.77dc26e2.js",
      "_useSchema.c5fb0729.js",
      "_InputOTP.vue.34ce9cc3.js",
      "_Group.vue.dbd5fea5.js",
      "_index.27906dea.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/forgot-password.vue"
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.1d37fed7.js",
    "imports": [
      "_HeadPage.vue.2fb6071b.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/index.vue"
  },
  "pages/admin/orders/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.dd31863d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_HeadPage.vue.2fb6071b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_PaginationAdmin.7a0a3d9d.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_config.ea66e5da.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/index.vue"
  },
  "pages/admin/orders/order-cars.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "order-cars.d95de671.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_HeadPage.vue.2fb6071b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_PaginationAdmin.7a0a3d9d.js",
      "_FormatMoneyDash.aea6127b.js",
      "_index.27906dea.js",
      "_swiper-vue.f9dac270.js",
      "_config.ea66e5da.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-cars.vue"
  },
  "pages/admin/orders/order-detail-car/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.5df659d9.js",
    "imports": [
      "_TitleAdminBack.8666969b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-detail-car/[slug].vue"
  },
  "pages/admin/orders/order-detail-tourpackage/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.a43e84ce.js",
    "imports": [
      "_TitleAdminBack.8666969b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-detail-tourpackage/[slug].vue"
  },
  "pages/admin/profile.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "profile.9289ea7b.js",
    "imports": [
      "_Alert.vue.a8555149.js",
      "_ChangePassword.625aa80f.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.8b30751e.js",
      "_useSchema.c5fb0729.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.efe63601.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_TransitionTopToBottom.c5ca4536.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_TransitionX.e95318ef.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "_usePasswordHelper.66d7e1e2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/profile.vue"
  },
  "pages/admin/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.cb2fe6cd.js",
    "imports": [
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.8b30751e.js",
      "_Btn.vue.77dc26e2.js",
      "_vee-validate.esm.c1170e9f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.c5fb0729.js",
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.e95318ef.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/sign-in.vue"
  },
  "pages/admin/tour-package/[slug]/edit.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "edit.4f3beaf7.js",
    "imports": [
      "_TitleBack.99929c86.js",
      "_TourPackage.2ce47ff8.js",
      "_useSchema.c5fb0729.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_DropdownsTest.66443284.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_client-only.bae35f15.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_clsx.0839fdbe.js",
      "_useTourPackage.014652ff.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/[slug]/edit.vue"
  },
  "pages/admin/tour-package/[slug]/images.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "images.1ec204b9.js",
    "imports": [
      "_TitleBack.99929c86.js",
      "_Alert.vue.a8555149.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Modal.66017e5d.js",
      "_index.3f648032.js",
      "_swiper-vue.f9dac270.js",
      "_client-only.bae35f15.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.989c4c14.js",
      "_TransitionTopToBottom.c5ca4536.js",
      "_config.ea66e5da.js",
      "_index.7d9a9c74.js",
      "_index.27906dea.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/[slug]/images.vue"
  },
  "pages/admin/tour-package/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.d202efb7.js",
    "imports": [
      "_TitleBack.99929c86.js",
      "_TourPackage.2ce47ff8.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_DropdownsTest.66443284.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_client-only.bae35f15.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_clsx.0839fdbe.js",
      "_useTourPackage.014652ff.js",
      "_nofication.efe63601.js",
      "_useSchema.c5fb0729.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/add.vue"
  },
  "pages/admin/tour-package/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.f7649311.js",
    "imports": [
      "_ButtonAddAdmin.b7cb6b11.js",
      "_TitleAdmin.d9ac3a1d.js",
      "_StatusTrueOrFalse.b4309c51.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.66017e5d.js",
      "_swiper-vue.f9dac270.js",
      "_useTourPackage.014652ff.js",
      "_FormatMoneyDash.aea6127b.js",
      "_config.ea66e5da.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/index.vue"
  },
  "pages/admin/transport/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.fe9d9020.js",
    "imports": [
      "_TitleBack.99929c86.js",
      "_Transport.dc579215.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputImageCropAdmin.00049c61.js",
      "_Modal.66017e5d.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_client-only.bae35f15.js",
      "_index.989c4c14.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_DropdownsTest.66443284.js",
      "_useSchema.c5fb0729.js",
      "_useTransport.c49d92c8.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/add.vue"
  },
  "pages/admin/transport/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.e61e469b.js",
    "imports": [
      "_TitleBack.99929c86.js",
      "_Transport.dc579215.js",
      "_useSchema.c5fb0729.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputImageCropAdmin.00049c61.js",
      "_Modal.66017e5d.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_client-only.bae35f15.js",
      "_index.989c4c14.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_DropdownsTest.66443284.js",
      "_useTransport.c49d92c8.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/edit/[slug].vue"
  },
  "pages/admin/transport/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.19308bac.js",
    "imports": [
      "_ButtonAddAdmin.b7cb6b11.js",
      "_TitleAdmin.d9ac3a1d.js",
      "_StatusTrueOrFalse.b4309c51.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.66017e5d.js",
      "_swiper-vue.f9dac270.js",
      "_useTransport.c49d92c8.js",
      "_FormatMoneyDash.aea6127b.js",
      "_config.ea66e5da.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/index.vue"
  },
  "pages/admin/users/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.d5939191.js",
    "imports": [
      "_TitleBack.99929c86.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/users/edit/[slug].vue"
  },
  "pages/admin/users/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.9dc28d94.js",
    "imports": [
      "_TitleAdmin.d9ac3a1d.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/users/index.vue"
  },
  "pages/auth-redirect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth-redirect.5bf8310c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/auth-redirect.vue"
  },
  "pages/email-verification/[token].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_token_.2725e0f9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/email-verification/[token].vue"
  },
  "pages/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.fd5d55ab.js",
    "imports": [
      "_Change.vue.5353c472.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.3f648032.js",
      "_swiper-vue.f9dac270.js",
      "_Alert.vue.40f07a06.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_TransitionTopToBottom.c5ca4536.js",
      "_MTextField.vue.00f77f35.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MGroup.vue.8b30751e.js",
      "_TransitionX.e95318ef.js",
      "_Btn.vue.77dc26e2.js",
      "_useSchema.c5fb0729.js",
      "_InputOTP.vue.34ce9cc3.js",
      "_Group.vue.dbd5fea5.js",
      "_index.27906dea.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/forgot-password.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.1392f658.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.85d433d5.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_clsx.0839fdbe.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.3f648032.js",
      "_index.7d9a9c74.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MGroup.vue.8b30751e.js",
      "_MTextField.vue.00f77f35.js",
      "_MSelect.vue.344734d3.js",
      "_Btn.vue.77dc26e2.js",
      "_nofication.efe63601.js",
      "_useSchema.c5fb0729.js",
      "_useCarStore.5d3ffa2e.js",
      "_useTourStore.f54ee4ac.js",
      "_Card.3ced18d9.js",
      "_Container.b9395283.js",
      "_CtaSection.vue.81c13cb2.js",
      "_config.ea66e5da.js",
      "_index.27906dea.js",
      "_TransitionX.e95318ef.js",
      "_FormatMoneyDash.aea6127b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.1392f658.css": {
    "file": "index.1392f658.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/payment-failed.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "payment-failed.d4795466.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/payment-failed.vue"
  },
  "pages/payment-successfull.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "payment-successfull.2cc6cc24.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/payment-successfull.vue"
  },
  "pages/privacy-policy.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "privacy-policy.700c503e.js",
    "imports": [
      "_Container.b9395283.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/privacy-policy.vue"
  },
  "pages/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.f9ada8f3.js",
    "imports": [
      "_Alert.vue.40f07a06.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.8b30751e.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.77dc26e2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.c5fb0729.js",
      "_usePasswordHelper.66d7e1e2.js",
      "_swiper-vue.f9dac270.js",
      "_TransitionTopToBottom.c5ca4536.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.e95318ef.js",
      "_config.ea66e5da.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign-in.vue"
  },
  "pages/sign-up.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-up.43d70179.js",
    "imports": [
      "_Alert.vue.40f07a06.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.8b30751e.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.77dc26e2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.c5fb0729.js",
      "_usePasswordHelper.66d7e1e2.js",
      "_swiper-vue.f9dac270.js",
      "_TransitionTopToBottom.c5ca4536.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.e95318ef.js",
      "_config.ea66e5da.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign-up.vue"
  },
  "pages/terms-and-refunds.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "terms-and-refunds.240710c4.js",
    "imports": [
      "_Container.b9395283.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/terms-and-refunds.vue"
  },
  "pages/terms-condition.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "terms-condition.5c457a81.js",
    "imports": [
      "_Container.b9395283.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/terms-condition.vue"
  },
  "pages/tours/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.e9156926.css",
    "src": "pages/tours/[slug].css"
  },
  "pages/tours/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.cf85ea57.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.b9395283.js",
      "_CtaSection.vue.81c13cb2.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.8b30751e.js",
      "_Btn.vue.77dc26e2.js",
      "_vee-validate.esm.c1170e9f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.c5fb0729.js",
      "_useTourStore.f54ee4ac.js",
      "_Modal.66017e5d.js",
      "_FormatMoneyDash.aea6127b.js",
      "_config.ea66e5da.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.e95318ef.js",
      "_nofication.efe63601.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/[slug].vue"
  },
  "_slug_.e9156926.css": {
    "file": "_slug_.e9156926.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/tours/booking/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkout.6629a369.js",
    "imports": [
      "_SelectedCard.vue.225d8c13.js",
      "_swiper-vue.f9dac270.js",
      "_FormatMoneyDash.aea6127b.js",
      "_Container.b9395283.js",
      "_useTourStore.f54ee4ac.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking/checkout.vue"
  },
  "pages/tours/booking/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.0feb0efe.js",
    "imports": [
      "_SelectedCard.vue.225d8c13.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.8b30751e.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useTourStore.f54ee4ac.js",
      "_swiper-vue.f9dac270.js",
      "_MSelect.vue.344734d3.js",
      "_Container.b9395283.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.e95318ef.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking/index.vue"
  },
  "pages/tours/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.aef4904b.js",
    "imports": [
      "_Btn.vue.77dc26e2.js",
      "_Container.b9395283.js",
      "_MSelect.vue.344734d3.js",
      "_MGroup.vue.8b30751e.js",
      "_Card.3ced18d9.js",
      "_Empty.1d65daef.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useTourStore.f54ee4ac.js",
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.e95318ef.js",
      "_FormatMoneyDash.aea6127b.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/index.vue"
  },
  "pages/user/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.601d3146.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Container.b9395283.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_config.ea66e5da.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/index.vue"
  },
  "pages/user/order/order-summary/car/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.9b0efbc7.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Container.b9395283.js",
      "_Verified.832ecc46.js",
      "_Modal.66017e5d.js",
      "_nofication.efe63601.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_config.ea66e5da.js",
      "_Alert.vue.a8555149.js",
      "_TransitionTopToBottom.c5ca4536.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputOTP.vue.34ce9cc3.js",
      "_useSchema.c5fb0729.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/order/order-summary/car/[slug].vue"
  },
  "pages/user/order/order-summary/tour/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.5d0c1459.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Container.b9395283.js",
      "_Verified.832ecc46.js",
      "_Modal.66017e5d.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_config.ea66e5da.js",
      "_Alert.vue.a8555149.js",
      "_TransitionTopToBottom.c5ca4536.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputOTP.vue.34ce9cc3.js",
      "_useSchema.c5fb0729.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/order/order-summary/tour/[slug].vue"
  },
  "pages/user/profile.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "profile.20a19c18.js",
    "imports": [
      "_Alert.vue.a8555149.js",
      "_ChangePassword.625aa80f.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.8b30751e.js",
      "_useSchema.c5fb0729.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.efe63601.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.ea66e5da.js",
      "_TransitionTopToBottom.c5ca4536.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_TransitionX.e95318ef.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "_usePasswordHelper.66d7e1e2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/profile.vue"
  },
  "pages/vehicles/booking.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "booking.c6002c09.js",
    "imports": [
      "_Btn.vue.77dc26e2.js",
      "_Container.b9395283.js",
      "_AddressInformation.vue.874d55ed.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.8b30751e.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.c5fb0729.js",
      "_useCarStore.5d3ffa2e.js",
      "_swiper-vue.f9dac270.js",
      "_SelectedCard.vue.58d16422.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.e95318ef.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/booking.vue"
  },
  "pages/vehicles/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkout.8c840513.js",
    "imports": [
      "_Btn.vue.77dc26e2.js",
      "_Container.b9395283.js",
      "_AddressInformation.vue.874d55ed.js",
      "_swiper-vue.f9dac270.js",
      "_SelectedCard.vue.58d16422.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useCarStore.5d3ffa2e.js",
      "_FormatMoneyDash.aea6127b.js",
      "_clsx.0839fdbe.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/checkout.vue"
  },
  "pages/vehicles/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.eaee60ff.js",
    "imports": [
      "_Btn.vue.77dc26e2.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.b9395283.js",
      "_AddressInformation.vue.874d55ed.js",
      "_MSelect.vue.344734d3.js",
      "_MGroup.vue.8b30751e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useCarStore.5d3ffa2e.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_Empty.1d65daef.js",
      "_clsx.0839fdbe.js",
      "_config.ea66e5da.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.e95318ef.js",
      "_nofication.efe63601.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/index.vue"
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.d33d3671.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
