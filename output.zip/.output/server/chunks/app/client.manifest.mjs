const client_manifest = {
  "Modal.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Modal.200da282.css",
    "src": "Modal.css"
  },
  "TourPackage.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "TourPackage.da417478.css",
    "src": "TourPackage.css"
  },
  "_AddressInformation.vue.874d55ed.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AddressInformation.vue.874d55ed.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Alert.vue.1f67701b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Alert.vue.1f67701b.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_TransitionTopToBottom.80a1678d.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Alert.vue.2bc3e474.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Alert.vue.2bc3e474.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_TransitionTopToBottom.80a1678d.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Btn.vue.77dc26e2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Btn.vue.77dc26e2.js",
    "imports": [
      "_clsx.0839fdbe.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_ButtonAddAdmin.0e74a4b6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddAdmin.0e74a4b6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Card.930c80d0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Card.930c80d0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useTourStore.68e5a867.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Change.vue.32c06571.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Change.vue.32c06571.js",
    "imports": [
      "_Alert.vue.1f67701b.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.9b7e5a8f.js",
      "_Btn.vue.77dc26e2.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.9cf65e3f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_InputOTP.vue.7597b1b1.js",
      "_TransitionX.c85110ef.js",
      "_Group.vue.dbd5fea5.js"
    ]
  },
  "_ChangePassword.173d0ca9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ChangePassword.173d0ca9.js",
    "imports": [
      "_Alert.vue.2bc3e474.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.7c745e28.js",
      "_swiper-vue.f9dac270.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.9b7e5a8f.js",
      "_useSchema.9cf65e3f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.94ff8438.js",
      "_TransitionX.c85110ef.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "_usePasswordHelper.66d7e1e2.js"
    ]
  },
  "_Container.a9267f38.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Container.a9267f38.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_CtaSection.vue.251acdd6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CtaSection.vue.251acdd6.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Default.vue.5c8b35f9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Default.vue.5c8b35f9.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_Container.a9267f38.js"
    ]
  },
  "_Destinations.aa98c38f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Destinations.aa98c38f.js",
    "imports": [
      "_TextFieldWLabel.vue.bae6c828.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.9cf65e3f.js",
      "_useDestinations.0e3ba5d9.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Driver.8c8cd317.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Driver.8c8cd317.js",
    "imports": [
      "_TextFieldWLabel.vue.bae6c828.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.9cf65e3f.js",
      "_useDriver.15d57446.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_DropdownsTest.fda820eb.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DropdownsTest.fda820eb.js",
    "imports": [
      "_vee-validate.esm.c1170e9f.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.7c745e28.js"
    ]
  },
  "_Empty.1d65daef.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Empty.1d65daef.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_FacilityCar.98d2103b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FacilityCar.98d2103b.js",
    "imports": [
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_InputImageCropAdmin.96181217.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.9cf65e3f.js",
      "_useFacility.63f5c58f.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_FormAdmin.vue.c9eeed15.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FormAdmin.vue.c9eeed15.js",
    "imports": [
      "_Alert.vue.2bc3e474.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.c85110ef.js",
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.94ff8438.js"
    ]
  },
  "_FormatMoneyDash.aea6127b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FormatMoneyDash.aea6127b.js"
  },
  "_Group.vue.dbd5fea5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Group.vue.dbd5fea5.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_HeadPage.vue.c6a84d3b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "HeadPage.vue.c6a84d3b.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_InputImageCropAdmin.96181217.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "InputImageCropAdmin.96181217.js",
    "imports": [
      "_Modal.76bfb28c.js",
      "_vee-validate.esm.c1170e9f.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_client-only.bae35f15.js",
      "_index.7c745e28.js",
      "_index.989c4c14.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_InputOTP.vue.7597b1b1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "InputOTP.vue.7597b1b1.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_MGroup.vue.9b7e5a8f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MGroup.vue.9b7e5a8f.js",
    "imports": [
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.c85110ef.js",
      "_clsx.0839fdbe.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_MSelect.vue.344734d3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MSelect.vue.344734d3.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js"
    ]
  },
  "_MTextField.vue.00f77f35.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MTextField.vue.00f77f35.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js"
    ]
  },
  "_Modal.76bfb28c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Modal.200da282.css"
    ],
    "file": "Modal.76bfb28c.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.f9dac270.js",
      "_index.7c745e28.js",
      "_index.7d9a9c74.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "Modal.200da282.css": {
    "file": "Modal.200da282.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_PaginationAdmin.7a0a3d9d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "PaginationAdmin.7a0a3d9d.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_SelectedCard.vue.225d8c13.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "SelectedCard.vue.225d8c13.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_SelectedCard.vue.dbb0b593.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "SelectedCard.vue.dbb0b593.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Switch.vue.f18e049c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Switch.vue.f18e049c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TabContent.vue.9e619e50.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TabContent.vue.9e619e50.js",
    "imports": [
      "_clsx.0839fdbe.js",
      "_swiper-vue.f9dac270.js",
      "_client-only.bae35f15.js"
    ]
  },
  "_TextFieldWLabel.vue.bae6c828.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TextFieldWLabel.vue.bae6c828.js",
    "imports": [
      "_vee-validate.esm.c1170e9f.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TitleAdmin.d9ac3a1d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleAdmin.d9ac3a1d.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TitleAdminBack.5a99adc4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleAdminBack.5a99adc4.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TitleBack.7966ebf3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleBack.7966ebf3.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TourPackage.99b6d6d5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "TourPackage.da417478.css"
    ],
    "file": "TourPackage.99b6d6d5.js",
    "imports": [
      "_TextFieldWLabel.vue.bae6c828.js",
      "_DropdownsTest.fda820eb.js",
      "_vee-validate.esm.c1170e9f.js",
      "_client-only.bae35f15.js",
      "_swiper-vue.f9dac270.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useTourPackage.18f44e27.js",
      "_index.7c745e28.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.9cf65e3f.js"
    ]
  },
  "TourPackage.da417478.css": {
    "file": "TourPackage.da417478.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TransitionTopToBottom.80a1678d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TransitionTopToBottom.80a1678d.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_TransitionX.c85110ef.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TransitionX.c85110ef.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_Transport.49180477.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Transport.49180477.js",
    "imports": [
      "_vee-validate.esm.c1170e9f.js",
      "_InputImageCropAdmin.96181217.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_DropdownsTest.fda820eb.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.9cf65e3f.js",
      "_useTransport.e6587f30.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Verified.f0eecdd8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Verified.f0eecdd8.js",
    "imports": [
      "_Alert.vue.2bc3e474.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputOTP.vue.7597b1b1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_useSchema.9cf65e3f.js"
    ]
  },
  "_client-only.bae35f15.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client-only.bae35f15.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_clsx.0839fdbe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "clsx.0839fdbe.js"
  },
  "_config.e95216ed.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.e95216ed.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_hi-transfer-logo.68c7064c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hi-transfer-logo.68c7064c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.3f323406.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.3f323406.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_index.7c745e28.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.7c745e28.js",
    "imports": [
      "_index.3f323406.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_index.7d9a9c74.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.7d9a9c74.js"
  },
  "_index.989c4c14.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.989c4c14.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_nofication.94ff8438.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nofication.94ff8438.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_swiper-vue.f9dac270.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.d33d3671.css"
    ],
    "file": "swiper-vue.f9dac270.js"
  },
  "swiper-vue.d33d3671.css": {
    "file": "swiper-vue.d33d3671.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useCarStore.52bc453e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useCarStore.52bc453e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.94ff8438.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useDestinations.0e3ba5d9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useDestinations.0e3ba5d9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.94ff8438.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useDriver.15d57446.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useDriver.15d57446.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.94ff8438.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useFacility.63f5c58f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useFacility.63f5c58f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.94ff8438.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_usePasswordHelper.66d7e1e2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "usePasswordHelper.66d7e1e2.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useSchema.9cf65e3f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useSchema.9cf65e3f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useTourPackage.18f44e27.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTourPackage.18f44e27.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.94ff8438.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useTourStore.68e5a867.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTourStore.68e5a867.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.94ff8438.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useTransport.e6587f30.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTransport.e6587f30.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.94ff8438.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_vee-validate.esm.c1170e9f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vee-validate.esm.c1170e9f.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "assets/fonts/ClashGrotesk-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Bold.c4ea1fe3.ttf",
    "src": "assets/fonts/ClashGrotesk-Bold.ttf"
  },
  "assets/fonts/ClashGrotesk-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Bold.b1b9970d.woff",
    "src": "assets/fonts/ClashGrotesk-Bold.woff"
  },
  "assets/fonts/ClashGrotesk-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Bold.602a56af.woff2",
    "src": "assets/fonts/ClashGrotesk-Bold.woff2"
  },
  "assets/fonts/ClashGrotesk-Extralight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Extralight.6417ca23.ttf",
    "src": "assets/fonts/ClashGrotesk-Extralight.ttf"
  },
  "assets/fonts/ClashGrotesk-Extralight.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Extralight.c9c2a3a9.woff",
    "src": "assets/fonts/ClashGrotesk-Extralight.woff"
  },
  "assets/fonts/ClashGrotesk-Extralight.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Extralight.fe206472.woff2",
    "src": "assets/fonts/ClashGrotesk-Extralight.woff2"
  },
  "assets/fonts/ClashGrotesk-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Light.8e98f3c7.ttf",
    "src": "assets/fonts/ClashGrotesk-Light.ttf"
  },
  "assets/fonts/ClashGrotesk-Light.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Light.04e1d585.woff",
    "src": "assets/fonts/ClashGrotesk-Light.woff"
  },
  "assets/fonts/ClashGrotesk-Light.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Light.f0f7605c.woff2",
    "src": "assets/fonts/ClashGrotesk-Light.woff2"
  },
  "assets/fonts/ClashGrotesk-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Medium.717fd45f.ttf",
    "src": "assets/fonts/ClashGrotesk-Medium.ttf"
  },
  "assets/fonts/ClashGrotesk-Medium.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Medium.94bcd03c.woff",
    "src": "assets/fonts/ClashGrotesk-Medium.woff"
  },
  "assets/fonts/ClashGrotesk-Medium.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Medium.5c3815cf.woff2",
    "src": "assets/fonts/ClashGrotesk-Medium.woff2"
  },
  "assets/fonts/ClashGrotesk-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Regular.5c66c57f.ttf",
    "src": "assets/fonts/ClashGrotesk-Regular.ttf"
  },
  "assets/fonts/ClashGrotesk-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Regular.1c248756.woff",
    "src": "assets/fonts/ClashGrotesk-Regular.woff"
  },
  "assets/fonts/ClashGrotesk-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Regular.03ad7ecf.woff2",
    "src": "assets/fonts/ClashGrotesk-Regular.woff2"
  },
  "assets/fonts/ClashGrotesk-Semibold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Semibold.bdc47ea3.ttf",
    "src": "assets/fonts/ClashGrotesk-Semibold.ttf"
  },
  "assets/fonts/ClashGrotesk-Semibold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Semibold.48fdb6da.woff",
    "src": "assets/fonts/ClashGrotesk-Semibold.woff"
  },
  "assets/fonts/ClashGrotesk-Semibold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Semibold.befc1942.woff2",
    "src": "assets/fonts/ClashGrotesk-Semibold.woff2"
  },
  "assets/fonts/ClashGrotesk-Variable.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Variable.5887a1df.ttf",
    "src": "assets/fonts/ClashGrotesk-Variable.ttf"
  },
  "assets/fonts/ClashGrotesk-Variable.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Variable.de7ab3f6.woff",
    "src": "assets/fonts/ClashGrotesk-Variable.woff"
  },
  "assets/fonts/ClashGrotesk-Variable.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Variable.3c56fcff.woff2",
    "src": "assets/fonts/ClashGrotesk-Variable.woff2"
  },
  "assets/fonts/GeneralSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Bold.1c435b33.ttf",
    "src": "assets/fonts/GeneralSans-Bold.ttf"
  },
  "assets/fonts/GeneralSans-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Bold.4c2b7f63.woff",
    "src": "assets/fonts/GeneralSans-Bold.woff"
  },
  "assets/fonts/GeneralSans-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Bold.a29eab9b.woff2",
    "src": "assets/fonts/GeneralSans-Bold.woff2"
  },
  "assets/fonts/GeneralSans-BoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-BoldItalic.2297ae79.ttf",
    "src": "assets/fonts/GeneralSans-BoldItalic.ttf"
  },
  "assets/fonts/GeneralSans-BoldItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-BoldItalic.0599ec69.woff",
    "src": "assets/fonts/GeneralSans-BoldItalic.woff"
  },
  "assets/fonts/GeneralSans-BoldItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-BoldItalic.97483640.woff2",
    "src": "assets/fonts/GeneralSans-BoldItalic.woff2"
  },
  "assets/fonts/GeneralSans-Extralight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Extralight.4cb07dad.ttf",
    "src": "assets/fonts/GeneralSans-Extralight.ttf"
  },
  "assets/fonts/GeneralSans-Extralight.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Extralight.6a52bdce.woff",
    "src": "assets/fonts/GeneralSans-Extralight.woff"
  },
  "assets/fonts/GeneralSans-Extralight.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Extralight.3e6ee7e5.woff2",
    "src": "assets/fonts/GeneralSans-Extralight.woff2"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-ExtralightItalic.9b80b399.ttf",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.ttf"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-ExtralightItalic.acc7311a.woff",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.woff"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-ExtralightItalic.83bbc211.woff2",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.woff2"
  },
  "assets/fonts/GeneralSans-Italic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Italic.ea19866f.ttf",
    "src": "assets/fonts/GeneralSans-Italic.ttf"
  },
  "assets/fonts/GeneralSans-Italic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Italic.f9e5a73e.woff",
    "src": "assets/fonts/GeneralSans-Italic.woff"
  },
  "assets/fonts/GeneralSans-Italic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Italic.1c91e1d3.woff2",
    "src": "assets/fonts/GeneralSans-Italic.woff2"
  },
  "assets/fonts/GeneralSans-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Light.86a255b5.ttf",
    "src": "assets/fonts/GeneralSans-Light.ttf"
  },
  "assets/fonts/GeneralSans-Light.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Light.09f0f0fe.woff",
    "src": "assets/fonts/GeneralSans-Light.woff"
  },
  "assets/fonts/GeneralSans-Light.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Light.ac0b8f29.woff2",
    "src": "assets/fonts/GeneralSans-Light.woff2"
  },
  "assets/fonts/GeneralSans-LightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-LightItalic.eb313a89.ttf",
    "src": "assets/fonts/GeneralSans-LightItalic.ttf"
  },
  "assets/fonts/GeneralSans-LightItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-LightItalic.639de7d9.woff",
    "src": "assets/fonts/GeneralSans-LightItalic.woff"
  },
  "assets/fonts/GeneralSans-LightItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-LightItalic.7787625d.woff2",
    "src": "assets/fonts/GeneralSans-LightItalic.woff2"
  },
  "assets/fonts/GeneralSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Medium.e85572fe.ttf",
    "src": "assets/fonts/GeneralSans-Medium.ttf"
  },
  "assets/fonts/GeneralSans-Medium.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Medium.f5beb161.woff",
    "src": "assets/fonts/GeneralSans-Medium.woff"
  },
  "assets/fonts/GeneralSans-Medium.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Medium.c30377df.woff2",
    "src": "assets/fonts/GeneralSans-Medium.woff2"
  },
  "assets/fonts/GeneralSans-MediumItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-MediumItalic.3b4e2f45.ttf",
    "src": "assets/fonts/GeneralSans-MediumItalic.ttf"
  },
  "assets/fonts/GeneralSans-MediumItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-MediumItalic.d02080e7.woff",
    "src": "assets/fonts/GeneralSans-MediumItalic.woff"
  },
  "assets/fonts/GeneralSans-MediumItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-MediumItalic.ffe0560d.woff2",
    "src": "assets/fonts/GeneralSans-MediumItalic.woff2"
  },
  "assets/fonts/GeneralSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Regular.0723d125.ttf",
    "src": "assets/fonts/GeneralSans-Regular.ttf"
  },
  "assets/fonts/GeneralSans-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Regular.52af118f.woff",
    "src": "assets/fonts/GeneralSans-Regular.woff"
  },
  "assets/fonts/GeneralSans-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Regular.3ec2be77.woff2",
    "src": "assets/fonts/GeneralSans-Regular.woff2"
  },
  "assets/fonts/GeneralSans-Semibold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Semibold.307d27c4.ttf",
    "src": "assets/fonts/GeneralSans-Semibold.ttf"
  },
  "assets/fonts/GeneralSans-Semibold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Semibold.eec4ab4c.woff",
    "src": "assets/fonts/GeneralSans-Semibold.woff"
  },
  "assets/fonts/GeneralSans-Semibold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Semibold.94a2a0e1.woff2",
    "src": "assets/fonts/GeneralSans-Semibold.woff2"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-SemiboldItalic.d3b62cb5.ttf",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.ttf"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-SemiboldItalic.cd1fca15.woff",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.woff"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-SemiboldItalic.98c7276f.woff2",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.woff2"
  },
  "assets/fonts/GeneralSans-Variable.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Variable.4b2539d9.ttf",
    "src": "assets/fonts/GeneralSans-Variable.ttf"
  },
  "assets/fonts/GeneralSans-Variable.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Variable.473d4f5e.woff",
    "src": "assets/fonts/GeneralSans-Variable.woff"
  },
  "assets/fonts/GeneralSans-Variable.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Variable.49d3fbd2.woff2",
    "src": "assets/fonts/GeneralSans-Variable.woff2"
  },
  "assets/fonts/GeneralSans-VariableItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-VariableItalic.4aa0c20d.ttf",
    "src": "assets/fonts/GeneralSans-VariableItalic.ttf"
  },
  "assets/fonts/GeneralSans-VariableItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-VariableItalic.c0b7f35e.woff",
    "src": "assets/fonts/GeneralSans-VariableItalic.woff"
  },
  "assets/fonts/GeneralSans-VariableItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-VariableItalic.71537245.woff2",
    "src": "assets/fonts/GeneralSans-VariableItalic.woff2"
  },
  "assets/fonts/PlusJakartaSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Bold.3e08701b.ttf",
    "src": "assets/fonts/PlusJakartaSans-Bold.ttf"
  },
  "assets/fonts/PlusJakartaSans-BoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-BoldItalic.4486ec3d.ttf",
    "src": "assets/fonts/PlusJakartaSans-BoldItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraBold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraBold.644fda57.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraBold.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraBoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraBoldItalic.d51b806e.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraBoldItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraLight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraLight.9afaedac.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraLight.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraLightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraLightItalic.b7523f1e.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraLightItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Italic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Italic.b15bc27e.ttf",
    "src": "assets/fonts/PlusJakartaSans-Italic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Light.26e26359.ttf",
    "src": "assets/fonts/PlusJakartaSans-Light.ttf"
  },
  "assets/fonts/PlusJakartaSans-LightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-LightItalic.22823a55.ttf",
    "src": "assets/fonts/PlusJakartaSans-LightItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Medium.d6854d4b.ttf",
    "src": "assets/fonts/PlusJakartaSans-Medium.ttf"
  },
  "assets/fonts/PlusJakartaSans-MediumItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-MediumItalic.67cb7ae5.ttf",
    "src": "assets/fonts/PlusJakartaSans-MediumItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Regular.f7e7cebd.ttf",
    "src": "assets/fonts/PlusJakartaSans-Regular.ttf"
  },
  "assets/fonts/PlusJakartaSans-SemiBold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-SemiBold.d32adf41.ttf",
    "src": "assets/fonts/PlusJakartaSans-SemiBold.ttf"
  },
  "assets/fonts/PlusJakartaSans-SemiBoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-SemiBoldItalic.48a17bbd.ttf",
    "src": "assets/fonts/PlusJakartaSans-SemiBoldItalic.ttf"
  },
  "layouts/admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.ce81788c.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_nofication.94ff8438.js",
      "_hi-transfer-logo.68c7064c.js",
      "_index.7c745e28.js",
      "_config.e95216ed.js",
      "_index.3f323406.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/admin.vue"
  },
  "layouts/auth.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth.ba9788a5.js",
    "imports": [
      "_Switch.vue.f18e049c.js",
      "_client-only.bae35f15.js",
      "_hi-transfer-logo.68c7064c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/auth.vue"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.dc85ef43.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Switch.vue.f18e049c.js",
      "_Default.vue.5c8b35f9.js",
      "_client-only.bae35f15.js",
      "_hi-transfer-logo.68c7064c.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_Container.a9267f38.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "layouts/empty.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "empty.0125bad0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/empty.vue"
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "user.cd035214.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Switch.vue.f18e049c.js",
      "_Default.vue.5c8b35f9.js",
      "_client-only.bae35f15.js",
      "_hi-transfer-logo.68c7064c.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_Container.a9267f38.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "middleware/admin.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.ee0dd600.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/admin.ts"
  },
  "middleware/auth.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth.210afcc1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/auth.ts"
  },
  "middleware/guest.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "guest.92d95085.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/guest.ts"
  },
  "middleware/user.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "user.980668c9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/user.ts"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Icon.6f5d80f8.css",
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.css"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Icon.9e737a38.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_config.e95216ed.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.vue"
  },
  "Icon.6f5d80f8.css": {
    "file": "Icon.6f5d80f8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "IconCSS.fe0874d9.css",
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.css"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "IconCSS.f73ac668.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_config.e95216ed.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.vue"
  },
  "IconCSS.fe0874d9.css": {
    "file": "IconCSS.fe0874d9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.2cc35f7b.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.2cc35f7b.css"
    ],
    "dynamicImports": [
      "middleware/admin.ts",
      "middleware/auth.ts",
      "middleware/guest.ts",
      "middleware/user.ts",
      "layouts/admin.vue",
      "layouts/auth.vue",
      "layouts/default.vue",
      "layouts/empty.vue",
      "layouts/user.vue"
    ],
    "file": "entry.6d5aed04.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.2cc35f7b.css": {
    "file": "entry.2cc35f7b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/admin-list/[uuid]/edit.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "edit.acb1e526.js",
    "imports": [
      "_TitleBack.7966ebf3.js",
      "_FormAdmin.vue.c9eeed15.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_Alert.vue.2bc3e474.js",
      "_TransitionTopToBottom.80a1678d.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.c85110ef.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/[uuid]/edit.vue"
  },
  "pages/admin/admin-list/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.8dbc0ca0.js",
    "imports": [
      "_TitleBack.7966ebf3.js",
      "_FormAdmin.vue.c9eeed15.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_Alert.vue.2bc3e474.js",
      "_TransitionTopToBottom.80a1678d.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.c85110ef.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/add.vue"
  },
  "pages/admin/admin-list/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.fe317f98.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_TitleAdmin.d9ac3a1d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_PaginationAdmin.7a0a3d9d.js",
      "_index.3f323406.js",
      "_swiper-vue.f9dac270.js",
      "_config.e95216ed.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/index.vue"
  },
  "pages/admin/destinations/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.0af0c475.js",
    "imports": [
      "_TitleBack.7966ebf3.js",
      "_Destinations.aa98c38f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.9cf65e3f.js",
      "_useDestinations.0e3ba5d9.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/add.vue"
  },
  "pages/admin/destinations/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.ac78e5e6.js",
    "imports": [
      "_TitleBack.7966ebf3.js",
      "_Destinations.aa98c38f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.9cf65e3f.js",
      "_useDestinations.0e3ba5d9.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/edit/[slug].vue"
  },
  "pages/admin/destinations/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.3b514d56.js",
    "imports": [
      "_ButtonAddAdmin.0e74a4b6.js",
      "_TitleAdmin.d9ac3a1d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.76bfb28c.js",
      "_swiper-vue.f9dac270.js",
      "_useDestinations.0e3ba5d9.js",
      "_index.3f323406.js",
      "_config.e95216ed.js",
      "_index.7c745e28.js",
      "_index.7d9a9c74.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/index.vue"
  },
  "pages/admin/driver/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.6274a321.js",
    "imports": [
      "_TitleBack.7966ebf3.js",
      "_Driver.8c8cd317.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.9cf65e3f.js",
      "_useDriver.15d57446.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/add.vue"
  },
  "pages/admin/driver/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.2a76b46c.js",
    "imports": [
      "_TitleBack.7966ebf3.js",
      "_Driver.8c8cd317.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.9cf65e3f.js",
      "_useDriver.15d57446.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/edit/[slug].vue"
  },
  "pages/admin/driver/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.65675336.js",
    "imports": [
      "_ButtonAddAdmin.0e74a4b6.js",
      "_TitleAdmin.d9ac3a1d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.76bfb28c.js",
      "_swiper-vue.f9dac270.js",
      "_useDriver.15d57446.js",
      "_index.3f323406.js",
      "_config.e95216ed.js",
      "_index.7c745e28.js",
      "_index.7d9a9c74.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/index.vue"
  },
  "pages/admin/email-verification/[token].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_token_.12a9bcaa.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/email-verification/[token].vue"
  },
  "pages/admin/facility-car/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.49fece92.js",
    "imports": [
      "_TitleBack.7966ebf3.js",
      "_FacilityCar.98d2103b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_clsx.0839fdbe.js",
      "_client-only.bae35f15.js",
      "_InputImageCropAdmin.96181217.js",
      "_Modal.76bfb28c.js",
      "_index.7c745e28.js",
      "_index.3f323406.js",
      "_index.7d9a9c74.js",
      "_index.989c4c14.js",
      "_useSchema.9cf65e3f.js",
      "_useFacility.63f5c58f.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/add.vue"
  },
  "pages/admin/facility-car/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.5b3af474.js",
    "imports": [
      "_TitleBack.7966ebf3.js",
      "_FacilityCar.98d2103b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_clsx.0839fdbe.js",
      "_client-only.bae35f15.js",
      "_InputImageCropAdmin.96181217.js",
      "_Modal.76bfb28c.js",
      "_index.7c745e28.js",
      "_index.3f323406.js",
      "_index.7d9a9c74.js",
      "_index.989c4c14.js",
      "_useSchema.9cf65e3f.js",
      "_useFacility.63f5c58f.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/edit/[slug].vue"
  },
  "pages/admin/facility-car/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.c72677f6.js",
    "imports": [
      "_ButtonAddAdmin.0e74a4b6.js",
      "_TitleAdmin.d9ac3a1d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.76bfb28c.js",
      "_swiper-vue.f9dac270.js",
      "_useFacility.63f5c58f.js",
      "_index.3f323406.js",
      "_config.e95216ed.js",
      "_index.7c745e28.js",
      "_index.7d9a9c74.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/index.vue"
  },
  "pages/admin/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.57aed1a7.js",
    "imports": [
      "_Change.vue.32c06571.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.7c745e28.js",
      "_swiper-vue.f9dac270.js",
      "_Alert.vue.1f67701b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_TransitionTopToBottom.80a1678d.js",
      "_MTextField.vue.00f77f35.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MGroup.vue.9b7e5a8f.js",
      "_TransitionX.c85110ef.js",
      "_Btn.vue.77dc26e2.js",
      "_useSchema.9cf65e3f.js",
      "_InputOTP.vue.7597b1b1.js",
      "_Group.vue.dbd5fea5.js",
      "_index.3f323406.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/forgot-password.vue"
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.0358e7bc.js",
    "imports": [
      "_HeadPage.vue.c6a84d3b.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/index.vue"
  },
  "pages/admin/orders/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.f7e4ff97.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_HeadPage.vue.c6a84d3b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_PaginationAdmin.7a0a3d9d.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_index.3f323406.js",
      "_config.e95216ed.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/index.vue"
  },
  "pages/admin/orders/order-cars.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "order-cars.2aa3c7db.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_HeadPage.vue.c6a84d3b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_PaginationAdmin.7a0a3d9d.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_index.3f323406.js",
      "_config.e95216ed.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-cars.vue"
  },
  "pages/admin/orders/order-detail-car/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.f767358c.js",
    "imports": [
      "_TitleAdminBack.5a99adc4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-detail-car/[slug].vue"
  },
  "pages/admin/orders/order-detail-tourpackage/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.ae28b565.js",
    "imports": [
      "_TitleAdminBack.5a99adc4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-detail-tourpackage/[slug].vue"
  },
  "pages/admin/profile.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "profile.fc19fc0a.js",
    "imports": [
      "_ChangePassword.173d0ca9.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_Alert.vue.2bc3e474.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_TransitionTopToBottom.80a1678d.js",
      "_index.7c745e28.js",
      "_index.3f323406.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MTextField.vue.00f77f35.js",
      "_clsx.0839fdbe.js",
      "_MGroup.vue.9b7e5a8f.js",
      "_TransitionX.c85110ef.js",
      "_useSchema.9cf65e3f.js",
      "_nofication.94ff8438.js",
      "_Group.vue.dbd5fea5.js",
      "_usePasswordHelper.66d7e1e2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/profile.vue"
  },
  "pages/admin/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.df02bc91.js",
    "imports": [
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.9b7e5a8f.js",
      "_Btn.vue.77dc26e2.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.9cf65e3f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.c85110ef.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/sign-in.vue"
  },
  "pages/admin/tour-package/[slug]/edit.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "edit.20411ce1.js",
    "imports": [
      "_TitleBack.7966ebf3.js",
      "_TourPackage.99b6d6d5.js",
      "_useSchema.9cf65e3f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_DropdownsTest.fda820eb.js",
      "_index.7c745e28.js",
      "_index.3f323406.js",
      "_client-only.bae35f15.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_clsx.0839fdbe.js",
      "_useTourPackage.18f44e27.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/[slug]/edit.vue"
  },
  "pages/admin/tour-package/[slug]/images.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "images.92bc0c88.js",
    "imports": [
      "_TitleBack.7966ebf3.js",
      "_Alert.vue.2bc3e474.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Modal.76bfb28c.js",
      "_index.7c745e28.js",
      "_swiper-vue.f9dac270.js",
      "_client-only.bae35f15.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.989c4c14.js",
      "_TransitionTopToBottom.80a1678d.js",
      "_config.e95216ed.js",
      "_index.7d9a9c74.js",
      "_index.3f323406.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/[slug]/images.vue"
  },
  "pages/admin/tour-package/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.88174ef0.js",
    "imports": [
      "_TitleBack.7966ebf3.js",
      "_TourPackage.99b6d6d5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_DropdownsTest.fda820eb.js",
      "_index.7c745e28.js",
      "_index.3f323406.js",
      "_client-only.bae35f15.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_clsx.0839fdbe.js",
      "_useTourPackage.18f44e27.js",
      "_nofication.94ff8438.js",
      "_useSchema.9cf65e3f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/add.vue"
  },
  "pages/admin/tour-package/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.7b8ca9c5.js",
    "imports": [
      "_ButtonAddAdmin.0e74a4b6.js",
      "_TitleAdmin.d9ac3a1d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.76bfb28c.js",
      "_swiper-vue.f9dac270.js",
      "_useTourPackage.18f44e27.js",
      "_FormatMoneyDash.aea6127b.js",
      "_index.3f323406.js",
      "_config.e95216ed.js",
      "_index.7c745e28.js",
      "_index.7d9a9c74.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/index.vue"
  },
  "pages/admin/transport/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.8559b17a.js",
    "imports": [
      "_TitleBack.7966ebf3.js",
      "_Transport.49180477.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputImageCropAdmin.96181217.js",
      "_Modal.76bfb28c.js",
      "_index.7c745e28.js",
      "_index.3f323406.js",
      "_index.7d9a9c74.js",
      "_client-only.bae35f15.js",
      "_index.989c4c14.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_DropdownsTest.fda820eb.js",
      "_useSchema.9cf65e3f.js",
      "_useTransport.e6587f30.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/add.vue"
  },
  "pages/admin/transport/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.8d7e6865.js",
    "imports": [
      "_TitleBack.7966ebf3.js",
      "_Transport.49180477.js",
      "_useSchema.9cf65e3f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputImageCropAdmin.96181217.js",
      "_Modal.76bfb28c.js",
      "_index.7c745e28.js",
      "_index.3f323406.js",
      "_index.7d9a9c74.js",
      "_client-only.bae35f15.js",
      "_index.989c4c14.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_DropdownsTest.fda820eb.js",
      "_useTransport.e6587f30.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/edit/[slug].vue"
  },
  "pages/admin/transport/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.818f56b6.js",
    "imports": [
      "_ButtonAddAdmin.0e74a4b6.js",
      "_TitleAdmin.d9ac3a1d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.76bfb28c.js",
      "_useTransport.e6587f30.js",
      "_FormatMoneyDash.aea6127b.js",
      "_index.3f323406.js",
      "_config.e95216ed.js",
      "_index.7c745e28.js",
      "_index.7d9a9c74.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/index.vue"
  },
  "pages/admin/users/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.1e415ada.js",
    "imports": [
      "_TitleBack.7966ebf3.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/users/edit/[slug].vue"
  },
  "pages/admin/users/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.0d726da4.js",
    "imports": [
      "_TitleAdmin.d9ac3a1d.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/users/index.vue"
  },
  "pages/auth-redirect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth-redirect.1bc01f03.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/auth-redirect.vue"
  },
  "pages/email-verification/[token].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_token_.67bd3f7b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/email-verification/[token].vue"
  },
  "pages/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.a256a5cf.js",
    "imports": [
      "_Change.vue.32c06571.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.7c745e28.js",
      "_swiper-vue.f9dac270.js",
      "_Alert.vue.1f67701b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_TransitionTopToBottom.80a1678d.js",
      "_MTextField.vue.00f77f35.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MGroup.vue.9b7e5a8f.js",
      "_TransitionX.c85110ef.js",
      "_Btn.vue.77dc26e2.js",
      "_useSchema.9cf65e3f.js",
      "_InputOTP.vue.7597b1b1.js",
      "_Group.vue.dbd5fea5.js",
      "_index.3f323406.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/forgot-password.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.497a60e3.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.ba88c2ea.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_clsx.0839fdbe.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.7c745e28.js",
      "_index.7d9a9c74.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MGroup.vue.9b7e5a8f.js",
      "_MTextField.vue.00f77f35.js",
      "_MSelect.vue.344734d3.js",
      "_Btn.vue.77dc26e2.js",
      "_nofication.94ff8438.js",
      "_useSchema.9cf65e3f.js",
      "_useCarStore.52bc453e.js",
      "_useTourStore.68e5a867.js",
      "_Card.930c80d0.js",
      "_Container.a9267f38.js",
      "_CtaSection.vue.251acdd6.js",
      "_config.e95216ed.js",
      "_index.3f323406.js",
      "_TransitionX.c85110ef.js",
      "_FormatMoneyDash.aea6127b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.497a60e3.css": {
    "file": "index.497a60e3.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/payment-failed.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "payment-failed.9813b164.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/payment-failed.vue"
  },
  "pages/payment-successfull.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "payment-successfull.b2d1af73.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/payment-successfull.vue"
  },
  "pages/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.cdc00181.js",
    "imports": [
      "_Alert.vue.1f67701b.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.9b7e5a8f.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.77dc26e2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.9cf65e3f.js",
      "_usePasswordHelper.66d7e1e2.js",
      "_swiper-vue.f9dac270.js",
      "_TransitionTopToBottom.80a1678d.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.c85110ef.js",
      "_config.e95216ed.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign-in.vue"
  },
  "pages/sign-up.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-up.470fda62.js",
    "imports": [
      "_Alert.vue.1f67701b.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.9b7e5a8f.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.77dc26e2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.9cf65e3f.js",
      "_usePasswordHelper.66d7e1e2.js",
      "_swiper-vue.f9dac270.js",
      "_TransitionTopToBottom.80a1678d.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.c85110ef.js",
      "_config.e95216ed.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign-up.vue"
  },
  "pages/tours/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.d5f49000.css",
    "src": "pages/tours/[slug].css"
  },
  "pages/tours/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.7b92ad2f.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.a9267f38.js",
      "_CtaSection.vue.251acdd6.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.9b7e5a8f.js",
      "_Btn.vue.77dc26e2.js",
      "_vee-validate.esm.c1170e9f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.9cf65e3f.js",
      "_useTourStore.68e5a867.js",
      "_Modal.76bfb28c.js",
      "_FormatMoneyDash.aea6127b.js",
      "_config.e95216ed.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.c85110ef.js",
      "_nofication.94ff8438.js",
      "_index.7c745e28.js",
      "_index.3f323406.js",
      "_index.7d9a9c74.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/[slug].vue"
  },
  "_slug_.d5f49000.css": {
    "file": "_slug_.d5f49000.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/tours/booking/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkout.de62c6eb.js",
    "imports": [
      "_SelectedCard.vue.225d8c13.js",
      "_swiper-vue.f9dac270.js",
      "_FormatMoneyDash.aea6127b.js",
      "_Container.a9267f38.js",
      "_useTourStore.68e5a867.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking/checkout.vue"
  },
  "pages/tours/booking/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.ba412b13.js",
    "imports": [
      "_SelectedCard.vue.225d8c13.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.9b7e5a8f.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useTourStore.68e5a867.js",
      "_swiper-vue.f9dac270.js",
      "_MSelect.vue.344734d3.js",
      "_Container.a9267f38.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.c85110ef.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking/index.vue"
  },
  "pages/tours/bookingss.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "bookingss.eb63da9d.js",
    "imports": [
      "_SelectedCard.vue.225d8c13.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_Container.a9267f38.js",
      "_Btn.vue.77dc26e2.js",
      "_useTourStore.68e5a867.js",
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/bookingss.vue"
  },
  "pages/tours/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.7f33fc65.js",
    "imports": [
      "_Btn.vue.77dc26e2.js",
      "_Container.a9267f38.js",
      "_MSelect.vue.344734d3.js",
      "_MGroup.vue.9b7e5a8f.js",
      "_Card.930c80d0.js",
      "_Empty.1d65daef.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useTourStore.68e5a867.js",
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.c85110ef.js",
      "_FormatMoneyDash.aea6127b.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/index.vue"
  },
  "pages/user/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.cce3eed2.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Container.a9267f38.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_config.e95216ed.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/index.vue"
  },
  "pages/user/order/order-summary/car/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.5164f530.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Container.a9267f38.js",
      "_Verified.f0eecdd8.js",
      "_Modal.76bfb28c.js",
      "_nofication.94ff8438.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_config.e95216ed.js",
      "_Alert.vue.2bc3e474.js",
      "_TransitionTopToBottom.80a1678d.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputOTP.vue.7597b1b1.js",
      "_useSchema.9cf65e3f.js",
      "_index.7c745e28.js",
      "_index.3f323406.js",
      "_index.7d9a9c74.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/order/order-summary/car/[slug].vue"
  },
  "pages/user/order/order-summary/tour/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.1bcd681a.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Container.a9267f38.js",
      "_Verified.f0eecdd8.js",
      "_Modal.76bfb28c.js",
      "_nofication.94ff8438.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_config.e95216ed.js",
      "_Alert.vue.2bc3e474.js",
      "_TransitionTopToBottom.80a1678d.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputOTP.vue.7597b1b1.js",
      "_useSchema.9cf65e3f.js",
      "_index.7c745e28.js",
      "_index.3f323406.js",
      "_index.7d9a9c74.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/order/order-summary/tour/[slug].vue"
  },
  "pages/user/profile.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "profile.e3b0ee36.js",
    "imports": [
      "_ChangePassword.173d0ca9.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_Alert.vue.2bc3e474.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e95216ed.js",
      "_TransitionTopToBottom.80a1678d.js",
      "_index.7c745e28.js",
      "_index.3f323406.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MTextField.vue.00f77f35.js",
      "_clsx.0839fdbe.js",
      "_MGroup.vue.9b7e5a8f.js",
      "_TransitionX.c85110ef.js",
      "_useSchema.9cf65e3f.js",
      "_nofication.94ff8438.js",
      "_Group.vue.dbd5fea5.js",
      "_usePasswordHelper.66d7e1e2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/profile.vue"
  },
  "pages/vehicles/booking.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "booking.9facbef8.js",
    "imports": [
      "_Btn.vue.77dc26e2.js",
      "_Container.a9267f38.js",
      "_AddressInformation.vue.874d55ed.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.9b7e5a8f.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.9cf65e3f.js",
      "_useCarStore.52bc453e.js",
      "_swiper-vue.f9dac270.js",
      "_SelectedCard.vue.dbb0b593.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.c85110ef.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/booking.vue"
  },
  "pages/vehicles/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkout.86cde1b0.js",
    "imports": [
      "_Btn.vue.77dc26e2.js",
      "_Container.a9267f38.js",
      "_AddressInformation.vue.874d55ed.js",
      "_swiper-vue.f9dac270.js",
      "_SelectedCard.vue.dbb0b593.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useCarStore.52bc453e.js",
      "_FormatMoneyDash.aea6127b.js",
      "_clsx.0839fdbe.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/checkout.vue"
  },
  "pages/vehicles/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.b37d01e6.js",
    "imports": [
      "_Btn.vue.77dc26e2.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.a9267f38.js",
      "_AddressInformation.vue.874d55ed.js",
      "_MSelect.vue.344734d3.js",
      "_MGroup.vue.9b7e5a8f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useCarStore.52bc453e.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_Empty.1d65daef.js",
      "_clsx.0839fdbe.js",
      "_config.e95216ed.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.c85110ef.js",
      "_nofication.94ff8438.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/index.vue"
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.d33d3671.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
