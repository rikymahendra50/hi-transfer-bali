const client_manifest = {
  "Modal.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Modal.200da282.css",
    "src": "Modal.css"
  },
  "TourPackage.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "TourPackage.da417478.css",
    "src": "TourPackage.css"
  },
  "_AddressInformation.vue.6ff36c09.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AddressInformation.vue.6ff36c09.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_Alert.vue.b43fd441.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Alert.vue.b43fd441.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_TransitionTopToBottom.edd8bb8c.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_Alert.vue.ee06ff17.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Alert.vue.ee06ff17.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_TransitionTopToBottom.edd8bb8c.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_Btn.vue.0e457d86.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Btn.vue.0e457d86.js",
    "imports": [
      "_clsx.0839fdbe.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_ButtonAddAdmin.51c5f930.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddAdmin.51c5f930.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_Card.3c3cdea0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Card.3c3cdea0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_Change.vue.eb827dd9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Change.vue.eb827dd9.js",
    "imports": [
      "_Alert.vue.b43fd441.js",
      "_MTextField.vue.814f1dbe.js",
      "_MGroup.vue.9d22adaa.js",
      "_Btn.vue.0e457d86.js",
      "_vee-validate.esm.e2b400e5.js",
      "_useSchema.932d210d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "_InputOTP.vue.15a59199.js",
      "_Group.vue.92001ab3.js"
    ]
  },
  "_ChangePassword.edc839ba.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ChangePassword.edc839ba.js",
    "imports": [
      "_Alert.vue.ee06ff17.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.d7809de7.js",
      "_swiper-vue.fb38f7cd.js",
      "_vee-validate.esm.e2b400e5.js",
      "_MTextField.vue.814f1dbe.js",
      "_MGroup.vue.9d22adaa.js",
      "_useSchema.932d210d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.9cf9c57f.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.92001ab3.js",
      "_usePasswordHelper.98f23841.js"
    ]
  },
  "_Container.54dbe1d1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Container.54dbe1d1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_CtaSection.vue.2b2713c7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CtaSection.vue.2b2713c7.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_Default.vue.89de9292.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Default.vue.89de9292.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "_Container.54dbe1d1.js"
    ]
  },
  "_Destinations.e56aa04f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Destinations.e56aa04f.js",
    "imports": [
      "_TextFieldWLabel.vue.fe3347fa.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.e2b400e5.js",
      "_useSchema.932d210d.js",
      "_useDestinations.e345f80f.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_Driver.265b603b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Driver.265b603b.js",
    "imports": [
      "_TextFieldWLabel.vue.fe3347fa.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.e2b400e5.js",
      "_useSchema.932d210d.js",
      "_useDriver.44893058.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_DropdownsTest.848cecb4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DropdownsTest.848cecb4.js",
    "imports": [
      "_vee-validate.esm.e2b400e5.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.d7809de7.js"
    ]
  },
  "_Empty.b90e105b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Empty.b90e105b.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_FacilityCar.bf5b1bb8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FacilityCar.bf5b1bb8.js",
    "imports": [
      "_TextFieldWLabel.vue.fe3347fa.js",
      "_vee-validate.esm.e2b400e5.js",
      "_Group.vue.92001ab3.js",
      "_TabContent.vue.9f2b68ff.js",
      "_InputImageCropAdmin.54f6d474.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.932d210d.js",
      "_useFacility.c2c7ce8e.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_FormatMoneyDash.aea6127b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FormatMoneyDash.aea6127b.js"
  },
  "_Group.vue.92001ab3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Group.vue.92001ab3.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_InputImageCropAdmin.54f6d474.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "InputImageCropAdmin.54f6d474.js",
    "imports": [
      "_Modal.2d874f24.js",
      "_vee-validate.esm.e2b400e5.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_client-only.f2fe12f6.js",
      "_index.d7809de7.js",
      "_index.0521d086.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_InputOTP.vue.15a59199.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "InputOTP.vue.15a59199.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_MGroup.vue.9d22adaa.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MGroup.vue.9d22adaa.js",
    "imports": [
      "_vee-validate.esm.e2b400e5.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_clsx.0839fdbe.js"
    ]
  },
  "_MSelect.vue.2d999700.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MSelect.vue.2d999700.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.e2b400e5.js"
    ]
  },
  "_MTextField.vue.814f1dbe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MTextField.vue.814f1dbe.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.e2b400e5.js"
    ]
  },
  "_Modal.2d874f24.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Modal.200da282.css"
    ],
    "file": "Modal.2d874f24.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.fb38f7cd.js",
      "_index.d7809de7.js",
      "_index.7d9a9c74.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "Modal.200da282.css": {
    "file": "Modal.200da282.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_PaginationAdmin.b1590b3e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "PaginationAdmin.b1590b3e.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_PriceCheckoutInformation.2d7e1589.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "PriceCheckoutInformation.2d7e1589.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_SelectedCard.vue.8eac2080.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "SelectedCard.vue.8eac2080.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_Switch.vue.7ccdaf38.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Switch.vue.7ccdaf38.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_TabContent.vue.9f2b68ff.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TabContent.vue.9f2b68ff.js",
    "imports": [
      "_clsx.0839fdbe.js",
      "_swiper-vue.fb38f7cd.js",
      "_client-only.f2fe12f6.js"
    ]
  },
  "_TextFieldWLabel.vue.fe3347fa.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TextFieldWLabel.vue.fe3347fa.js",
    "imports": [
      "_vee-validate.esm.e2b400e5.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_TitleAdmin.e73adca6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleAdmin.e73adca6.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_TitleBack.477cf65c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleBack.477cf65c.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_TourPackage.2d6e408e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "TourPackage.da417478.css"
    ],
    "file": "TourPackage.2d6e408e.js",
    "imports": [
      "_TextFieldWLabel.vue.fe3347fa.js",
      "_DropdownsTest.848cecb4.js",
      "_vee-validate.esm.e2b400e5.js",
      "_client-only.f2fe12f6.js",
      "_swiper-vue.fb38f7cd.js",
      "_Group.vue.92001ab3.js",
      "_TabContent.vue.9f2b68ff.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useTourPackage.8121da60.js",
      "_index.d7809de7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.932d210d.js"
    ]
  },
  "TourPackage.da417478.css": {
    "file": "TourPackage.da417478.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TransitionTopToBottom.edd8bb8c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TransitionTopToBottom.edd8bb8c.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_Transport.d1836703.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Transport.d1836703.js",
    "imports": [
      "_vee-validate.esm.e2b400e5.js",
      "_InputImageCropAdmin.54f6d474.js",
      "_TextFieldWLabel.vue.fe3347fa.js",
      "_DropdownsTest.848cecb4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.932d210d.js",
      "_useTransport.4aecc59a.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_client-only.f2fe12f6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client-only.f2fe12f6.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_clsx.0839fdbe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "clsx.0839fdbe.js"
  },
  "_config.a4868098.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.a4868098.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_hi-transfer-logo.d8a768f6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hi-transfer-logo.d8a768f6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.0521d086.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.0521d086.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_index.7d9a9c74.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.7d9a9c74.js"
  },
  "_index.d7809de7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.d7809de7.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_nofication.9cf9c57f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nofication.9cf9c57f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_swiper-vue.fb38f7cd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.d33d3671.css"
    ],
    "file": "swiper-vue.fb38f7cd.js"
  },
  "swiper-vue.d33d3671.css": {
    "file": "swiper-vue.d33d3671.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useCarStore.39db8268.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useCarStore.39db8268.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.9cf9c57f.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_useDestinations.e345f80f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useDestinations.e345f80f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.9cf9c57f.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_useDriver.44893058.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useDriver.44893058.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.9cf9c57f.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_useFacility.c2c7ce8e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useFacility.c2c7ce8e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.9cf9c57f.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_usePasswordHelper.98f23841.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "usePasswordHelper.98f23841.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_useSchema.932d210d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useSchema.932d210d.js",
    "imports": [
      "_vee-validate-zod.esm.9c213e2c.js"
    ]
  },
  "_useTourPackage.8121da60.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTourPackage.8121da60.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.9cf9c57f.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_useTourStore.f3ad1418.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTourStore.f3ad1418.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_useTransport.4aecc59a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTransport.4aecc59a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.9cf9c57f.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_vee-validate-zod.esm.9c213e2c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vee-validate-zod.esm.9c213e2c.js"
  },
  "_vee-validate.esm.e2b400e5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vee-validate.esm.e2b400e5.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "_vehicleForm.bfc28a83.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vehicleForm.bfc28a83.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ]
  },
  "assets/fonts/ClashGrotesk-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Bold.c4ea1fe3.ttf",
    "src": "assets/fonts/ClashGrotesk-Bold.ttf"
  },
  "assets/fonts/ClashGrotesk-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Bold.b1b9970d.woff",
    "src": "assets/fonts/ClashGrotesk-Bold.woff"
  },
  "assets/fonts/ClashGrotesk-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Bold.602a56af.woff2",
    "src": "assets/fonts/ClashGrotesk-Bold.woff2"
  },
  "assets/fonts/ClashGrotesk-Extralight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Extralight.6417ca23.ttf",
    "src": "assets/fonts/ClashGrotesk-Extralight.ttf"
  },
  "assets/fonts/ClashGrotesk-Extralight.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Extralight.c9c2a3a9.woff",
    "src": "assets/fonts/ClashGrotesk-Extralight.woff"
  },
  "assets/fonts/ClashGrotesk-Extralight.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Extralight.fe206472.woff2",
    "src": "assets/fonts/ClashGrotesk-Extralight.woff2"
  },
  "assets/fonts/ClashGrotesk-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Light.8e98f3c7.ttf",
    "src": "assets/fonts/ClashGrotesk-Light.ttf"
  },
  "assets/fonts/ClashGrotesk-Light.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Light.04e1d585.woff",
    "src": "assets/fonts/ClashGrotesk-Light.woff"
  },
  "assets/fonts/ClashGrotesk-Light.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Light.f0f7605c.woff2",
    "src": "assets/fonts/ClashGrotesk-Light.woff2"
  },
  "assets/fonts/ClashGrotesk-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Medium.717fd45f.ttf",
    "src": "assets/fonts/ClashGrotesk-Medium.ttf"
  },
  "assets/fonts/ClashGrotesk-Medium.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Medium.94bcd03c.woff",
    "src": "assets/fonts/ClashGrotesk-Medium.woff"
  },
  "assets/fonts/ClashGrotesk-Medium.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Medium.5c3815cf.woff2",
    "src": "assets/fonts/ClashGrotesk-Medium.woff2"
  },
  "assets/fonts/ClashGrotesk-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Regular.5c66c57f.ttf",
    "src": "assets/fonts/ClashGrotesk-Regular.ttf"
  },
  "assets/fonts/ClashGrotesk-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Regular.1c248756.woff",
    "src": "assets/fonts/ClashGrotesk-Regular.woff"
  },
  "assets/fonts/ClashGrotesk-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Regular.03ad7ecf.woff2",
    "src": "assets/fonts/ClashGrotesk-Regular.woff2"
  },
  "assets/fonts/ClashGrotesk-Semibold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Semibold.bdc47ea3.ttf",
    "src": "assets/fonts/ClashGrotesk-Semibold.ttf"
  },
  "assets/fonts/ClashGrotesk-Semibold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Semibold.48fdb6da.woff",
    "src": "assets/fonts/ClashGrotesk-Semibold.woff"
  },
  "assets/fonts/ClashGrotesk-Semibold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Semibold.befc1942.woff2",
    "src": "assets/fonts/ClashGrotesk-Semibold.woff2"
  },
  "assets/fonts/ClashGrotesk-Variable.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Variable.5887a1df.ttf",
    "src": "assets/fonts/ClashGrotesk-Variable.ttf"
  },
  "assets/fonts/ClashGrotesk-Variable.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Variable.de7ab3f6.woff",
    "src": "assets/fonts/ClashGrotesk-Variable.woff"
  },
  "assets/fonts/ClashGrotesk-Variable.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Variable.3c56fcff.woff2",
    "src": "assets/fonts/ClashGrotesk-Variable.woff2"
  },
  "assets/fonts/GeneralSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Bold.1c435b33.ttf",
    "src": "assets/fonts/GeneralSans-Bold.ttf"
  },
  "assets/fonts/GeneralSans-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Bold.4c2b7f63.woff",
    "src": "assets/fonts/GeneralSans-Bold.woff"
  },
  "assets/fonts/GeneralSans-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Bold.a29eab9b.woff2",
    "src": "assets/fonts/GeneralSans-Bold.woff2"
  },
  "assets/fonts/GeneralSans-BoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-BoldItalic.2297ae79.ttf",
    "src": "assets/fonts/GeneralSans-BoldItalic.ttf"
  },
  "assets/fonts/GeneralSans-BoldItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-BoldItalic.0599ec69.woff",
    "src": "assets/fonts/GeneralSans-BoldItalic.woff"
  },
  "assets/fonts/GeneralSans-BoldItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-BoldItalic.97483640.woff2",
    "src": "assets/fonts/GeneralSans-BoldItalic.woff2"
  },
  "assets/fonts/GeneralSans-Extralight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Extralight.4cb07dad.ttf",
    "src": "assets/fonts/GeneralSans-Extralight.ttf"
  },
  "assets/fonts/GeneralSans-Extralight.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Extralight.6a52bdce.woff",
    "src": "assets/fonts/GeneralSans-Extralight.woff"
  },
  "assets/fonts/GeneralSans-Extralight.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Extralight.3e6ee7e5.woff2",
    "src": "assets/fonts/GeneralSans-Extralight.woff2"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-ExtralightItalic.9b80b399.ttf",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.ttf"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-ExtralightItalic.acc7311a.woff",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.woff"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-ExtralightItalic.83bbc211.woff2",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.woff2"
  },
  "assets/fonts/GeneralSans-Italic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Italic.ea19866f.ttf",
    "src": "assets/fonts/GeneralSans-Italic.ttf"
  },
  "assets/fonts/GeneralSans-Italic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Italic.f9e5a73e.woff",
    "src": "assets/fonts/GeneralSans-Italic.woff"
  },
  "assets/fonts/GeneralSans-Italic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Italic.1c91e1d3.woff2",
    "src": "assets/fonts/GeneralSans-Italic.woff2"
  },
  "assets/fonts/GeneralSans-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Light.86a255b5.ttf",
    "src": "assets/fonts/GeneralSans-Light.ttf"
  },
  "assets/fonts/GeneralSans-Light.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Light.09f0f0fe.woff",
    "src": "assets/fonts/GeneralSans-Light.woff"
  },
  "assets/fonts/GeneralSans-Light.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Light.ac0b8f29.woff2",
    "src": "assets/fonts/GeneralSans-Light.woff2"
  },
  "assets/fonts/GeneralSans-LightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-LightItalic.eb313a89.ttf",
    "src": "assets/fonts/GeneralSans-LightItalic.ttf"
  },
  "assets/fonts/GeneralSans-LightItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-LightItalic.639de7d9.woff",
    "src": "assets/fonts/GeneralSans-LightItalic.woff"
  },
  "assets/fonts/GeneralSans-LightItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-LightItalic.7787625d.woff2",
    "src": "assets/fonts/GeneralSans-LightItalic.woff2"
  },
  "assets/fonts/GeneralSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Medium.e85572fe.ttf",
    "src": "assets/fonts/GeneralSans-Medium.ttf"
  },
  "assets/fonts/GeneralSans-Medium.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Medium.f5beb161.woff",
    "src": "assets/fonts/GeneralSans-Medium.woff"
  },
  "assets/fonts/GeneralSans-Medium.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Medium.c30377df.woff2",
    "src": "assets/fonts/GeneralSans-Medium.woff2"
  },
  "assets/fonts/GeneralSans-MediumItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-MediumItalic.3b4e2f45.ttf",
    "src": "assets/fonts/GeneralSans-MediumItalic.ttf"
  },
  "assets/fonts/GeneralSans-MediumItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-MediumItalic.d02080e7.woff",
    "src": "assets/fonts/GeneralSans-MediumItalic.woff"
  },
  "assets/fonts/GeneralSans-MediumItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-MediumItalic.ffe0560d.woff2",
    "src": "assets/fonts/GeneralSans-MediumItalic.woff2"
  },
  "assets/fonts/GeneralSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Regular.0723d125.ttf",
    "src": "assets/fonts/GeneralSans-Regular.ttf"
  },
  "assets/fonts/GeneralSans-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Regular.52af118f.woff",
    "src": "assets/fonts/GeneralSans-Regular.woff"
  },
  "assets/fonts/GeneralSans-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Regular.3ec2be77.woff2",
    "src": "assets/fonts/GeneralSans-Regular.woff2"
  },
  "assets/fonts/GeneralSans-Semibold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Semibold.307d27c4.ttf",
    "src": "assets/fonts/GeneralSans-Semibold.ttf"
  },
  "assets/fonts/GeneralSans-Semibold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Semibold.eec4ab4c.woff",
    "src": "assets/fonts/GeneralSans-Semibold.woff"
  },
  "assets/fonts/GeneralSans-Semibold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Semibold.94a2a0e1.woff2",
    "src": "assets/fonts/GeneralSans-Semibold.woff2"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-SemiboldItalic.d3b62cb5.ttf",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.ttf"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-SemiboldItalic.cd1fca15.woff",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.woff"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-SemiboldItalic.98c7276f.woff2",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.woff2"
  },
  "assets/fonts/GeneralSans-Variable.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Variable.4b2539d9.ttf",
    "src": "assets/fonts/GeneralSans-Variable.ttf"
  },
  "assets/fonts/GeneralSans-Variable.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Variable.473d4f5e.woff",
    "src": "assets/fonts/GeneralSans-Variable.woff"
  },
  "assets/fonts/GeneralSans-Variable.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Variable.49d3fbd2.woff2",
    "src": "assets/fonts/GeneralSans-Variable.woff2"
  },
  "assets/fonts/GeneralSans-VariableItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-VariableItalic.4aa0c20d.ttf",
    "src": "assets/fonts/GeneralSans-VariableItalic.ttf"
  },
  "assets/fonts/GeneralSans-VariableItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-VariableItalic.c0b7f35e.woff",
    "src": "assets/fonts/GeneralSans-VariableItalic.woff"
  },
  "assets/fonts/GeneralSans-VariableItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-VariableItalic.71537245.woff2",
    "src": "assets/fonts/GeneralSans-VariableItalic.woff2"
  },
  "assets/fonts/PlusJakartaSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Bold.3e08701b.ttf",
    "src": "assets/fonts/PlusJakartaSans-Bold.ttf"
  },
  "assets/fonts/PlusJakartaSans-BoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-BoldItalic.4486ec3d.ttf",
    "src": "assets/fonts/PlusJakartaSans-BoldItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraBold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraBold.644fda57.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraBold.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraBoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraBoldItalic.d51b806e.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraBoldItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraLight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraLight.9afaedac.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraLight.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraLightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraLightItalic.b7523f1e.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraLightItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Italic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Italic.b15bc27e.ttf",
    "src": "assets/fonts/PlusJakartaSans-Italic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Light.26e26359.ttf",
    "src": "assets/fonts/PlusJakartaSans-Light.ttf"
  },
  "assets/fonts/PlusJakartaSans-LightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-LightItalic.22823a55.ttf",
    "src": "assets/fonts/PlusJakartaSans-LightItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Medium.d6854d4b.ttf",
    "src": "assets/fonts/PlusJakartaSans-Medium.ttf"
  },
  "assets/fonts/PlusJakartaSans-MediumItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-MediumItalic.67cb7ae5.ttf",
    "src": "assets/fonts/PlusJakartaSans-MediumItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Regular.f7e7cebd.ttf",
    "src": "assets/fonts/PlusJakartaSans-Regular.ttf"
  },
  "assets/fonts/PlusJakartaSans-SemiBold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-SemiBold.d32adf41.ttf",
    "src": "assets/fonts/PlusJakartaSans-SemiBold.ttf"
  },
  "assets/fonts/PlusJakartaSans-SemiBoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-SemiBoldItalic.48a17bbd.ttf",
    "src": "assets/fonts/PlusJakartaSans-SemiBoldItalic.ttf"
  },
  "layouts/admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.6f015909.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "_nofication.9cf9c57f.js",
      "_hi-transfer-logo.d8a768f6.js",
      "_index.d7809de7.js",
      "_config.a4868098.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/admin.vue"
  },
  "layouts/auth.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth.13afecf4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Switch.vue.7ccdaf38.js",
      "_client-only.f2fe12f6.js",
      "_hi-transfer-logo.d8a768f6.js",
      "_swiper-vue.fb38f7cd.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/auth.vue"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.53947b7e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Switch.vue.7ccdaf38.js",
      "_Default.vue.89de9292.js",
      "_client-only.f2fe12f6.js",
      "_hi-transfer-logo.d8a768f6.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_Container.54dbe1d1.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "layouts/empty.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "empty.e9eec030.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/empty.vue"
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "user.cffada9c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Switch.vue.7ccdaf38.js",
      "_Default.vue.89de9292.js",
      "_client-only.f2fe12f6.js",
      "_hi-transfer-logo.d8a768f6.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_Container.54dbe1d1.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "middleware/admin.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.dbac903c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/admin.ts"
  },
  "middleware/user.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "user.89736397.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/user.ts"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Icon.6f5d80f8.css",
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.css"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Icon.7a4cedb9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_config.a4868098.js",
      "_swiper-vue.fb38f7cd.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.vue"
  },
  "Icon.6f5d80f8.css": {
    "file": "Icon.6f5d80f8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "IconCSS.fe0874d9.css",
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.css"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "IconCSS.ec71a85c.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js",
      "_config.a4868098.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.vue"
  },
  "IconCSS.fe0874d9.css": {
    "file": "IconCSS.fe0874d9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.2cc35f7b.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.2cc35f7b.css"
    ],
    "dynamicImports": [
      "middleware/admin.ts",
      "middleware/user.ts",
      "layouts/admin.vue",
      "layouts/auth.vue",
      "layouts/default.vue",
      "layouts/empty.vue",
      "layouts/user.vue"
    ],
    "file": "entry.d37566ec.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.2cc35f7b.css": {
    "file": "entry.2cc35f7b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/admin-list/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.a2bdcd5c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_TitleAdmin.e73adca6.js",
      "_swiper-vue.fb38f7cd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/index.vue"
  },
  "pages/admin/destinations/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.6492bf82.js",
    "imports": [
      "_TitleBack.477cf65c.js",
      "_Destinations.e56aa04f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_TextFieldWLabel.vue.fe3347fa.js",
      "_vee-validate.esm.e2b400e5.js",
      "_useSchema.932d210d.js",
      "_vee-validate-zod.esm.9c213e2c.js",
      "_useDestinations.e345f80f.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/add.vue"
  },
  "pages/admin/destinations/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.05e0a956.js",
    "imports": [
      "_TitleBack.477cf65c.js",
      "_Destinations.e56aa04f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_TextFieldWLabel.vue.fe3347fa.js",
      "_vee-validate.esm.e2b400e5.js",
      "_useSchema.932d210d.js",
      "_vee-validate-zod.esm.9c213e2c.js",
      "_useDestinations.e345f80f.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/edit/[slug].vue"
  },
  "pages/admin/destinations/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.a425be35.js",
    "imports": [
      "_ButtonAddAdmin.51c5f930.js",
      "_TitleAdmin.e73adca6.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.b1590b3e.js",
      "_Modal.2d874f24.js",
      "_swiper-vue.fb38f7cd.js",
      "_useDestinations.e345f80f.js",
      "_config.a4868098.js",
      "_index.d7809de7.js",
      "_index.7d9a9c74.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/index.vue"
  },
  "pages/admin/driver/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.60a929a5.js",
    "imports": [
      "_TitleBack.477cf65c.js",
      "_Driver.265b603b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_TextFieldWLabel.vue.fe3347fa.js",
      "_vee-validate.esm.e2b400e5.js",
      "_useSchema.932d210d.js",
      "_vee-validate-zod.esm.9c213e2c.js",
      "_useDriver.44893058.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/add.vue"
  },
  "pages/admin/driver/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.3f79ab2b.js",
    "imports": [
      "_TitleBack.477cf65c.js",
      "_Driver.265b603b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_TextFieldWLabel.vue.fe3347fa.js",
      "_vee-validate.esm.e2b400e5.js",
      "_useSchema.932d210d.js",
      "_vee-validate-zod.esm.9c213e2c.js",
      "_useDriver.44893058.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/edit/[slug].vue"
  },
  "pages/admin/driver/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.ebe8d335.js",
    "imports": [
      "_ButtonAddAdmin.51c5f930.js",
      "_TitleAdmin.e73adca6.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.b1590b3e.js",
      "_Modal.2d874f24.js",
      "_swiper-vue.fb38f7cd.js",
      "_useDriver.44893058.js",
      "_index.d7809de7.js",
      "_config.a4868098.js",
      "_index.7d9a9c74.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/index.vue"
  },
  "pages/admin/email-verification/[token].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_token_.cbff258c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/email-verification/[token].vue"
  },
  "pages/admin/facility-car/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.ddfc8de4.js",
    "imports": [
      "_TitleBack.477cf65c.js",
      "_FacilityCar.bf5b1bb8.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_TextFieldWLabel.vue.fe3347fa.js",
      "_vee-validate.esm.e2b400e5.js",
      "_Group.vue.92001ab3.js",
      "_TabContent.vue.9f2b68ff.js",
      "_clsx.0839fdbe.js",
      "_client-only.f2fe12f6.js",
      "_InputImageCropAdmin.54f6d474.js",
      "_Modal.2d874f24.js",
      "_index.d7809de7.js",
      "_index.7d9a9c74.js",
      "_index.0521d086.js",
      "_useSchema.932d210d.js",
      "_vee-validate-zod.esm.9c213e2c.js",
      "_useFacility.c2c7ce8e.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/add.vue"
  },
  "pages/admin/facility-car/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.16bc727c.js",
    "imports": [
      "_TitleBack.477cf65c.js",
      "_FacilityCar.bf5b1bb8.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_TextFieldWLabel.vue.fe3347fa.js",
      "_vee-validate.esm.e2b400e5.js",
      "_Group.vue.92001ab3.js",
      "_TabContent.vue.9f2b68ff.js",
      "_clsx.0839fdbe.js",
      "_client-only.f2fe12f6.js",
      "_InputImageCropAdmin.54f6d474.js",
      "_Modal.2d874f24.js",
      "_index.d7809de7.js",
      "_index.7d9a9c74.js",
      "_index.0521d086.js",
      "_useSchema.932d210d.js",
      "_vee-validate-zod.esm.9c213e2c.js",
      "_useFacility.c2c7ce8e.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/edit/[slug].vue"
  },
  "pages/admin/facility-car/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.0c0d2793.js",
    "imports": [
      "_ButtonAddAdmin.51c5f930.js",
      "_TitleAdmin.e73adca6.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.b1590b3e.js",
      "_Modal.2d874f24.js",
      "_swiper-vue.fb38f7cd.js",
      "_useFacility.c2c7ce8e.js",
      "_config.a4868098.js",
      "_index.d7809de7.js",
      "_index.7d9a9c74.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/index.vue"
  },
  "pages/admin/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.cec8a835.js",
    "imports": [
      "_Change.vue.eb827dd9.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.d7809de7.js",
      "_swiper-vue.fb38f7cd.js",
      "_Alert.vue.b43fd441.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_TransitionTopToBottom.edd8bb8c.js",
      "_MTextField.vue.814f1dbe.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.e2b400e5.js",
      "_MGroup.vue.9d22adaa.js",
      "_Btn.vue.0e457d86.js",
      "_useSchema.932d210d.js",
      "_vee-validate-zod.esm.9c213e2c.js",
      "_InputOTP.vue.15a59199.js",
      "_Group.vue.92001ab3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/forgot-password.vue"
  },
  "pages/admin/orders/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.b0b1a3bf.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_config.a4868098.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/index.vue"
  },
  "pages/admin/orders/order-detail-fastboat/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.66f1e020.js",
    "imports": [
      "_TitleAdmin.e73adca6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-detail-fastboat/[slug].vue"
  },
  "pages/admin/orders/order-detail-tourpackage/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.5940133c.js",
    "imports": [
      "_MSelect.vue.2d999700.js",
      "_MGroup.vue.9d22adaa.js",
      "_TitleAdmin.e73adca6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.e2b400e5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-detail-tourpackage/[slug].vue"
  },
  "pages/admin/orders/order-edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.08df3b58.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-edit/[slug].vue"
  },
  "pages/admin/profile.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "profile.3f7d298e.js",
    "imports": [
      "_ChangePassword.edc839ba.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "_Alert.vue.ee06ff17.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_TransitionTopToBottom.edd8bb8c.js",
      "_index.d7809de7.js",
      "_vee-validate.esm.e2b400e5.js",
      "_MTextField.vue.814f1dbe.js",
      "_clsx.0839fdbe.js",
      "_MGroup.vue.9d22adaa.js",
      "_useSchema.932d210d.js",
      "_vee-validate-zod.esm.9c213e2c.js",
      "_nofication.9cf9c57f.js",
      "_Group.vue.92001ab3.js",
      "_usePasswordHelper.98f23841.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/profile.vue"
  },
  "pages/admin/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.08c6858e.js",
    "imports": [
      "_MTextField.vue.814f1dbe.js",
      "_MGroup.vue.9d22adaa.js",
      "_Btn.vue.0e457d86.js",
      "_vee-validate.esm.e2b400e5.js",
      "_useSchema.932d210d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "_clsx.0839fdbe.js",
      "_vee-validate-zod.esm.9c213e2c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/sign-in.vue"
  },
  "pages/admin/tour-package/[slug]/edit.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "edit.e9ae15f8.js",
    "imports": [
      "_TitleBack.477cf65c.js",
      "_TourPackage.2d6e408e.js",
      "_useSchema.932d210d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_TextFieldWLabel.vue.fe3347fa.js",
      "_vee-validate.esm.e2b400e5.js",
      "_DropdownsTest.848cecb4.js",
      "_index.d7809de7.js",
      "_client-only.f2fe12f6.js",
      "_Group.vue.92001ab3.js",
      "_TabContent.vue.9f2b68ff.js",
      "_clsx.0839fdbe.js",
      "_useTourPackage.8121da60.js",
      "_nofication.9cf9c57f.js",
      "_vee-validate-zod.esm.9c213e2c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/[slug]/edit.vue"
  },
  "pages/admin/tour-package/[slug]/images.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "images.dd239b27.js",
    "imports": [
      "_TitleBack.477cf65c.js",
      "_Alert.vue.ee06ff17.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Modal.2d874f24.js",
      "_index.d7809de7.js",
      "_swiper-vue.fb38f7cd.js",
      "_client-only.f2fe12f6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.0521d086.js",
      "_TransitionTopToBottom.edd8bb8c.js",
      "_config.a4868098.js",
      "_index.7d9a9c74.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/[slug]/images.vue"
  },
  "pages/admin/tour-package/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.ee309f7e.js",
    "imports": [
      "_TitleBack.477cf65c.js",
      "_TourPackage.2d6e408e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_TextFieldWLabel.vue.fe3347fa.js",
      "_vee-validate.esm.e2b400e5.js",
      "_DropdownsTest.848cecb4.js",
      "_index.d7809de7.js",
      "_client-only.f2fe12f6.js",
      "_Group.vue.92001ab3.js",
      "_TabContent.vue.9f2b68ff.js",
      "_clsx.0839fdbe.js",
      "_useTourPackage.8121da60.js",
      "_nofication.9cf9c57f.js",
      "_useSchema.932d210d.js",
      "_vee-validate-zod.esm.9c213e2c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/add.vue"
  },
  "pages/admin/tour-package/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.4650a29c.js",
    "imports": [
      "_ButtonAddAdmin.51c5f930.js",
      "_TitleAdmin.e73adca6.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.b1590b3e.js",
      "_Modal.2d874f24.js",
      "_swiper-vue.fb38f7cd.js",
      "_useTourPackage.8121da60.js",
      "_index.d7809de7.js",
      "_config.a4868098.js",
      "_index.7d9a9c74.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/index.vue"
  },
  "pages/admin/transport/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.1718c054.js",
    "imports": [
      "_TitleBack.477cf65c.js",
      "_Transport.d1836703.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_vee-validate.esm.e2b400e5.js",
      "_InputImageCropAdmin.54f6d474.js",
      "_Modal.2d874f24.js",
      "_index.d7809de7.js",
      "_index.7d9a9c74.js",
      "_client-only.f2fe12f6.js",
      "_index.0521d086.js",
      "_TextFieldWLabel.vue.fe3347fa.js",
      "_DropdownsTest.848cecb4.js",
      "_useSchema.932d210d.js",
      "_vee-validate-zod.esm.9c213e2c.js",
      "_useTransport.4aecc59a.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/add.vue"
  },
  "pages/admin/transport/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.480891f2.js",
    "imports": [
      "_TitleBack.477cf65c.js",
      "_Transport.d1836703.js",
      "_useSchema.932d210d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_vee-validate.esm.e2b400e5.js",
      "_InputImageCropAdmin.54f6d474.js",
      "_Modal.2d874f24.js",
      "_index.d7809de7.js",
      "_index.7d9a9c74.js",
      "_client-only.f2fe12f6.js",
      "_index.0521d086.js",
      "_TextFieldWLabel.vue.fe3347fa.js",
      "_DropdownsTest.848cecb4.js",
      "_useTransport.4aecc59a.js",
      "_nofication.9cf9c57f.js",
      "_vee-validate-zod.esm.9c213e2c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/edit/[slug].vue"
  },
  "pages/admin/transport/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.b18160a7.js",
    "imports": [
      "_ButtonAddAdmin.51c5f930.js",
      "_TitleAdmin.e73adca6.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.b1590b3e.js",
      "_Modal.2d874f24.js",
      "_useTransport.4aecc59a.js",
      "_index.d7809de7.js",
      "_config.a4868098.js",
      "_index.7d9a9c74.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/index.vue"
  },
  "pages/admin/users/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.0c93124f.js",
    "imports": [
      "_TitleBack.477cf65c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/users/edit/[slug].vue"
  },
  "pages/admin/users/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.3903ee95.js",
    "imports": [
      "_TitleAdmin.e73adca6.js",
      "_PaginationAdmin.b1590b3e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/users/index.vue"
  },
  "pages/auth-redirect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth-redirect.9451f626.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/auth-redirect.vue"
  },
  "pages/daisy-example.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "daisy-example.69051001.js",
    "imports": [
      "_MTextField.vue.814f1dbe.js",
      "_MGroup.vue.9d22adaa.js",
      "_vee-validate.esm.e2b400e5.js",
      "_swiper-vue.fb38f7cd.js",
      "_clsx.0839fdbe.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_MSelect.vue.2d999700.js",
      "_Btn.vue.0e457d86.js",
      "_Container.54dbe1d1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate-zod.esm.9c213e2c.js",
      "_config.a4868098.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/daisy-example.vue"
  },
  "pages/email-verification/[token].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_token_.d5deb30e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/email-verification/[token].vue"
  },
  "pages/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.2bdc28c2.js",
    "imports": [
      "_Change.vue.eb827dd9.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.d7809de7.js",
      "_swiper-vue.fb38f7cd.js",
      "_Alert.vue.b43fd441.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_TransitionTopToBottom.edd8bb8c.js",
      "_MTextField.vue.814f1dbe.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.e2b400e5.js",
      "_MGroup.vue.9d22adaa.js",
      "_Btn.vue.0e457d86.js",
      "_useSchema.932d210d.js",
      "_vee-validate-zod.esm.9c213e2c.js",
      "_InputOTP.vue.15a59199.js",
      "_Group.vue.92001ab3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/forgot-password.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.9c5e21f3.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.5a8c035f.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_clsx.0839fdbe.js",
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.d7809de7.js",
      "_index.7d9a9c74.js",
      "_vee-validate.esm.e2b400e5.js",
      "_MGroup.vue.9d22adaa.js",
      "_MTextField.vue.814f1dbe.js",
      "_MSelect.vue.2d999700.js",
      "_Btn.vue.0e457d86.js",
      "_nofication.9cf9c57f.js",
      "_useSchema.932d210d.js",
      "_useCarStore.39db8268.js",
      "_useTourStore.f3ad1418.js",
      "_Card.3c3cdea0.js",
      "_Container.54dbe1d1.js",
      "_CtaSection.vue.2b2713c7.js",
      "_config.a4868098.js",
      "_vee-validate-zod.esm.9c213e2c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.9c5e21f3.css": {
    "file": "index.9c5e21f3.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.d39fbbd9.js",
    "imports": [
      "_Alert.vue.b43fd441.js",
      "_MTextField.vue.814f1dbe.js",
      "_MGroup.vue.9d22adaa.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.0e457d86.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.e2b400e5.js",
      "_useSchema.932d210d.js",
      "_usePasswordHelper.98f23841.js",
      "_swiper-vue.fb38f7cd.js",
      "_TransitionTopToBottom.edd8bb8c.js",
      "_clsx.0839fdbe.js",
      "_config.a4868098.js",
      "_vee-validate-zod.esm.9c213e2c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign-in.vue"
  },
  "pages/sign-up.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-up.db6c8a5d.js",
    "imports": [
      "_Alert.vue.b43fd441.js",
      "_MTextField.vue.814f1dbe.js",
      "_MGroup.vue.9d22adaa.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.0e457d86.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.e2b400e5.js",
      "_useSchema.932d210d.js",
      "_usePasswordHelper.98f23841.js",
      "_swiper-vue.fb38f7cd.js",
      "_TransitionTopToBottom.edd8bb8c.js",
      "_clsx.0839fdbe.js",
      "_config.a4868098.js",
      "_vee-validate-zod.esm.9c213e2c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign-up.vue"
  },
  "pages/tours/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.fff7e3ce.css",
    "src": "pages/tours/[slug].css"
  },
  "pages/tours/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.4fb751f0.js",
    "imports": [
      "_swiper-vue.fb38f7cd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_FormatMoneyDash.aea6127b.js",
      "_Container.54dbe1d1.js",
      "_CtaSection.vue.2b2713c7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useTourStore.f3ad1418.js",
      "_config.a4868098.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/[slug].vue"
  },
  "_slug_.fff7e3ce.css": {
    "file": "_slug_.fff7e3ce.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/tours/booking.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "booking.7e40e750.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "_Container.54dbe1d1.js",
      "_Btn.vue.0e457d86.js",
      "_vehicleForm.bfc28a83.js",
      "_clsx.0839fdbe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking.vue"
  },
  "pages/tours/booking/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkout.4d8d31af.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "_PriceCheckoutInformation.2d7e1589.js",
      "_FormatMoneyDash.aea6127b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking/checkout.vue"
  },
  "pages/tours/booking/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.10d371d8.js",
    "imports": [
      "_MTextField.vue.814f1dbe.js",
      "_MGroup.vue.9d22adaa.js",
      "_vee-validate.esm.e2b400e5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "_MSelect.vue.2d999700.js",
      "_vehicleForm.bfc28a83.js",
      "_useTourStore.f3ad1418.js",
      "_clsx.0839fdbe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking/index.vue"
  },
  "pages/tours/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.a57a7996.js",
    "imports": [
      "_Btn.vue.0e457d86.js",
      "_Container.54dbe1d1.js",
      "_Card.3c3cdea0.js",
      "_Empty.b90e105b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useTourStore.f3ad1418.js",
      "_swiper-vue.fb38f7cd.js",
      "_clsx.0839fdbe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/index.vue"
  },
  "pages/user/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.b844d269.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_PaginationAdmin.b1590b3e.js",
      "_Container.54dbe1d1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "_config.a4868098.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/index.vue"
  },
  "pages/user/order/order-summary/car/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.d61d1a57.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Container.54dbe1d1.js",
      "_Alert.vue.ee06ff17.js",
      "_vee-validate.esm.e2b400e5.js",
      "_InputOTP.vue.15a59199.js",
      "_swiper-vue.fb38f7cd.js",
      "_useSchema.932d210d.js",
      "_Modal.2d874f24.js",
      "_config.a4868098.js",
      "_TransitionTopToBottom.edd8bb8c.js",
      "_vee-validate-zod.esm.9c213e2c.js",
      "_index.d7809de7.js",
      "_index.7d9a9c74.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/order/order-summary/car/[slug].vue"
  },
  "pages/user/order/order-summary/tour/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.8fe26075.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/order/order-summary/tour/[slug].vue"
  },
  "pages/user/profile.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "profile.02578e77.js",
    "imports": [
      "_ChangePassword.edc839ba.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.fb38f7cd.js",
      "_Alert.vue.ee06ff17.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.a4868098.js",
      "_TransitionTopToBottom.edd8bb8c.js",
      "_index.d7809de7.js",
      "_vee-validate.esm.e2b400e5.js",
      "_MTextField.vue.814f1dbe.js",
      "_clsx.0839fdbe.js",
      "_MGroup.vue.9d22adaa.js",
      "_useSchema.932d210d.js",
      "_vee-validate-zod.esm.9c213e2c.js",
      "_nofication.9cf9c57f.js",
      "_Group.vue.92001ab3.js",
      "_usePasswordHelper.98f23841.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/profile.vue"
  },
  "pages/vehicles/booking.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "booking.6a09c1c2.js",
    "imports": [
      "_Btn.vue.0e457d86.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.54dbe1d1.js",
      "_AddressInformation.vue.6ff36c09.js",
      "_MTextField.vue.814f1dbe.js",
      "_MGroup.vue.9d22adaa.js",
      "_vee-validate.esm.e2b400e5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.932d210d.js",
      "_useCarStore.39db8268.js",
      "_swiper-vue.fb38f7cd.js",
      "_SelectedCard.vue.8eac2080.js",
      "_clsx.0839fdbe.js",
      "_config.a4868098.js",
      "_vee-validate-zod.esm.9c213e2c.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/booking.vue"
  },
  "pages/vehicles/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkout.7ed32601.js",
    "imports": [
      "_Btn.vue.0e457d86.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.54dbe1d1.js",
      "_AddressInformation.vue.6ff36c09.js",
      "_swiper-vue.fb38f7cd.js",
      "_SelectedCard.vue.8eac2080.js",
      "_PriceCheckoutInformation.2d7e1589.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useCarStore.39db8268.js",
      "_clsx.0839fdbe.js",
      "_config.a4868098.js",
      "_FormatMoneyDash.aea6127b.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/checkout.vue"
  },
  "pages/vehicles/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.911a0c91.js",
    "imports": [
      "_Btn.vue.0e457d86.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.54dbe1d1.js",
      "_AddressInformation.vue.6ff36c09.js",
      "_MSelect.vue.2d999700.js",
      "_MGroup.vue.9d22adaa.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useCarStore.39db8268.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.fb38f7cd.js",
      "_Empty.b90e105b.js",
      "_clsx.0839fdbe.js",
      "_config.a4868098.js",
      "_vee-validate.esm.e2b400e5.js",
      "_nofication.9cf9c57f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/index.vue"
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.d33d3671.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
