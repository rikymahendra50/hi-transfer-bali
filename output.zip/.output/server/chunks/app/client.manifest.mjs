const client_manifest = {
  "Modal.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Modal.200da282.css",
    "src": "Modal.css"
  },
  "TourPackage.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "TourPackage.da417478.css",
    "src": "TourPackage.css"
  },
  "_AddressInformation.vue.affccd46.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AddressInformation.vue.affccd46.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_Alert.vue.bc459fbf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Alert.vue.bc459fbf.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_TransitionTopToBottom.4698d329.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_Alert.vue.f8aa7eab.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Alert.vue.f8aa7eab.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_TransitionTopToBottom.4698d329.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_Btn.vue.5fe404b2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Btn.vue.5fe404b2.js",
    "imports": [
      "_clsx.0839fdbe.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_ButtonAddAdmin.88f11a76.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddAdmin.88f11a76.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_Card.960f2e39.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Card.960f2e39.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_Change.vue.98719626.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Change.vue.98719626.js",
    "imports": [
      "_Alert.vue.f8aa7eab.js",
      "_MTextField.vue.b498aaa7.js",
      "_MGroup.vue.3adfa2ee.js",
      "_Btn.vue.5fe404b2.js",
      "_vee-validate.esm.e1d01c89.js",
      "_useSchema.4cccd410.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "_InputOTP.vue.13875574.js",
      "_Group.vue.544f3917.js"
    ]
  },
  "_ChangePassword.3c19cb3f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ChangePassword.3c19cb3f.js",
    "imports": [
      "_Alert.vue.bc459fbf.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.bc2033b3.js",
      "_swiper-vue.a2ec9d3a.js",
      "_vee-validate.esm.e1d01c89.js",
      "_MTextField.vue.b498aaa7.js",
      "_MGroup.vue.3adfa2ee.js",
      "_useSchema.4cccd410.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.fd9a7f77.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.544f3917.js",
      "_usePasswordHelper.405d6e13.js"
    ]
  },
  "_Container.0cd5d143.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Container.0cd5d143.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_CtaSection.vue.0ca7b93b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CtaSection.vue.0ca7b93b.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_Default.vue.21eafb3e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Default.vue.21eafb3e.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "_Container.0cd5d143.js"
    ]
  },
  "_Destinations.c704fcac.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Destinations.c704fcac.js",
    "imports": [
      "_TextFieldWLabel.vue.ea251b34.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.e1d01c89.js",
      "_useSchema.4cccd410.js",
      "_useDestinations.7197978e.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_Driver.257b3846.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Driver.257b3846.js",
    "imports": [
      "_TextFieldWLabel.vue.ea251b34.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.e1d01c89.js",
      "_useSchema.4cccd410.js",
      "_useDriver.d5135469.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_DropdownsTest.1d69538b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DropdownsTest.1d69538b.js",
    "imports": [
      "_vee-validate.esm.e1d01c89.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.bc2033b3.js"
    ]
  },
  "_Empty.f49c129e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Empty.f49c129e.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_FacilityCar.2d6f15c3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FacilityCar.2d6f15c3.js",
    "imports": [
      "_TextFieldWLabel.vue.ea251b34.js",
      "_vee-validate.esm.e1d01c89.js",
      "_Group.vue.544f3917.js",
      "_TabContent.vue.13eed56e.js",
      "_InputImageCropAdmin.99af01ac.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.4cccd410.js",
      "_useFacility.8ace1d60.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_FormatMoneyDash.aea6127b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FormatMoneyDash.aea6127b.js"
  },
  "_Group.vue.544f3917.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Group.vue.544f3917.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_HeadPage.vue.205eac6b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "HeadPage.vue.205eac6b.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_InputImageCropAdmin.99af01ac.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "InputImageCropAdmin.99af01ac.js",
    "imports": [
      "_Modal.18c50805.js",
      "_vee-validate.esm.e1d01c89.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_client-only.6d667476.js",
      "_index.bc2033b3.js",
      "_index.4f128f8f.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_InputOTP.vue.13875574.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "InputOTP.vue.13875574.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_MGroup.vue.3adfa2ee.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MGroup.vue.3adfa2ee.js",
    "imports": [
      "_vee-validate.esm.e1d01c89.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_clsx.0839fdbe.js"
    ]
  },
  "_MSelect.vue.caed18e9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MSelect.vue.caed18e9.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.e1d01c89.js"
    ]
  },
  "_MTextField.vue.b498aaa7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MTextField.vue.b498aaa7.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.e1d01c89.js"
    ]
  },
  "_Modal.18c50805.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Modal.200da282.css"
    ],
    "file": "Modal.18c50805.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.a2ec9d3a.js",
      "_index.bc2033b3.js",
      "_index.7d9a9c74.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "Modal.200da282.css": {
    "file": "Modal.200da282.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_PaginationAdmin.8ea8d350.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "PaginationAdmin.8ea8d350.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_PriceCheckoutInformation.b98e0ac4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "PriceCheckoutInformation.b98e0ac4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_SelectedCard.vue.c4671fff.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "SelectedCard.vue.c4671fff.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_Switch.vue.a1a98db5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Switch.vue.a1a98db5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_TabContent.vue.13eed56e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TabContent.vue.13eed56e.js",
    "imports": [
      "_clsx.0839fdbe.js",
      "_swiper-vue.a2ec9d3a.js",
      "_client-only.6d667476.js"
    ]
  },
  "_TextFieldWLabel.vue.ea251b34.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TextFieldWLabel.vue.ea251b34.js",
    "imports": [
      "_vee-validate.esm.e1d01c89.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_TitleAdmin.6ef3e3ec.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleAdmin.6ef3e3ec.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_TitleBack.2045ca6f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleBack.2045ca6f.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_TourPackage.2a5a7a35.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "TourPackage.da417478.css"
    ],
    "file": "TourPackage.2a5a7a35.js",
    "imports": [
      "_TextFieldWLabel.vue.ea251b34.js",
      "_DropdownsTest.1d69538b.js",
      "_vee-validate.esm.e1d01c89.js",
      "_client-only.6d667476.js",
      "_swiper-vue.a2ec9d3a.js",
      "_Group.vue.544f3917.js",
      "_TabContent.vue.13eed56e.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useTourPackage.b7ec0efb.js",
      "_index.bc2033b3.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.4cccd410.js"
    ]
  },
  "TourPackage.da417478.css": {
    "file": "TourPackage.da417478.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TransitionTopToBottom.4698d329.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TransitionTopToBottom.4698d329.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_Transport.09bdb897.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Transport.09bdb897.js",
    "imports": [
      "_vee-validate.esm.e1d01c89.js",
      "_InputImageCropAdmin.99af01ac.js",
      "_TextFieldWLabel.vue.ea251b34.js",
      "_DropdownsTest.1d69538b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.4cccd410.js",
      "_useTransport.d88aeb30.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_client-only.6d667476.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client-only.6d667476.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_clsx.0839fdbe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "clsx.0839fdbe.js"
  },
  "_config.74fcdb9d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.74fcdb9d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_hi-transfer-logo.87e657eb.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hi-transfer-logo.87e657eb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.4f128f8f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.4f128f8f.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_index.7d9a9c74.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.7d9a9c74.js"
  },
  "_index.bc2033b3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.bc2033b3.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_nofication.fd9a7f77.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nofication.fd9a7f77.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_swiper-vue.a2ec9d3a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.d33d3671.css"
    ],
    "file": "swiper-vue.a2ec9d3a.js"
  },
  "swiper-vue.d33d3671.css": {
    "file": "swiper-vue.d33d3671.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useCarStore.72c76b4e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useCarStore.72c76b4e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.fd9a7f77.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_useDestinations.7197978e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useDestinations.7197978e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.fd9a7f77.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_useDriver.d5135469.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useDriver.d5135469.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.fd9a7f77.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_useFacility.8ace1d60.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useFacility.8ace1d60.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.fd9a7f77.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_usePasswordHelper.405d6e13.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "usePasswordHelper.405d6e13.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_useSchema.4cccd410.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useSchema.4cccd410.js"
  },
  "_useTourPackage.b7ec0efb.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTourPackage.b7ec0efb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.fd9a7f77.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_useTourStore.e47357eb.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTourStore.e47357eb.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_useTransport.d88aeb30.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTransport.d88aeb30.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.fd9a7f77.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_vee-validate.esm.e1d01c89.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vee-validate.esm.e1d01c89.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "_vehicleForm.8ba2b956.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vehicleForm.8ba2b956.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ]
  },
  "assets/fonts/ClashGrotesk-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Bold.c4ea1fe3.ttf",
    "src": "assets/fonts/ClashGrotesk-Bold.ttf"
  },
  "assets/fonts/ClashGrotesk-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Bold.b1b9970d.woff",
    "src": "assets/fonts/ClashGrotesk-Bold.woff"
  },
  "assets/fonts/ClashGrotesk-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Bold.602a56af.woff2",
    "src": "assets/fonts/ClashGrotesk-Bold.woff2"
  },
  "assets/fonts/ClashGrotesk-Extralight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Extralight.6417ca23.ttf",
    "src": "assets/fonts/ClashGrotesk-Extralight.ttf"
  },
  "assets/fonts/ClashGrotesk-Extralight.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Extralight.c9c2a3a9.woff",
    "src": "assets/fonts/ClashGrotesk-Extralight.woff"
  },
  "assets/fonts/ClashGrotesk-Extralight.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Extralight.fe206472.woff2",
    "src": "assets/fonts/ClashGrotesk-Extralight.woff2"
  },
  "assets/fonts/ClashGrotesk-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Light.8e98f3c7.ttf",
    "src": "assets/fonts/ClashGrotesk-Light.ttf"
  },
  "assets/fonts/ClashGrotesk-Light.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Light.04e1d585.woff",
    "src": "assets/fonts/ClashGrotesk-Light.woff"
  },
  "assets/fonts/ClashGrotesk-Light.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Light.f0f7605c.woff2",
    "src": "assets/fonts/ClashGrotesk-Light.woff2"
  },
  "assets/fonts/ClashGrotesk-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Medium.717fd45f.ttf",
    "src": "assets/fonts/ClashGrotesk-Medium.ttf"
  },
  "assets/fonts/ClashGrotesk-Medium.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Medium.94bcd03c.woff",
    "src": "assets/fonts/ClashGrotesk-Medium.woff"
  },
  "assets/fonts/ClashGrotesk-Medium.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Medium.5c3815cf.woff2",
    "src": "assets/fonts/ClashGrotesk-Medium.woff2"
  },
  "assets/fonts/ClashGrotesk-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Regular.5c66c57f.ttf",
    "src": "assets/fonts/ClashGrotesk-Regular.ttf"
  },
  "assets/fonts/ClashGrotesk-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Regular.1c248756.woff",
    "src": "assets/fonts/ClashGrotesk-Regular.woff"
  },
  "assets/fonts/ClashGrotesk-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Regular.03ad7ecf.woff2",
    "src": "assets/fonts/ClashGrotesk-Regular.woff2"
  },
  "assets/fonts/ClashGrotesk-Semibold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Semibold.bdc47ea3.ttf",
    "src": "assets/fonts/ClashGrotesk-Semibold.ttf"
  },
  "assets/fonts/ClashGrotesk-Semibold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Semibold.48fdb6da.woff",
    "src": "assets/fonts/ClashGrotesk-Semibold.woff"
  },
  "assets/fonts/ClashGrotesk-Semibold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Semibold.befc1942.woff2",
    "src": "assets/fonts/ClashGrotesk-Semibold.woff2"
  },
  "assets/fonts/ClashGrotesk-Variable.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Variable.5887a1df.ttf",
    "src": "assets/fonts/ClashGrotesk-Variable.ttf"
  },
  "assets/fonts/ClashGrotesk-Variable.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Variable.de7ab3f6.woff",
    "src": "assets/fonts/ClashGrotesk-Variable.woff"
  },
  "assets/fonts/ClashGrotesk-Variable.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Variable.3c56fcff.woff2",
    "src": "assets/fonts/ClashGrotesk-Variable.woff2"
  },
  "assets/fonts/GeneralSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Bold.1c435b33.ttf",
    "src": "assets/fonts/GeneralSans-Bold.ttf"
  },
  "assets/fonts/GeneralSans-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Bold.4c2b7f63.woff",
    "src": "assets/fonts/GeneralSans-Bold.woff"
  },
  "assets/fonts/GeneralSans-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Bold.a29eab9b.woff2",
    "src": "assets/fonts/GeneralSans-Bold.woff2"
  },
  "assets/fonts/GeneralSans-BoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-BoldItalic.2297ae79.ttf",
    "src": "assets/fonts/GeneralSans-BoldItalic.ttf"
  },
  "assets/fonts/GeneralSans-BoldItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-BoldItalic.0599ec69.woff",
    "src": "assets/fonts/GeneralSans-BoldItalic.woff"
  },
  "assets/fonts/GeneralSans-BoldItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-BoldItalic.97483640.woff2",
    "src": "assets/fonts/GeneralSans-BoldItalic.woff2"
  },
  "assets/fonts/GeneralSans-Extralight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Extralight.4cb07dad.ttf",
    "src": "assets/fonts/GeneralSans-Extralight.ttf"
  },
  "assets/fonts/GeneralSans-Extralight.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Extralight.6a52bdce.woff",
    "src": "assets/fonts/GeneralSans-Extralight.woff"
  },
  "assets/fonts/GeneralSans-Extralight.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Extralight.3e6ee7e5.woff2",
    "src": "assets/fonts/GeneralSans-Extralight.woff2"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-ExtralightItalic.9b80b399.ttf",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.ttf"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-ExtralightItalic.acc7311a.woff",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.woff"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-ExtralightItalic.83bbc211.woff2",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.woff2"
  },
  "assets/fonts/GeneralSans-Italic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Italic.ea19866f.ttf",
    "src": "assets/fonts/GeneralSans-Italic.ttf"
  },
  "assets/fonts/GeneralSans-Italic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Italic.f9e5a73e.woff",
    "src": "assets/fonts/GeneralSans-Italic.woff"
  },
  "assets/fonts/GeneralSans-Italic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Italic.1c91e1d3.woff2",
    "src": "assets/fonts/GeneralSans-Italic.woff2"
  },
  "assets/fonts/GeneralSans-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Light.86a255b5.ttf",
    "src": "assets/fonts/GeneralSans-Light.ttf"
  },
  "assets/fonts/GeneralSans-Light.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Light.09f0f0fe.woff",
    "src": "assets/fonts/GeneralSans-Light.woff"
  },
  "assets/fonts/GeneralSans-Light.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Light.ac0b8f29.woff2",
    "src": "assets/fonts/GeneralSans-Light.woff2"
  },
  "assets/fonts/GeneralSans-LightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-LightItalic.eb313a89.ttf",
    "src": "assets/fonts/GeneralSans-LightItalic.ttf"
  },
  "assets/fonts/GeneralSans-LightItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-LightItalic.639de7d9.woff",
    "src": "assets/fonts/GeneralSans-LightItalic.woff"
  },
  "assets/fonts/GeneralSans-LightItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-LightItalic.7787625d.woff2",
    "src": "assets/fonts/GeneralSans-LightItalic.woff2"
  },
  "assets/fonts/GeneralSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Medium.e85572fe.ttf",
    "src": "assets/fonts/GeneralSans-Medium.ttf"
  },
  "assets/fonts/GeneralSans-Medium.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Medium.f5beb161.woff",
    "src": "assets/fonts/GeneralSans-Medium.woff"
  },
  "assets/fonts/GeneralSans-Medium.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Medium.c30377df.woff2",
    "src": "assets/fonts/GeneralSans-Medium.woff2"
  },
  "assets/fonts/GeneralSans-MediumItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-MediumItalic.3b4e2f45.ttf",
    "src": "assets/fonts/GeneralSans-MediumItalic.ttf"
  },
  "assets/fonts/GeneralSans-MediumItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-MediumItalic.d02080e7.woff",
    "src": "assets/fonts/GeneralSans-MediumItalic.woff"
  },
  "assets/fonts/GeneralSans-MediumItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-MediumItalic.ffe0560d.woff2",
    "src": "assets/fonts/GeneralSans-MediumItalic.woff2"
  },
  "assets/fonts/GeneralSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Regular.0723d125.ttf",
    "src": "assets/fonts/GeneralSans-Regular.ttf"
  },
  "assets/fonts/GeneralSans-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Regular.52af118f.woff",
    "src": "assets/fonts/GeneralSans-Regular.woff"
  },
  "assets/fonts/GeneralSans-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Regular.3ec2be77.woff2",
    "src": "assets/fonts/GeneralSans-Regular.woff2"
  },
  "assets/fonts/GeneralSans-Semibold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Semibold.307d27c4.ttf",
    "src": "assets/fonts/GeneralSans-Semibold.ttf"
  },
  "assets/fonts/GeneralSans-Semibold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Semibold.eec4ab4c.woff",
    "src": "assets/fonts/GeneralSans-Semibold.woff"
  },
  "assets/fonts/GeneralSans-Semibold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Semibold.94a2a0e1.woff2",
    "src": "assets/fonts/GeneralSans-Semibold.woff2"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-SemiboldItalic.d3b62cb5.ttf",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.ttf"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-SemiboldItalic.cd1fca15.woff",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.woff"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-SemiboldItalic.98c7276f.woff2",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.woff2"
  },
  "assets/fonts/GeneralSans-Variable.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Variable.4b2539d9.ttf",
    "src": "assets/fonts/GeneralSans-Variable.ttf"
  },
  "assets/fonts/GeneralSans-Variable.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Variable.473d4f5e.woff",
    "src": "assets/fonts/GeneralSans-Variable.woff"
  },
  "assets/fonts/GeneralSans-Variable.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Variable.49d3fbd2.woff2",
    "src": "assets/fonts/GeneralSans-Variable.woff2"
  },
  "assets/fonts/GeneralSans-VariableItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-VariableItalic.4aa0c20d.ttf",
    "src": "assets/fonts/GeneralSans-VariableItalic.ttf"
  },
  "assets/fonts/GeneralSans-VariableItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-VariableItalic.c0b7f35e.woff",
    "src": "assets/fonts/GeneralSans-VariableItalic.woff"
  },
  "assets/fonts/GeneralSans-VariableItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-VariableItalic.71537245.woff2",
    "src": "assets/fonts/GeneralSans-VariableItalic.woff2"
  },
  "assets/fonts/PlusJakartaSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Bold.3e08701b.ttf",
    "src": "assets/fonts/PlusJakartaSans-Bold.ttf"
  },
  "assets/fonts/PlusJakartaSans-BoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-BoldItalic.4486ec3d.ttf",
    "src": "assets/fonts/PlusJakartaSans-BoldItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraBold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraBold.644fda57.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraBold.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraBoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraBoldItalic.d51b806e.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraBoldItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraLight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraLight.9afaedac.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraLight.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraLightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraLightItalic.b7523f1e.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraLightItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Italic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Italic.b15bc27e.ttf",
    "src": "assets/fonts/PlusJakartaSans-Italic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Light.26e26359.ttf",
    "src": "assets/fonts/PlusJakartaSans-Light.ttf"
  },
  "assets/fonts/PlusJakartaSans-LightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-LightItalic.22823a55.ttf",
    "src": "assets/fonts/PlusJakartaSans-LightItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Medium.d6854d4b.ttf",
    "src": "assets/fonts/PlusJakartaSans-Medium.ttf"
  },
  "assets/fonts/PlusJakartaSans-MediumItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-MediumItalic.67cb7ae5.ttf",
    "src": "assets/fonts/PlusJakartaSans-MediumItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Regular.f7e7cebd.ttf",
    "src": "assets/fonts/PlusJakartaSans-Regular.ttf"
  },
  "assets/fonts/PlusJakartaSans-SemiBold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-SemiBold.d32adf41.ttf",
    "src": "assets/fonts/PlusJakartaSans-SemiBold.ttf"
  },
  "assets/fonts/PlusJakartaSans-SemiBoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-SemiBoldItalic.48a17bbd.ttf",
    "src": "assets/fonts/PlusJakartaSans-SemiBoldItalic.ttf"
  },
  "layouts/admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.407f4792.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "_nofication.fd9a7f77.js",
      "_hi-transfer-logo.87e657eb.js",
      "_index.bc2033b3.js",
      "_config.74fcdb9d.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/admin.vue"
  },
  "layouts/auth.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth.2c135292.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Switch.vue.a1a98db5.js",
      "_client-only.6d667476.js",
      "_hi-transfer-logo.87e657eb.js",
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/auth.vue"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.ad4470b1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Switch.vue.a1a98db5.js",
      "_Default.vue.21eafb3e.js",
      "_client-only.6d667476.js",
      "_hi-transfer-logo.87e657eb.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_Container.0cd5d143.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "layouts/empty.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "empty.bc08d9ee.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/empty.vue"
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "user.191f232a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Switch.vue.a1a98db5.js",
      "_Default.vue.21eafb3e.js",
      "_client-only.6d667476.js",
      "_hi-transfer-logo.87e657eb.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_Container.0cd5d143.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "middleware/admin.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.8c8fd615.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/admin.ts"
  },
  "middleware/user.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "user.51b4e018.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/user.ts"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Icon.6f5d80f8.css",
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.css"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Icon.ffa047f6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_config.74fcdb9d.js",
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.vue"
  },
  "Icon.6f5d80f8.css": {
    "file": "Icon.6f5d80f8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "IconCSS.fe0874d9.css",
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.css"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "IconCSS.0f179e5e.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_config.74fcdb9d.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.vue"
  },
  "IconCSS.fe0874d9.css": {
    "file": "IconCSS.fe0874d9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.2cc35f7b.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.2cc35f7b.css"
    ],
    "dynamicImports": [
      "middleware/admin.ts",
      "middleware/user.ts",
      "layouts/admin.vue",
      "layouts/auth.vue",
      "layouts/default.vue",
      "layouts/empty.vue",
      "layouts/user.vue"
    ],
    "file": "entry.d8fd5a2c.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.2cc35f7b.css": {
    "file": "entry.2cc35f7b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/admin-list/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.ebe24a90.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_TitleAdmin.6ef3e3ec.js",
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/index.vue"
  },
  "pages/admin/destinations/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.d99b4d5d.js",
    "imports": [
      "_TitleBack.2045ca6f.js",
      "_Destinations.c704fcac.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_TextFieldWLabel.vue.ea251b34.js",
      "_vee-validate.esm.e1d01c89.js",
      "_useSchema.4cccd410.js",
      "_useDestinations.7197978e.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/add.vue"
  },
  "pages/admin/destinations/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.d80d2448.js",
    "imports": [
      "_TitleBack.2045ca6f.js",
      "_Destinations.c704fcac.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_TextFieldWLabel.vue.ea251b34.js",
      "_vee-validate.esm.e1d01c89.js",
      "_useSchema.4cccd410.js",
      "_useDestinations.7197978e.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/edit/[slug].vue"
  },
  "pages/admin/destinations/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.d1825211.js",
    "imports": [
      "_ButtonAddAdmin.88f11a76.js",
      "_TitleAdmin.6ef3e3ec.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.8ea8d350.js",
      "_Modal.18c50805.js",
      "_swiper-vue.a2ec9d3a.js",
      "_useDestinations.7197978e.js",
      "_config.74fcdb9d.js",
      "_index.bc2033b3.js",
      "_index.7d9a9c74.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/index.vue"
  },
  "pages/admin/driver/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.988c9412.js",
    "imports": [
      "_TitleBack.2045ca6f.js",
      "_Driver.257b3846.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_TextFieldWLabel.vue.ea251b34.js",
      "_vee-validate.esm.e1d01c89.js",
      "_useSchema.4cccd410.js",
      "_useDriver.d5135469.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/add.vue"
  },
  "pages/admin/driver/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.ff0e1c12.js",
    "imports": [
      "_TitleBack.2045ca6f.js",
      "_Driver.257b3846.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_TextFieldWLabel.vue.ea251b34.js",
      "_vee-validate.esm.e1d01c89.js",
      "_useSchema.4cccd410.js",
      "_useDriver.d5135469.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/edit/[slug].vue"
  },
  "pages/admin/driver/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.b4052f20.js",
    "imports": [
      "_ButtonAddAdmin.88f11a76.js",
      "_TitleAdmin.6ef3e3ec.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.8ea8d350.js",
      "_Modal.18c50805.js",
      "_swiper-vue.a2ec9d3a.js",
      "_useDriver.d5135469.js",
      "_index.bc2033b3.js",
      "_config.74fcdb9d.js",
      "_index.7d9a9c74.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/index.vue"
  },
  "pages/admin/email-verification/[token].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_token_.62ecbdc4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/email-verification/[token].vue"
  },
  "pages/admin/facility-car/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.54da6a67.js",
    "imports": [
      "_TitleBack.2045ca6f.js",
      "_FacilityCar.2d6f15c3.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_TextFieldWLabel.vue.ea251b34.js",
      "_vee-validate.esm.e1d01c89.js",
      "_Group.vue.544f3917.js",
      "_TabContent.vue.13eed56e.js",
      "_clsx.0839fdbe.js",
      "_client-only.6d667476.js",
      "_InputImageCropAdmin.99af01ac.js",
      "_Modal.18c50805.js",
      "_index.bc2033b3.js",
      "_index.7d9a9c74.js",
      "_index.4f128f8f.js",
      "_useSchema.4cccd410.js",
      "_useFacility.8ace1d60.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/add.vue"
  },
  "pages/admin/facility-car/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.5546d6aa.js",
    "imports": [
      "_TitleBack.2045ca6f.js",
      "_FacilityCar.2d6f15c3.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_TextFieldWLabel.vue.ea251b34.js",
      "_vee-validate.esm.e1d01c89.js",
      "_Group.vue.544f3917.js",
      "_TabContent.vue.13eed56e.js",
      "_clsx.0839fdbe.js",
      "_client-only.6d667476.js",
      "_InputImageCropAdmin.99af01ac.js",
      "_Modal.18c50805.js",
      "_index.bc2033b3.js",
      "_index.7d9a9c74.js",
      "_index.4f128f8f.js",
      "_useSchema.4cccd410.js",
      "_useFacility.8ace1d60.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/edit/[slug].vue"
  },
  "pages/admin/facility-car/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.de448846.js",
    "imports": [
      "_ButtonAddAdmin.88f11a76.js",
      "_TitleAdmin.6ef3e3ec.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.8ea8d350.js",
      "_Modal.18c50805.js",
      "_swiper-vue.a2ec9d3a.js",
      "_useFacility.8ace1d60.js",
      "_config.74fcdb9d.js",
      "_index.bc2033b3.js",
      "_index.7d9a9c74.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/index.vue"
  },
  "pages/admin/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.4e4e1d28.js",
    "imports": [
      "_Change.vue.98719626.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.bc2033b3.js",
      "_swiper-vue.a2ec9d3a.js",
      "_Alert.vue.f8aa7eab.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_TransitionTopToBottom.4698d329.js",
      "_MTextField.vue.b498aaa7.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.e1d01c89.js",
      "_MGroup.vue.3adfa2ee.js",
      "_Btn.vue.5fe404b2.js",
      "_useSchema.4cccd410.js",
      "_InputOTP.vue.13875574.js",
      "_Group.vue.544f3917.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/forgot-password.vue"
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.6bbc20ab.js",
    "imports": [
      "_HeadPage.vue.205eac6b.js",
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/index.vue"
  },
  "pages/admin/orders/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.66e059d8.js",
    "imports": [
      "_HeadPage.vue.205eac6b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "_config.74fcdb9d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/index.vue"
  },
  "pages/admin/orders/order-detail-fastboat/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.dedfee0a.js",
    "imports": [
      "_TitleAdmin.6ef3e3ec.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-detail-fastboat/[slug].vue"
  },
  "pages/admin/orders/order-detail-tourpackage/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.f37837e9.js",
    "imports": [
      "_MSelect.vue.caed18e9.js",
      "_MGroup.vue.3adfa2ee.js",
      "_TitleAdmin.6ef3e3ec.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.e1d01c89.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-detail-tourpackage/[slug].vue"
  },
  "pages/admin/orders/order-edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.995eabbd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-edit/[slug].vue"
  },
  "pages/admin/profile.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "profile.6b7e7926.js",
    "imports": [
      "_ChangePassword.3c19cb3f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "_Alert.vue.bc459fbf.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_TransitionTopToBottom.4698d329.js",
      "_index.bc2033b3.js",
      "_vee-validate.esm.e1d01c89.js",
      "_MTextField.vue.b498aaa7.js",
      "_clsx.0839fdbe.js",
      "_MGroup.vue.3adfa2ee.js",
      "_useSchema.4cccd410.js",
      "_nofication.fd9a7f77.js",
      "_Group.vue.544f3917.js",
      "_usePasswordHelper.405d6e13.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/profile.vue"
  },
  "pages/admin/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.8aea5711.js",
    "imports": [
      "_MTextField.vue.b498aaa7.js",
      "_MGroup.vue.3adfa2ee.js",
      "_Btn.vue.5fe404b2.js",
      "_vee-validate.esm.e1d01c89.js",
      "_useSchema.4cccd410.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "_clsx.0839fdbe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/sign-in.vue"
  },
  "pages/admin/tour-package/[slug]/edit.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "edit.b7385161.js",
    "imports": [
      "_TitleBack.2045ca6f.js",
      "_TourPackage.2a5a7a35.js",
      "_useSchema.4cccd410.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_TextFieldWLabel.vue.ea251b34.js",
      "_vee-validate.esm.e1d01c89.js",
      "_DropdownsTest.1d69538b.js",
      "_index.bc2033b3.js",
      "_client-only.6d667476.js",
      "_Group.vue.544f3917.js",
      "_TabContent.vue.13eed56e.js",
      "_clsx.0839fdbe.js",
      "_useTourPackage.b7ec0efb.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/[slug]/edit.vue"
  },
  "pages/admin/tour-package/[slug]/images.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "images.9593b3ed.js",
    "imports": [
      "_TitleBack.2045ca6f.js",
      "_Alert.vue.bc459fbf.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Modal.18c50805.js",
      "_index.bc2033b3.js",
      "_swiper-vue.a2ec9d3a.js",
      "_client-only.6d667476.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.4f128f8f.js",
      "_TransitionTopToBottom.4698d329.js",
      "_config.74fcdb9d.js",
      "_index.7d9a9c74.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/[slug]/images.vue"
  },
  "pages/admin/tour-package/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.4e9d7daa.js",
    "imports": [
      "_TitleBack.2045ca6f.js",
      "_TourPackage.2a5a7a35.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_TextFieldWLabel.vue.ea251b34.js",
      "_vee-validate.esm.e1d01c89.js",
      "_DropdownsTest.1d69538b.js",
      "_index.bc2033b3.js",
      "_client-only.6d667476.js",
      "_Group.vue.544f3917.js",
      "_TabContent.vue.13eed56e.js",
      "_clsx.0839fdbe.js",
      "_useTourPackage.b7ec0efb.js",
      "_nofication.fd9a7f77.js",
      "_useSchema.4cccd410.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/add.vue"
  },
  "pages/admin/tour-package/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.3ef1b5b5.js",
    "imports": [
      "_ButtonAddAdmin.88f11a76.js",
      "_TitleAdmin.6ef3e3ec.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.8ea8d350.js",
      "_Modal.18c50805.js",
      "_swiper-vue.a2ec9d3a.js",
      "_useTourPackage.b7ec0efb.js",
      "_FormatMoneyDash.aea6127b.js",
      "_index.bc2033b3.js",
      "_config.74fcdb9d.js",
      "_index.7d9a9c74.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/index.vue"
  },
  "pages/admin/transport/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.a7417fce.js",
    "imports": [
      "_TitleBack.2045ca6f.js",
      "_Transport.09bdb897.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_vee-validate.esm.e1d01c89.js",
      "_InputImageCropAdmin.99af01ac.js",
      "_Modal.18c50805.js",
      "_index.bc2033b3.js",
      "_index.7d9a9c74.js",
      "_client-only.6d667476.js",
      "_index.4f128f8f.js",
      "_TextFieldWLabel.vue.ea251b34.js",
      "_DropdownsTest.1d69538b.js",
      "_useSchema.4cccd410.js",
      "_useTransport.d88aeb30.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/add.vue"
  },
  "pages/admin/transport/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.be5c1c10.js",
    "imports": [
      "_TitleBack.2045ca6f.js",
      "_Transport.09bdb897.js",
      "_useSchema.4cccd410.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_vee-validate.esm.e1d01c89.js",
      "_InputImageCropAdmin.99af01ac.js",
      "_Modal.18c50805.js",
      "_index.bc2033b3.js",
      "_index.7d9a9c74.js",
      "_client-only.6d667476.js",
      "_index.4f128f8f.js",
      "_TextFieldWLabel.vue.ea251b34.js",
      "_DropdownsTest.1d69538b.js",
      "_useTransport.d88aeb30.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/edit/[slug].vue"
  },
  "pages/admin/transport/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.c0036203.js",
    "imports": [
      "_ButtonAddAdmin.88f11a76.js",
      "_TitleAdmin.6ef3e3ec.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.8ea8d350.js",
      "_Modal.18c50805.js",
      "_useTransport.d88aeb30.js",
      "_FormatMoneyDash.aea6127b.js",
      "_index.bc2033b3.js",
      "_config.74fcdb9d.js",
      "_index.7d9a9c74.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/index.vue"
  },
  "pages/admin/users/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.185ef2ec.js",
    "imports": [
      "_TitleBack.2045ca6f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/users/edit/[slug].vue"
  },
  "pages/admin/users/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.33142f57.js",
    "imports": [
      "_TitleAdmin.6ef3e3ec.js",
      "_PaginationAdmin.8ea8d350.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/users/index.vue"
  },
  "pages/auth-redirect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth-redirect.29521092.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/auth-redirect.vue"
  },
  "pages/email-verification/[token].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_token_.857c514c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/email-verification/[token].vue"
  },
  "pages/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.24a94c11.js",
    "imports": [
      "_Change.vue.98719626.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.bc2033b3.js",
      "_swiper-vue.a2ec9d3a.js",
      "_Alert.vue.f8aa7eab.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_TransitionTopToBottom.4698d329.js",
      "_MTextField.vue.b498aaa7.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.e1d01c89.js",
      "_MGroup.vue.3adfa2ee.js",
      "_Btn.vue.5fe404b2.js",
      "_useSchema.4cccd410.js",
      "_InputOTP.vue.13875574.js",
      "_Group.vue.544f3917.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/forgot-password.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.971e16b8.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.73ddd1e0.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_clsx.0839fdbe.js",
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.bc2033b3.js",
      "_index.7d9a9c74.js",
      "_vee-validate.esm.e1d01c89.js",
      "_MGroup.vue.3adfa2ee.js",
      "_MTextField.vue.b498aaa7.js",
      "_MSelect.vue.caed18e9.js",
      "_Btn.vue.5fe404b2.js",
      "_nofication.fd9a7f77.js",
      "_useSchema.4cccd410.js",
      "_useCarStore.72c76b4e.js",
      "_useTourStore.e47357eb.js",
      "_Card.960f2e39.js",
      "_Container.0cd5d143.js",
      "_CtaSection.vue.0ca7b93b.js",
      "_config.74fcdb9d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.971e16b8.css": {
    "file": "index.971e16b8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.5d8094d9.js",
    "imports": [
      "_Alert.vue.f8aa7eab.js",
      "_MTextField.vue.b498aaa7.js",
      "_MGroup.vue.3adfa2ee.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.5fe404b2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.e1d01c89.js",
      "_useSchema.4cccd410.js",
      "_usePasswordHelper.405d6e13.js",
      "_swiper-vue.a2ec9d3a.js",
      "_TransitionTopToBottom.4698d329.js",
      "_clsx.0839fdbe.js",
      "_config.74fcdb9d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign-in.vue"
  },
  "pages/sign-up.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-up.1e106597.js",
    "imports": [
      "_Alert.vue.f8aa7eab.js",
      "_MTextField.vue.b498aaa7.js",
      "_MGroup.vue.3adfa2ee.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.5fe404b2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.e1d01c89.js",
      "_useSchema.4cccd410.js",
      "_usePasswordHelper.405d6e13.js",
      "_swiper-vue.a2ec9d3a.js",
      "_TransitionTopToBottom.4698d329.js",
      "_clsx.0839fdbe.js",
      "_config.74fcdb9d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign-up.vue"
  },
  "pages/tours/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.b14ca90f.css",
    "src": "pages/tours/[slug].css"
  },
  "pages/tours/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.3f3e45bc.js",
    "imports": [
      "_swiper-vue.a2ec9d3a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_FormatMoneyDash.aea6127b.js",
      "_Container.0cd5d143.js",
      "_CtaSection.vue.0ca7b93b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useTourStore.e47357eb.js",
      "_config.74fcdb9d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/[slug].vue"
  },
  "_slug_.b14ca90f.css": {
    "file": "_slug_.b14ca90f.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/tours/booking.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "booking.d38f9158.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "_Container.0cd5d143.js",
      "_Btn.vue.5fe404b2.js",
      "_vehicleForm.8ba2b956.js",
      "_clsx.0839fdbe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking.vue"
  },
  "pages/tours/booking/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkout.f2f182e2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "_PriceCheckoutInformation.b98e0ac4.js",
      "_FormatMoneyDash.aea6127b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking/checkout.vue"
  },
  "pages/tours/booking/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.7f95b5cc.js",
    "imports": [
      "_MTextField.vue.b498aaa7.js",
      "_MGroup.vue.3adfa2ee.js",
      "_vee-validate.esm.e1d01c89.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "_MSelect.vue.caed18e9.js",
      "_vehicleForm.8ba2b956.js",
      "_useTourStore.e47357eb.js",
      "_clsx.0839fdbe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking/index.vue"
  },
  "pages/tours/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.9ae4b32b.js",
    "imports": [
      "_Btn.vue.5fe404b2.js",
      "_Container.0cd5d143.js",
      "_Card.960f2e39.js",
      "_Empty.f49c129e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useTourStore.e47357eb.js",
      "_swiper-vue.a2ec9d3a.js",
      "_clsx.0839fdbe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/index.vue"
  },
  "pages/user/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.a2398617.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_PaginationAdmin.8ea8d350.js",
      "_Container.0cd5d143.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "_config.74fcdb9d.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/index.vue"
  },
  "pages/user/order/order-summary/car/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.2c18087c.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Container.0cd5d143.js",
      "_Alert.vue.bc459fbf.js",
      "_vee-validate.esm.e1d01c89.js",
      "_InputOTP.vue.13875574.js",
      "_swiper-vue.a2ec9d3a.js",
      "_useSchema.4cccd410.js",
      "_Modal.18c50805.js",
      "_config.74fcdb9d.js",
      "_TransitionTopToBottom.4698d329.js",
      "_index.bc2033b3.js",
      "_index.7d9a9c74.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/order/order-summary/car/[slug].vue"
  },
  "pages/user/order/order-summary/tour/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.912a01c6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/order/order-summary/tour/[slug].vue"
  },
  "pages/user/profile.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "profile.b4fedc11.js",
    "imports": [
      "_ChangePassword.3c19cb3f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.a2ec9d3a.js",
      "_Alert.vue.bc459fbf.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.74fcdb9d.js",
      "_TransitionTopToBottom.4698d329.js",
      "_index.bc2033b3.js",
      "_vee-validate.esm.e1d01c89.js",
      "_MTextField.vue.b498aaa7.js",
      "_clsx.0839fdbe.js",
      "_MGroup.vue.3adfa2ee.js",
      "_useSchema.4cccd410.js",
      "_nofication.fd9a7f77.js",
      "_Group.vue.544f3917.js",
      "_usePasswordHelper.405d6e13.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/profile.vue"
  },
  "pages/vehicles/booking.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "booking.7a011784.js",
    "imports": [
      "_Btn.vue.5fe404b2.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.0cd5d143.js",
      "_AddressInformation.vue.affccd46.js",
      "_MTextField.vue.b498aaa7.js",
      "_MGroup.vue.3adfa2ee.js",
      "_vee-validate.esm.e1d01c89.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.4cccd410.js",
      "_useCarStore.72c76b4e.js",
      "_swiper-vue.a2ec9d3a.js",
      "_SelectedCard.vue.c4671fff.js",
      "_clsx.0839fdbe.js",
      "_config.74fcdb9d.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/booking.vue"
  },
  "pages/vehicles/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkout.dbd76c5d.js",
    "imports": [
      "_Btn.vue.5fe404b2.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.0cd5d143.js",
      "_AddressInformation.vue.affccd46.js",
      "_swiper-vue.a2ec9d3a.js",
      "_SelectedCard.vue.c4671fff.js",
      "_PriceCheckoutInformation.b98e0ac4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useCarStore.72c76b4e.js",
      "_clsx.0839fdbe.js",
      "_config.74fcdb9d.js",
      "_FormatMoneyDash.aea6127b.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/checkout.vue"
  },
  "pages/vehicles/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.ae4bec36.js",
    "imports": [
      "_Btn.vue.5fe404b2.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.0cd5d143.js",
      "_AddressInformation.vue.affccd46.js",
      "_MSelect.vue.caed18e9.js",
      "_MGroup.vue.3adfa2ee.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useCarStore.72c76b4e.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.a2ec9d3a.js",
      "_Empty.f49c129e.js",
      "_clsx.0839fdbe.js",
      "_config.74fcdb9d.js",
      "_vee-validate.esm.e1d01c89.js",
      "_nofication.fd9a7f77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/index.vue"
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.d33d3671.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
