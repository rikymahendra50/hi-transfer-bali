const client_manifest = {
  "FloatingWa.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "FloatingWa.a9fd3de1.css",
    "src": "FloatingWa.css"
  },
  "Modal.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Modal.200da282.css",
    "src": "Modal.css"
  },
  "TourPackage.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "TourPackage.da417478.css",
    "src": "TourPackage.css"
  },
  "_AddressInformation.vue.874d55ed.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AddressInformation.vue.874d55ed.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Alert.vue.14b4e95a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Alert.vue.14b4e95a.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_TransitionTopToBottom.a65a6e06.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Alert.vue.a8667257.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Alert.vue.a8667257.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_TransitionTopToBottom.a65a6e06.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Btn.vue.77dc26e2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Btn.vue.77dc26e2.js",
    "imports": [
      "_clsx.0839fdbe.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_ButtonAddAdmin.b3c4f406.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddAdmin.b3c4f406.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Card.fc3a008c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Card.fc3a008c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useTourStore.b27b72b1.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Change.vue.7f8ebdc7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Change.vue.7f8ebdc7.js",
    "imports": [
      "_Alert.vue.a8667257.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.fbe4ab58.js",
      "_Btn.vue.77dc26e2.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.f9491038.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_InputOTP.vue.34ce9cc3.js",
      "_TransitionX.f014ad75.js",
      "_Group.vue.dbd5fea5.js"
    ]
  },
  "_ChangePassword.27a125e5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ChangePassword.27a125e5.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.3f648032.js",
      "_swiper-vue.f9dac270.js",
      "_Alert.vue.14b4e95a.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.f014ad75.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.12fb76c2.js",
      "_useSchema.f9491038.js",
      "_usePasswordHelper.66d7e1e2.js"
    ]
  },
  "_Container.a5133fd3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Container.a5133fd3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_CtaSection.vue.111a3771.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CtaSection.vue.111a3771.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Destinations.053e60ae.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Destinations.053e60ae.js",
    "imports": [
      "_TextFieldWLabel.vue.bae6c828.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.f9491038.js",
      "_useDestinations.e996f63f.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Driver.8582dd28.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Driver.8582dd28.js",
    "imports": [
      "_TextFieldWLabel.vue.bae6c828.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.f9491038.js",
      "_useDriver.b3fe46fb.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_DropdownsTest.3420dba9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DropdownsTest.3420dba9.js",
    "imports": [
      "_vee-validate.esm.c1170e9f.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.3f648032.js"
    ]
  },
  "_Empty.1d65daef.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Empty.1d65daef.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_FacilityCar.1ba58a9e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FacilityCar.1ba58a9e.js",
    "imports": [
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_InputImageCropAdmin.3a591c6e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.f9491038.js",
      "_useFacility.f13172b7.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_FloatingWa.6c2bde58.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "FloatingWa.a9fd3de1.css"
    ],
    "file": "FloatingWa.6c2bde58.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_Container.a5133fd3.js"
    ]
  },
  "FloatingWa.a9fd3de1.css": {
    "file": "FloatingWa.a9fd3de1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_FormAdmin.vue.f80385c8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FormAdmin.vue.f80385c8.js",
    "imports": [
      "_Alert.vue.14b4e95a.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.f014ad75.js",
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.12fb76c2.js"
    ]
  },
  "_FormatMoneyDash.aea6127b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "FormatMoneyDash.aea6127b.js"
  },
  "_Group.vue.dbd5fea5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Group.vue.dbd5fea5.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_HeadPage.vue.2fb6071b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "HeadPage.vue.2fb6071b.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_InputImageCropAdmin.3a591c6e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "InputImageCropAdmin.3a591c6e.js",
    "imports": [
      "_Modal.faa57450.js",
      "_vee-validate.esm.c1170e9f.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_client-only.bae35f15.js",
      "_index.3f648032.js",
      "_index.989c4c14.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_InputOTP.vue.34ce9cc3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "InputOTP.vue.34ce9cc3.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_MGroup.vue.fbe4ab58.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MGroup.vue.fbe4ab58.js",
    "imports": [
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.f014ad75.js",
      "_clsx.0839fdbe.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_MSelect.vue.344734d3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MSelect.vue.344734d3.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js"
    ]
  },
  "_MTextField.vue.00f77f35.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MTextField.vue.00f77f35.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js"
    ]
  },
  "_Modal.faa57450.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Modal.200da282.css"
    ],
    "file": "Modal.faa57450.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.f9dac270.js",
      "_index.3f648032.js",
      "_index.7d9a9c74.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "Modal.200da282.css": {
    "file": "Modal.200da282.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_PaginationAdmin.7a0a3d9d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "PaginationAdmin.7a0a3d9d.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_SelectedCard.vue.225d8c13.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "SelectedCard.vue.225d8c13.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_SelectedCard.vue.c17d99f4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "SelectedCard.vue.c17d99f4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_StatusActive.46e41038.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "StatusActive.46e41038.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_StatusTrueOrFalse.ce1ce725.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "StatusTrueOrFalse.ce1ce725.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Switch.vue.06203ac3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Switch.vue.06203ac3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TabContent.vue.9e619e50.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TabContent.vue.9e619e50.js",
    "imports": [
      "_clsx.0839fdbe.js",
      "_swiper-vue.f9dac270.js",
      "_client-only.bae35f15.js"
    ]
  },
  "_TextFieldWLabel.vue.bae6c828.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TextFieldWLabel.vue.bae6c828.js",
    "imports": [
      "_vee-validate.esm.c1170e9f.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TitleAdmin.d9ac3a1d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleAdmin.d9ac3a1d.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TitleAdminBack.5d2853b8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleAdminBack.5d2853b8.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TitleBack.db770a10.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleBack.db770a10.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_TourPackage.48749476.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "TourPackage.da417478.css"
    ],
    "file": "TourPackage.48749476.js",
    "imports": [
      "_TextFieldWLabel.vue.bae6c828.js",
      "_DropdownsTest.3420dba9.js",
      "_vee-validate.esm.c1170e9f.js",
      "_client-only.bae35f15.js",
      "_swiper-vue.f9dac270.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useTourPackage.b313d132.js",
      "_index.3f648032.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.f9491038.js"
    ]
  },
  "TourPackage.da417478.css": {
    "file": "TourPackage.da417478.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TransitionTopToBottom.a65a6e06.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TransitionTopToBottom.a65a6e06.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_TransitionX.f014ad75.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TransitionX.f014ad75.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_Transport.460c1453.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Transport.460c1453.js",
    "imports": [
      "_vee-validate.esm.c1170e9f.js",
      "_InputImageCropAdmin.3a591c6e.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_DropdownsTest.3420dba9.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.f9491038.js",
      "_useTransport.af9938f2.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_Verified.1801a22a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Verified.1801a22a.js",
    "imports": [
      "_Alert.vue.14b4e95a.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputOTP.vue.34ce9cc3.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_useSchema.f9491038.js"
    ]
  },
  "_client-only.bae35f15.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client-only.bae35f15.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_clsx.0839fdbe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "clsx.0839fdbe.js"
  },
  "_config.e1ad2671.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.e1ad2671.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_hi-transfer-logo.04c4b947.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hi-transfer-logo.04c4b947.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.27906dea.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.27906dea.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_index.3f648032.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.3f648032.js",
    "imports": [
      "_index.27906dea.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_index.7d9a9c74.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.7d9a9c74.js"
  },
  "_index.989c4c14.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.989c4c14.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_nofication.12fb76c2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nofication.12fb76c2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_swiper-vue.f9dac270.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.d33d3671.css"
    ],
    "file": "swiper-vue.f9dac270.js"
  },
  "swiper-vue.d33d3671.css": {
    "file": "swiper-vue.d33d3671.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useCarStore.eb19eba8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useCarStore.eb19eba8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.12fb76c2.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useDestinations.e996f63f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useDestinations.e996f63f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.12fb76c2.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useDriver.b3fe46fb.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useDriver.b3fe46fb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.12fb76c2.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useFacility.f13172b7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useFacility.f13172b7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.12fb76c2.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useFormatDate.74b73f07.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useFormatDate.74b73f07.js"
  },
  "_usePasswordHelper.66d7e1e2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "usePasswordHelper.66d7e1e2.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useSchema.f9491038.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useSchema.f9491038.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useTourPackage.b313d132.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTourPackage.b313d132.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.12fb76c2.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useTourStore.b27b72b1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTourStore.b27b72b1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.12fb76c2.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_useTransport.af9938f2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useTransport.af9938f2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.12fb76c2.js",
      "_swiper-vue.f9dac270.js"
    ]
  },
  "_vee-validate.esm.c1170e9f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vee-validate.esm.c1170e9f.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ]
  },
  "assets/fonts/ClashGrotesk-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Bold.c4ea1fe3.ttf",
    "src": "assets/fonts/ClashGrotesk-Bold.ttf"
  },
  "assets/fonts/ClashGrotesk-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Bold.b1b9970d.woff",
    "src": "assets/fonts/ClashGrotesk-Bold.woff"
  },
  "assets/fonts/ClashGrotesk-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Bold.602a56af.woff2",
    "src": "assets/fonts/ClashGrotesk-Bold.woff2"
  },
  "assets/fonts/ClashGrotesk-Extralight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Extralight.6417ca23.ttf",
    "src": "assets/fonts/ClashGrotesk-Extralight.ttf"
  },
  "assets/fonts/ClashGrotesk-Extralight.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Extralight.c9c2a3a9.woff",
    "src": "assets/fonts/ClashGrotesk-Extralight.woff"
  },
  "assets/fonts/ClashGrotesk-Extralight.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Extralight.fe206472.woff2",
    "src": "assets/fonts/ClashGrotesk-Extralight.woff2"
  },
  "assets/fonts/ClashGrotesk-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Light.8e98f3c7.ttf",
    "src": "assets/fonts/ClashGrotesk-Light.ttf"
  },
  "assets/fonts/ClashGrotesk-Light.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Light.04e1d585.woff",
    "src": "assets/fonts/ClashGrotesk-Light.woff"
  },
  "assets/fonts/ClashGrotesk-Light.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Light.f0f7605c.woff2",
    "src": "assets/fonts/ClashGrotesk-Light.woff2"
  },
  "assets/fonts/ClashGrotesk-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Medium.717fd45f.ttf",
    "src": "assets/fonts/ClashGrotesk-Medium.ttf"
  },
  "assets/fonts/ClashGrotesk-Medium.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Medium.94bcd03c.woff",
    "src": "assets/fonts/ClashGrotesk-Medium.woff"
  },
  "assets/fonts/ClashGrotesk-Medium.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Medium.5c3815cf.woff2",
    "src": "assets/fonts/ClashGrotesk-Medium.woff2"
  },
  "assets/fonts/ClashGrotesk-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Regular.5c66c57f.ttf",
    "src": "assets/fonts/ClashGrotesk-Regular.ttf"
  },
  "assets/fonts/ClashGrotesk-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Regular.1c248756.woff",
    "src": "assets/fonts/ClashGrotesk-Regular.woff"
  },
  "assets/fonts/ClashGrotesk-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Regular.03ad7ecf.woff2",
    "src": "assets/fonts/ClashGrotesk-Regular.woff2"
  },
  "assets/fonts/ClashGrotesk-Semibold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Semibold.bdc47ea3.ttf",
    "src": "assets/fonts/ClashGrotesk-Semibold.ttf"
  },
  "assets/fonts/ClashGrotesk-Semibold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Semibold.48fdb6da.woff",
    "src": "assets/fonts/ClashGrotesk-Semibold.woff"
  },
  "assets/fonts/ClashGrotesk-Semibold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Semibold.befc1942.woff2",
    "src": "assets/fonts/ClashGrotesk-Semibold.woff2"
  },
  "assets/fonts/ClashGrotesk-Variable.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Variable.5887a1df.ttf",
    "src": "assets/fonts/ClashGrotesk-Variable.ttf"
  },
  "assets/fonts/ClashGrotesk-Variable.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Variable.de7ab3f6.woff",
    "src": "assets/fonts/ClashGrotesk-Variable.woff"
  },
  "assets/fonts/ClashGrotesk-Variable.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Variable.3c56fcff.woff2",
    "src": "assets/fonts/ClashGrotesk-Variable.woff2"
  },
  "assets/fonts/GeneralSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Bold.1c435b33.ttf",
    "src": "assets/fonts/GeneralSans-Bold.ttf"
  },
  "assets/fonts/GeneralSans-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Bold.4c2b7f63.woff",
    "src": "assets/fonts/GeneralSans-Bold.woff"
  },
  "assets/fonts/GeneralSans-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Bold.a29eab9b.woff2",
    "src": "assets/fonts/GeneralSans-Bold.woff2"
  },
  "assets/fonts/GeneralSans-BoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-BoldItalic.2297ae79.ttf",
    "src": "assets/fonts/GeneralSans-BoldItalic.ttf"
  },
  "assets/fonts/GeneralSans-BoldItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-BoldItalic.0599ec69.woff",
    "src": "assets/fonts/GeneralSans-BoldItalic.woff"
  },
  "assets/fonts/GeneralSans-BoldItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-BoldItalic.97483640.woff2",
    "src": "assets/fonts/GeneralSans-BoldItalic.woff2"
  },
  "assets/fonts/GeneralSans-Extralight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Extralight.4cb07dad.ttf",
    "src": "assets/fonts/GeneralSans-Extralight.ttf"
  },
  "assets/fonts/GeneralSans-Extralight.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Extralight.6a52bdce.woff",
    "src": "assets/fonts/GeneralSans-Extralight.woff"
  },
  "assets/fonts/GeneralSans-Extralight.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Extralight.3e6ee7e5.woff2",
    "src": "assets/fonts/GeneralSans-Extralight.woff2"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-ExtralightItalic.9b80b399.ttf",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.ttf"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-ExtralightItalic.acc7311a.woff",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.woff"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-ExtralightItalic.83bbc211.woff2",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.woff2"
  },
  "assets/fonts/GeneralSans-Italic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Italic.ea19866f.ttf",
    "src": "assets/fonts/GeneralSans-Italic.ttf"
  },
  "assets/fonts/GeneralSans-Italic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Italic.f9e5a73e.woff",
    "src": "assets/fonts/GeneralSans-Italic.woff"
  },
  "assets/fonts/GeneralSans-Italic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Italic.1c91e1d3.woff2",
    "src": "assets/fonts/GeneralSans-Italic.woff2"
  },
  "assets/fonts/GeneralSans-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Light.86a255b5.ttf",
    "src": "assets/fonts/GeneralSans-Light.ttf"
  },
  "assets/fonts/GeneralSans-Light.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Light.09f0f0fe.woff",
    "src": "assets/fonts/GeneralSans-Light.woff"
  },
  "assets/fonts/GeneralSans-Light.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Light.ac0b8f29.woff2",
    "src": "assets/fonts/GeneralSans-Light.woff2"
  },
  "assets/fonts/GeneralSans-LightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-LightItalic.eb313a89.ttf",
    "src": "assets/fonts/GeneralSans-LightItalic.ttf"
  },
  "assets/fonts/GeneralSans-LightItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-LightItalic.639de7d9.woff",
    "src": "assets/fonts/GeneralSans-LightItalic.woff"
  },
  "assets/fonts/GeneralSans-LightItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-LightItalic.7787625d.woff2",
    "src": "assets/fonts/GeneralSans-LightItalic.woff2"
  },
  "assets/fonts/GeneralSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Medium.e85572fe.ttf",
    "src": "assets/fonts/GeneralSans-Medium.ttf"
  },
  "assets/fonts/GeneralSans-Medium.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Medium.f5beb161.woff",
    "src": "assets/fonts/GeneralSans-Medium.woff"
  },
  "assets/fonts/GeneralSans-Medium.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Medium.c30377df.woff2",
    "src": "assets/fonts/GeneralSans-Medium.woff2"
  },
  "assets/fonts/GeneralSans-MediumItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-MediumItalic.3b4e2f45.ttf",
    "src": "assets/fonts/GeneralSans-MediumItalic.ttf"
  },
  "assets/fonts/GeneralSans-MediumItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-MediumItalic.d02080e7.woff",
    "src": "assets/fonts/GeneralSans-MediumItalic.woff"
  },
  "assets/fonts/GeneralSans-MediumItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-MediumItalic.ffe0560d.woff2",
    "src": "assets/fonts/GeneralSans-MediumItalic.woff2"
  },
  "assets/fonts/GeneralSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Regular.0723d125.ttf",
    "src": "assets/fonts/GeneralSans-Regular.ttf"
  },
  "assets/fonts/GeneralSans-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Regular.52af118f.woff",
    "src": "assets/fonts/GeneralSans-Regular.woff"
  },
  "assets/fonts/GeneralSans-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Regular.3ec2be77.woff2",
    "src": "assets/fonts/GeneralSans-Regular.woff2"
  },
  "assets/fonts/GeneralSans-Semibold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Semibold.307d27c4.ttf",
    "src": "assets/fonts/GeneralSans-Semibold.ttf"
  },
  "assets/fonts/GeneralSans-Semibold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Semibold.eec4ab4c.woff",
    "src": "assets/fonts/GeneralSans-Semibold.woff"
  },
  "assets/fonts/GeneralSans-Semibold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Semibold.94a2a0e1.woff2",
    "src": "assets/fonts/GeneralSans-Semibold.woff2"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-SemiboldItalic.d3b62cb5.ttf",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.ttf"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-SemiboldItalic.cd1fca15.woff",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.woff"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-SemiboldItalic.98c7276f.woff2",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.woff2"
  },
  "assets/fonts/GeneralSans-Variable.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Variable.4b2539d9.ttf",
    "src": "assets/fonts/GeneralSans-Variable.ttf"
  },
  "assets/fonts/GeneralSans-Variable.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Variable.473d4f5e.woff",
    "src": "assets/fonts/GeneralSans-Variable.woff"
  },
  "assets/fonts/GeneralSans-Variable.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Variable.49d3fbd2.woff2",
    "src": "assets/fonts/GeneralSans-Variable.woff2"
  },
  "assets/fonts/GeneralSans-VariableItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-VariableItalic.4aa0c20d.ttf",
    "src": "assets/fonts/GeneralSans-VariableItalic.ttf"
  },
  "assets/fonts/GeneralSans-VariableItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-VariableItalic.c0b7f35e.woff",
    "src": "assets/fonts/GeneralSans-VariableItalic.woff"
  },
  "assets/fonts/GeneralSans-VariableItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-VariableItalic.71537245.woff2",
    "src": "assets/fonts/GeneralSans-VariableItalic.woff2"
  },
  "assets/fonts/PlusJakartaSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Bold.3e08701b.ttf",
    "src": "assets/fonts/PlusJakartaSans-Bold.ttf"
  },
  "assets/fonts/PlusJakartaSans-BoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-BoldItalic.4486ec3d.ttf",
    "src": "assets/fonts/PlusJakartaSans-BoldItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraBold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraBold.644fda57.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraBold.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraBoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraBoldItalic.d51b806e.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraBoldItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraLight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraLight.9afaedac.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraLight.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraLightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraLightItalic.b7523f1e.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraLightItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Italic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Italic.b15bc27e.ttf",
    "src": "assets/fonts/PlusJakartaSans-Italic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Light.26e26359.ttf",
    "src": "assets/fonts/PlusJakartaSans-Light.ttf"
  },
  "assets/fonts/PlusJakartaSans-LightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-LightItalic.22823a55.ttf",
    "src": "assets/fonts/PlusJakartaSans-LightItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Medium.d6854d4b.ttf",
    "src": "assets/fonts/PlusJakartaSans-Medium.ttf"
  },
  "assets/fonts/PlusJakartaSans-MediumItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-MediumItalic.67cb7ae5.ttf",
    "src": "assets/fonts/PlusJakartaSans-MediumItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Regular.f7e7cebd.ttf",
    "src": "assets/fonts/PlusJakartaSans-Regular.ttf"
  },
  "assets/fonts/PlusJakartaSans-SemiBold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-SemiBold.d32adf41.ttf",
    "src": "assets/fonts/PlusJakartaSans-SemiBold.ttf"
  },
  "assets/fonts/PlusJakartaSans-SemiBoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-SemiBoldItalic.48a17bbd.ttf",
    "src": "assets/fonts/PlusJakartaSans-SemiBoldItalic.ttf"
  },
  "layouts/admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.fe7cc3ce.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "_nofication.12fb76c2.js",
      "_hi-transfer-logo.04c4b947.js",
      "_index.3f648032.js",
      "_config.e1ad2671.js",
      "_index.27906dea.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/admin.vue"
  },
  "layouts/auth.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth.94e3e3d6.js",
    "imports": [
      "_Switch.vue.06203ac3.js",
      "_client-only.bae35f15.js",
      "_hi-transfer-logo.04c4b947.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/auth.vue"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.79546f13.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Switch.vue.06203ac3.js",
      "_FloatingWa.6c2bde58.js",
      "_client-only.bae35f15.js",
      "_hi-transfer-logo.04c4b947.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_Container.a5133fd3.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "layouts/empty.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "empty.ee838071.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/empty.vue"
  },
  "layouts/user.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "user.1fd6ad05.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Switch.vue.06203ac3.js",
      "_FloatingWa.6c2bde58.js",
      "_client-only.bae35f15.js",
      "_hi-transfer-logo.04c4b947.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_Container.a5133fd3.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/user.vue"
  },
  "middleware/admin.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.1af5b488.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/admin.ts"
  },
  "middleware/auth.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth.bb5227a6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/auth.ts"
  },
  "middleware/guest.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "guest.e223c413.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/guest.ts"
  },
  "middleware/user.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "user.d256b7b3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/user.ts"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Icon.6f5d80f8.css",
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.css"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Icon.f21da0aa.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_config.e1ad2671.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.vue"
  },
  "Icon.6f5d80f8.css": {
    "file": "Icon.6f5d80f8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "IconCSS.fe0874d9.css",
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.css"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "IconCSS.310eee6d.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_config.e1ad2671.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.vue"
  },
  "IconCSS.fe0874d9.css": {
    "file": "IconCSS.fe0874d9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.2cc35f7b.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.2cc35f7b.css"
    ],
    "dynamicImports": [
      "middleware/admin.ts",
      "middleware/auth.ts",
      "middleware/guest.ts",
      "middleware/user.ts",
      "layouts/admin.vue",
      "layouts/auth.vue",
      "layouts/default.vue",
      "layouts/empty.vue",
      "layouts/user.vue"
    ],
    "file": "entry.63ebc2b0.js",
    "imports": [
      "_swiper-vue.f9dac270.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.2cc35f7b.css": {
    "file": "entry.2cc35f7b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/admin-list/[uuid]/edit.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "edit.1b180105.js",
    "imports": [
      "_TitleBack.db770a10.js",
      "_FormAdmin.vue.f80385c8.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_Alert.vue.14b4e95a.js",
      "_TransitionTopToBottom.a65a6e06.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.f014ad75.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/[uuid]/edit.vue"
  },
  "pages/admin/admin-list/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.c86bf869.js",
    "imports": [
      "_TitleBack.db770a10.js",
      "_FormAdmin.vue.f80385c8.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_Alert.vue.14b4e95a.js",
      "_TransitionTopToBottom.a65a6e06.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.f014ad75.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/add.vue"
  },
  "pages/admin/admin-list/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.78b8257d.js",
    "imports": [
      "_ButtonAddAdmin.b3c4f406.js",
      "_TitleAdmin.d9ac3a1d.js",
      "_StatusActive.46e41038.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_swiper-vue.f9dac270.js",
      "_config.e1ad2671.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/index.vue"
  },
  "pages/admin/destinations/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.26161cf9.js",
    "imports": [
      "_TitleBack.db770a10.js",
      "_Destinations.053e60ae.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.f9491038.js",
      "_useDestinations.e996f63f.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/add.vue"
  },
  "pages/admin/destinations/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.fde423d0.js",
    "imports": [
      "_TitleBack.db770a10.js",
      "_Destinations.053e60ae.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.f9491038.js",
      "_useDestinations.e996f63f.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/edit/[slug].vue"
  },
  "pages/admin/destinations/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.7eaf70ec.js",
    "imports": [
      "_ButtonAddAdmin.b3c4f406.js",
      "_TitleAdmin.d9ac3a1d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.faa57450.js",
      "_swiper-vue.f9dac270.js",
      "_useDestinations.e996f63f.js",
      "_config.e1ad2671.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/destinations/index.vue"
  },
  "pages/admin/driver/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.1fff7327.js",
    "imports": [
      "_TitleBack.db770a10.js",
      "_Driver.8582dd28.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.f9491038.js",
      "_useDriver.b3fe46fb.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/add.vue"
  },
  "pages/admin/driver/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.de55947c.js",
    "imports": [
      "_TitleBack.db770a10.js",
      "_Driver.8582dd28.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.f9491038.js",
      "_useDriver.b3fe46fb.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/edit/[slug].vue"
  },
  "pages/admin/driver/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.540c2f03.js",
    "imports": [
      "_ButtonAddAdmin.b3c4f406.js",
      "_TitleAdmin.d9ac3a1d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.faa57450.js",
      "_swiper-vue.f9dac270.js",
      "_useDriver.b3fe46fb.js",
      "_config.e1ad2671.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/driver/index.vue"
  },
  "pages/admin/email-verification/[token].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_token_.381f7499.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/email-verification/[token].vue"
  },
  "pages/admin/facility-car/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.96c4af56.js",
    "imports": [
      "_TitleBack.db770a10.js",
      "_FacilityCar.1ba58a9e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_clsx.0839fdbe.js",
      "_client-only.bae35f15.js",
      "_InputImageCropAdmin.3a591c6e.js",
      "_Modal.faa57450.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_index.989c4c14.js",
      "_useSchema.f9491038.js",
      "_useFacility.f13172b7.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/add.vue"
  },
  "pages/admin/facility-car/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.aa998e5a.js",
    "imports": [
      "_TitleBack.db770a10.js",
      "_FacilityCar.1ba58a9e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_clsx.0839fdbe.js",
      "_client-only.bae35f15.js",
      "_InputImageCropAdmin.3a591c6e.js",
      "_Modal.faa57450.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_index.989c4c14.js",
      "_useSchema.f9491038.js",
      "_useFacility.f13172b7.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/edit/[slug].vue"
  },
  "pages/admin/facility-car/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.b34e6a36.js",
    "imports": [
      "_ButtonAddAdmin.b3c4f406.js",
      "_TitleAdmin.d9ac3a1d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.faa57450.js",
      "_swiper-vue.f9dac270.js",
      "_useFacility.f13172b7.js",
      "_config.e1ad2671.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility-car/index.vue"
  },
  "pages/admin/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.d81b2020.js",
    "imports": [
      "_Change.vue.7f8ebdc7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.3f648032.js",
      "_swiper-vue.f9dac270.js",
      "_Alert.vue.a8667257.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_TransitionTopToBottom.a65a6e06.js",
      "_MTextField.vue.00f77f35.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MGroup.vue.fbe4ab58.js",
      "_TransitionX.f014ad75.js",
      "_Btn.vue.77dc26e2.js",
      "_useSchema.f9491038.js",
      "_InputOTP.vue.34ce9cc3.js",
      "_Group.vue.dbd5fea5.js",
      "_index.27906dea.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/forgot-password.vue"
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.1d37fed7.js",
    "imports": [
      "_HeadPage.vue.2fb6071b.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/index.vue"
  },
  "pages/admin/orders/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.2050dd32.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_HeadPage.vue.2fb6071b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_PaginationAdmin.7a0a3d9d.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_config.e1ad2671.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/index.vue"
  },
  "pages/admin/orders/order-cars.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "order-cars.d1219b9e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_HeadPage.vue.2fb6071b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_PaginationAdmin.7a0a3d9d.js",
      "_FormatMoneyDash.aea6127b.js",
      "_index.27906dea.js",
      "_swiper-vue.f9dac270.js",
      "_config.e1ad2671.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-cars.vue"
  },
  "pages/admin/orders/order-detail-car/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.afdf9efe.js",
    "imports": [
      "_TitleAdminBack.5d2853b8.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useFormatDate.74b73f07.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-detail-car/[slug].vue"
  },
  "pages/admin/orders/order-detail-tourpackage/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.c9071555.js",
    "imports": [
      "_TitleAdminBack.5d2853b8.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useFormatDate.74b73f07.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/orders/order-detail-tourpackage/[slug].vue"
  },
  "pages/admin/profile.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "profile.b03302af.js",
    "imports": [
      "_Alert.vue.14b4e95a.js",
      "_ChangePassword.27a125e5.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.fbe4ab58.js",
      "_useSchema.f9491038.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.12fb76c2.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_TransitionTopToBottom.a65a6e06.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_TransitionX.f014ad75.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "_usePasswordHelper.66d7e1e2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/profile.vue"
  },
  "pages/admin/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.b458a13b.js",
    "imports": [
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.fbe4ab58.js",
      "_Btn.vue.77dc26e2.js",
      "_vee-validate.esm.c1170e9f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.f9491038.js",
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.f014ad75.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/sign-in.vue"
  },
  "pages/admin/tour-package/[slug]/edit.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "edit.74e9d971.js",
    "imports": [
      "_TitleBack.db770a10.js",
      "_TourPackage.48749476.js",
      "_useSchema.f9491038.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_DropdownsTest.3420dba9.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_client-only.bae35f15.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_clsx.0839fdbe.js",
      "_useTourPackage.b313d132.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/[slug]/edit.vue"
  },
  "pages/admin/tour-package/[slug]/images.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "images.92d9d57c.js",
    "imports": [
      "_TitleBack.db770a10.js",
      "_Alert.vue.14b4e95a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Modal.faa57450.js",
      "_index.3f648032.js",
      "_swiper-vue.f9dac270.js",
      "_client-only.bae35f15.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.989c4c14.js",
      "_TransitionTopToBottom.a65a6e06.js",
      "_config.e1ad2671.js",
      "_index.7d9a9c74.js",
      "_index.27906dea.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/[slug]/images.vue"
  },
  "pages/admin/tour-package/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.439a40f5.js",
    "imports": [
      "_TitleBack.db770a10.js",
      "_TourPackage.48749476.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_vee-validate.esm.c1170e9f.js",
      "_DropdownsTest.3420dba9.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_client-only.bae35f15.js",
      "_Group.vue.dbd5fea5.js",
      "_TabContent.vue.9e619e50.js",
      "_clsx.0839fdbe.js",
      "_useTourPackage.b313d132.js",
      "_nofication.12fb76c2.js",
      "_useSchema.f9491038.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/add.vue"
  },
  "pages/admin/tour-package/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.93e3776b.js",
    "imports": [
      "_ButtonAddAdmin.b3c4f406.js",
      "_TitleAdmin.d9ac3a1d.js",
      "_StatusTrueOrFalse.ce1ce725.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.faa57450.js",
      "_swiper-vue.f9dac270.js",
      "_useTourPackage.b313d132.js",
      "_FormatMoneyDash.aea6127b.js",
      "_config.e1ad2671.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/tour-package/index.vue"
  },
  "pages/admin/transport/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.412440cc.js",
    "imports": [
      "_TitleBack.db770a10.js",
      "_Transport.460c1453.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputImageCropAdmin.3a591c6e.js",
      "_Modal.faa57450.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_client-only.bae35f15.js",
      "_index.989c4c14.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_DropdownsTest.3420dba9.js",
      "_useSchema.f9491038.js",
      "_useTransport.af9938f2.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/add.vue"
  },
  "pages/admin/transport/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.764f11ac.js",
    "imports": [
      "_TitleBack.db770a10.js",
      "_Transport.460c1453.js",
      "_useSchema.f9491038.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputImageCropAdmin.3a591c6e.js",
      "_Modal.faa57450.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_client-only.bae35f15.js",
      "_index.989c4c14.js",
      "_TextFieldWLabel.vue.bae6c828.js",
      "_DropdownsTest.3420dba9.js",
      "_useTransport.af9938f2.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/edit/[slug].vue"
  },
  "pages/admin/transport/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.a39d9e11.js",
    "imports": [
      "_ButtonAddAdmin.b3c4f406.js",
      "_TitleAdmin.d9ac3a1d.js",
      "_StatusTrueOrFalse.ce1ce725.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Modal.faa57450.js",
      "_swiper-vue.f9dac270.js",
      "_useTransport.af9938f2.js",
      "_FormatMoneyDash.aea6127b.js",
      "_config.e1ad2671.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/transport/index.vue"
  },
  "pages/admin/users/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.39ed9294.js",
    "imports": [
      "_TitleBack.db770a10.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/users/edit/[slug].vue"
  },
  "pages/admin/users/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.a9645e82.js",
    "imports": [
      "_TitleAdmin.d9ac3a1d.js",
      "_StatusActive.46e41038.js",
      "_PaginationAdmin.7a0a3d9d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/users/index.vue"
  },
  "pages/auth-redirect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth-redirect.a7dbe409.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/auth-redirect.vue"
  },
  "pages/email-verification/[token].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_token_.23f42e9b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/email-verification/[token].vue"
  },
  "pages/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.a8b892ed.js",
    "imports": [
      "_Change.vue.7f8ebdc7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.3f648032.js",
      "_swiper-vue.f9dac270.js",
      "_Alert.vue.a8667257.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_TransitionTopToBottom.a65a6e06.js",
      "_MTextField.vue.00f77f35.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MGroup.vue.fbe4ab58.js",
      "_TransitionX.f014ad75.js",
      "_Btn.vue.77dc26e2.js",
      "_useSchema.f9491038.js",
      "_InputOTP.vue.34ce9cc3.js",
      "_Group.vue.dbd5fea5.js",
      "_index.27906dea.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/forgot-password.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.1392f658.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.17b2e848.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_clsx.0839fdbe.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.3f648032.js",
      "_index.7d9a9c74.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MGroup.vue.fbe4ab58.js",
      "_MTextField.vue.00f77f35.js",
      "_MSelect.vue.344734d3.js",
      "_Btn.vue.77dc26e2.js",
      "_nofication.12fb76c2.js",
      "_useSchema.f9491038.js",
      "_useCarStore.eb19eba8.js",
      "_useTourStore.b27b72b1.js",
      "_Card.fc3a008c.js",
      "_Container.a5133fd3.js",
      "_CtaSection.vue.111a3771.js",
      "_config.e1ad2671.js",
      "_index.27906dea.js",
      "_TransitionX.f014ad75.js",
      "_FormatMoneyDash.aea6127b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.1392f658.css": {
    "file": "index.1392f658.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/payment-failed.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "payment-failed.87035534.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/payment-failed.vue"
  },
  "pages/payment-successfull.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "payment-successfull.798fd4aa.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/payment-successfull.vue"
  },
  "pages/privacy-policy.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "privacy-policy.a08e8ba4.js",
    "imports": [
      "_Container.a5133fd3.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/privacy-policy.vue"
  },
  "pages/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.ce27f217.js",
    "imports": [
      "_Alert.vue.a8667257.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.fbe4ab58.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.77dc26e2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.f9491038.js",
      "_usePasswordHelper.66d7e1e2.js",
      "_swiper-vue.f9dac270.js",
      "_TransitionTopToBottom.a65a6e06.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.f014ad75.js",
      "_config.e1ad2671.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign-in.vue"
  },
  "pages/sign-up.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-up.8734ac32.js",
    "imports": [
      "_Alert.vue.a8667257.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.fbe4ab58.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.77dc26e2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.f9491038.js",
      "_usePasswordHelper.66d7e1e2.js",
      "_swiper-vue.f9dac270.js",
      "_TransitionTopToBottom.a65a6e06.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.f014ad75.js",
      "_config.e1ad2671.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign-up.vue"
  },
  "pages/terms-and-refunds.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "terms-and-refunds.4e87ff76.js",
    "imports": [
      "_Container.a5133fd3.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/terms-and-refunds.vue"
  },
  "pages/terms-condition.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "terms-condition.f1dd5f57.js",
    "imports": [
      "_Container.a5133fd3.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.f9dac270.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/terms-condition.vue"
  },
  "pages/tours/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.e9156926.css",
    "src": "pages/tours/[slug].css"
  },
  "pages/tours/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.4db19a33.js",
    "imports": [
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.a5133fd3.js",
      "_CtaSection.vue.111a3771.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.fbe4ab58.js",
      "_Btn.vue.77dc26e2.js",
      "_vee-validate.esm.c1170e9f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.f9491038.js",
      "_useTourStore.b27b72b1.js",
      "_Modal.faa57450.js",
      "_FormatMoneyDash.aea6127b.js",
      "_config.e1ad2671.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.f014ad75.js",
      "_nofication.12fb76c2.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/[slug].vue"
  },
  "_slug_.e9156926.css": {
    "file": "_slug_.e9156926.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/tours/booking/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkout.1a25f43d.js",
    "imports": [
      "_SelectedCard.vue.225d8c13.js",
      "_swiper-vue.f9dac270.js",
      "_FormatMoneyDash.aea6127b.js",
      "_Container.a5133fd3.js",
      "_useTourStore.b27b72b1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking/checkout.vue"
  },
  "pages/tours/booking/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.fac1b721.js",
    "imports": [
      "_SelectedCard.vue.225d8c13.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.fbe4ab58.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useTourStore.b27b72b1.js",
      "_swiper-vue.f9dac270.js",
      "_MSelect.vue.344734d3.js",
      "_Container.a5133fd3.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.f014ad75.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking/index.vue"
  },
  "pages/tours/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.03d9eced.js",
    "imports": [
      "_Btn.vue.77dc26e2.js",
      "_Container.a5133fd3.js",
      "_MSelect.vue.344734d3.js",
      "_MGroup.vue.fbe4ab58.js",
      "_Card.fc3a008c.js",
      "_Empty.1d65daef.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useTourStore.b27b72b1.js",
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.f014ad75.js",
      "_FormatMoneyDash.aea6127b.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/index.vue"
  },
  "pages/user/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.9a5d1f05.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_PaginationAdmin.7a0a3d9d.js",
      "_Container.a5133fd3.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useFormatDate.74b73f07.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_config.e1ad2671.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/index.vue"
  },
  "pages/user/order/order-summary/car/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.c588e50d.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Container.a5133fd3.js",
      "_Verified.1801a22a.js",
      "_Modal.faa57450.js",
      "_useFormatDate.74b73f07.js",
      "_nofication.12fb76c2.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_config.e1ad2671.js",
      "_Alert.vue.14b4e95a.js",
      "_TransitionTopToBottom.a65a6e06.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputOTP.vue.34ce9cc3.js",
      "_useSchema.f9491038.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/order/order-summary/car/[slug].vue"
  },
  "pages/user/order/order-summary/tour/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.673212d6.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Container.a5133fd3.js",
      "_Verified.1801a22a.js",
      "_Modal.faa57450.js",
      "_useFormatDate.74b73f07.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_config.e1ad2671.js",
      "_Alert.vue.14b4e95a.js",
      "_TransitionTopToBottom.a65a6e06.js",
      "_vee-validate.esm.c1170e9f.js",
      "_InputOTP.vue.34ce9cc3.js",
      "_useSchema.f9491038.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_index.7d9a9c74.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/order/order-summary/tour/[slug].vue"
  },
  "pages/user/profile.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "profile.7c017695.js",
    "imports": [
      "_Alert.vue.14b4e95a.js",
      "_ChangePassword.27a125e5.js",
      "_vee-validate.esm.c1170e9f.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.fbe4ab58.js",
      "_useSchema.f9491038.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nofication.12fb76c2.js",
      "_swiper-vue.f9dac270.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e1ad2671.js",
      "_TransitionTopToBottom.a65a6e06.js",
      "_index.3f648032.js",
      "_index.27906dea.js",
      "_TransitionX.f014ad75.js",
      "_clsx.0839fdbe.js",
      "_Group.vue.dbd5fea5.js",
      "_usePasswordHelper.66d7e1e2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/profile.vue"
  },
  "pages/vehicles/booking.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "booking.f4f2fa15.js",
    "imports": [
      "_Btn.vue.77dc26e2.js",
      "_Container.a5133fd3.js",
      "_AddressInformation.vue.874d55ed.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_MTextField.vue.00f77f35.js",
      "_MGroup.vue.fbe4ab58.js",
      "_SelectedCard.vue.c17d99f4.js",
      "_vee-validate.esm.c1170e9f.js",
      "_useSchema.f9491038.js",
      "_useCarStore.eb19eba8.js",
      "_swiper-vue.f9dac270.js",
      "_clsx.0839fdbe.js",
      "_TransitionX.f014ad75.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/booking.vue"
  },
  "pages/vehicles/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkout.cfa43071.js",
    "imports": [
      "_Btn.vue.77dc26e2.js",
      "_Container.a5133fd3.js",
      "_AddressInformation.vue.874d55ed.js",
      "_swiper-vue.f9dac270.js",
      "_SelectedCard.vue.c17d99f4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useCarStore.eb19eba8.js",
      "_FormatMoneyDash.aea6127b.js",
      "_clsx.0839fdbe.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/checkout.vue"
  },
  "pages/vehicles/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.1d43953d.js",
    "imports": [
      "_Btn.vue.77dc26e2.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.a5133fd3.js",
      "_AddressInformation.vue.874d55ed.js",
      "_MSelect.vue.344734d3.js",
      "_MGroup.vue.fbe4ab58.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useCarStore.eb19eba8.js",
      "_FormatMoneyDash.aea6127b.js",
      "_swiper-vue.f9dac270.js",
      "_Empty.1d65daef.js",
      "_clsx.0839fdbe.js",
      "_config.e1ad2671.js",
      "_vee-validate.esm.c1170e9f.js",
      "_TransitionX.f014ad75.js",
      "_nofication.12fb76c2.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/index.vue"
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.d33d3671.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
