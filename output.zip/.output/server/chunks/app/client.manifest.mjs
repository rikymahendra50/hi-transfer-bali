const client_manifest = {
  "_Btn.vue.66239b17.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Btn.vue.66239b17.js",
    "imports": [
      "_clsx.0839fdbe.js",
      "_swiper-vue.1e1b85e5.js"
    ]
  },
  "_Card.27c5ed69.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Card.27c5ed69.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ]
  },
  "_Change.vue.89938f19.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Change.vue.89938f19.js",
    "imports": [
      "_useSchema.84f1eb8d.js",
      "_MTextField.vue.108e79d6.js",
      "_MGroup.vue.4bec4f2c.js",
      "_Btn.vue.66239b17.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ]
  },
  "_Container.7be6ce06.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Container.7be6ce06.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ]
  },
  "_CtaSection.f61ee246.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CtaSection.f61ee246.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ]
  },
  "_MGroup.vue.4bec4f2c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MGroup.vue.4bec4f2c.js",
    "imports": [
      "_swiper-vue.1e1b85e5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_clsx.0839fdbe.js"
    ]
  },
  "_MSelect.vue.1934a26c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MSelect.vue.1934a26c.js",
    "imports": [
      "_swiper-vue.1e1b85e5.js",
      "_clsx.0839fdbe.js",
      "_MGroup.vue.4bec4f2c.js"
    ]
  },
  "_MTextField.vue.108e79d6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MTextField.vue.108e79d6.js",
    "imports": [
      "_swiper-vue.1e1b85e5.js",
      "_clsx.0839fdbe.js",
      "_MGroup.vue.4bec4f2c.js"
    ]
  },
  "_SelectedCard.vue.085c31f3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "SelectedCard.vue.085c31f3.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ]
  },
  "_Switch.vue.3077817c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Switch.vue.3077817c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ]
  },
  "_clsx.0839fdbe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "clsx.0839fdbe.js"
  },
  "_config.e2eaf067.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.e2eaf067.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ]
  },
  "_hi-transfer-logo.51e99e76.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hi-transfer-logo.51e99e76.js",
    "imports": [
      "_swiper-vue.1e1b85e5.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.7f0fb765.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.7f0fb765.js",
    "imports": [
      "_swiper-vue.1e1b85e5.js"
    ]
  },
  "_swiper-vue.1e1b85e5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.d33d3671.css"
    ],
    "file": "swiper-vue.1e1b85e5.js"
  },
  "swiper-vue.d33d3671.css": {
    "file": "swiper-vue.d33d3671.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_usePasswordHelper.6b70d872.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "usePasswordHelper.6b70d872.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ]
  },
  "_useSchema.84f1eb8d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useSchema.84f1eb8d.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.1e1b85e5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate-zod.esm.98e8bb52.js"
    ]
  },
  "_vee-validate-zod.esm.98e8bb52.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vee-validate-zod.esm.98e8bb52.js"
  },
  "_vehicleForm.ebd1e30c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vehicleForm.ebd1e30c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ]
  },
  "assets/fonts/ClashGrotesk-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Bold.c4ea1fe3.ttf",
    "src": "assets/fonts/ClashGrotesk-Bold.ttf"
  },
  "assets/fonts/ClashGrotesk-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Bold.b1b9970d.woff",
    "src": "assets/fonts/ClashGrotesk-Bold.woff"
  },
  "assets/fonts/ClashGrotesk-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Bold.602a56af.woff2",
    "src": "assets/fonts/ClashGrotesk-Bold.woff2"
  },
  "assets/fonts/ClashGrotesk-Extralight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Extralight.6417ca23.ttf",
    "src": "assets/fonts/ClashGrotesk-Extralight.ttf"
  },
  "assets/fonts/ClashGrotesk-Extralight.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Extralight.c9c2a3a9.woff",
    "src": "assets/fonts/ClashGrotesk-Extralight.woff"
  },
  "assets/fonts/ClashGrotesk-Extralight.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Extralight.fe206472.woff2",
    "src": "assets/fonts/ClashGrotesk-Extralight.woff2"
  },
  "assets/fonts/ClashGrotesk-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Light.8e98f3c7.ttf",
    "src": "assets/fonts/ClashGrotesk-Light.ttf"
  },
  "assets/fonts/ClashGrotesk-Light.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Light.04e1d585.woff",
    "src": "assets/fonts/ClashGrotesk-Light.woff"
  },
  "assets/fonts/ClashGrotesk-Light.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Light.f0f7605c.woff2",
    "src": "assets/fonts/ClashGrotesk-Light.woff2"
  },
  "assets/fonts/ClashGrotesk-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Medium.717fd45f.ttf",
    "src": "assets/fonts/ClashGrotesk-Medium.ttf"
  },
  "assets/fonts/ClashGrotesk-Medium.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Medium.94bcd03c.woff",
    "src": "assets/fonts/ClashGrotesk-Medium.woff"
  },
  "assets/fonts/ClashGrotesk-Medium.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Medium.5c3815cf.woff2",
    "src": "assets/fonts/ClashGrotesk-Medium.woff2"
  },
  "assets/fonts/ClashGrotesk-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Regular.5c66c57f.ttf",
    "src": "assets/fonts/ClashGrotesk-Regular.ttf"
  },
  "assets/fonts/ClashGrotesk-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Regular.1c248756.woff",
    "src": "assets/fonts/ClashGrotesk-Regular.woff"
  },
  "assets/fonts/ClashGrotesk-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Regular.03ad7ecf.woff2",
    "src": "assets/fonts/ClashGrotesk-Regular.woff2"
  },
  "assets/fonts/ClashGrotesk-Semibold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Semibold.bdc47ea3.ttf",
    "src": "assets/fonts/ClashGrotesk-Semibold.ttf"
  },
  "assets/fonts/ClashGrotesk-Semibold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Semibold.48fdb6da.woff",
    "src": "assets/fonts/ClashGrotesk-Semibold.woff"
  },
  "assets/fonts/ClashGrotesk-Semibold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Semibold.befc1942.woff2",
    "src": "assets/fonts/ClashGrotesk-Semibold.woff2"
  },
  "assets/fonts/ClashGrotesk-Variable.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Variable.5887a1df.ttf",
    "src": "assets/fonts/ClashGrotesk-Variable.ttf"
  },
  "assets/fonts/ClashGrotesk-Variable.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Variable.de7ab3f6.woff",
    "src": "assets/fonts/ClashGrotesk-Variable.woff"
  },
  "assets/fonts/ClashGrotesk-Variable.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Variable.3c56fcff.woff2",
    "src": "assets/fonts/ClashGrotesk-Variable.woff2"
  },
  "assets/fonts/GeneralSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Bold.1c435b33.ttf",
    "src": "assets/fonts/GeneralSans-Bold.ttf"
  },
  "assets/fonts/GeneralSans-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Bold.4c2b7f63.woff",
    "src": "assets/fonts/GeneralSans-Bold.woff"
  },
  "assets/fonts/GeneralSans-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Bold.a29eab9b.woff2",
    "src": "assets/fonts/GeneralSans-Bold.woff2"
  },
  "assets/fonts/GeneralSans-BoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-BoldItalic.2297ae79.ttf",
    "src": "assets/fonts/GeneralSans-BoldItalic.ttf"
  },
  "assets/fonts/GeneralSans-BoldItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-BoldItalic.0599ec69.woff",
    "src": "assets/fonts/GeneralSans-BoldItalic.woff"
  },
  "assets/fonts/GeneralSans-BoldItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-BoldItalic.97483640.woff2",
    "src": "assets/fonts/GeneralSans-BoldItalic.woff2"
  },
  "assets/fonts/GeneralSans-Extralight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Extralight.4cb07dad.ttf",
    "src": "assets/fonts/GeneralSans-Extralight.ttf"
  },
  "assets/fonts/GeneralSans-Extralight.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Extralight.6a52bdce.woff",
    "src": "assets/fonts/GeneralSans-Extralight.woff"
  },
  "assets/fonts/GeneralSans-Extralight.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Extralight.3e6ee7e5.woff2",
    "src": "assets/fonts/GeneralSans-Extralight.woff2"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-ExtralightItalic.9b80b399.ttf",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.ttf"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-ExtralightItalic.acc7311a.woff",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.woff"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-ExtralightItalic.83bbc211.woff2",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.woff2"
  },
  "assets/fonts/GeneralSans-Italic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Italic.ea19866f.ttf",
    "src": "assets/fonts/GeneralSans-Italic.ttf"
  },
  "assets/fonts/GeneralSans-Italic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Italic.f9e5a73e.woff",
    "src": "assets/fonts/GeneralSans-Italic.woff"
  },
  "assets/fonts/GeneralSans-Italic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Italic.1c91e1d3.woff2",
    "src": "assets/fonts/GeneralSans-Italic.woff2"
  },
  "assets/fonts/GeneralSans-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Light.86a255b5.ttf",
    "src": "assets/fonts/GeneralSans-Light.ttf"
  },
  "assets/fonts/GeneralSans-Light.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Light.09f0f0fe.woff",
    "src": "assets/fonts/GeneralSans-Light.woff"
  },
  "assets/fonts/GeneralSans-Light.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Light.ac0b8f29.woff2",
    "src": "assets/fonts/GeneralSans-Light.woff2"
  },
  "assets/fonts/GeneralSans-LightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-LightItalic.eb313a89.ttf",
    "src": "assets/fonts/GeneralSans-LightItalic.ttf"
  },
  "assets/fonts/GeneralSans-LightItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-LightItalic.639de7d9.woff",
    "src": "assets/fonts/GeneralSans-LightItalic.woff"
  },
  "assets/fonts/GeneralSans-LightItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-LightItalic.7787625d.woff2",
    "src": "assets/fonts/GeneralSans-LightItalic.woff2"
  },
  "assets/fonts/GeneralSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Medium.e85572fe.ttf",
    "src": "assets/fonts/GeneralSans-Medium.ttf"
  },
  "assets/fonts/GeneralSans-Medium.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Medium.f5beb161.woff",
    "src": "assets/fonts/GeneralSans-Medium.woff"
  },
  "assets/fonts/GeneralSans-Medium.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Medium.c30377df.woff2",
    "src": "assets/fonts/GeneralSans-Medium.woff2"
  },
  "assets/fonts/GeneralSans-MediumItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-MediumItalic.3b4e2f45.ttf",
    "src": "assets/fonts/GeneralSans-MediumItalic.ttf"
  },
  "assets/fonts/GeneralSans-MediumItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-MediumItalic.d02080e7.woff",
    "src": "assets/fonts/GeneralSans-MediumItalic.woff"
  },
  "assets/fonts/GeneralSans-MediumItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-MediumItalic.ffe0560d.woff2",
    "src": "assets/fonts/GeneralSans-MediumItalic.woff2"
  },
  "assets/fonts/GeneralSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Regular.0723d125.ttf",
    "src": "assets/fonts/GeneralSans-Regular.ttf"
  },
  "assets/fonts/GeneralSans-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Regular.52af118f.woff",
    "src": "assets/fonts/GeneralSans-Regular.woff"
  },
  "assets/fonts/GeneralSans-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Regular.3ec2be77.woff2",
    "src": "assets/fonts/GeneralSans-Regular.woff2"
  },
  "assets/fonts/GeneralSans-Semibold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Semibold.307d27c4.ttf",
    "src": "assets/fonts/GeneralSans-Semibold.ttf"
  },
  "assets/fonts/GeneralSans-Semibold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Semibold.eec4ab4c.woff",
    "src": "assets/fonts/GeneralSans-Semibold.woff"
  },
  "assets/fonts/GeneralSans-Semibold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Semibold.94a2a0e1.woff2",
    "src": "assets/fonts/GeneralSans-Semibold.woff2"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-SemiboldItalic.d3b62cb5.ttf",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.ttf"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-SemiboldItalic.cd1fca15.woff",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.woff"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-SemiboldItalic.98c7276f.woff2",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.woff2"
  },
  "assets/fonts/GeneralSans-Variable.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Variable.4b2539d9.ttf",
    "src": "assets/fonts/GeneralSans-Variable.ttf"
  },
  "assets/fonts/GeneralSans-Variable.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Variable.473d4f5e.woff",
    "src": "assets/fonts/GeneralSans-Variable.woff"
  },
  "assets/fonts/GeneralSans-Variable.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Variable.49d3fbd2.woff2",
    "src": "assets/fonts/GeneralSans-Variable.woff2"
  },
  "assets/fonts/GeneralSans-VariableItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-VariableItalic.4aa0c20d.ttf",
    "src": "assets/fonts/GeneralSans-VariableItalic.ttf"
  },
  "assets/fonts/GeneralSans-VariableItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-VariableItalic.c0b7f35e.woff",
    "src": "assets/fonts/GeneralSans-VariableItalic.woff"
  },
  "assets/fonts/GeneralSans-VariableItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-VariableItalic.71537245.woff2",
    "src": "assets/fonts/GeneralSans-VariableItalic.woff2"
  },
  "assets/fonts/PlusJakartaSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Bold.3e08701b.ttf",
    "src": "assets/fonts/PlusJakartaSans-Bold.ttf"
  },
  "assets/fonts/PlusJakartaSans-BoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-BoldItalic.4486ec3d.ttf",
    "src": "assets/fonts/PlusJakartaSans-BoldItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraBold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraBold.644fda57.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraBold.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraBoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraBoldItalic.d51b806e.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraBoldItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraLight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraLight.9afaedac.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraLight.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraLightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraLightItalic.b7523f1e.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraLightItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Italic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Italic.b15bc27e.ttf",
    "src": "assets/fonts/PlusJakartaSans-Italic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Light.26e26359.ttf",
    "src": "assets/fonts/PlusJakartaSans-Light.ttf"
  },
  "assets/fonts/PlusJakartaSans-LightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-LightItalic.22823a55.ttf",
    "src": "assets/fonts/PlusJakartaSans-LightItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Medium.d6854d4b.ttf",
    "src": "assets/fonts/PlusJakartaSans-Medium.ttf"
  },
  "assets/fonts/PlusJakartaSans-MediumItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-MediumItalic.67cb7ae5.ttf",
    "src": "assets/fonts/PlusJakartaSans-MediumItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Regular.f7e7cebd.ttf",
    "src": "assets/fonts/PlusJakartaSans-Regular.ttf"
  },
  "assets/fonts/PlusJakartaSans-SemiBold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-SemiBold.d32adf41.ttf",
    "src": "assets/fonts/PlusJakartaSans-SemiBold.ttf"
  },
  "assets/fonts/PlusJakartaSans-SemiBoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-SemiBoldItalic.48a17bbd.ttf",
    "src": "assets/fonts/PlusJakartaSans-SemiBoldItalic.ttf"
  },
  "layouts/admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.3803db66.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.1e1b85e5.js",
      "_hi-transfer-logo.51e99e76.js",
      "_index.7f0fb765.js",
      "_config.e2eaf067.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/admin.vue"
  },
  "layouts/auth.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth.f6b17b1e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Switch.vue.3077817c.js",
      "_hi-transfer-logo.51e99e76.js",
      "_swiper-vue.1e1b85e5.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/auth.vue"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.9caa27e4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Switch.vue.3077817c.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.7be6ce06.js",
      "_swiper-vue.1e1b85e5.js",
      "_hi-transfer-logo.51e99e76.js",
      "_config.e2eaf067.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "layouts/empty.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "empty.8bb60b00.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/empty.vue"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Icon.6f5d80f8.css",
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.css"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Icon.95403093.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_config.e2eaf067.js",
      "_swiper-vue.1e1b85e5.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.vue"
  },
  "Icon.6f5d80f8.css": {
    "file": "Icon.6f5d80f8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "IconCSS.fe0874d9.css",
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.css"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "IconCSS.037022f2.js",
    "imports": [
      "_swiper-vue.1e1b85e5.js",
      "_config.e2eaf067.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.vue"
  },
  "IconCSS.fe0874d9.css": {
    "file": "IconCSS.fe0874d9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.2cc35f7b.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.2cc35f7b.css"
    ],
    "dynamicImports": [
      "layouts/admin.vue",
      "layouts/auth.vue",
      "layouts/default.vue",
      "layouts/empty.vue"
    ],
    "file": "entry.535e5687.js",
    "imports": [
      "_swiper-vue.1e1b85e5.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.2cc35f7b.css": {
    "file": "entry.2cc35f7b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/email-verification/[token].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_token_.8a1ac498.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/email-verification/[token].vue"
  },
  "pages/admin/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.529a553d.js",
    "imports": [
      "_Change.vue.89938f19.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.7f0fb765.js",
      "_swiper-vue.1e1b85e5.js",
      "_useSchema.84f1eb8d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e2eaf067.js",
      "_vee-validate-zod.esm.98e8bb52.js",
      "_MTextField.vue.108e79d6.js",
      "_clsx.0839fdbe.js",
      "_MGroup.vue.4bec4f2c.js",
      "_Btn.vue.66239b17.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/forgot-password.vue"
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.13984e64.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js",
      "_config.e2eaf067.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/index.vue"
  },
  "pages/admin/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.f85f9e73.js",
    "imports": [
      "_useSchema.84f1eb8d.js",
      "_MTextField.vue.108e79d6.js",
      "_MGroup.vue.4bec4f2c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_Btn.vue.66239b17.js",
      "_swiper-vue.1e1b85e5.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e2eaf067.js",
      "_vee-validate-zod.esm.98e8bb52.js",
      "_clsx.0839fdbe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/sign-in.vue"
  },
  "pages/auth-redirect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth-redirect.573bede7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/auth-redirect.vue"
  },
  "pages/daisy-example.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "daisy-example.dff71f9c.js",
    "imports": [
      "_MTextField.vue.108e79d6.js",
      "_MGroup.vue.4bec4f2c.js",
      "_swiper-vue.1e1b85e5.js",
      "_clsx.0839fdbe.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_MSelect.vue.1934a26c.js",
      "_Btn.vue.66239b17.js",
      "_Container.7be6ce06.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate-zod.esm.98e8bb52.js",
      "_config.e2eaf067.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/daisy-example.vue"
  },
  "pages/email-verification/[token].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_token_.e5bd7c6d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/email-verification/[token].vue"
  },
  "pages/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.c18f3483.js",
    "imports": [
      "_Change.vue.89938f19.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.7f0fb765.js",
      "_swiper-vue.1e1b85e5.js",
      "_useSchema.84f1eb8d.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e2eaf067.js",
      "_vee-validate-zod.esm.98e8bb52.js",
      "_MTextField.vue.108e79d6.js",
      "_clsx.0839fdbe.js",
      "_MGroup.vue.4bec4f2c.js",
      "_Btn.vue.66239b17.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/forgot-password.vue"
  },
  "pages/gsap.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "gsap.b2dbd5e1.js",
    "imports": [
      "_swiper-vue.1e1b85e5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/gsap.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.adf9eedf.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.55f0d5c2.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_clsx.0839fdbe.js",
      "_swiper-vue.1e1b85e5.js",
      "_MTextField.vue.108e79d6.js",
      "_MGroup.vue.4bec4f2c.js",
      "_MSelect.vue.1934a26c.js",
      "_Btn.vue.66239b17.js",
      "_index.7f0fb765.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_Card.27c5ed69.js",
      "_Container.7be6ce06.js",
      "_CtaSection.f61ee246.js",
      "_config.e2eaf067.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.adf9eedf.css": {
    "file": "index.adf9eedf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.23ca66f4.js",
    "imports": [
      "_useSchema.84f1eb8d.js",
      "_MTextField.vue.108e79d6.js",
      "_MGroup.vue.4bec4f2c.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.66239b17.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_usePasswordHelper.6b70d872.js",
      "_swiper-vue.1e1b85e5.js",
      "_vee-validate-zod.esm.98e8bb52.js",
      "_clsx.0839fdbe.js",
      "_config.e2eaf067.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign-in.vue"
  },
  "pages/sign-up.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-up.b9eb2302.js",
    "imports": [
      "_useSchema.84f1eb8d.js",
      "_MTextField.vue.108e79d6.js",
      "_MGroup.vue.4bec4f2c.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.66239b17.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_usePasswordHelper.6b70d872.js",
      "_swiper-vue.1e1b85e5.js",
      "_vee-validate-zod.esm.98e8bb52.js",
      "_clsx.0839fdbe.js",
      "_config.e2eaf067.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign-up.vue"
  },
  "pages/tours/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.0411f872.js",
    "imports": [
      "_swiper-vue.1e1b85e5.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.7be6ce06.js",
      "_CtaSection.f61ee246.js",
      "_config.e2eaf067.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/[slug].vue"
  },
  "pages/tours/booking.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "booking.f4577b97.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js",
      "_Container.7be6ce06.js",
      "_Btn.vue.66239b17.js",
      "_vehicleForm.ebd1e30c.js",
      "_clsx.0839fdbe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking.vue"
  },
  "pages/tours/booking/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkout.aa2a9a68.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking/checkout.vue"
  },
  "pages/tours/booking/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.00aec991.js",
    "imports": [
      "_MTextField.vue.108e79d6.js",
      "_MGroup.vue.4bec4f2c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vehicleForm.ebd1e30c.js",
      "_swiper-vue.1e1b85e5.js",
      "_MSelect.vue.1934a26c.js",
      "_clsx.0839fdbe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking/index.vue"
  },
  "pages/tours/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.e2dda045.js",
    "imports": [
      "_Btn.vue.66239b17.js",
      "_Container.7be6ce06.js",
      "_MSelect.vue.1934a26c.js",
      "_MGroup.vue.4bec4f2c.js",
      "_Card.27c5ed69.js",
      "_swiper-vue.1e1b85e5.js",
      "_clsx.0839fdbe.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/index.vue"
  },
  "pages/user/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.d7c26bb5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/index.vue"
  },
  "pages/vehicles.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vehicles.bc70e324.js",
    "imports": [
      "_Btn.vue.66239b17.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.7be6ce06.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js",
      "_vehicleForm.ebd1e30c.js",
      "_clsx.0839fdbe.js",
      "_config.e2eaf067.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles.vue"
  },
  "pages/vehicles/booking.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "booking.6700bb01.js",
    "imports": [
      "_MTextField.vue.108e79d6.js",
      "_MGroup.vue.4bec4f2c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vehicleForm.ebd1e30c.js",
      "_swiper-vue.1e1b85e5.js",
      "_SelectedCard.vue.085c31f3.js",
      "_clsx.0839fdbe.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e2eaf067.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/booking.vue"
  },
  "pages/vehicles/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkout.6b67fbc6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js",
      "_SelectedCard.vue.085c31f3.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.e2eaf067.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/checkout.vue"
  },
  "pages/vehicles/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.4540eaec.js",
    "imports": [
      "_MSelect.vue.1934a26c.js",
      "_MGroup.vue.4bec4f2c.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.66239b17.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.1e1b85e5.js",
      "_clsx.0839fdbe.js",
      "_config.e2eaf067.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/index.vue"
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.d33d3671.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
