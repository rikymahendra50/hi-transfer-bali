const client_manifest = {
  "_Btn.vue.70015b1e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Btn.vue.70015b1e.js",
    "imports": [
      "_clsx.0839fdbe.js",
      "_swiper-vue.2b8caf10.js"
    ]
  },
  "_Card.9fb06fe1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Card.9fb06fe1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ]
  },
  "_Change.vue.ee830d5d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Change.vue.ee830d5d.js",
    "imports": [
      "_useSchema.5921adcd.js",
      "_MTextField.vue.e14131a0.js",
      "_MGroup.vue.f6af789b.js",
      "_Btn.vue.70015b1e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ]
  },
  "_Container.e7aa4e31.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Container.e7aa4e31.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ]
  },
  "_CtaSection.3d338844.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "CtaSection.3d338844.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ]
  },
  "_MGroup.vue.f6af789b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MGroup.vue.f6af789b.js",
    "imports": [
      "_swiper-vue.2b8caf10.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_clsx.0839fdbe.js"
    ]
  },
  "_MSelect.vue.6e5b66f4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MSelect.vue.6e5b66f4.js",
    "imports": [
      "_swiper-vue.2b8caf10.js",
      "_clsx.0839fdbe.js",
      "_MGroup.vue.f6af789b.js"
    ]
  },
  "_MTextField.vue.e14131a0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MTextField.vue.e14131a0.js",
    "imports": [
      "_swiper-vue.2b8caf10.js",
      "_clsx.0839fdbe.js",
      "_MGroup.vue.f6af789b.js"
    ]
  },
  "_SelectedCard.vue.a4a8386c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "SelectedCard.vue.a4a8386c.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ]
  },
  "_client-only.22d3c37a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client-only.22d3c37a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ]
  },
  "_clsx.0839fdbe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "clsx.0839fdbe.js"
  },
  "_config.83afc88b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.83afc88b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ]
  },
  "_hi-transfer-logo.e21ff7fe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "hi-transfer-logo.e21ff7fe.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.86a84ec9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.86a84ec9.js",
    "imports": [
      "_swiper-vue.2b8caf10.js"
    ]
  },
  "_swiper-vue.2b8caf10.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.d33d3671.css"
    ],
    "file": "swiper-vue.2b8caf10.js"
  },
  "swiper-vue.d33d3671.css": {
    "file": "swiper-vue.d33d3671.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_usePasswordHelper.9360086c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "usePasswordHelper.9360086c.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ]
  },
  "_useSchema.5921adcd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useSchema.5921adcd.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.2b8caf10.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate-zod.esm.98e8bb52.js"
    ]
  },
  "_vee-validate-zod.esm.98e8bb52.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vee-validate-zod.esm.98e8bb52.js"
  },
  "_vehicleForm.59febb9c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vehicleForm.59febb9c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ]
  },
  "assets/fonts/ClashGrotesk-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Bold.c4ea1fe3.ttf",
    "src": "assets/fonts/ClashGrotesk-Bold.ttf"
  },
  "assets/fonts/ClashGrotesk-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Bold.b1b9970d.woff",
    "src": "assets/fonts/ClashGrotesk-Bold.woff"
  },
  "assets/fonts/ClashGrotesk-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Bold.602a56af.woff2",
    "src": "assets/fonts/ClashGrotesk-Bold.woff2"
  },
  "assets/fonts/ClashGrotesk-Extralight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Extralight.6417ca23.ttf",
    "src": "assets/fonts/ClashGrotesk-Extralight.ttf"
  },
  "assets/fonts/ClashGrotesk-Extralight.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Extralight.c9c2a3a9.woff",
    "src": "assets/fonts/ClashGrotesk-Extralight.woff"
  },
  "assets/fonts/ClashGrotesk-Extralight.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Extralight.fe206472.woff2",
    "src": "assets/fonts/ClashGrotesk-Extralight.woff2"
  },
  "assets/fonts/ClashGrotesk-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Light.8e98f3c7.ttf",
    "src": "assets/fonts/ClashGrotesk-Light.ttf"
  },
  "assets/fonts/ClashGrotesk-Light.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Light.04e1d585.woff",
    "src": "assets/fonts/ClashGrotesk-Light.woff"
  },
  "assets/fonts/ClashGrotesk-Light.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Light.f0f7605c.woff2",
    "src": "assets/fonts/ClashGrotesk-Light.woff2"
  },
  "assets/fonts/ClashGrotesk-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Medium.717fd45f.ttf",
    "src": "assets/fonts/ClashGrotesk-Medium.ttf"
  },
  "assets/fonts/ClashGrotesk-Medium.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Medium.94bcd03c.woff",
    "src": "assets/fonts/ClashGrotesk-Medium.woff"
  },
  "assets/fonts/ClashGrotesk-Medium.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Medium.5c3815cf.woff2",
    "src": "assets/fonts/ClashGrotesk-Medium.woff2"
  },
  "assets/fonts/ClashGrotesk-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Regular.5c66c57f.ttf",
    "src": "assets/fonts/ClashGrotesk-Regular.ttf"
  },
  "assets/fonts/ClashGrotesk-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Regular.1c248756.woff",
    "src": "assets/fonts/ClashGrotesk-Regular.woff"
  },
  "assets/fonts/ClashGrotesk-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Regular.03ad7ecf.woff2",
    "src": "assets/fonts/ClashGrotesk-Regular.woff2"
  },
  "assets/fonts/ClashGrotesk-Semibold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Semibold.bdc47ea3.ttf",
    "src": "assets/fonts/ClashGrotesk-Semibold.ttf"
  },
  "assets/fonts/ClashGrotesk-Semibold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Semibold.48fdb6da.woff",
    "src": "assets/fonts/ClashGrotesk-Semibold.woff"
  },
  "assets/fonts/ClashGrotesk-Semibold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Semibold.befc1942.woff2",
    "src": "assets/fonts/ClashGrotesk-Semibold.woff2"
  },
  "assets/fonts/ClashGrotesk-Variable.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "ClashGrotesk-Variable.5887a1df.ttf",
    "src": "assets/fonts/ClashGrotesk-Variable.ttf"
  },
  "assets/fonts/ClashGrotesk-Variable.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "ClashGrotesk-Variable.de7ab3f6.woff",
    "src": "assets/fonts/ClashGrotesk-Variable.woff"
  },
  "assets/fonts/ClashGrotesk-Variable.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "ClashGrotesk-Variable.3c56fcff.woff2",
    "src": "assets/fonts/ClashGrotesk-Variable.woff2"
  },
  "assets/fonts/GeneralSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Bold.1c435b33.ttf",
    "src": "assets/fonts/GeneralSans-Bold.ttf"
  },
  "assets/fonts/GeneralSans-Bold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Bold.4c2b7f63.woff",
    "src": "assets/fonts/GeneralSans-Bold.woff"
  },
  "assets/fonts/GeneralSans-Bold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Bold.a29eab9b.woff2",
    "src": "assets/fonts/GeneralSans-Bold.woff2"
  },
  "assets/fonts/GeneralSans-BoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-BoldItalic.2297ae79.ttf",
    "src": "assets/fonts/GeneralSans-BoldItalic.ttf"
  },
  "assets/fonts/GeneralSans-BoldItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-BoldItalic.0599ec69.woff",
    "src": "assets/fonts/GeneralSans-BoldItalic.woff"
  },
  "assets/fonts/GeneralSans-BoldItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-BoldItalic.97483640.woff2",
    "src": "assets/fonts/GeneralSans-BoldItalic.woff2"
  },
  "assets/fonts/GeneralSans-Extralight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Extralight.4cb07dad.ttf",
    "src": "assets/fonts/GeneralSans-Extralight.ttf"
  },
  "assets/fonts/GeneralSans-Extralight.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Extralight.6a52bdce.woff",
    "src": "assets/fonts/GeneralSans-Extralight.woff"
  },
  "assets/fonts/GeneralSans-Extralight.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Extralight.3e6ee7e5.woff2",
    "src": "assets/fonts/GeneralSans-Extralight.woff2"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-ExtralightItalic.9b80b399.ttf",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.ttf"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-ExtralightItalic.acc7311a.woff",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.woff"
  },
  "assets/fonts/GeneralSans-ExtralightItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-ExtralightItalic.83bbc211.woff2",
    "src": "assets/fonts/GeneralSans-ExtralightItalic.woff2"
  },
  "assets/fonts/GeneralSans-Italic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Italic.ea19866f.ttf",
    "src": "assets/fonts/GeneralSans-Italic.ttf"
  },
  "assets/fonts/GeneralSans-Italic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Italic.f9e5a73e.woff",
    "src": "assets/fonts/GeneralSans-Italic.woff"
  },
  "assets/fonts/GeneralSans-Italic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Italic.1c91e1d3.woff2",
    "src": "assets/fonts/GeneralSans-Italic.woff2"
  },
  "assets/fonts/GeneralSans-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Light.86a255b5.ttf",
    "src": "assets/fonts/GeneralSans-Light.ttf"
  },
  "assets/fonts/GeneralSans-Light.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Light.09f0f0fe.woff",
    "src": "assets/fonts/GeneralSans-Light.woff"
  },
  "assets/fonts/GeneralSans-Light.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Light.ac0b8f29.woff2",
    "src": "assets/fonts/GeneralSans-Light.woff2"
  },
  "assets/fonts/GeneralSans-LightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-LightItalic.eb313a89.ttf",
    "src": "assets/fonts/GeneralSans-LightItalic.ttf"
  },
  "assets/fonts/GeneralSans-LightItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-LightItalic.639de7d9.woff",
    "src": "assets/fonts/GeneralSans-LightItalic.woff"
  },
  "assets/fonts/GeneralSans-LightItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-LightItalic.7787625d.woff2",
    "src": "assets/fonts/GeneralSans-LightItalic.woff2"
  },
  "assets/fonts/GeneralSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Medium.e85572fe.ttf",
    "src": "assets/fonts/GeneralSans-Medium.ttf"
  },
  "assets/fonts/GeneralSans-Medium.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Medium.f5beb161.woff",
    "src": "assets/fonts/GeneralSans-Medium.woff"
  },
  "assets/fonts/GeneralSans-Medium.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Medium.c30377df.woff2",
    "src": "assets/fonts/GeneralSans-Medium.woff2"
  },
  "assets/fonts/GeneralSans-MediumItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-MediumItalic.3b4e2f45.ttf",
    "src": "assets/fonts/GeneralSans-MediumItalic.ttf"
  },
  "assets/fonts/GeneralSans-MediumItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-MediumItalic.d02080e7.woff",
    "src": "assets/fonts/GeneralSans-MediumItalic.woff"
  },
  "assets/fonts/GeneralSans-MediumItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-MediumItalic.ffe0560d.woff2",
    "src": "assets/fonts/GeneralSans-MediumItalic.woff2"
  },
  "assets/fonts/GeneralSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Regular.0723d125.ttf",
    "src": "assets/fonts/GeneralSans-Regular.ttf"
  },
  "assets/fonts/GeneralSans-Regular.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Regular.52af118f.woff",
    "src": "assets/fonts/GeneralSans-Regular.woff"
  },
  "assets/fonts/GeneralSans-Regular.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Regular.3ec2be77.woff2",
    "src": "assets/fonts/GeneralSans-Regular.woff2"
  },
  "assets/fonts/GeneralSans-Semibold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Semibold.307d27c4.ttf",
    "src": "assets/fonts/GeneralSans-Semibold.ttf"
  },
  "assets/fonts/GeneralSans-Semibold.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Semibold.eec4ab4c.woff",
    "src": "assets/fonts/GeneralSans-Semibold.woff"
  },
  "assets/fonts/GeneralSans-Semibold.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Semibold.94a2a0e1.woff2",
    "src": "assets/fonts/GeneralSans-Semibold.woff2"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-SemiboldItalic.d3b62cb5.ttf",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.ttf"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-SemiboldItalic.cd1fca15.woff",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.woff"
  },
  "assets/fonts/GeneralSans-SemiboldItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-SemiboldItalic.98c7276f.woff2",
    "src": "assets/fonts/GeneralSans-SemiboldItalic.woff2"
  },
  "assets/fonts/GeneralSans-Variable.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-Variable.4b2539d9.ttf",
    "src": "assets/fonts/GeneralSans-Variable.ttf"
  },
  "assets/fonts/GeneralSans-Variable.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-Variable.473d4f5e.woff",
    "src": "assets/fonts/GeneralSans-Variable.woff"
  },
  "assets/fonts/GeneralSans-Variable.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-Variable.49d3fbd2.woff2",
    "src": "assets/fonts/GeneralSans-Variable.woff2"
  },
  "assets/fonts/GeneralSans-VariableItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "GeneralSans-VariableItalic.4aa0c20d.ttf",
    "src": "assets/fonts/GeneralSans-VariableItalic.ttf"
  },
  "assets/fonts/GeneralSans-VariableItalic.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "GeneralSans-VariableItalic.c0b7f35e.woff",
    "src": "assets/fonts/GeneralSans-VariableItalic.woff"
  },
  "assets/fonts/GeneralSans-VariableItalic.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "GeneralSans-VariableItalic.71537245.woff2",
    "src": "assets/fonts/GeneralSans-VariableItalic.woff2"
  },
  "assets/fonts/PlusJakartaSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Bold.3e08701b.ttf",
    "src": "assets/fonts/PlusJakartaSans-Bold.ttf"
  },
  "assets/fonts/PlusJakartaSans-BoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-BoldItalic.4486ec3d.ttf",
    "src": "assets/fonts/PlusJakartaSans-BoldItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraBold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraBold.644fda57.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraBold.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraBoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraBoldItalic.d51b806e.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraBoldItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraLight.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraLight.9afaedac.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraLight.ttf"
  },
  "assets/fonts/PlusJakartaSans-ExtraLightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-ExtraLightItalic.b7523f1e.ttf",
    "src": "assets/fonts/PlusJakartaSans-ExtraLightItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Italic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Italic.b15bc27e.ttf",
    "src": "assets/fonts/PlusJakartaSans-Italic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Light.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Light.26e26359.ttf",
    "src": "assets/fonts/PlusJakartaSans-Light.ttf"
  },
  "assets/fonts/PlusJakartaSans-LightItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-LightItalic.22823a55.ttf",
    "src": "assets/fonts/PlusJakartaSans-LightItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Medium.d6854d4b.ttf",
    "src": "assets/fonts/PlusJakartaSans-Medium.ttf"
  },
  "assets/fonts/PlusJakartaSans-MediumItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-MediumItalic.67cb7ae5.ttf",
    "src": "assets/fonts/PlusJakartaSans-MediumItalic.ttf"
  },
  "assets/fonts/PlusJakartaSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-Regular.f7e7cebd.ttf",
    "src": "assets/fonts/PlusJakartaSans-Regular.ttf"
  },
  "assets/fonts/PlusJakartaSans-SemiBold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-SemiBold.d32adf41.ttf",
    "src": "assets/fonts/PlusJakartaSans-SemiBold.ttf"
  },
  "assets/fonts/PlusJakartaSans-SemiBoldItalic.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "PlusJakartaSans-SemiBoldItalic.48a17bbd.ttf",
    "src": "assets/fonts/PlusJakartaSans-SemiBoldItalic.ttf"
  },
  "layouts/admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.0e2ef9b2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.2b8caf10.js",
      "_hi-transfer-logo.e21ff7fe.js",
      "_index.86a84ec9.js",
      "_config.83afc88b.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/admin.vue"
  },
  "layouts/auth.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth.0482c6a6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_client-only.22d3c37a.js",
      "_hi-transfer-logo.e21ff7fe.js",
      "_swiper-vue.2b8caf10.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/auth.vue"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.8882e208.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_client-only.22d3c37a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.e7aa4e31.js",
      "_swiper-vue.2b8caf10.js",
      "_hi-transfer-logo.e21ff7fe.js",
      "_config.83afc88b.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "layouts/empty.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "empty.79095713.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/empty.vue"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Icon.6f5d80f8.css",
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.css"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Icon.c65ed671.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_config.83afc88b.js",
      "_swiper-vue.2b8caf10.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.vue"
  },
  "Icon.6f5d80f8.css": {
    "file": "Icon.6f5d80f8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "IconCSS.fe0874d9.css",
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.css"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "IconCSS.45a5325b.js",
    "imports": [
      "_swiper-vue.2b8caf10.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_config.83afc88b.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.vue"
  },
  "IconCSS.fe0874d9.css": {
    "file": "IconCSS.fe0874d9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.2cc35f7b.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.2cc35f7b.css"
    ],
    "dynamicImports": [
      "layouts/admin.vue",
      "layouts/auth.vue",
      "layouts/default.vue",
      "layouts/empty.vue"
    ],
    "file": "entry.7d3f68b3.js",
    "imports": [
      "_swiper-vue.2b8caf10.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.2cc35f7b.css": {
    "file": "entry.2cc35f7b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/email-verification/[token].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_token_.1756c247.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/email-verification/[token].vue"
  },
  "pages/admin/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.24938ce3.js",
    "imports": [
      "_Change.vue.ee830d5d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.86a84ec9.js",
      "_swiper-vue.2b8caf10.js",
      "_useSchema.5921adcd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.83afc88b.js",
      "_vee-validate-zod.esm.98e8bb52.js",
      "_MTextField.vue.e14131a0.js",
      "_clsx.0839fdbe.js",
      "_MGroup.vue.f6af789b.js",
      "_Btn.vue.70015b1e.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/forgot-password.vue"
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.5bfe4eb8.js",
    "imports": [
      "_swiper-vue.2b8caf10.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/index.vue"
  },
  "pages/admin/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.54c78297.js",
    "imports": [
      "_useSchema.5921adcd.js",
      "_MTextField.vue.e14131a0.js",
      "_MGroup.vue.f6af789b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_Btn.vue.70015b1e.js",
      "_swiper-vue.2b8caf10.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.83afc88b.js",
      "_vee-validate-zod.esm.98e8bb52.js",
      "_clsx.0839fdbe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/sign-in.vue"
  },
  "pages/auth-redirect.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "auth-redirect.99303598.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/auth-redirect.vue"
  },
  "pages/daisy-example.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "daisy-example.369180e8.js",
    "imports": [
      "_MTextField.vue.e14131a0.js",
      "_MGroup.vue.f6af789b.js",
      "_swiper-vue.2b8caf10.js",
      "_clsx.0839fdbe.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_MSelect.vue.6e5b66f4.js",
      "_Btn.vue.70015b1e.js",
      "_Container.e7aa4e31.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate-zod.esm.98e8bb52.js",
      "_config.83afc88b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/daisy-example.vue"
  },
  "pages/email-verification/[token].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_token_.d9504772.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/email-verification/[token].vue"
  },
  "pages/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.599585e3.js",
    "imports": [
      "_Change.vue.ee830d5d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.86a84ec9.js",
      "_swiper-vue.2b8caf10.js",
      "_useSchema.5921adcd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.83afc88b.js",
      "_vee-validate-zod.esm.98e8bb52.js",
      "_MTextField.vue.e14131a0.js",
      "_clsx.0839fdbe.js",
      "_MGroup.vue.f6af789b.js",
      "_Btn.vue.70015b1e.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/forgot-password.vue"
  },
  "pages/gsap.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "gsap.a974d076.js",
    "imports": [
      "_swiper-vue.2b8caf10.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/gsap.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.adf9eedf.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.fc64c8b6.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_clsx.0839fdbe.js",
      "_swiper-vue.2b8caf10.js",
      "_MTextField.vue.e14131a0.js",
      "_MGroup.vue.f6af789b.js",
      "_MSelect.vue.6e5b66f4.js",
      "_Btn.vue.70015b1e.js",
      "_index.86a84ec9.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_Card.9fb06fe1.js",
      "_Container.e7aa4e31.js",
      "_CtaSection.3d338844.js",
      "_config.83afc88b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.adf9eedf.css": {
    "file": "index.adf9eedf.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.1549f6e7.js",
    "imports": [
      "_useSchema.5921adcd.js",
      "_MTextField.vue.e14131a0.js",
      "_MGroup.vue.f6af789b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.70015b1e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_usePasswordHelper.9360086c.js",
      "_swiper-vue.2b8caf10.js",
      "_vee-validate-zod.esm.98e8bb52.js",
      "_clsx.0839fdbe.js",
      "_config.83afc88b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign-in.vue"
  },
  "pages/sign-up.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-up.29f3e05c.js",
    "imports": [
      "_useSchema.5921adcd.js",
      "_MTextField.vue.e14131a0.js",
      "_MGroup.vue.f6af789b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.70015b1e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_usePasswordHelper.9360086c.js",
      "_swiper-vue.2b8caf10.js",
      "_vee-validate-zod.esm.98e8bb52.js",
      "_clsx.0839fdbe.js",
      "_config.83afc88b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/sign-up.vue"
  },
  "pages/tours/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.2706432b.js",
    "imports": [
      "_swiper-vue.2b8caf10.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.e7aa4e31.js",
      "_CtaSection.3d338844.js",
      "_config.83afc88b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/[slug].vue"
  },
  "pages/tours/booking.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "booking.2373d282.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js",
      "_Container.e7aa4e31.js",
      "_Btn.vue.70015b1e.js",
      "_vehicleForm.59febb9c.js",
      "_clsx.0839fdbe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking.vue"
  },
  "pages/tours/booking/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkout.f30b25c8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking/checkout.vue"
  },
  "pages/tours/booking/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.41590a83.js",
    "imports": [
      "_MTextField.vue.e14131a0.js",
      "_MGroup.vue.f6af789b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vehicleForm.59febb9c.js",
      "_swiper-vue.2b8caf10.js",
      "_MSelect.vue.6e5b66f4.js",
      "_clsx.0839fdbe.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/booking/index.vue"
  },
  "pages/tours/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.f6ebf134.js",
    "imports": [
      "_Btn.vue.70015b1e.js",
      "_Container.e7aa4e31.js",
      "_MSelect.vue.6e5b66f4.js",
      "_MGroup.vue.f6af789b.js",
      "_Card.9fb06fe1.js",
      "_swiper-vue.2b8caf10.js",
      "_clsx.0839fdbe.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tours/index.vue"
  },
  "pages/user/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.1e729b52.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/index.vue"
  },
  "pages/vehicles.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vehicles.f2e6718d.js",
    "imports": [
      "_Btn.vue.70015b1e.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Container.e7aa4e31.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js",
      "_vehicleForm.59febb9c.js",
      "_clsx.0839fdbe.js",
      "_config.83afc88b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles.vue"
  },
  "pages/vehicles/booking.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "booking.42484761.js",
    "imports": [
      "_MTextField.vue.e14131a0.js",
      "_MGroup.vue.f6af789b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vehicleForm.59febb9c.js",
      "_swiper-vue.2b8caf10.js",
      "_SelectedCard.vue.a4a8386c.js",
      "_clsx.0839fdbe.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.83afc88b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/booking.vue"
  },
  "pages/vehicles/checkout.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkout.ef42b388.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js",
      "_SelectedCard.vue.a4a8386c.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.83afc88b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/checkout.vue"
  },
  "pages/vehicles/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.12151e61.js",
    "imports": [
      "_MSelect.vue.6e5b66f4.js",
      "_MGroup.vue.f6af789b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Btn.vue.70015b1e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.2b8caf10.js",
      "_clsx.0839fdbe.js",
      "_config.83afc88b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/vehicles/index.vue"
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.d33d3671.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
